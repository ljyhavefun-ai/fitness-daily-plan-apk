// 每日健身计划：今日计划 / 训练中逐组记录+感受+Muse 实时调整 / 总结与 Drive 上传 / 历史 / 趋势。
import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { SafeAreaTopScrim } from "@hatch/space-sdk/client";
import {
Bar,
BarChart,
Line,
LineChart,
ResponsiveContainer,
Tooltip,
XAxis,
YAxis,
} from "recharts";
import { api, type ApiResponse } from "./api";
import { actionFields } from "@hatch/space-sdk/fields" with { type: "macro" };
import type { Actions } from "../../server/src/actions";

// 表单输入的限制（maxLength/min/max 等）一律取自服务端动作的请求 schema
const FIELDS = actionFields<typeof Actions>();

type DayData = ApiResponse<typeof api, "getDay">;
type SetLog = DayData["sets"][number];
type SessionT = NonNullable<DayData["session"]>;
type PlanT = NonNullable<DayData["plan"]>;
type ExerciseT = PlanT["exercises"][number];
type StatsT = ApiResponse<typeof api, "getStats">;

const WEEKDAYS = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];

function todayStr(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai" }).format(new Date());
}

function shiftDate(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00`);
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

function dateLabel(dateStr: string): string {
  const d = new Date(`${dateStr}T00:00:00`);
  return `${d.getMonth() + 1}月${d.getDate()}日 ${WEEKDAYS[d.getDay()] ?? ""}`;
}

function fmtW(w: number | null): string {
  return w == null ? "未设" : `${w}kg`;
}

// 一组目标的展示：重量未定且次数不是纯数字（如「20分钟」）时只显示次数本身
function fmtPair(w: number | null, reps: string): string {
  if (w == null && !/^\d/.test(reps.trim())) return reps;
  return `${fmtW(w)} × ${reps}`;
}

// 首页紧凑行第二行（13px 次要正文）：每组「重量 × 次数」以 · 行内分隔，
// 未设重量写「重量未设」，时长型次数（如「20分钟」）只写次数本身；
// 目标组间休息全组一致时在行尾写一次，不一致时逐组带上。
function exerciseSummary(ex: ExerciseT): string {
  if (ex.sets.length === 0) return "暂无组";
  const seg = (s: ExerciseT["sets"][number]): string => {
    // 时长型次数（含「分钟」等单位字，如「20分钟」）只写次数本身，不标重量未设；
    // 纯数字或数字区间（如「10-12」）才是需要重量的次数。
    if (s.weightKg == null && /[^\d\s.\-–~]/.test(s.reps.trim())) return s.reps;
    if (s.weightKg == null) return `重量未设 × ${s.reps}`;
    return `${s.weightKg}kg × ${s.reps}`;
  };
  // 热身组排在最前、逐组标「热身」；休息标注按工作组口径
  const warmups = ex.sets.filter((s) => s.warmup);
  const works = ex.sets.filter((s) => !s.warmup);
  const rests = works.map((s) => s.restSeconds);
  const uniform = rests.length > 0 && rests.every((r) => r === rests[0]);
  const workParts = works.map((s) => (uniform ? seg(s) : `${seg(s)} · 休息 ${s.restSeconds}s`));
  const parts = [...warmups.map((s) => `热身 ${seg(s)}`), ...workParts];
  if (uniform) return [...parts, `休息 ${rests[0] ?? 0}s`].join(" · ");
  return parts.join(" · ");
}

function fmtClock(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function repsNumberOf(reps: string): number {
  const n = Number.parseInt(reps, 10);
  return Number.isFinite(n) ? n : 0;
}

/* ---------------- 震动反馈 ---------------- */

// 关键交互的震动反馈；不支持的设备（如 iOS Safari）静默跳过。
function buzz(pattern: number | number[]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    /* ignore */
  }
}

/* ---------------- 屏幕常亮锁（Wake Lock）与提示音 ---------------- */

type WakeLockSentinelLike = { release: () => Promise<void> };

// 申请屏幕常亮：训练中保持页面前台不休眠，计时器才不会被系统挂起。
// 不支持的浏览器静默返回 null；页面切后台后锁会被系统自动释放，
// 切回前台时由调用方重新申请。
async function requestWakeLock(): Promise<WakeLockSentinelLike | null> {
  try {
    const nav = navigator as Navigator & {
      wakeLock?: { request: (type: "screen") => Promise<WakeLockSentinelLike> };
    };
    if (!nav.wakeLock) return null;
    return await nav.wakeLock.request("screen");
  } catch {
    return null;
  }
}

// 休息到时的前台提示音（Web Audio 三声短鸣）：只在页面前台发声，
// 切后台时浏览器可能暂停音频，靠震动与系统闹钟兜底。
function beep() {
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    const ac = new Ctor();
    [0, 0.35, 0.7].forEach((offset) => {
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.frequency.value = 880;
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(ac.destination);
      const t = ac.currentTime + offset;
      osc.start(t);
      osc.stop(t + 0.18);
    });
    window.setTimeout(() => void ac.close().catch(() => undefined), 1600);
  } catch {
    /* 音频不可用时静默 */
  }
}

/* ---------------- 动效助手（02 §2：WAAPI 单实例驱动） ---------------- */

const RM =
  typeof window !== "undefined" &&
  typeof window.matchMedia === "function" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// 单实例播放：先 cancel 上一个动画再 animate，不叠 class 队列。
// reduced-motion 时直接跳过（保留结果、去掉过程）。
function playAnim(
  el: HTMLElement | null | undefined,
  keyframes: Keyframe[] | PropertyIndexedKeyframes,
  options: KeyframeAnimationOptions,
) {
  if (!el || RM) return;
  const holder = el as HTMLElement & { _anim?: Animation };
  try {
    holder._anim?.cancel();
    holder._anim = el.animate(keyframes, options);
  } catch {
    /* 动画不可用时静默 */
  }
}

function animPress(el: HTMLElement | null | undefined) {
  playAnim(
    el,
    [
      { transform: "scale(1)", filter: "brightness(1)" },
      { transform: "scale(0.96)", filter: "brightness(1.06)", offset: 0.4 },
      { transform: "scale(1)", filter: "brightness(1)" },
    ],
    { duration: 220, easing: "cubic-bezier(0.34,1.56,0.64,1)" },
  );
}

function animShake(el: HTMLElement | null | undefined) {
  if (!el) return;
  if (RM) return;
  playAnim(
    el,
    [
      { transform: "translateX(0)" },
      { transform: "translateX(-6px)" },
      { transform: "translateX(6px)" },
      { transform: "translateX(-3px)" },
      { transform: "translateX(0)" },
    ],
    { duration: 280, easing: "cubic-bezier(0.36,0.07,0.19,0.97)" },
  );
}

// ⑤ 步进滑动换数：旧值上滑淡出、新值滑入（方向随步进正负）
function animStepSlide(el: HTMLElement | null | undefined, dir: 1 | -1) {
  playAnim(
    el,
    [
      { transform: `translateY(${dir > 0 ? 100 : -100}%)`, opacity: 0 },
      { transform: "translateY(0)", opacity: 1 },
    ],
    { duration: 140, easing: "cubic-bezier(0.34,1.56,0.64,1)" },
  );
}

// ③ 数字弹跳
function animNumPop(el: HTMLElement | null | undefined) {
  playAnim(
    el,
    [{ transform: "scale(1)" }, { transform: "scale(1.06)" }, { transform: "scale(1)" }],
    { duration: 160, easing: "cubic-bezier(0.34,1.56,0.64,1)" },
  );
}

/* ---------------- 骨架屏 ⑰（灰条无字，不填任何数字） ---------------- */

function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div aria-label="加载中" className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: i === 0 ? 96 : 56 }} />
      ))}
    </div>
  );
}

/* ---------------- 统计数字滚动计数 ⑯（末帧强写真值） ---------------- */

function CountUp({ value, suffix = "" }: { value: number; suffix?: string }) {
  const [display, setDisplay] = useState(RM ? value : 0);
  const ref = useRef<HTMLSpanElement | null>(null);
  useEffect(() => {
    if (RM) {
      setDisplay(value);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = () => {
      // 用 performance.now() 取时（rAF 回调时间戳在个别浏览器与之基准不一致，会算出负进度）
      const k = Math.min(1, Math.max(0, (performance.now() - t0) / 800));
      const eased = 1 - Math.pow(1 - k, 3);
      setDisplay(Math.max(0, Math.min(value, Math.round(value * eased))));
      if (k < 1) raf = window.requestAnimationFrame(tick);
      else setDisplay(value);
    };
    raf = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(raf);
  }, [value]);
  return (
    <span ref={ref} className="num">
      {display.toLocaleString()}
      {suffix}
    </span>
  );
}

/* ---------------- 底部 SHEET 抽屉（证据/确认共用） ---------------- */

function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
      <button
        type="button"
        aria-label="关闭抽屉"
        className="absolute inset-0 h-full w-full cursor-default"
        style={{ background: "var(--scrim)" }}
        onClick={onClose}
      />
      <div
        className="anim-sheet-in absolute inset-x-0 bottom-0 max-h-[86dvh] overflow-y-auto pb-safe"
        style={{
          background: "var(--sheet-bg)",
          backdropFilter: "var(--sheet-blur)",
          WebkitBackdropFilter: "var(--sheet-blur)",
          borderTop: "var(--sheet-border)",
          boxShadow: "var(--sheet-shadow)",
          borderRadius: "20px 20px 0 0",
          // better-ui：抽屉内滚动到头不再链到背后的页面
          overscrollBehavior: "contain",
        }}
      >
        <div className="mx-auto w-full max-w-2xl px-4 pb-6 pt-3">
          <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-[rgba(242,247,243,0.25)]" aria-hidden="true" />
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-base font-bold">{title}</h3>
            <button
              type="button"
              onClick={onClose}
              className="glass-btn min-h-11 shrink-0 px-4 py-2 text-sm font-medium"
            >
              关闭
            </button>
          </div>
          <div className="mt-3">{children}</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Toast ⑭（上浮，2 秒级停留，不排队） ---------------- */

function Toast({ text, onClose }: { text: string; onClose: () => void }) {
  useEffect(() => {
    const t = window.setTimeout(onClose, 2600);
    return () => window.clearTimeout(t);
  }, [onClose]);
  return (
    <div
      role="status"
      className="anim-toast-in fixed inset-x-4 bottom-24 z-40 mx-auto max-w-md px-4 py-3 text-sm font-medium"
      style={{
        // 纯提示条、无任何可点元素：不拦截触摸，否则它盖住的区域在
        // 显示的 2.6 秒内会吞掉起滑手势，表现为「滑动没反应」。
        pointerEvents: "none",
        background: "var(--sheet-bg)",
        backdropFilter: "var(--sheet-blur)",
        WebkitBackdropFilter: "var(--sheet-blur)",
        border: "var(--sheet-border)",
        borderRadius: 12,
      }}
    >
      {text}
    </div>
  );
}

function setVolume(s: SetLog): number {
  if (!s.done) return 0;
  const w = s.actualWeightKg ?? s.targetWeightKg;
  if (w == null) return 0;
  const reps = Number.parseInt(s.actualReps ?? s.targetReps, 10);
  return Number.isFinite(reps) ? w * reps : 0;
}

// 一组有没有留下任何感受/反馈：没有就是「未填感受」——一种正常状态，
// 必须明确显示出来（而不是空白），且不影响流程与统计分母。
function hasFeedback(s: SetLog): boolean {
  return (
    s.rir != null ||
    !!s.deform ||
    !!s.joint ||
    s.sorenessOver72 ||
    s.pump != null ||
    s.fatigue != null ||
    !!s.note ||
    !!s.aiSuggestion ||
    !!s.difficulty
  );
}

// 一组的裁决被中断：反馈已经保存、却没有裁决结果。判据是服务端落库的
// 在途状态（running=请求断了标记还留着 / failed=服务端明确失败），以及
// 本次修复前留下的旧状态（状态为空、反馈已存、建议为空）。这类组在组
// 列表标「裁决被中断」，表单里给「重新裁决」续跑入口，反馈不用重填。
function adjudicationInterrupted(s: SetLog): boolean {
  if (s.aiSuggestion || !s.done) return false;
  if (s.adjudicationStatus === "running" || s.adjudicationStatus === "failed") return true;
  return (
    s.adjudicationStatus == null &&
    s.proposalStatus == null &&
    (s.rir != null || !!s.deform || !!s.joint || !!s.note || s.pump != null)
  );
}

// 待确认建议是否已经失效：它要改的同动作后续组如果都已经练完或跳过，
// 再接受也没有可改的对象——展示为「未处理 · 已失效」，不可再直接接受，
// 但不改服务端状态（不把历史 pending 自动改写成 dismissed）。
function pendingExpired(s: SetLog, sets: SetLog[]): boolean {
  if (s.proposalStatus !== "pending") return false;
  const later = sets.filter((x) => x.exerciseIdx === s.exerciseIdx && x.setIdx > s.setIdx);
  if (later.length === 0) return true;
  return later.every((x) => x.done || x.skipped);
}

function groupSets(sets: SetLog[]): { name: string; note: string; items: SetLog[] }[] {
  const groups: { name: string; note: string; items: SetLog[] }[] = [];
  for (const s of sets) {
    const g = groups[s.exerciseIdx];
    if (g) g.items.push(s);
    else groups[s.exerciseIdx] = { name: s.exerciseName, note: "", items: [s] };
  }
  return groups.filter(Boolean);
}

/* ---------------- Drive 上传状态与按钮 ---------------- */

function DriveButton({ session }: { session: SessionT }) {
  const queryClient = useQueryClient();
  const upload = useMutation({
    mutationFn: () => api.uploadToDrive({ sessionId: session.id }),
    // 失败已由组件内 isError 文案就地提示，onError 标记已处理，避免底部通知重复
    onError: () => {},
    onSuccess: () => {
      void queryClient.invalidateQueries();
    },
  });

  // 上传是异步任务（结果由 recordDriveUpload 回写）：pending 时每 4 秒轮询一次，
  // 最多 7 轮（28 秒）；第 30 秒起提示「可先离开」，不判失败（02 §1.4）。
  const isPending = session.driveStatus === "pending";
  const [pollsLeft, setPollsLeft] = useState(7);
  const [pendingSince, setPendingSince] = useState<number | null>(null);
  const [, setTick] = useState(0);
  useEffect(() => {
    if (!isPending) {
      setPollsLeft(7);
      setPendingSince(null);
      return;
    }
    setPendingSince((prev) => prev ?? Date.now());
    if (pollsLeft <= 0) return;
    const t = window.setTimeout(() => {
      void queryClient.invalidateQueries();
      setPollsLeft((n) => n - 1);
      setTick((n) => n + 1);
    }, 4000);
    return () => window.clearTimeout(t);
  }, [isPending, pollsLeft, queryClient]);
  const pendingLong =
    isPending && pendingSince != null && Date.now() - pendingSince > 30000;

  const fileName = session.driveFileName ?? `健身日志-${session.date}.md`;

  // 上传结果是异步回写的：状态从「上传中」变为成功/失败时震动反馈。
  // 初次打开旧记录（非 pending 起步）不触发。
  const prevDriveStatus = useRef(session.driveStatus);
  useEffect(() => {
    const prev = prevDriveStatus.current;
    prevDriveStatus.current = session.driveStatus;
    if (prev !== "pending") return;
    if (session.driveStatus === "uploaded") {
      buzz([50, 60, 50]);
    } else if (session.driveStatus === "failed") {
      buzz([140, 70, 140]);
    }
  }, [session.driveStatus, session.id]);

  if (session.driveStatus === "uploaded") {
    return (
      <div aria-live="polite">
        <p className="flex items-center gap-2 rounded-lg bg-[var(--green)] px-4 py-3 text-sm font-semibold text-white">
          <span aria-hidden="true">✓</span> 训练日志已上传，已存入 Drive「健身日志」文件夹
        </p>
        <p className="num mt-2 text-sm text-[var(--dim)]">文件名：{fileName}</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {session.driveLink ? (
            <a
              href={session.driveLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[var(--ink)] px-4 py-2 text-sm font-semibold"
              style={{ color: "var(--bg)" }}
            >
              在 Google Drive 中打开
            </a>
          ) : null}
          <button
            type="button"
            disabled={upload.isPending}
            onClick={() => upload.mutate()}
            className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[var(--surface2)] px-4 py-2 text-sm font-medium disabled:opacity-50"
          >
            {upload.isPending ? "正在启动上传…" : "上传修正版"}
          </button>
        </div>
        <p className="mt-1 text-xs text-[var(--dim)]">
          更正过记录后点「上传修正版」：会新建一份带时间后缀的文件，Drive 里的旧版本不会被覆盖或删除。
        </p>
        {upload.data && !upload.data.started ? (
          <p className="mt-2 text-sm text-red-600">{upload.data.message}</p>
        ) : upload.data?.message ? (
          <p className="mt-2 text-sm text-[var(--dim)]">{upload.data.message}</p>
        ) : null}
        {upload.isError ? <p className="mt-2 text-sm text-red-600">启动上传失败，请检查网络后重试。</p> : null}
      </div>
    );
  }

  if (isPending) {
    return (
      <div aria-live="polite">
        <p className="rounded-lg bg-[var(--surface2)] px-4 py-3 text-sm">
          <span className="inline-block animate-spin font-semibold" aria-hidden="true">◌</span>
          <span className="font-semibold"> 正在上传至 Google Drive「健身日志」文件夹...</span>
          <span className="text-[var(--dim)]"> 摘要「{fileName}」，完成后这里会自动变成成功提示。</span>
          {pendingLong ? (
            <span className="mt-1 block font-medium text-[var(--text)]">
              仍在处理，可先离开此页面，之后在历史页查看结果。
            </span>
          ) : null}
        </p>
        <button
          type="button"
          onClick={() => void queryClient.invalidateQueries()}
          className="mt-2 min-h-10 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-medium"
        >
          立即刷新状态
        </button>
      </div>
    );
  }

  const failed = session.driveStatus === "failed";
  return (
    <div aria-live="polite">
      {failed ? (
        <p className="mb-2 rounded-lg bg-[rgba(227,106,106,0.10)] px-4 py-3 text-sm font-semibold text-[var(--st-stop)]  dark:text-red-300">
          上传失败：上次上传到 Drive 没有成功。训练记录本身已保存在应用内、没有丢失，点下面按钮重试上传。
        </p>
      ) : (
        <p className="mb-2 text-sm text-[var(--dim)]">
          训练日志尚未存档。本次训练记录已保存在应用内，上传 Drive 只是多一份存档，不影响训练完成。
        </p>
      )}
      <button
        type="button"
        disabled={upload.isPending}
        onClick={() => upload.mutate()}
        className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-[var(--ink)] px-4 py-2 text-sm font-semibold disabled:opacity-50"
        style={{ color: "var(--bg)" }}
      >
        {upload.isPending ? "正在启动上传…" : failed ? "重试上传到 Drive" : "上传到 Drive"}
      </button>
      {upload.data && !upload.data.started ? (
        <p className="mt-2 text-sm text-red-600">{upload.data.message}</p>
      ) : upload.data?.message ? (
        <p className="mt-2 text-sm text-[var(--dim)]">{upload.data.message}</p>
      ) : null}
      {upload.isError ? (
        <p className="mt-2 text-sm text-red-600">启动上传失败，请检查网络后重试。</p>
      ) : null}
    </div>
  );
}

/* ---------------- 休息计时器 ---------------- */

function RestTimer({
  targetSec,
  startTs,
  nowOffsetMs,
  onFinish,
  onTimeUp,
  onCollapse,
}: {
  targetSec: number;
  // 休息开始时刻（已按服务端时间戳校准的毫秒值）
  startTs: number;
  // 服务端时间 - 本机时间的差值：本机时钟不准或切后台回来时用它校准
  nowOffsetMs: number;
  onFinish: (elapsedSec: number) => void;
  onTimeUp?: () => void;
  // 「收起，按计划继续」：不调 AI、不提交反馈，直接进下一组（与 onFinish 互不覆盖）
  onCollapse?: (elapsedSec: number) => void;
}) {
  const [extra, setExtra] = useState(0);
  const [now, setNow] = useState(() => Date.now() + nowOffsetMs);
  const vibrated = useRef(false);
  const endAtRef = useRef(0);
  // ⑦ 休息计时环：rAF 逐帧 + linear，剩余时间一律用 endAt 时间戳重算，禁止自减计数；
  // 切屏/锁屏回来按真实时间差恢复，不会因为页面被挂起而丢计时。
  useEffect(() => {
    endAtRef.current = startTs + (targetSec + extra) * 1000;
    let raf = 0;
    const tick = () => {
      setNow(Date.now() + nowOffsetMs);
      raf = window.requestAnimationFrame(tick);
    };
    raf = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(raf);
  }, [startTs, targetSec, extra, nowOffsetMs]);
  const elapsed = Math.max(0, (now - startTs) / 1000);
  const total = targetSec + extra;
  const remaining = total - elapsed;
  useEffect(() => {
    if (remaining <= 0 && !vibrated.current) {
      vibrated.current = true;
      buzz([200, 100, 200, 100, 200]);
      beep();
      onTimeUp?.();
    }
  }, [remaining, onTimeUp]);
  const over = remaining < 0;
  const R = 66;
  const C = 2 * Math.PI * R;
  const frac = total > 0 ? Math.min(1, Math.max(0, elapsed / total)) : 0;
  return (
    <div className="glass-panel2 p-4">
      <div className="flex flex-col items-center">
        <div className="relative" style={{ width: 150, height: 150 }} role="timer" aria-label={`休息倒计时 ${fmtClock(Math.max(0, remaining))}`}>
          <svg width="150" height="150" viewBox="0 0 150 150" aria-hidden="true">
            <circle cx="75" cy="75" r={R} fill="none" stroke="rgba(242,247,243,0.12)" strokeWidth="8" />
            <circle
              cx="75"
              cy="75"
              r={R}
              fill="none"
              stroke={over ? "var(--st-stop)" : "var(--lime)"}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C * (1 - frac)}
              transform="rotate(-90 75 75)"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <p className={`num font-extrabold leading-none ${over ? "text-[var(--st-stop)]" : ""}`} style={{ fontSize: 52 }}>
              {over ? `+${fmtClock(-remaining)}` : fmtClock(remaining)}
            </p>
            <p className="num mt-1 text-[13px] text-[var(--text-2)]">
              已休 {Math.floor(elapsed)} / {total} 秒
            </p>
          </div>
        </div>
      </div>
      <div className="mt-3 flex gap-3">
        <button
          type="button"
          aria-label="休息加 30 秒"
          onClick={(e) => {
            animPress(e.currentTarget);
            setExtra((x) => x + 30);
          }}
          className="glass-btn pressable min-h-14 flex-1 px-3 py-2 text-sm font-semibold"
        >
          +30 秒
        </button>
        <button
          type="button"
          onClick={(e) => {
            animPress(e.currentTarget);
            buzz(40);
            onFinish(Math.max(1, Math.round(elapsed)));
          }}
          className="cta-lime pressable min-h-14 flex-1 px-3 py-2 text-base"
        >
          立即结束休息
        </button>
      </div>
      {onCollapse ? (
        <div className="mt-1 text-center">
          <button
            type="button"
            onClick={() => onCollapse(Math.max(1, Math.round(elapsed)))}
            className="text-link-48 text-sm"
          >
            收起，按计划继续
          </button>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- 感受输入 ---------------- */

// 把一份待确认建议翻成人话清单（接受前先让用户看清会改什么）
function proposalLines(p: NonNullable<SetLog["proposal"]>): string[] {
  const lines: string[] = [];
  if (p.action.includes("停止")) lines.push(`停止该动作当日剩余组`);
  if (p.replaceWith) lines.push(`剩余组动作换成「${p.replaceWith}」`);
  if (p.nextWeightKg != null) lines.push(`剩余组重量改为 ${p.nextWeightKg}kg`);
  if (p.nextReps != null) lines.push(`剩余组次数改为 ${p.nextReps}`);
  if (p.restSeconds != null) lines.push(`剩余组休息改为 ${p.restSeconds} 秒`);
  if (p.setsDelta < 0 && !p.action.includes("停止")) lines.push(`减少 ${-p.setsDelta} 组（跳过最后 ${-p.setsDelta} 组）`);
  if (p.setsDelta > 0) lines.push(`增加 ${p.setsDelta} 组`);
  if (p.nextSessionWeightKg != null) lines.push(`下次训练重量建议 ${p.nextSessionWeightKg}kg（只是建议，不会自动改计划）`);
  if (p.stopWarning) {
    lines.push(
      `后续动作提醒：${p.stopWarning.message}（涉及 ${p.stopWarning.affectedExercises.join("、") || "后续同类动作"}，开始前会标红让你确认）`,
    );
  }
  return lines;
}

// 建议卡一行结论（01 §E.1 模板）：动词 + 数值带单位，第二项改动写「休息改 N 秒」，
// 不用箭头（箭头只在展开层）。只拼服务端 proposal 的字段，客户端不做任何裁决。
function proposalConclusion(p: NonNullable<SetLog["proposal"]>): string {
  const verb = p.action;
  if (verb.includes("停止")) return "停止该动作今日剩余组";
  const parts: string[] = [verb];
  if (p.nextWeightKg != null) parts.push(`${p.nextWeightKg}kg`);
  if (p.nextReps != null) parts.push(`次数改 ${p.nextReps}`);
  if (p.setsDelta < 0) parts.push(`减 ${-p.setsDelta} 组`);
  if (p.setsDelta > 0) parts.push(`加 ${p.setsDelta} 组`);
  if (p.replaceWith) parts.push(`换成${p.replaceWith}`);
  let line = parts.join(" ");
  if (parts.length > 1 && (p.nextWeightKg != null || p.nextReps != null || p.setsDelta !== 0 || p.replaceWith)) {
    line = `${verb} ${parts.slice(1).join("，")}`;
  }
  if (p.restSeconds != null) line += `${parts.length > 1 ? "，" : " "}休息改 ${p.restSeconds} 秒`;
  if (p.nextSessionWeightKg != null) line += `，下次 ${p.nextSessionWeightKg}kg`;
  return line;
}

// 界面只显示裁决结论本身：服务端存的完整建议还包含反馈事实、理由、
// 证据编号与原书原文——那些留给模型与复盘用，不铺到用户眼前。
// ATI 格式取【ATI 裁决】段；旧规则格式取「建议：」段；更早的无分段
// 长文本只取第一句，避免把整段推理铺出来。
function shortSuggestion(text: string | null | undefined): string {
  if (!text) return "";
  const ati = text.match(/【ATI 裁决】([\s\S]*?)(?=【|$)/);
  if (ati?.[1]) return ati[1].trim();
  const legacy = text.match(/建议：([\s\S]*?)(?:。依据：|$)/);
  if (legacy?.[1]) return legacy[1].trim();
  if (text.length > 160) {
    const cut = text.indexOf("。", 40);
    if (cut > 0 && cut < 200) return text.slice(0, cut + 1);
    return `${text.slice(0, 120)}…`;
  }
  return text;
}

const RECOVERY_COLORS: Record<string, string> = {
  GREEN: "#7FD48A",
  BLUE: "#6E9BC7",
  AMBER: "#E5C05B",
  RED: "#E36A6A",
};

function FeedbackForm({
  setLog,
  onDone,
  proposalExpired = false,
  onNoteDirtyChange,
  preRecord = false,
  recordFirst,
}: {
  setLog: SetLog;
  onDone: (info: { suggestion: string; appliedNote: string; status?: string }) => void;
  // 这条待确认建议要改的后续组都已练完/跳过：只展示为已失效，不可再接受
  proposalExpired?: boolean;
  onNoteDirtyChange?: (dirty: boolean) => void;
  // 先反馈再记录：这一组还没落库，表单先行；提交时先执行 recordFirst
  // 把这一组记下来，成功后才提交反馈。记录失败则整单失败、反馈不提交。
  preRecord?: boolean;
  recordFirst?: () => Promise<void>;
}) {
  const queryClient = useQueryClient();
  // 四项客观证据：完成次数来自本组记录本身；这里填 RIR、动作是否变形、
  // 关节感受。RIR 用知识库统一标尺 3+/2/1/0（存 3 表示 3+，旧数据 4 并入）。
  const [rir, setRir] = useState<number | null>(setLog.rir != null ? Math.min(3, setLog.rir) : null);
  const [deform, setDeform] = useState<string>(setLog.deform ?? "");
  const [soreness, setSoreness] = useState<boolean>(setLog.sorenessOver72);
  const [joint, setJoint] = useState(setLog.joint ?? "");
  const [pump, setPump] = useState<number | null>(setLog.pump);
  const [fatigue, setFatigue] = useState<number>(setLog.fatigue ?? 5);
  const [note, setNote] = useState(setLog.note ?? "");
  // 建议制状态：以服务端记录为准（刷新页面也能恢复待确认/已接受状态）
  const status = setLog.proposalStatus ?? (setLog.aiSuggestion ? "none" : null);
  const [localResult, setLocalResult] = useState<{ suggestion: string; note: string } | null>(null);

  const payload = () => ({
    setId: setLog.id,
    rir,
    deform: (deform || null) as "未变形" | "变形" | "变形且无法纠正" | null,
    sorenessOver72: soreness,
    joint: joint.trim() ? joint.trim() : null,
    pump,
    fatigue,
    note: note.trim() ? note.trim() : null,
  });

  const submit = useMutation({
    mutationFn: async () => {
      // 先反馈再记录模式：先把这一组记下来（父组件负责落库与开始休息），
      // 记录成功后才提交反馈；记录失败直接抛错，反馈不会被提交。
      if (recordFirst) await recordFirst();
      return api.submitFeedback(payload());
    },
    // 失败已由表单内 isError 文案就地提示，onError 标记已处理，避免底部通知重复
    onError: () => {},
    onSuccess: (data) => {
      buzz([60, 80, 60]);
      if (data.proposalStatus === "pending") {
        onDone({ suggestion: data.suggestion, appliedNote: "有待确认的调整建议，接受后才会改动后续组。", status: "pending" });
      } else {
        onDone({
          suggestion: data.suggestion,
          appliedNote: "裁决完成：无需改动后续组，按计划继续。已记录的实际成绩会进入本次复盘。",
          status: data.proposalStatus ?? "none",
        });
      }
      void queryClient.invalidateQueries();
    },
  });

  // 只记下感受、不调 AI 的记录路径（表单内保留，服务端 quickContinue 口径不变）
  const quick = useMutation({
    mutationFn: async () => {
      if (recordFirst) await recordFirst();
      return api.submitFeedback({ ...payload(), quickContinue: true });
    },
    onError: () => {},
    onSuccess: () => {
      buzz(40);
      setLocalResult({ suggestion: "", note: "已记录感受，按计划继续，后续组不变。" });
      void queryClient.invalidateQueries();
      onDone({ suggestion: "", appliedNote: "已记录感受，按计划继续，后续组不变。", status: "quick" });
    },
  });

  const respond = useMutation({
    mutationFn: (accept: boolean) => api.respondProposal({ setId: setLog.id, accept }),
    onError: () => {},
    onSuccess: (data) => {
      buzz(data.proposalStatus === "accepted" ? [60, 80, 60] : 30);
      setLocalResult(null);
      void queryClient.invalidateQueries();
      onDone({ suggestion: setLog.aiSuggestion ?? "", appliedNote: data.appliedNote, status: data.proposalStatus });
    },
  });

  const undo = useMutation({
    mutationFn: () => api.undoProposal({ setId: setLog.id }),
    onSuccess: () => {
      buzz(30);
      void queryClient.invalidateQueries();
      onDone({ suggestion: setLog.aiSuggestion ?? "", appliedNote: "已撤销这条调整，后续组恢复到接受前的目标。", status: "undone" });
    },
  });

  // ---- 裁决在途恢复（切后台/息屏/退出空间后）----
  // 裁决状态以服务端落库为准，不只看本页这一次请求：请求被系统掐断时
  // 本地 promise 永不落定，但服务端状态还在，刷新/回前台后据此恢复，
  // 用已保存的反馈续跑，不用重填。
  const adjInterrupted = adjudicationInterrupted(setLog) && !submit.isPending;
  const resume = useMutation({
    mutationFn: () => api.resumeAdjudication({ setId: setLog.id }),
    onError: () => {},
    onSuccess: (data) => {
      if (data.stillRunning) {
        setLocalResult({ suggestion: "", note: "裁决还在进行中，稍等片刻会自动出现结果，不用重复点。" });
        void queryClient.invalidateQueries();
        return;
      }
      buzz([60, 80, 60]);
      if (data.proposalStatus === "pending") {
        onDone({ suggestion: data.suggestion, appliedNote: "有待确认的调整建议，接受后才会改动后续组。", status: "pending" });
      } else {
        onDone({
          suggestion: data.suggestion,
          appliedNote: "裁决完成：无需改动后续组，按计划继续。已记录的实际成绩会进入本次复盘。",
          status: data.proposalStatus ?? "none",
        });
      }
      void queryClient.invalidateQueries();
    },
  });

  // 本地请求迟迟不回（多半是切后台被系统冻结）：超过 20 秒给一句说明——
  // 反馈已经保存、回来能续跑，不让用户对着「正在综合裁决」干等或误判卡死。
  const [submitSlow, setSubmitSlow] = useState(false);
  useEffect(() => {
    if (!submit.isPending) {
      setSubmitSlow(false);
      return;
    }
    const t = window.setTimeout(() => setSubmitSlow(true), 20000);
    return () => window.clearTimeout(t);
  }, [submit.isPending]);

  // 服务端已经有裁决结果（原请求其实跑完了、或续跑完成了）但本地请求
  // 还挂着：解开本地 pending，免得按钮永远停在「正在综合裁决」。
  useEffect(() => {
    if (setLog.aiSuggestion && submit.isPending) submit.reset();
  }, [setLog.aiSuggestion, submit]);

  const chip = (active: boolean) =>
    `pressable min-h-12 rounded-xl px-3 py-2 text-[15px] font-medium border ${
      active
        ? "border-[var(--lime)] text-[var(--text-1)]"
        : "border-[rgba(255,255,255,0.14)] text-[var(--text-2)]"
    }`;
  const chipStyle = (active: boolean): CSSProperties =>
    active ? { background: "rgba(185,242,125,0.20)" } : { background: "var(--glass-l3-bg)" };
  // ⑮ 未选余力抖动报错：提交 AI 裁决前必须先选余力
  const [rirError, setRirError] = useState(false);
  const rirGroupRef = useRef<HTMLDivElement | null>(null);
  const [undoConfirmOpen, setUndoConfirmOpen] = useState(false);
  const submitWithCheck = () => {
    if (rir === null) {
      setRirError(true);
      animShake(rirGroupRef.current);
      buzz(80);
      return;
    }
    setRirError(false);
    submit.mutate();
  };

  const busy = submit.isPending || quick.isPending || respond.isPending || undo.isPending || resume.isPending;

  return (
    <div className="glass-card p-4">
      {preRecord ? (
        <p className="mb-3 rounded-lg px-3 py-2 text-sm font-medium" style={{ background: "var(--lime-08)", color: "var(--lime)" }}>
          这一组还没记录：先把反馈填好，点提交时才会先记录这一组、再让 Muse 按反馈裁决后续组。
        </p>
      ) : null}
      <p className="num glass-inner px-3 py-2 text-sm">
        完成次数：<span className="font-bold">{setLog.actualReps ?? "未记录"} / 目标 {setLog.targetReps}</span>
        <span className="ml-1 text-xs text-[var(--dim)]">{setLog.exerciseName} 第 {setLog.setIdx + 1} 组{setLog.warmup ? "（热身组）" : ""}</span>
      </p>
      <div className="mt-3">
        <label htmlFor={`note-${setLog.id}`} className="text-sm font-bold">
          写给 AI 的反馈记录
        </label>
        <textarea
          {...FIELDS.submitFeedback.note}
          id={`note-${setLog.id}`}
          value={note}
          onChange={(e) => {
            setNote(e.target.value);
            onNoteDirtyChange?.(e.target.value.trim().length > 0);
          }}
          rows={3}
          placeholder="如：最后两次明显慢了；左膝有点紧；这组很轻松，感觉还能加 2.5kg……"
          className="glass-input mt-2 min-h-20 w-full px-3 py-2 text-base"
        />
        {note.trim() ? (
          <button
            type="button"
            disabled={busy}
            onClick={submitWithCheck}
            className="glass-btn pressable mt-2 min-h-12 w-full px-4 py-2 text-[15px] font-semibold disabled:opacity-50"
          >
            {submit.isPending ? "Muse 正在综合裁决这一组…" : preRecord ? "提交反馈并记录这一组" : "提交反馈，让 Muse 调整后续组"}
          </button>
        ) : null}
      </div>
      <div className="mt-3">
        <p className="text-sm text-[var(--dim)]">做完停下时，还能标准地再做几个？</p>
        <div
          ref={rirGroupRef}
          className={`mt-1 grid grid-cols-2 gap-3 rounded-[24px] p-1 ${rirError ? "outline outline-2 outline-[var(--st-stop)]" : ""}`}
          role="group"
          aria-label="剩余次数余量 RIR"
        >
          {[
            { v: 3, label: "还能做 3 个以上" },
            { v: 2, label: "还能做 2 个" },
            { v: 1, label: "还能做 1 个" },
            { v: 0, label: "还能做 0 个" },
          ].map((o) => {
            const active = o.v === 0 ? rir === 0 && deform !== "变形" : rir === o.v;
            return (
              <button
                key={o.v}
                type="button"
                aria-pressed={active}
                aria-label={o.label}
                style={chipStyle(active)}
                className={`${chip(active)} min-h-12 px-3 py-2 text-left`}
                onClick={(e) => {
                  animNumPop(e.currentTarget);
                  setRirError(false);
                  setRir(rir === o.v ? null : o.v);
                }}
              >
                <span className="num block text-base font-bold leading-tight">{o.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            aria-pressed={rir === 0 && deform === "变形"}
            aria-label="0 个，且动作变形了 = 技术力竭，安全边界：停该动作"
            style={chipStyle(rir === 0 && deform === "变形")}
            className={`${chip(rir === 0 && deform === "变形")} col-span-2 min-h-12 px-3 py-2 text-left`}
            onClick={(e) => {
              animNumPop(e.currentTarget);
              setRirError(false);
              if (rir === 0 && deform === "变形") {
                setRir(null);
                setDeform("");
              } else {
                setRir(0);
                setDeform("变形");
              }
            }}
          >
            <span className="num block text-base font-bold leading-tight">0 个，且动作变形了 = 技术力竭，安全边界：停该动作</span>
          </button>
        </div>
        {rirError ? (
          <p className="mt-1 text-[11px] font-medium text-[var(--st-stop)]" role="alert">先选一个余力</p>
        ) : null}
      </div>
      <div className="mt-3">
        <p className="text-sm text-[var(--dim)]">动作有没有变形？</p>
        <div className="mt-1 flex gap-2" role="group" aria-label="动作是否变形">
          {["未变形", "变形", "变形且无法纠正"].map((d) => (
            <button
              key={d}
              type="button"
              aria-pressed={deform === d}
              className={`${chip(deform === d)} flex-1`}
              onClick={() => setDeform(deform === d ? "" : d)}
            >
              {d}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-3">
        <label htmlFor={`joint-${setLog.id}`} className="text-sm text-[var(--dim)]">关节感觉（刺痛 = 安全停止信号）</label>
        <div className="mt-1 flex gap-2">
          {["正常", "发紧", "刺痛"].map((j) => (
            <button
              key={j}
              type="button"
              className={chip(joint === j)}
              onClick={() => setJoint(joint === j ? "" : j)}
            >
              {j}
            </button>
          ))}
          <input
            {...FIELDS.submitFeedback.joint}
            id={`joint-${setLog.id}`}
            aria-label="关节感觉补充"
            value={joint}
            onChange={(e) => setJoint(e.target.value)}
            placeholder="或自己写"
            className="min-h-10 w-full flex-1 rounded-lg border border-[var(--border)] bg-[var(--glass-l1-bg)] px-3 py-2 text-sm"
          />
        </div>
        <div className="mt-2 flex items-center gap-2">
          <span className="text-sm text-[var(--dim)]">同一部位酸痛已持续超过 72 小时？</span>
          <button
            type="button"
            aria-pressed={soreness}
            className={chip(soreness)}
            onClick={() => setSoreness(!soreness)}
          >
            {soreness ? "是（安全停止信号）" : "否"}
          </button>
        </div>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <span className="text-sm text-[var(--dim)]">泵感（参考）</span>
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            aria-label={`泵感 ${n} 分`}
            className={chip(pump === n)}
            onClick={() => setPump(pump === n ? null : n)}
          >
            {n}
          </button>
        ))}
      </div>
      <div className="mt-3">
        <label htmlFor={`fatigue-${setLog.id}`} className="flex justify-between text-sm text-[var(--dim)]">
          <span>疲劳度（参考信号）</span>
          <span className="num font-semibold text-[var(--text)]">{fatigue}/10</span>
        </label>
        <input
          {...FIELDS.submitFeedback.fatigue}
          id={`fatigue-${setLog.id}`}
          type="range"
          step={1}
          value={fatigue}
          onChange={(e) => setFatigue(Number(e.target.value))}
          className="mt-1 w-full accent-[var(--accent)]"
        />
      </div>
      <button
        type="button"
        disabled={busy}
        onClick={submitWithCheck}
        className="cta-lime pressable mt-3 min-h-12 w-full px-4 py-2 text-base disabled:opacity-50"
      >
        {submit.isPending ? "Muse 正在综合裁决这一组…" : preRecord ? "提交反馈并记录这一组" : "提交反馈，让 Muse 调整后续组"}
      </button>
      {submit.isError || quick.isError ? (
        <p className="mt-2 text-sm text-red-600">
          {preRecord ? "提交失败：这一组还没记上，反馈也没有提交。你填的内容还在，网络恢复后重试即可。" : "提交失败，网络恢复后重试，感受内容不会丢。"}
        </p>
      ) : null}
      {respond.isError ? (
        <p className="mt-2 text-sm text-red-600">处理建议失败，请重试。</p>
      ) : null}
      {submit.isPending && submitSlow ? (
        <p className="mt-2 text-sm leading-relaxed text-[var(--dim)]" aria-live="polite">
          裁决需要一点时间（通常几十秒）。可以放心切到后台或锁屏：反馈已经保存，回来后裁决结果会自动出现，没完成也能一键重新裁决。
        </p>
      ) : null}
      {adjInterrupted ? (
        <div
          className="mt-3 rounded-xl p-3"
          style={{ border: "1px solid var(--st-pending)", background: "var(--glass-l1-bg)" }}
          aria-live="polite"
        >
          <p className="text-sm leading-relaxed">
            {setLog.adjudicationStatus === "failed"
              ? "上次裁决中断了。你的反馈已经保存，不用重填，点下面重新裁决就行。"
              : setLog.adjudicationStatus === "running"
                ? "这一组的裁决还没完成——刚才切到后台、息屏或退出空间，可能把裁决请求中断了。反馈已经保存，不用重填。"
                : "这一组的反馈已经保存，但裁决没有完成（多半是切后台或息屏时被中断了）。"}
          </p>
          <button
            type="button"
            disabled={resume.isPending}
            onClick={() => resume.mutate()}
            className="cta-lime pressable mt-2 min-h-12 w-full px-4 py-2 text-base disabled:opacity-50"
          >
            {resume.isPending ? "正在重新裁决…" : "重新裁决这一组"}
          </button>
          {resume.isError ? (
            <p className="mt-2 text-sm text-red-600">重新裁决失败，请检查网络后重试。反馈还在，不会丢。</p>
          ) : null}
        </div>
      ) : null}

      {localResult && status !== "pending" ? (
        <div className="mt-3 rounded-lg bg-[var(--surface2)] p-3" aria-live="polite">
          <p className="text-sm">{localResult.note}</p>
        </div>
      ) : null}

      {status === "pending" && setLog.proposal ? (
        <div
          className="anim-card-in mt-3 p-3"
          aria-live="polite"
          style={{
            background: "var(--glass-l1-bg)",
            backdropFilter: "var(--glass-l1-blur)",
            WebkitBackdropFilter: "var(--glass-l1-blur)",
            border: "var(--glass-l1-border)",
            borderLeft: `3px solid ${proposalExpired ? "var(--text-4)" : "var(--st-pending)"}`,
            borderRadius: 24,
          }}
        >
          <div className="flex items-center gap-3">
            {!proposalExpired ? <span className="pulse-dot h-2 w-2 shrink-0 rounded-full" style={{ background: "var(--st-pending)" }} aria-hidden="true" /> : null}
            <p className={`flex-1 text-base font-semibold leading-snug ${proposalExpired ? "text-[var(--text-4)]" : ""}`}>
              {proposalExpired ? "未处理，已失效：" : ""}
              {proposalConclusion(setLog.proposal)}
            </p>
            <div className="flex shrink-0 gap-3">
              <button
                type="button"
                disabled={busy || proposalExpired}
                aria-disabled={busy || proposalExpired}
                onClick={() => respond.mutate(true)}
                className="pressable min-h-12 px-4 text-sm font-bold disabled:cursor-not-allowed"
                style={
                  proposalExpired
                    ? { background: "var(--lime-18)", color: "var(--text-4)", borderRadius: 12, minWidth: 48 }
                    : { background: "var(--cta-bg)", color: "var(--cta-ink)", borderRadius: 12, minWidth: 48 }
                }
              >
                {respond.isPending ? "处理中…" : "接受"}
              </button>
              <button
                type="button"
                disabled={busy || proposalExpired}
                onClick={() => respond.mutate(false)}
                className="glass-btn pressable min-h-12 px-4 text-sm font-medium disabled:opacity-50"
                style={{ minWidth: 48 }}
              >
                忽略
              </button>
            </div>
          </div>
          {proposalLines(setLog.proposal).length ? (
            <ul className="mt-2 list-disc space-y-0.5 pl-5 text-sm">
              {proposalLines(setLog.proposal).map((l) => (
                <li key={l}>{l}</li>
              ))}
            </ul>
          ) : null}
          {setLog.proposal.guardNotes.map((g) => (
            <p key={g} className="mt-1 text-xs font-medium text-[var(--st-pending)]">{g}</p>
          ))}
          {setLog.proposal.recoveryChecklist.length ? (
            <p className="mt-2 text-xs leading-relaxed text-[var(--dim)]">
              接下来几组留意：{setLog.proposal.recoveryChecklist.join("；")}
            </p>
          ) : null}
          <p className="mt-2 text-xs text-[var(--dim)]">
            {proposalExpired
              ? "这条建议只作记录保留，不会改动任何一组。"
              : "接受前不会改动任何一组；忽略则保持原计划。"}
          </p>
        </div>
      ) : null}

      {status === "accepted" ? (
        <div className="mt-3 p-3" aria-live="polite" style={{ background: "var(--glass-l1-bg)", border: "var(--glass-l1-border)", borderLeft: "3px solid var(--st-maintain)", borderRadius: 24 }}>
          <p className="text-[15px] font-semibold"><span style={{ color: "var(--st-maintain)" }}>已应用：</span>{setLog.appliedNote}</p>
          {setLog.aiSuggestion ? <p className="mt-1 text-sm leading-relaxed">{shortSuggestion(setLog.aiSuggestion)}</p> : null}
          <button
            type="button"
            disabled={busy}
            onClick={() => setUndoConfirmOpen(true)}
            className="glass-btn pressable mt-2 min-h-12 px-4 py-2 text-sm font-medium disabled:opacity-50"
          >
            撤销
          </button>
          <Sheet open={undoConfirmOpen} title="撤销这条已接受的调整？" onClose={() => setUndoConfirmOpen(false)}>
            <p className="text-sm leading-relaxed text-[var(--dim)]">撤销后，后续组会恢复到接受这条建议之前的目标。{setLog.appliedNote}</p>
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                setUndoConfirmOpen(false);
                undo.mutate();
              }}
              className="pressable mt-4 min-h-14 w-full px-4 text-base font-bold text-white disabled:opacity-50"
              style={{ background: "var(--st-stop)", borderRadius: 12 }}
            >
              {undo.isPending ? "撤销中…" : "确认撤销"}
            </button>
          </Sheet>
        </div>
      ) : null}

      {status === "dismissed" ? (
        <div className="mt-3 rounded-lg bg-[var(--surface2)] p-3" aria-live="polite">
          <p className="text-sm">已忽略这条建议，后续组保持原计划。</p>
          {setLog.aiSuggestion ? <p className="mt-1 text-xs leading-relaxed text-[var(--dim)]">{shortSuggestion(setLog.aiSuggestion)}</p> : null}
        </div>
      ) : null}

      {status === "undone" ? (
        <div className="mt-3 rounded-lg bg-[var(--surface2)] p-3" aria-live="polite">
          <p className="text-sm">这条调整已撤销，后续组恢复到接受前的目标。</p>
        </div>
      ) : null}

      {status === "none" && setLog.aiSuggestion ? (
        <div className="mt-3 rounded-lg bg-[var(--surface2)] p-3" aria-live="polite">
          <p className="text-sm leading-relaxed">{shortSuggestion(setLog.aiSuggestion)}</p>
          <p className="mt-1 text-xs text-[var(--dim)]">不需要改动后续组，按计划继续即可。</p>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- 旧版记录决策横幅（会话兼容） ---------------- */

// 进行中的训练里若有旧版已完成组（有旧难度字段、无 RIR/变形/关节证据），
// 不静默处理：让用户三选一——补全 RIR、原样保留（标记后不参与连续失败
// 判定）、或删除这次进行中会话重练。
function LegacyBanner({ session, sets }: { session: SessionT; sets: SetLog[] }) {
  const queryClient = useQueryClient();
  const legacySets = sets.filter((s) => s.needsRir);
  const [mode, setMode] = useState<"choose" | "backfill" | "confirmDelete">("choose");
  // RIR 补填选择：3 / 2 / 1 / 0，9 表示「0 且变形」
  const [picks, setPicks] = useState<Record<number, number>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  if (!legacySets.length) return null;

  const startTime = session.startedAt
    ? new Date(session.startedAt).toLocaleTimeString("zh-CN", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      })
    : "";
  const exNames = [...new Set(legacySets.map((s) => s.exerciseName))].join("、");
  const invalidate = () => void queryClient.invalidateQueries();

  const saveBackfill = async () => {
    setBusy(true);
    setErr("");
    try {
      for (const s of legacySets) {
        const pick = picks[s.id];
        if (pick == null) continue;
        await api.submitFeedback({
          setId: s.id,
          rir: pick === 9 ? 0 : pick,
          deform: pick === 9 ? "变形" : "未变形",
          sorenessOver72: false,
          joint: "正常",
          pump: s.pump,
          fatigue: s.fatigue,
          note: s.note,
          quickContinue: true,
        });
      }
      buzz(40);
      invalidate();
    } catch {
      setErr("补填保存失败，请检查网络后重试。");
    } finally {
      setBusy(false);
    }
  };

  const keepLegacy = async () => {
    setBusy(true);
    setErr("");
    try {
      await api.markLegacySets({ sessionId: session.id });
      buzz(40);
      invalidate();
    } catch {
      setErr("标记失败，请重试。");
    } finally {
      setBusy(false);
    }
  };

  const deleteSession = async () => {
    setBusy(true);
    setErr("");
    try {
      await api.deleteSession({ sessionId: session.id });
      buzz(30);
      invalidate();
    } catch {
      setErr("删除失败，请重试。");
    } finally {
      setBusy(false);
    }
  };

  const chipCls = (active: boolean) =>
    `min-h-12 flex-1 rounded-lg px-2 py-2 text-sm font-bold border ${
      active
        ? "bg-[var(--accent)] border-[var(--accent)] text-[var(--cta-ink)]"
        : "bg-[var(--glass-l1-bg)] border-[var(--border)]"
    }`;

  return (
    <div role="alert" className="rounded-xl border-2 border-amber-500 bg-amber-50 p-4 dark:bg-amber-950">
      <p className="font-bold text-amber-900 dark:text-amber-200">
        检测到今日 {startTime} 有未完成的旧版训练记录（已记 {legacySets.length} 组{exNames}，未包含 RIR 数据），请选择处理方式：
      </p>
      {mode === "choose" ? (
        <div className="mt-3 space-y-2">
          <button
            type="button"
            disabled={busy}
            onClick={() => setMode("backfill")}
            className="min-h-12 w-full rounded-lg bg-amber-500 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
          >
            补全 RIR 并继续训练
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => void keepLegacy()}
            className="min-h-12 w-full rounded-lg bg-[var(--glass-l1-bg)] px-4 py-2 text-sm font-bold disabled:opacity-50"
          >
            保留原样并继续第 3 组
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => setMode("confirmDelete")}
            className="min-h-12 w-full rounded-lg bg-[var(--glass-l1-bg)] px-4 py-2 text-sm font-medium text-[var(--st-stop)] disabled:opacity-50"
          >
            删除此进行中会话
          </button>
          <p className="text-xs leading-relaxed text-[var(--st-pending)]">
            「保留原样」会把这 {legacySets.length} 组标记为旧版记录，不进入 ATI 决策的今日趋势判断，数值一个都不改。
          </p>
        </div>
      ) : null}
      {mode === "backfill" ? (
        <div className="mt-3 space-y-3">
          {legacySets.map((s) => (
            <div key={s.id}>
              <p className="num text-sm font-semibold text-amber-900 dark:text-amber-200">
                {s.exerciseName} 第 {s.setIdx + 1} 组 · 实际 {fmtPair(s.actualWeightKg ?? s.targetWeightKg, s.actualReps ?? s.targetReps)}，当时还剩几次余量？
              </p>
              <div className="mt-1 grid grid-cols-2 gap-1.5" role="group" aria-label={`${s.exerciseName} 第 ${s.setIdx + 1} 组补填 RIR`}>
                {[
                  { v: 3, label: "还能做 3 个以上", sub: "偏轻" },
                  { v: 2, label: "还能做 2 个", sub: "目标区间" },
                  { v: 1, label: "还能做 1 个", sub: "接近极限" },
                  { v: 0, label: "还能做 0 个", sub: "一个也做不了，已力竭" },
                  { v: 9, label: "0 个，且动作变形了", sub: "技术力竭" },
                ].map((o) => (
                  <button
                    key={o.v}
                    type="button"
                    aria-pressed={picks[s.id] === o.v}
                    aria-label={`${o.label}：${o.sub}`}
                    className={`${chipCls(picks[s.id] === o.v)} px-2 py-2 text-left ${o.v === 9 ? "col-span-2" : ""}`}
                    onClick={() => setPicks((p) => ({ ...p, [s.id]: o.v }))}
                  >
                    <span className="block leading-tight">{o.label}</span>
                    <span className="mt-0.5 block text-xs font-normal leading-snug opacity-80">{o.sub}</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="flex gap-2">
            <button
              type="button"
              disabled={busy || legacySets.some((s) => picks[s.id] == null)}
              onClick={() => void saveBackfill()}
              className="min-h-12 flex-1 rounded-lg bg-amber-500 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
            >
              {busy ? "保存中…" : "保存补填，继续训练"}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => setMode("choose")}
              className="min-h-12 rounded-lg bg-[var(--glass-l1-bg)] px-4 py-2 text-sm font-medium"
            >
              返回
            </button>
          </div>
          <p className="text-xs text-[var(--st-pending)]">记不清的那组可以返回选「保留原样」，不强制补填。</p>
        </div>
      ) : null}
      {mode === "confirmDelete" ? (
        <div className="mt-3 space-y-2">
          <p className="text-sm font-semibold text-[var(--st-stop)]">
            确认删除这次进行中的训练？已记的 {legacySets.length} 组记录会一起删掉，删除后可重新点「开始训练」。此操作不可恢复。
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => void deleteSession()}
              className="min-h-12 flex-1 rounded-lg bg-[var(--st-stop)] px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
            >
              {busy ? "删除中…" : "确认删除此会话"}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => setMode("choose")}
              className="min-h-12 rounded-lg bg-[var(--glass-l1-bg)] px-4 py-2 text-sm font-medium"
            >
              取消
            </button>
          </div>
        </div>
      ) : null}
      {err ? <p className="mt-2 text-sm text-red-600">{err}</p> : null}
    </div>
  );
}

/* ---------------- 训练中 ---------------- */

function TrainingView({
  date,
  session,
  sets,
  plan,
}: {
  date: string;
  session: SessionT;
  sets: SetLog[];
  plan: PlanT | null;
}) {
  const queryClient = useQueryClient();
  const groups = useMemo(() => groupSets(sets), [sets]);
  const current = sets.find((s) => !s.done && !s.skipped) ?? null;
  // 休息状态持久化：切后台/切页面回来后，按服务端校准过的开始时刻和真实
  // 经过时间补算，不会因为页面被挂起而丢计时。
  const restStorageKey = `fitness-rest-${session.id}`;
  const [rest, setRest] = useState<{ forSetId: number; startTs: number; targetSec: number } | null>(() => {
    try {
      const raw = window.localStorage.getItem(restStorageKey);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as { forSetId: number; startTs: number; targetSec: number };
      return typeof parsed.forSetId === "number" ? parsed : null;
    } catch {
      return null;
    }
  });
  const [clockOffsetMs, setClockOffsetMs] = useState(0);
  const [feedbackSetId, setFeedbackSetId] = useState<number | null>(null);
  // 先反馈再记录：被标记的当前组只打开反馈表单、不落库；提交反馈时才
  // 先记录这一组（recordFirst），记录成功后反馈才真正提交。
  const [feedbackFirstId, setFeedbackFirstId] = useState<number | null>(null);
  const feedbackWrapRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (feedbackFirstId != null) {
      feedbackWrapRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [feedbackFirstId]);
  const [confirmRestoreId, setConfirmRestoreId] = useState<number | null>(null);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const [banner, setBanner] = useState<{ title: string; body: string } | null>(null);
  const [talkLevel, setTalkLevel] = useState<string>("");

  // 屏幕常亮锁：训练中自动保持屏幕常亮防计时休眠；切回前台时重新
  // 申请（系统会在切后台时自动释放）。不支持的设备静默跳过。
  const [wakeLockOn, setWakeLockOn] = useState(false);
  useEffect(() => {
    let sentinel: WakeLockSentinelLike | null = null;
    let disposed = false;
    const acquire = async () => {
      const s = await requestWakeLock();
      if (disposed) {
        if (s) void s.release().catch(() => undefined);
        return;
      }
      sentinel = s;
      setWakeLockOn(s != null);
    };
    void acquire();
    const onVis = () => {
      if (document.visibilityState === "visible") void acquire();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      disposed = true;
      document.removeEventListener("visibilitychange", onVis);
      if (sentinel) void sentinel.release().catch(() => undefined);
    };
  }, []);

  // 有裁决在途时每 8 秒拉一次最新状态：原请求若在后台跑完了，结果自动
  // 出现；若被系统掐断，状态停在 running/failed，表单里给出续跑入口。
  const anyAdjudicating = sets.some((s) => s.adjudicationStatus === "running");
  useEffect(() => {
    if (!anyAdjudicating) return;
    const t = window.setInterval(() => {
      void queryClient.invalidateQueries({ queryKey: ["day", date] });
    }, 8000);
    return () => window.clearInterval(t);
  }, [anyAdjudicating, date, queryClient]);

  const persistRest = (r: { forSetId: number; startTs: number; targetSec: number } | null) => {
    setRest(r);
    try {
      if (r) window.localStorage.setItem(restStorageKey, JSON.stringify(r));
      else window.localStorage.removeItem(restStorageKey);
    } catch {
      /* 存储不可用时仅内存计时 */
    }
  };

  // 当前组的重量/次数：默认直接用计划目标预填——开始新一组时就是计划里的
  // 重量，不用手动再输；Muse 的调整被接受、后续组目标改写时也会自动跟着
  // 新目标走。只有用户手动改过、且目标没再变时，才用改后的值（草稿按
  // 「组+当下目标」作键）。
  // 目标重量未设时，默认沿用同动作上一组的实际重量（没有则用其目标），可改。
  const prevSameSet = current
    ? [...sets]
        .filter((s) => s.exerciseIdx === current.exerciseIdx && s.setIdx < current.setIdx)
        .sort((a, b) => b.setIdx - a.setIdx)[0] ?? null
    : null;
  const carriedWeight =
    current?.targetWeightKg == null
      ? prevSameSet?.actualWeightKg ?? prevSameSet?.targetWeightKg ?? null
      : null;
  const [draft, setDraft] = useState<{ key: string; weight: string; reps: string } | null>(null);
  const draftKey = current
    ? `${current.id}|${current.actualWeightKg ?? ""}|${current.targetWeightKg ?? ""}|${current.targetReps}|${carriedWeight ?? ""}`
    : "";
  const activeDraft = draft && draft.key === draftKey ? draft : null;
  const weightIn = activeDraft
    ? activeDraft.weight
    : current?.actualWeightKg != null
      ? String(current.actualWeightKg)
      : current?.targetWeightKg != null
        ? String(current.targetWeightKg)
        : "";
  const repsIn = activeDraft ? activeDraft.reps : (current?.actualReps ?? current?.targetReps ?? "");
  const setWeightIn = (v: string) => setDraft({ key: draftKey, weight: v, reps: repsIn });
  const setRepsIn = (v: string) => setDraft({ key: draftKey, weight: weightIn, reps: v });

  // 当前组大数字的字号随位数收放：127.5 这类 5 位数在 44px 下必然被裁切，
  // 按字符数降档，配合下方「数字独占一行、± 按钮移到下一行」的布局保证完整显示。
  const stepFontSize = (v: string) => {
    const n = v.trim().length;
    if (n <= 4) return 44;
    if (n === 5) return 38;
    if (n === 6) return 33;
    return 29;
  };

  // 有氧组（计划类别为 cardio，或无重量且次数是「20分钟」这类时长）：
  // 改用结构化字段记录
  const isCardio =
    current != null &&
    (plan?.exercises[current.exerciseIdx]?.category === "cardio" ||
      (current.targetWeightKg == null && !/^\d+$/.test(current.targetReps.trim())));
  const [cardio, setCardioState] = useState<{ key: string; dur: string; dist: string; pace: string } | null>(null);
  const cardioKey = current ? `${current.id}|${current.targetReps}` : "";
  const cardioDurDefault = current?.durationMin != null
    ? String(current.durationMin)
    : String(repsNumberOf(current?.targetReps ?? "") || 20);
  const cardioVal = cardio && cardio.key === cardioKey
    ? cardio
    : {
        key: cardioKey,
        dur: cardioDurDefault,
        dist: current?.distanceKm != null ? String(current.distanceKm) : "",
        pace: current?.pace ?? "",
      };
  const setCardio = (patch: Partial<{ dur: string; dist: string; pace: string }>) =>
    setCardioState({ ...cardioVal, ...patch });
  // 配速由时长/距离自动算（分:秒/公里），用户可直接改
  const autoPace = (() => {
    const d = Number(cardioVal.dur);
    const km = Number(cardioVal.dist);
    if (!Number.isFinite(d) || !Number.isFinite(km) || d <= 0 || km <= 0) return "";
    const per = d / km;
    const mm = Math.floor(per);
    const ss = Math.round((per - mm) * 60);
    return `${mm}:${String(ss).padStart(2, "0")}`;
  })();

  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ["day", date] });

  const logMut = useMutation({
    mutationFn: (args: Parameters<typeof api.logSet>[0]) => api.logSet(args),
    onSuccess: invalidate,
  });

  const ackAlert = useMutation({
    mutationFn: (alertId: string) => api.acknowledgeAlert({ sessionId: session.id, alertId }),
    onSuccess: invalidate,
  });

  const finishMut = useMutation({
    mutationFn: () => api.finishSession({ sessionId: session.id }),
    // 失败已由 isError 文案就地提示，onError 标记已处理，避免底部通知重复
    onError: () => {},
    onSuccess: () => {
      buzz([80, 60, 80]);
      void queryClient.invalidateQueries();
    },
  });

  const feedbackSet = feedbackSetId != null ? sets.find((s) => s.id === feedbackSetId) ?? null : null;
  const restSet = rest ? sets.find((s) => s.id === rest.forSetId) ?? null : null;
  const doneCount = sets.filter((s) => s.done).length;
  // 最近一条真正生效的调整：训练中常驻展示，让「接受」之后的变化看得见，
  // 不必等到总结页才知道改了什么。
  const lastAccepted = [...sets]
    .filter((s) => s.proposalStatus === "accepted" && s.appliedNote)
    .sort((a, b) => b.id - a.id)[0] ?? null;
  // D2/D3 同屏挂着的待确认建议（只认服务端 proposalStatus，不自行推导禁用态）
  const pendingSet = [...sets]
    .filter((s) => s.proposalStatus === "pending" && s.proposal && !pendingExpired(s, sets))
    .sort((a, b) => b.id - a.id)[0] ?? null;
  const respondMut = useMutation({
    mutationFn: (args: { setId: number; accept: boolean }) => api.respondProposal(args),
    onSuccess: () => {
      buzz([60, 80, 60]);
      invalidate();
    },
  });
  // ⑪ 训练进度条弹簧推进：从当前视觉值继续，不重置为 0
  const progressFillRef = useRef<HTMLDivElement | null>(null);
  const prevFracRef = useRef(0);
  useEffect(() => {
    const frac = sets.length ? doneCount / sets.length : 0;
    const el = progressFillRef.current;
    if (el && frac !== prevFracRef.current) {
      playAnim(
        el,
        [
          { transform: `scaleX(${prevFracRef.current})` },
          { transform: `scaleX(${Math.min(1, frac * 1.08)})`, offset: 0.7 },
          { transform: `scaleX(${frac})` },
        ],
        { duration: 320, easing: "cubic-bezier(0.34,1.56,0.64,1)" },
      );
      el.style.transform = `scaleX(${frac})`;
    }
    prevFracRef.current = frac;
  }, [doneCount, sets.length]);
  // 反馈文字未提交就结束休息时的 2 秒级 Toast（不弹模态框）
  const noteDirtyRef = useRef(false);
  const [restToast, setRestToast] = useState("");
  // 休息中 = 刚记录完一组、它的实际休息秒数还没落库：这段时间页面只显示
  // 「已记录 + 休息计时 + 下一组预告」，不提前把下一组面板推出来当当前组。
  const restActive = !!(rest && restSet && restSet.restSeconds == null);
  // 先反馈再记录进行中：当前组被标记、尚未落库，反馈表单以 preRecord 模式打开
  const feedbackFirstActive =
    feedbackFirstId != null && current != null && feedbackFirstId === current.id && !current.done;
  // 该模式下表单顶部的「完成次数」显示待记录的草稿实际值（步进器里的数），
  // 与提交时真正落库的入参同源；其余情况直接用服务端行。
  const displayFeedbackSet =
    feedbackFirstActive && feedbackSet && current && feedbackSet.id === current.id
      ? {
          ...feedbackSet,
          actualWeightKg: (() => {
            const n = Number(weightIn);
            return weightIn.trim() !== "" && Number.isFinite(n) ? n : null;
          })(),
          actualReps: repsIn.trim() ? repsIn.trim() : feedbackSet.targetReps,
        }
      : feedbackSet;

  // 记录一组的统一入口：记住这次提交的内容与成功回调。以前点完按钮只靠
  // 请求返回才有下文，网络卡住时按钮半透明锁死、无文案无报错，人只能干等
  // 以为「卡住了」。现在：按钮有「正在记录…」文案；超过 8 秒显示慢提示；
  // 失败显示红色错误条并能原样重试（logSet 是同值更新，重发不会记重）。
  const [logError, setLogError] = useState(false);
  const [slowPending, setSlowPending] = useState(false);
  const attemptRef = useRef<{
    payload: Parameters<typeof api.logSet>[0];
    onOk: (data: { serverNow: number }) => void;
  } | null>(null);
  const lastClickRef = useRef(0);
  const runLog = (
    payload: Parameters<typeof api.logSet>[0],
    onOk: (data: { serverNow: number }) => void,
  ) => {
    const nowMs = Date.now();
    if (nowMs - lastClickRef.current < 300 || logMut.isPending) return;
    lastClickRef.current = nowMs;
    attemptRef.current = { payload, onOk };
    setLogError(false);
    logMut.mutate(payload, {
      onSuccess: (data) => {
        setLogError(false);
        onOk(data);
      },
      onError: () => setLogError(true),
    });
  };
  const retryLog = () => {
    const a = attemptRef.current;
    if (a) runLog(a.payload, a.onOk);
  };
  useEffect(() => {
    if (!logMut.isPending) {
      setSlowPending(false);
      return;
    }
    const t = window.setTimeout(() => setSlowPending(true), 8000);
    return () => window.clearTimeout(t);
  }, [logMut.isPending]);

  // 完成一组后启动休息计时：用服务端返回的时间戳校准本机时钟
  const startRest = (setId: number, targetRestSeconds: number, serverNow: number) => {
    if (targetRestSeconds <= 0) return;
    const offset = serverNow - Date.now();
    setClockOffsetMs(offset);
    persistRest({ forSetId: setId, startTs: serverNow, targetSec: targetRestSeconds });
  };

  const [draftError, setDraftError] = useState("");
  // 当前组草稿 → logSet 入参：校验不过时把错误标回输入框并返回 null。
  // 「完成」与「先反馈再记录」共用同一份构建，保证两条路记下的数据一致。
  const buildCurrentPayload = (): Parameters<typeof api.logSet>[0] | null => {
    if (!current) return null;
    if (!isCardio) {
      const wRaw = weightIn.trim();
      if (wRaw !== "") {
        const wv = Number(wRaw);
        if (!Number.isFinite(wv) || wv <= 0 || wv > 400 || Math.abs(wv * 10 - Math.round(wv * 10)) > 1e-9) {
          setDraftError("重量要在 0–400kg 之间，最多 1 位小数");
          buzz(80);
          return null;
        }
      }
      const rRaw = repsIn.trim();
      if (rRaw !== "") {
        const rv = Number(rRaw);
        if (!Number.isInteger(rv) || rv < 1 || rv > 99) {
          setDraftError("次数要是 1–99 的整数");
          buzz(80);
          return null;
        }
      }
    }
    setDraftError("");
    const w = weightIn.trim() === "" ? null : Number(weightIn);
    return isCardio
      ? {
          setId: current.id,
          actualWeightKg: null,
          actualReps: `${cardioVal.dur || cardioDurDefault}分钟`,
          durationMin: Number(cardioVal.dur) || null,
          pace: (cardioVal.pace.trim() || autoPace) ? (cardioVal.pace.trim() || autoPace) : null,
          distanceKm: cardioVal.dist.trim() === "" ? null : Number(cardioVal.dist) || null,
          restSeconds: current.restSeconds,
          done: true,
          skipped: false,
        }
      : {
          setId: current.id,
          actualWeightKg: w != null && Number.isFinite(w) ? w : null,
          actualReps: repsIn.trim() ? repsIn.trim() : current.targetReps,
          restSeconds: current.restSeconds,
          done: true,
          skipped: false,
        };
  };

  const completeCurrent = () => {
    if (!current) return;
    const payload = buildCurrentPayload();
    if (!payload) return;
    runLog(payload, (data) => {
        buzz(60);
        const nxt = sets.find((s) => !s.done && !s.skipped && s.id !== current.id);
        setBanner({
          title: `已保存：${current.exerciseName} 第 ${current.setIdx + 1} 组`,
          body: nxt
            ? `这组已经记好了。下一步：先休息，休息结束开始 ${nxt.exerciseName} 第 ${nxt.setIdx + 1} 组 · ${fmtPair(nxt.targetWeightKg, nxt.targetReps)}。想让 Muse 按实时状况调整后续组，就在下面打开的反馈栏里写给它；不写就按计划继续。`
            : "这组已经记好了，这是最后一组。下一步：休息完点下方「结束训练，生成总结」。",
        });
        // 记录成功 = 立刻进入休息。正式训练里反馈入口直接摆在主屏：
        // 力量组记完就打开这一组的反馈表单（写给 AI 的反馈栏在表单顶部），
        // 休息时顺手写、提交后 AI 裁决调整后续组；不写就收起按计划走。
        // 已经填过反馈或已有建议的组不重复打开。
        startRest(current.id, current.targetRestSeconds, data.serverNow);
        if (!isCardio && !current.aiSuggestion && !hasFeedback(current)) {
          setFeedbackSetId(current.id);
        }
        // 有氧的喘息/说话程度随手记进备注（走快速通道，不调 AI）
        if (isCardio && talkLevel) {
          void api
            .submitFeedback({
              setId: current.id,
              rir: null,
              deform: null,
              sorenessOver72: false,
              joint: null,
              pump: null,
              fatigue: null,
              note: `喘息程度：${talkLevel}`,
              quickContinue: true,
            })
            .catch(() => undefined);
          setTalkLevel("");
        }
    });
  };

  // 「填感受再记」：只校验草稿并打开当前组的反馈表单，绝不调用 logSet。
  // 这一组在用户提交反馈之前保持未记录状态（旧实现误接到了 completeCurrent，
  // 点一下就直接记完，反馈永远排在记录之后）。
  const startFeedbackFirst = () => {
    if (!current || isCardio) return;
    if (!buildCurrentPayload()) return;
    setFeedbackFirstId(current.id);
    setFeedbackSetId(current.id);
    buzz(30);
  };

  // 先反馈再记录的落库一步：由 FeedbackForm 在提交反馈时先行调用。
  // 用提交那一刻的最新草稿构建入参；成功后与「完成」走同一套收尾
  // （横幅 + 开始休息），失败抛错让表单停在未提交状态。
  const recordFirstForFeedback = async (): Promise<void> => {
    if (!current) throw new Error("当前组不存在");
    const target = current;
    const payload = buildCurrentPayload();
    if (!payload) throw new Error("重量或次数不合规");
    const data = await logMut.mutateAsync(payload);
    buzz(60);
    const nxt = sets.find((s) => !s.done && !s.skipped && s.id !== target.id);
    setBanner({
      title: `已保存：${target.exerciseName} 第 ${target.setIdx + 1} 组`,
      body: nxt
        ? `这组已经记好了，反馈也已提交。下一步：先休息，休息结束开始 ${nxt.exerciseName} 第 ${nxt.setIdx + 1} 组 · ${fmtPair(nxt.targetWeightKg, nxt.targetReps)}。`
        : "这组已经记好了，反馈也已提交，这是最后一组。下一步：休息完点下方「结束训练，生成总结」。",
    });
    startRest(target.id, target.targetRestSeconds, data.serverNow);
    setFeedbackFirstId(null);
  };

  const finishRest = (elapsedSec: number) => {
    setBanner(null);
    // 已输入反馈文字却直接结束休息：给一次短 Toast，不弹模态框（01 §C.3）
    if (noteDirtyRef.current && feedbackSetId != null && restSet && feedbackSetId === restSet.id) {
      setRestToast("反馈没提交，下组开始后可再写");
      noteDirtyRef.current = false;
    }
    if (!rest || !restSet) {
      persistRest(null);
      return;
    }
    runLog(
      {
        setId: restSet.id,
        actualWeightKg: restSet.actualWeightKg,
        actualReps: restSet.actualReps,
        restSeconds: elapsedSec,
        done: restSet.done,
        skipped: restSet.skipped,
      },
      () => undefined,
    );
    persistRest(null);
  };

  // 休息到点：页面横幅写明下一组是哪个动作、第几组、什么目标。
  const handleRestTimeUp = () => {
    const next = current;
    const body = next
      ? `${next.exerciseName} 第 ${next.setIdx + 1} 组 · 目标 ${fmtPair(next.targetWeightKg, next.targetReps)}`
      : "计划内的组都处理完了，可以结束训练生成总结。";
    setBanner({ title: "休息结束，下一组可以开始", body });
  };

  return (
    <div className="space-y-4">
      <LegacyBanner session={session} sets={sets} />
      <div className="flex items-center justify-between gap-2">
        <p className="text-[17px] font-semibold">
          {restActive && restSet
            ? `${restSet.exerciseName} · 第 ${restSet.setIdx + 1} 组已记`
            : current
              ? `${current.exerciseName} · 第 ${current.setIdx + 1}/${sets.filter((x) => x.exerciseIdx === current.exerciseIdx).length} 组`
              : "全部组已处理完"}
        </p>
        <p className="num shrink-0 text-sm text-[var(--text-2)]">
          {restActive ? `已记 ${doneCount}/${sets.length} 组` : current ? `第 ${sets.indexOf(current) + 1}/${sets.length} 组` : `${doneCount}/${sets.length} 组`}
        </p>
      </div>
      <div aria-label="训练进度" className="h-1.5 overflow-hidden rounded-full" style={{ background: "rgba(242,247,243,0.10)" }}>
        <div
          ref={progressFillRef}
          className="h-full rounded-full"
          style={{ background: "var(--lime)", transformOrigin: "left", transform: `scaleX(${sets.length ? doneCount / sets.length : 0})` }}
        />
      </div>
      {lastAccepted ? (
        <p className="num truncate text-[13px] leading-5" role="status" title={lastAccepted.appliedNote ?? ""}>
          <span style={{ color: "var(--st-maintain)" }}>已应用：</span>
          {lastAccepted.appliedNote}
        </p>
      ) : null}
      {wakeLockOn ? (
        <p className="text-xs font-medium text-[var(--green)]">已激活屏幕常亮，防止计时器休眠</p>
      ) : null}

      {logMut.isPending ? (
        <p className="rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-medium" role="status">
          正在记录这一组…{slowPending ? "网络有点慢，已经超过 8 秒，还在发送；若一直没动静，可以点下面「重新记录」再发一次（不会记重）。" : "记好后自动开始休息计时。"}
        </p>
      ) : null}
      {slowPending && logMut.isPending ? (
        <button
          type="button"
          onClick={retryLog}
          className="min-h-11 w-full rounded-lg bg-[var(--surface2)] px-4 py-2 text-sm font-bold"
        >
          重新记录这一组
        </button>
      ) : null}
      {logError ? (
        <div role="alert" className="flex items-center gap-3 rounded-lg border border-[rgba(227,106,106,0.4)] bg-[rgba(227,106,106,0.10)] px-3 py-2 ">
          <p className="flex-1 text-sm font-medium text-[var(--st-stop)]">
            这一组没有记上（网络或服务问题）。你填的数字还在，不用重填，网络恢复后重试即可。
          </p>
          <button
            type="button"
            disabled={logMut.isPending}
            onClick={retryLog}
            className="min-h-11 shrink-0 rounded-lg bg-[var(--st-stop)] px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
          >
            重新记录
          </button>
        </div>
      ) : null}

      {banner ? (
        <div role="alert" className="flex items-start gap-3 glass-card p-4">
          <div className="flex-1">
            <p className="font-bold">{banner.title}</p>
            <p className="mt-0.5 text-sm leading-relaxed text-[var(--dim)]">{banner.body}</p>
          </div>
          <button
            type="button"
            onClick={() => setBanner(null)}
            className="min-h-9 shrink-0 rounded-md bg-[var(--surface2)] px-3 py-1 text-sm font-medium"
          >
            知道了
          </button>
        </div>
      ) : null}

      {restActive && rest && restSet ? (
        <section aria-label="休息中" className="space-y-3">
          <p className="text-sm font-semibold text-[var(--green)]">
            ✓ 已记录：{restSet.exerciseName} 第 {restSet.setIdx + 1} 组 ·{" "}
            {fmtPair(restSet.actualWeightKg ?? restSet.targetWeightKg, restSet.actualReps ?? restSet.targetReps)}
          </p>
          <RestTimer
            key={rest.forSetId}
            targetSec={rest.targetSec}
            startTs={rest.startTs}
            nowOffsetMs={clockOffsetMs}
            onFinish={finishRest}
            onCollapse={finishRest}
            onTimeUp={handleRestTimeUp}
          />
          {current ? (
            <p className="text-sm text-[var(--dim)]">
              下一组：<span className="font-semibold text-[var(--text)]">{current.exerciseName} 第 {current.setIdx + 1} 组{current.warmup ? "（热身组）" : ""} · {fmtPair(current.targetWeightKg, current.targetReps)} · 休息 {current.targetRestSeconds} 秒</span>
            </p>
          ) : (
            <p className="text-sm text-[var(--dim)]">这是最后一组，休息完点下方「结束训练，生成总结」。</p>
          )}
          {/* 44px 调整槽位：pending 与 applied 共用同一位置同一高度，二选一 */}
          {pendingSet && pendingSet.proposal ? (
            <div
              className="flex min-h-11 items-center gap-3 px-3"
              style={{ background: "var(--glass-l1-bg)", border: "var(--glass-l1-border)", borderLeft: "3px solid var(--st-pending)", borderRadius: 12 }}
            >
              <span className="pulse-dot h-2 w-2 shrink-0 rounded-full" style={{ background: "var(--st-pending)" }} aria-hidden="true" />
              <p className="flex-1 truncate text-[15px] font-semibold">{proposalConclusion(pendingSet.proposal)}</p>
              <button
                type="button"
                disabled={respondMut.isPending}
                onClick={() => respondMut.mutate({ setId: pendingSet.id, accept: true })}
                className="pressable min-h-12 shrink-0 px-3 text-sm font-bold disabled:opacity-50"
                style={{ background: "var(--cta-bg)", color: "var(--cta-ink)", borderRadius: 12 }}
              >
                接受
              </button>
              <button
                type="button"
                disabled={respondMut.isPending}
                onClick={() => respondMut.mutate({ setId: pendingSet.id, accept: false })}
                className="glass-btn pressable min-h-12 shrink-0 px-3 text-sm font-medium disabled:opacity-50"
              >
                忽略
              </button>
            </div>
          ) : lastAccepted ? (
            <div
              className="flex min-h-11 items-center gap-3 px-3"
              style={{ background: "var(--glass-l1-bg)", border: "var(--glass-l1-border)", borderLeft: "3px solid var(--st-maintain)", borderRadius: 12 }}
            >
              <p className="num flex-1 truncate text-[15px] font-semibold">
                <span style={{ color: "var(--st-maintain)" }}>✓ 已应用：</span>
                {lastAccepted.appliedNote}
              </p>
              <button
                type="button"
                onClick={() => setFeedbackSetId(lastAccepted.id)}
                className="pressable min-h-12 shrink-0 px-3 text-sm font-medium text-[var(--text-2)]"
              >
                撤销
              </button>
            </div>
          ) : null}
          {feedbackSetId !== restSet.id ? (
            <div>
              <button
                type="button"
                onClick={() => setFeedbackSetId(restSet.id)}
                className="min-h-12 w-full rounded-lg bg-[var(--glass-l1-bg)] px-4 py-2 text-sm font-bold border border-[var(--border)]"
              >
                给刚才这组写反馈，让 Muse 调整后续组
              </button>
              <p className="mt-1 text-center text-xs text-[var(--dim)]">
                也可以之后在下方组列表点「写感受」补。
              </p>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setFeedbackSetId(null)}
              className="min-h-10 w-full rounded-lg px-4 py-1.5 text-sm font-medium text-[var(--dim)]"
            >
              先不写反馈，收起
            </button>
          )}
        </section>
      ) : null}

      {(() => {
        const alert = current
          ? session.alerts.find((a) => !a.acknowledged && a.exerciseIdx === current.exerciseIdx)
          : null;
        if (!alert) return null;
        return (
          <div role="alert" className="rounded-xl border-2 border-[var(--st-stop)] bg-[rgba(227,106,106,0.10)] p-4 ">
            <p className="font-bold text-[var(--st-stop)]">
              Muse 曾建议停止同类动作：{alert.exerciseName}
            </p>
            <p className="mt-0.5 text-sm leading-relaxed text-[var(--st-stop)]">{alert.message}</p>
            <p className="mt-1 text-xs text-[var(--st-stop)]">
              这是你在前面确认过的提醒。确认身体没问题再继续这个动作；不舒服就跳过它，不要硬撑。
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              <button
                type="button"
                disabled={ackAlert.isPending}
                onClick={() => ackAlert.mutate(alert.id)}
                className="min-h-12 rounded-lg bg-[var(--st-stop)] px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                已知晓风险，确认继续本动作
              </button>
              <button
                type="button"
                disabled={logMut.isPending}
                onClick={() => {
                  for (const s of sets.filter(
                    (x) => x.exerciseIdx === alert.exerciseIdx && !x.done && !x.skipped,
                  )) {
                    logMut.mutate({
                      setId: s.id,
                      actualWeightKg: s.actualWeightKg,
                      actualReps: s.actualReps,
                      restSeconds: s.restSeconds,
                      done: false,
                      skipped: true,
                    });
                  }
                  ackAlert.mutate(alert.id);
                  buzz(30);
                }}
                className="min-h-12 rounded-lg bg-[var(--glass-l1-bg)] px-3 py-2 text-sm font-bold text-[var(--st-stop)] disabled:opacity-50 dark:text-red-300"
              >
                跳过本动作全部组
              </button>
            </div>
          </div>
        );
      })()}

      {current && !restActive ? (
        <section aria-label="当前组" className="glass-panel2 anim-enter p-4">
          <div className="flex items-baseline justify-between gap-2">
            <h2 className="text-[17px] font-semibold">{current.exerciseName}</h2>
            <p className="num text-[13px] text-[var(--text-2)]">
              第 {current.setIdx + 1} / {sets.filter((x) => x.exerciseIdx === current.exerciseIdx).length} 组 · 休息 {current.targetRestSeconds} 秒
              {current.warmup ? (
                <span className="ml-1.5 rounded bg-[var(--lime-18)] px-1.5 py-0.5 text-xs font-bold whitespace-nowrap text-[var(--lime)]">热身组</span>
              ) : null}
            </p>
          </div>
          {plan?.exercises[current.exerciseIdx]?.note ? (
            <details className="glass-inner mt-2 px-3 py-1.5">
              <summary className="cursor-pointer text-sm font-medium text-[var(--dim)]">
                动作要点（点开看，默认收起）
              </summary>
              <p className="py-1.5 text-sm leading-relaxed">
                {plan.exercises[current.exerciseIdx]?.note}
              </p>
            </details>
          ) : null}
          {isCardio ? (
            <>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <div>
                <label htmlFor="cur-dur" className="text-sm text-[var(--dim)]">时长（分钟）</label>
                <input
                  {...FIELDS.logSet.durationMin}
                  id="cur-dur"
                  inputMode="decimal"
                  value={cardioVal.dur}
                  onChange={(e) => setCardio({ dur: e.target.value })}
                  className="num mt-1 min-h-11 w-full glass-input px-2 text-center text-2xl font-bold"
                />
              </div>
              <div>
                <label htmlFor="cur-dist" className="text-sm text-[var(--dim)]">距离（km）</label>
                <input
                  {...FIELDS.logSet.distanceKm}
                  id="cur-dist"
                  inputMode="decimal"
                  value={cardioVal.dist}
                  onChange={(e) => setCardio({ dist: e.target.value })}
                  placeholder="可选"
                  className="num mt-1 min-h-11 w-full glass-input px-2 text-center text-2xl font-bold"
                />
              </div>
              <div>
                <label htmlFor="cur-pace" className="text-sm text-[var(--dim)]">配速（分/公里）</label>
                <input
                  {...FIELDS.logSet.pace}
                  id="cur-pace"
                  value={cardioVal.pace}
                  onChange={(e) => setCardio({ pace: e.target.value })}
                  placeholder={autoPace || "如 6:30"}
                  className="num mt-1 min-h-11 w-full glass-input px-2 text-center text-2xl font-bold"
                />
              </div>
              <p className="col-span-3 text-xs text-[var(--dim)]">
                配速留空时按时长÷距离自动算{autoPace ? `（当前约 ${autoPace}/公里）` : ""}，练完点「完成这一组」即可。
              </p>
            </div>
            <div className="mt-3">
              <p className="text-sm text-[var(--dim)]">喘息 / 说话程度（点选，随手记进备注）</p>
              <div className="mt-1 flex gap-2" role="group" aria-label="喘息说话程度">
                {["能轻松完整说话", "能说短句", "喘息明显难说话"].map((t) => (
                  <button
                    key={t}
                    type="button"
                    aria-pressed={talkLevel === t}
                    onClick={() => setTalkLevel(talkLevel === t ? "" : t)}
                    className={`min-h-12 flex-1 rounded-lg px-2 py-2 text-sm font-medium border ${
                      talkLevel === t
                        ? "bg-[var(--accent)] border-[var(--accent)] text-[var(--cta-ink)]"
                        : "bg-[var(--glass-l1-bg)] border-[var(--border)]"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
            </>
          ) : (
          <>
          <div className="mt-4 flex items-start gap-2">
            <div className="min-w-0 flex-[1.3]">
              <div className="overflow-hidden">
                <input
                  id="cur-weight"
                  inputMode="decimal"
                  value={weightIn}
                  onChange={(e) => setWeightIn(e.target.value)}
                  placeholder="—"
                  aria-label="重量公斤（点数字可直接输入）"
                  className={`glass-input num min-h-12 w-full min-w-0 px-1 text-center font-extrabold ${draftError.startsWith("重量") ? "input-error" : ""}`}
                  style={{ fontSize: stepFontSize(weightIn), lineHeight: "48px" }}
                />
              </div>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  aria-label="重量减 2.5 公斤"
                  className="glass-btn pressable min-h-12 flex-1 text-lg font-bold"
                  onClick={(e) => {
                    animPress(e.currentTarget);
                    if (weightIn.trim() === "") {
                      document.getElementById("cur-weight")?.focus();
                      return;
                    }
                    setWeightIn(String(Math.max(0, (Number(weightIn) || 0) - 2.5)));
                    animStepSlide(document.getElementById("cur-weight"), -1);
                  }}
                >
                  −
                </button>
                <span className="w-5 shrink-0 text-center text-[11px] text-[var(--text-3)]">kg</span>
                <button
                  type="button"
                  aria-label="重量加 2.5 公斤"
                  className="glass-btn pressable min-h-12 flex-1 text-lg font-bold"
                  onClick={(e) => {
                    animPress(e.currentTarget);
                    if (weightIn.trim() === "") {
                      document.getElementById("cur-weight")?.focus();
                      return;
                    }
                    setWeightIn(String((Number(weightIn) || 0) + 2.5));
                    animStepSlide(document.getElementById("cur-weight"), 1);
                  }}
                >
                  +
                </button>
              </div>
            </div>
            <span className="pt-3 text-2xl font-bold text-[var(--text-3)]" aria-hidden="true">×</span>
            <div className="min-w-0 flex-1">
              <div className="overflow-hidden">
                <input
                  id="cur-reps"
                  inputMode="numeric"
                  value={repsIn}
                  onChange={(e) => setRepsIn(e.target.value)}
                  aria-label="次数（点数字可直接输入）"
                  className={`glass-input num min-h-12 w-full min-w-0 px-1 text-center font-extrabold ${draftError.startsWith("次数") ? "input-error" : ""}`}
                  style={{ fontSize: stepFontSize(repsIn), lineHeight: "48px" }}
                />
              </div>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  aria-label="次数减 1"
                  className="glass-btn pressable min-h-12 flex-1 text-lg font-bold"
                  onClick={(e) => {
                    animPress(e.currentTarget);
                    setRepsIn(String(Math.max(0, (Number.parseInt(repsIn, 10) || 0) - 1)));
                    animStepSlide(document.getElementById("cur-reps"), -1);
                  }}
                >
                  −
                </button>
                <span className="w-5 shrink-0 text-center text-[11px] text-[var(--text-3)]">次</span>
                <button
                  type="button"
                  aria-label="次数加 1"
                  className="glass-btn pressable min-h-12 flex-1 text-lg font-bold"
                  onClick={(e) => {
                    animPress(e.currentTarget);
                    setRepsIn(String((Number.parseInt(repsIn, 10) || 0) + 1));
                    animStepSlide(document.getElementById("cur-reps"), 1);
                  }}
                >
                  +
                </button>
              </div>
            </div>
          </div>
          {draftError ? (
            <p className="mt-1 text-center text-[11px] font-medium text-[var(--st-stop)]" role="alert">{draftError}</p>
          ) : null}
          <p className="mt-1 text-center text-[11px] leading-4 text-[var(--text-3)]">
            {current.targetWeightKg == null ? (
              <>重量未设，点数字输入</>
            ) : weightIn !== String(current.targetWeightKg) || repsIn !== current.targetReps ? (
              <>
                <span className="mr-1 inline-block h-1.5 w-1.5 rounded-full align-middle" style={{ background: "var(--lime)" }} aria-hidden="true" />
                <span style={{ color: "var(--lime)" }}>
                  计划 {current.targetWeightKg} × {current.targetReps}
                </span>
                {" · "}
                <button
                  type="button"
                  className="underline underline-offset-2"
                  onClick={() => {
                    setWeightIn(String(current.targetWeightKg));
                    setRepsIn(current.targetReps);
                    setDraftError("");
                  }}
                >
                  回到计划值 ↺
                </button>
              </>
            ) : (
              <>点数字可直接输入</>
            )}
          </p>
          {current.targetWeightKg == null && carriedWeight != null ? (
            <div className="mt-2 flex flex-wrap justify-center gap-1.5" role="group" aria-label="沿用上组重量快捷选择">
              {[
                { label: `沿用上组 ${carriedWeight}kg`, v: carriedWeight },
                { label: `${carriedWeight - 5}kg (-5)`, v: carriedWeight - 5 },
                { label: `${carriedWeight - 2.5}kg (-2.5)`, v: carriedWeight - 2.5 },
                { label: `${carriedWeight + 2.5}kg (+2.5)`, v: carriedWeight + 2.5 },
                { label: `${carriedWeight + 5}kg (+5)`, v: carriedWeight + 5 },
              ].map((c) => (
                <button
                  key={c.label}
                  type="button"
                  aria-pressed={Number(weightIn) === c.v}
                  onClick={() => setWeightIn(String(c.v))}
                  className={`pressable min-h-12 rounded-full px-3 py-2 text-sm font-bold border ${
                    Number(weightIn) === c.v
                      ? "bg-[var(--accent)] border-[var(--accent)] text-[var(--cta-ink)]"
                      : "bg-[var(--glass-l1-bg)] border-[var(--border)]"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          ) : null}
          </>
          )}
          {/* D2 建议卡（84px 条）：与 D3 的 44px 槽位同一张卡，只认服务端状态 */}
          {!isCardio && pendingSet && pendingSet.proposal ? (
            <div
              className="anim-card-in mt-3 flex items-center gap-3 p-3"
              style={{ background: "var(--glass-l1-bg)", border: "var(--glass-l1-border)", borderLeft: "3px solid var(--st-pending)", borderRadius: 24, minHeight: 84 }}
            >
              <span className="pulse-dot h-2 w-2 shrink-0 rounded-full" style={{ background: "var(--st-pending)" }} aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <p className="text-base font-semibold leading-snug">{proposalConclusion(pendingSet.proposal)}</p>
              </div>
              <div className="flex shrink-0 gap-3">
                <button
                  type="button"
                  disabled={respondMut.isPending}
                  onClick={() => respondMut.mutate({ setId: pendingSet.id, accept: true })}
                  className="pressable min-h-12 px-4 text-sm font-bold disabled:opacity-50"
                  style={{ background: "var(--cta-bg)", color: "var(--cta-ink)", borderRadius: 12, minWidth: 48 }}
                >
                  接受
                </button>
                <button
                  type="button"
                  disabled={respondMut.isPending}
                  onClick={() => respondMut.mutate({ setId: pendingSet.id, accept: false })}
                  className="glass-btn pressable min-h-12 px-4 text-sm font-medium disabled:opacity-50"
                  style={{ minWidth: 48 }}
                >
                  忽略
                </button>
              </div>
            </div>
          ) : null}
          {feedbackFirstActive ? (
            <div className="mt-3">
              <p className="text-center text-sm font-medium" style={{ color: "var(--lime)" }}>
                先填下面的反馈 — 提交时才会记录这一组
              </p>
              <div className="mt-1 text-center">
                <button
                  type="button"
                  disabled={logMut.isPending}
                  onClick={() => {
                    setFeedbackFirstId(null);
                    completeCurrent();
                  }}
                  data-action-name="logset"
                  className="text-link-48 text-sm disabled:opacity-50"
                >
                  不填了，直接记录这一组
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="mt-3 flex items-center gap-3">
                <button
                  type="button"
                  disabled={logMut.isPending}
                  onClick={completeCurrent}
                  data-action-name="logset"
                  className="cta-lime pressable min-h-14 flex-1 px-4 text-lg disabled:opacity-50"
                >
                  {logMut.isPending ? "记录中…" : "完成"}
                </button>
                <button
                  type="button"
                  disabled={logMut.isPending}
                  onClick={() =>
                    runLog(
                      {
                        setId: current.id,
                        actualWeightKg: current.actualWeightKg,
                        actualReps: current.actualReps,
                        restSeconds: current.restSeconds,
                        done: false,
                        skipped: true,
                      },
                      () => buzz(30),
                    )
                  }
                  className="glass-btn pressable min-h-12 px-4 text-sm font-medium"
                >
                  跳过
                </button>
              </div>
              {!isCardio ? (
                <div className="mt-1 text-center">
                  <button
                    type="button"
                    disabled={logMut.isPending}
                    onClick={startFeedbackFirst}
                    className="text-link-48 text-sm disabled:opacity-50"
                  >
                    填感受再记
                  </button>
                </div>
              ) : null}
            </>
          )}
          {(() => {
            const next = sets.find((x) => !x.done && !x.skipped && x.id !== current.id);
            return next ? (
              <p className="mt-2 text-sm text-[var(--dim)]">
                下一组：{next.exerciseName} 第 {next.setIdx + 1} 组{next.warmup ? "（热身组）" : ""} · {fmtPair(next.targetWeightKg, next.targetReps)} · 休息 {next.targetRestSeconds} 秒
              </p>
            ) : null;
          })()}
        </section>
      ) : restActive ? null : (
        <section className="glass-card p-4 text-center">
          <p className="text-base font-semibold">计划内的组都处理完了</p>
          <p className="mt-1 text-sm text-[var(--dim)]">可以结束训练生成总结，或在下面把跳过的组找回来。</p>
        </section>
      )}

      {restToast ? <Toast text={restToast} onClose={() => setRestToast("")} /> : null}
      {feedbackSet ? (
        <div ref={feedbackWrapRef} style={restActive ? { maxHeight: 292, overflowY: "auto" } : undefined}>
        <FeedbackForm
          key={feedbackSet.id}
          setLog={displayFeedbackSet ?? feedbackSet}
          preRecord={!!(feedbackFirstActive && feedbackSet.id === feedbackFirstId)}
          recordFirst={
            feedbackFirstActive && feedbackSet.id === feedbackFirstId
              ? recordFirstForFeedback
              : undefined
          }
          onNoteDirtyChange={(d) => {
            noteDirtyRef.current = d;
          }}
          proposalExpired={pendingExpired(feedbackSet, sets)}
          onDone={(info) => {
            if (info.status === "accepted") {
              setBanner({ title: "✓ 已应用调整，后续组目标已更新", body: info.appliedNote });
            } else if (info.status === "undone") {
              setBanner({ title: "已撤销这条调整", body: info.appliedNote });
            } else if (info.status === "dismissed") {
              setBanner({ title: "已忽略这条建议", body: "后续组保持原计划，没有改动。" });
            } else if (info.status === "pending") {
              setBanner({ title: "Muse 的调整建议到了，等你确认", body: info.appliedNote });
            } else {
              setBanner({ title: "这一组已记录", body: info.appliedNote });
            }
          }}
        />
        </div>
      ) : null}

      <div className="space-y-3">
        {groups.map((g) => {
          const gAlert = session.alerts.find(
            (a) => a.exerciseIdx === g.items[0]?.exerciseIdx,
          );
          return (
          <section
            key={g.name + g.items[0]?.id}
            className={`glass-card p-4 ${gAlert && !gAlert.acknowledged ? "border-2 border-[var(--st-stop)]" : ""}`}
          >
            <h3 className="font-semibold">
              {g.name}
              {gAlert ? (
                <span className="ml-2 rounded bg-[var(--st-stop)] px-1.5 py-0.5 text-xs font-bold text-white">
                  {gAlert.acknowledged ? "停止提醒·已确认" : "停止提醒"}
                </span>
              ) : null}
            </h3>
            {gAlert ? (
              <p className="mt-1 text-xs leading-relaxed text-[var(--st-stop)]">{gAlert.message}</p>
            ) : null}
            <div className="mt-2 divide-y divide-[var(--border)]">
              {g.items.map((s) => (
                <div key={s.id} className="flex items-center gap-2 py-2 text-sm">
                  <span
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                      s.done
                        ? "bg-[var(--green)] text-white"
                        : s.skipped
                          ? "bg-[var(--surface2)] text-[var(--dim)]"
                          : current?.id === s.id
                            ? "bg-[var(--accent)] text-[var(--cta-ink)]"
                            : "bg-[var(--surface2)] text-[var(--dim)]"
                    }`}
                  >
                    {s.done ? "✓" : s.setIdx + 1}
                  </span>
                  <span className="num flex-1">
                    {s.warmup ? (
                      <span className="mr-1.5 rounded bg-[var(--lime-18)] px-1.5 py-0.5 text-xs font-bold text-[var(--lime)]">热身</span>
                    ) : null}
                    {fmtPair(s.targetWeightKg, s.targetReps)}
                    {s.done && (s.actualWeightKg !== s.targetWeightKg || s.actualReps !== s.targetReps)
                      ? ` → 实际 ${fmtPair(s.actualWeightKg ?? s.targetWeightKg, s.actualReps ?? s.targetReps)}`
                      : ""}
                  </span>
                  <span className="num text-[var(--dim)]">
                    {s.restSeconds != null
                      ? `休 ${s.restSeconds}s`
                      : s.skipped
                        ? s.skippedBy === "ai"
                          ? "已跳过（AI 建议·已确认）"
                          : "已跳过（本人决定）"
                        : ""}
                  </span>
                  {s.done && !hasFeedback(s) ? (
                    <span className="shrink-0 rounded bg-[var(--surface2)] px-1.5 py-0.5 text-xs text-[var(--dim)]">未填感受</span>
                  ) : null}
                  {adjudicationInterrupted(s) ? (
                    <span
                      className="shrink-0 rounded px-1.5 py-0.5 text-xs font-semibold"
                      style={{ background: "rgba(229,192,91,0.18)", color: "var(--st-pending)" }}
                    >
                      裁决被中断
                    </span>
                  ) : null}
                  {s.aiSuggestion ? (
                    <button
                      type="button"
                      className="min-h-9 rounded-md bg-[var(--surface2)] px-2 py-1 text-xs font-medium"
                      onClick={() => setFeedbackSetId(s.id)}
                    >
                      看建议
                    </button>
                  ) : s.done ? (
                    <button
                      type="button"
                      className="min-h-9 rounded-md bg-[var(--surface2)] px-2 py-1 text-xs font-medium"
                      onClick={() => setFeedbackSetId(s.id)}
                    >
                      {adjudicationInterrupted(s) ? "继续裁决" : "写感受"}
                    </button>
                  ) : null}
                  {s.skipped ? (
                    <button
                      type="button"
                      aria-label={`恢复第 ${s.setIdx + 1} 组（需要两次确认）`}
                      className="min-h-12 rounded-md px-2 py-1 text-xs font-medium text-[var(--dim)]"
                      onClick={() => setConfirmRestoreId(s.id)}
                    >
                      {s.skippedBy === "ai" ? "我知道，仍要做此组" : "恢复此组"}
                    </button>
                  ) : s.done ? (
                    <button
                      type="button"
                      aria-label={`撤销第 ${s.setIdx + 1} 组`}
                      className="min-h-12 rounded-md px-2 py-1 text-xs font-medium text-[var(--dim)]"
                      onClick={() =>
                        logMut.mutate({
                          setId: s.id,
                          actualWeightKg: s.actualWeightKg,
                          actualReps: s.actualReps,
                          restSeconds: null,
                          done: false,
                          skipped: false,
                        })
                      }
                    >
                      撤销
                    </button>
                  ) : null}
                </div>
              ))}
            </div>
            {g.items.some((s) => s.aiSuggestion) ? (
              <div className="mt-2 space-y-1">
                {g.items.filter((s) => s.aiSuggestion).map((s) => (
                  <p key={s.id} className="rounded-lg bg-[var(--surface2)] px-3 py-2 text-xs leading-relaxed">
                    <span className="font-semibold text-[var(--accent)]">第 {s.setIdx + 1} 组后 · Muse：</span>
                    {shortSuggestion(s.aiSuggestion)}
                    {s.proposalStatus === "pending" ? (
                      pendingExpired(s, sets) ? (
                        <span className="mt-0.5 block font-semibold text-[var(--dim)]">这条建议未处理且已失效（后续组已练完），只作记录保留，不会改动任何组。</span>
                      ) : (
                        <span className="mt-0.5 block font-semibold text-[var(--accent)]">有待确认的调整建议，点上方这组的「看建议」处理。不处理不挡训练，但后续组练完后它会失效。</span>
                      )
                    ) : null}
                    {s.proposalStatus === "accepted" && s.appliedNote ? (
                      <span className="mt-0.5 block font-medium text-[var(--green)]">{s.appliedNote}（可点「看建议」撤销）</span>
                    ) : null}
                    {s.proposalStatus === "dismissed" ? (
                      <span className="mt-0.5 block text-[var(--dim)]">这条建议已被忽略，后续组未改动。</span>
                    ) : null}
                    {s.proposalStatus === "undone" ? (
                      <span className="mt-0.5 block text-[var(--dim)]">这条调整已撤销，后续组已恢复。</span>
                    ) : null}
                  </p>
                ))}
              </div>
            ) : null}
          </section>
          );
        })}
      </div>

      <div className="pb-2 pt-1">
        <button
          type="button"
          onClick={() => setConfirmFinish(true)}
          className="glass-btn pressable min-h-12 w-full px-4 text-base font-bold"
        >
          结束训练，生成总结
        </button>
        {finishMut.isError ? <p className="mt-2 text-sm text-red-600">结束失败，请重试。</p> : null}
      </div>
      <Sheet open={confirmFinish} title="结束今天的训练？" onClose={() => setConfirmFinish(false)}>
        <p className="text-sm leading-relaxed text-[var(--dim)]">结束后会生成本次总结与下次建议，没记录的组会按未完成留在明细里。</p>
        <button
          type="button"
          disabled={finishMut.isPending}
          onClick={() => finishMut.mutate()}
          className="cta-lime pressable mt-4 min-h-14 w-full px-4 text-base disabled:opacity-50"
        >
          {finishMut.isPending ? "正在生成总结…" : "确认结束并生成总结"}
        </button>
        <button
          type="button"
          onClick={() => setConfirmFinish(false)}
          className="glass-btn pressable mt-3 min-h-12 w-full px-4 text-sm font-medium"
        >
          再练会儿
        </button>
      </Sheet>
      <Sheet
        open={confirmRestoreId != null}
        title="仍要做这一组？"
        onClose={() => setConfirmRestoreId(null)}
      >
        <p className="text-sm leading-relaxed text-[var(--dim)]">
          这组之前被跳过了。恢复后它会回到自动流程，成为当前要做的组。
        </p>
        <button
          type="button"
          className="cta-lime pressable mt-4 min-h-14 w-full px-4 text-base"
          onClick={() => {
            const target = sets.find((x) => x.id === confirmRestoreId);
            setConfirmRestoreId(null);
            if (target) {
              logMut.mutate({
                setId: target.id,
                actualWeightKg: target.actualWeightKg,
                actualReps: target.actualReps,
                restSeconds: null,
                done: false,
                skipped: false,
              });
            }
          }}
        >
          我知道，仍要做此组
        </button>
      </Sheet>
    </div>
  );
}

/* ---------------- 计划总览与编辑 ---------------- */

function PlanOverview({
  date,
  plan,
  onEdit,
}: {
  date: string;
  plan: PlanT;
  onEdit: () => void;
}) {
  const queryClient = useQueryClient();
  const start = useMutation({
    mutationFn: () => api.startSession({ date }),
    // 失败已由 isError 文案就地提示，onError 标记已处理，避免底部通知重复
    onError: () => {},
    onSuccess: () => {
      buzz(50);
      void queryClient.invalidateQueries();
    },
  });
  const del = useMutation({
    mutationFn: () => api.deletePlan({ date }),
    onSuccess: () => void queryClient.invalidateQueries(),
  });
  const [testDayNote, setTestDayNote] = useState("");
  const toggleTestDay = useMutation({
    // 只改测试日这一列的专用动作：不走 savePlan，不碰任何会话与逐组记录
    mutationFn: (on: boolean) => api.setPlanTestDay({ date, testDay: on }),
    onSuccess: (data) => {
      buzz(30);
      setTestDayNote(
        `已保存：测试日 ${plan.testDay ? "开" : "关"} → ${data.testDay ? "开" : "关"}。只改了这个开关，计划组表和任何训练记录都没动。`,
      );
      void queryClient.invalidateQueries();
    },
    onError: () => setTestDayNote("测试日开关保存失败，请重试；当前状态没有变。"),
  });
  const fillWeight = useMutation({
    mutationFn: (args: { exerciseIdx: number; setIdx: number; weightKg: number }) =>
      api.updatePlanSetWeight({ date, ...args }),
    onSuccess: () => void queryClient.invalidateQueries(),
  });
  const [fillDraft, setFillDraft] = useState<{ key: string; value: string } | null>(null);
  // 紧凑行展开的是哪个动作（动作要点与逐组明细默认收起，点行展开）
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  // 上次归档一行：取历史列表里最近一次已上传的 Drive 文件名（服务端数据）
  const sessionsQ = useQuery({ queryKey: ["sessions"], queryFn: () => api.listSessions({ limit: 50 }) });
  const lastArchived = (sessionsQ.data?.sessions ?? []).find((x) => x.driveStatus === "uploaded") ?? null;
  const [confirmDelete, setConfirmDelete] = useState(false);
  // 总组数只计工作组；热身组单列展示、不计入
  const totalSets = plan.exercises.reduce((a, e) => a + e.sets.filter((s) => !s.warmup).length, 0);
  const totalWarmups = plan.exercises.reduce((a, e) => a + e.sets.filter((s) => s.warmup).length, 0);
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h2 className="text-2xl font-bold leading-8">{plan.title}</h2>
          <p className="num mt-1 flex flex-wrap items-center gap-2 text-sm text-[var(--dim)]">
            {plan.testDay ? (
              <span
                className="rounded-full px-2 py-0.5 text-[11px] font-semibold"
                style={{ border: "1px solid var(--st-pending)", color: "var(--st-pending)", borderRadius: 999 }}
              >
                测试日
              </span>
            ) : null}
            <span>{totalSets} 组 · {plan.exercises.length} 个动作{totalWarmups ? ` · 热身 ${totalWarmups} 组（不计入）` : ""}</span>
          </p>
          <div className="mt-2 flex items-center gap-2">
            <button
              type="button"
              role="switch"
              aria-checked={plan.testDay}
              aria-label="测试日开关"
              disabled={toggleTestDay.isPending}
              onClick={() => toggleTestDay.mutate(!plan.testDay)}
              className={`min-h-9 rounded-lg px-3 py-1.5 text-xs font-bold ${
                plan.testDay ? "bg-[var(--accent)] text-[var(--cta-ink)]" : "bg-[var(--surface2)] text-[var(--dim)]"
              }`}
            >
              测试日 {plan.testDay ? "开" : "关"}
            </button>
            {plan.testDay ? (
              <span className="text-xs text-[var(--dim)]">开时 Muse 只给建议，不降测试重量、不减组、不换测试动作</span>
            ) : null}
          </div>
          {testDayNote ? (
            <p className="mt-1 text-xs font-medium text-[var(--green)]" role="status">{testDayNote}</p>
          ) : null}
          {toggleTestDay.isPending ? (
            <p className="mt-1 text-xs text-[var(--dim)]" role="status">正在保存测试日开关…</p>
          ) : null}
        </div>
        <div className="flex shrink-0 gap-1">
          <button type="button" onClick={onEdit} className="min-h-10 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-medium">
            编辑计划
          </button>
          {confirmDelete ? (
            <button
              type="button"
              onClick={() => del.mutate()}
              className="min-h-10 rounded-lg bg-[var(--st-stop)] px-3 py-2 text-sm font-medium text-white"
            >
              确认删除
            </button>
          ) : (
            <button
              type="button"
              aria-label="删除这一天的计划"
              onClick={() => setConfirmDelete(true)}
              className="min-h-10 rounded-lg px-2 py-2 text-sm text-[var(--dim)]"
            >
              删除
            </button>
          )}
        </div>
      </div>
      {/* 计划区定高 453px（设计 spec §C.1 D1）：每动作一条 60px 紧凑行，
          超出只在本区内滚动；CTA 与上次归档行在本区之外固定不动。
          注意：这里不能用 overscroll-behavior: contain——本区占主屏大半，
          列表滚到边界后手势会被 contain 吞掉、传不到外层页面，矮屏上
          页面本身需要滚动时就会出现「上下滑动没反应」。保持默认 auto，
          让滚动在边界处链回页面。 */}
      <div
        className="space-y-2 overflow-y-auto"
        style={{ height: 453, overscrollBehavior: "auto", touchAction: "pan-y" }}
        aria-label="今日计划动作列表"
      >
        {plan.exercises.map((ex, i) => {
          const open = openIdx === i;
          return (
            <section key={`${ex.name}-${i}`} className="glass-card overflow-hidden">
              <button
                type="button"
                aria-expanded={open}
                aria-label={`${ex.name}，共 ${ex.sets.filter((s) => !s.warmup).length} 个工作组${ex.sets.some((s) => s.warmup) ? `、${ex.sets.filter((s) => s.warmup).length} 个热身组` : ""}，${open ? "收起" : "展开"}动作要点与逐组明细`}
                onClick={() => setOpenIdx(open ? null : i)}
                className="flex h-[60px] w-full flex-col justify-center px-4 text-left"
              >
                <span className="flex w-full items-baseline justify-between gap-2">
                  <span className="min-w-0 truncate text-base font-semibold">{ex.name}</span>
                  <span className="num shrink-0 text-sm text-[var(--dim)]">{ex.sets.filter((s) => !s.warmup).length} 组{ex.sets.some((s) => s.warmup) ? ` +${ex.sets.filter((s) => s.warmup).length} 热身` : ""}</span>
                </span>
                <span className="num mt-0.5 w-full truncate text-[13px] leading-[18px] text-[var(--text-3)]">
                  {exerciseSummary(ex)}
                </span>
              </button>
              {open ? (
                <div className="px-4 pb-3">
                  {ex.note ? (
                    <p className="text-sm leading-relaxed text-[var(--dim)]">
                      <span className="font-medium text-[var(--text-2)]">动作要点：</span>
                      {ex.note}
                    </p>
                  ) : null}
                  <div className="mt-1 divide-y divide-[var(--border)]">
                    {ex.sets.map((s, si) => (
                      <div key={si} className="num flex items-center justify-between gap-2 py-1.5 text-sm">
                        <span className="text-[var(--dim)]">
                          {s.warmup ? (
                            <span className="rounded bg-[var(--lime-18)] px-1.5 py-0.5 text-xs font-bold text-[var(--lime)]">热身</span>
                          ) : (
                            `第 ${si + 1 - ex.sets.slice(0, si).filter((x) => x.warmup).length} 组`
                          )}
                        </span>
                        {s.weightKg == null && !/^\d+$/.test(s.reps.trim()) ? (
                          <span className="font-medium">{s.reps}</span>
                        ) : s.weightKg == null ? (
                          <span className="flex items-center gap-1">
                            <input
                              {...FIELDS.updatePlanSetWeight.weightKg}
                              aria-label={`${ex.name} 第 ${si + 1} 组补填重量公斤`}
                              inputMode="decimal"
                              placeholder="未设，填 kg"
                              value={fillDraft?.key === `${i}-${si}` ? fillDraft.value : ""}
                              onChange={(e) => setFillDraft({ key: `${i}-${si}`, value: e.target.value })}
                              className="num min-h-9 w-32 rounded-lg border border-[var(--accent)] bg-[var(--glass-l1-bg)] px-2 py-1 text-base"
                            />
                            <button
                              type="button"
                              disabled={fillWeight.isPending || !(fillDraft?.key === `${i}-${si}` && fillDraft.value.trim())}
                              onClick={() =>
                                fillWeight.mutate({ exerciseIdx: i, setIdx: si, weightKg: Number(fillDraft?.value) })
                              }
                              className="min-h-9 rounded-lg bg-[var(--accent)] px-2 py-1 text-xs font-bold text-white disabled:opacity-40"
                            >
                              填入
                            </button>
                          </span>
                        ) : (
                          <span className="font-medium">{fmtPair(s.weightKg, s.reps)}</span>
                        )}
                        <span className="text-[var(--dim)]">休息 {s.restSeconds}s</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </section>
          );
        })}
      </div>
      <button
        type="button"
        disabled={start.isPending}
        onClick={() => start.mutate()}
        className="cta-lime pressable min-h-14 w-full px-4 text-lg disabled:opacity-50"
      >
        {start.isPending ? "开始中…" : "开始今日训练"}
      </button>
      <p className="num mt-2 text-[13px] text-[var(--text-3)]">
        {lastArchived
          ? `上次归档：${lastArchived.driveFileName ?? `健身日志-${lastArchived.date}.md`}`
          : "今日还没有日志"}
      </p>
      {start.isError ? <p className="text-sm text-red-600">开始失败，请重试。</p> : null}
    </div>
  );
}

type DraftExercise = {
  name: string;
  note: string;
  sets: { weightKg: string; reps: string; restSeconds: string; warmup: boolean }[];
};

function PlanEditor({
  date,
  initial,
  onClose,
}: {
  date: string;
  initial: PlanT | null;
  onClose: () => void;
}) {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState(initial?.title ?? "");
  const [testDay, setTestDay] = useState<boolean>(
    initial?.testDay ?? /摸底|测试/.test(initial?.title ?? ""),
  );
  const [exercises, setExercises] = useState<DraftExercise[]>(
    initial
      ? initial.exercises.map((e) => ({
          name: e.name,
          note: e.note,
          sets: e.sets.map((s) => ({
            weightKg: s.weightKg != null ? String(s.weightKg) : "",
            reps: s.reps,
            restSeconds: String(s.restSeconds),
            warmup: s.warmup,
          })),
        }))
      : [{ name: "", note: "", sets: [{ weightKg: "", reps: "8", restSeconds: "90", warmup: false }] }],
  );
  const [error, setError] = useState("");

  const save = useMutation({
    mutationFn: (payload: { title: string; exercises: ExerciseT[] }) =>
      api.savePlan({ date, title: payload.title, testDay, exercises: payload.exercises }),
    onSuccess: () => {
      buzz(40);
      void queryClient.invalidateQueries();
      onClose();
    },
    onError: () => setError("保存失败，请检查每一组都填了次数后重试。"),
  });

  const updateEx = (i: number, patch: Partial<DraftExercise>) =>
    setExercises((prev) => prev.map((e, idx) => (idx === i ? { ...e, ...patch } : e)));
  const updateSet = (i: number, si: number, field: "weightKg" | "reps" | "restSeconds", value: string) =>
    setExercises((prev) =>
      prev.map((e, idx) =>
        idx === i ? { ...e, sets: e.sets.map((s, j) => (j === si ? { ...s, [field]: value } : s)) } : e,
      ),
    );

  const doSave = () => {
    if (!title.trim()) {
      setError("先给这份计划起个名字。");
      return;
    }
    const cleaned: ExerciseT[] = [];
    for (const e of exercises) {
      if (!e.name.trim()) {
        setError("每个动作都要有名字。");
        return;
      }
      cleaned.push({
        name: e.name.trim(),
        note: e.note.trim(),
        sets: e.sets.map((s) => ({
          weightKg: s.weightKg.trim() === "" ? null : Number(s.weightKg),
          reps: s.reps.trim() || "8",
          restSeconds: Math.max(0, Number.parseInt(s.restSeconds, 10) || 0),
          warmup: s.warmup,
        })),
      });
    }
    setError("");
    save.mutate({ title: title.trim(), exercises: cleaned });
  };

  const inputCls = "min-h-10 rounded-lg border border-[var(--border)] bg-[var(--glass-l1-bg)] px-2 py-2 text-sm";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">{initial ? "编辑计划" : "新建计划"} · {dateLabel(date)}</h2>
        <button type="button" onClick={onClose} className="min-h-10 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm">
          取消
        </button>
      </div>
      <div>
        <label htmlFor="plan-title" className="text-sm text-[var(--dim)]">计划名称</label>
        <input
          {...FIELDS.savePlan.title}
          id="plan-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="例如：全身力量 A"
          className={`${inputCls} mt-1 w-full text-base`}
        />
      </div>
      <div className="flex items-center justify-between glass-card p-4">
        <div>
          <p className="text-sm font-semibold">测试日（摸底日）</p>
          <p className="mt-0.5 text-xs leading-relaxed text-[var(--dim)]">
            打开后 Muse 只给建议：不降测试重量、不减组、不替换测试动作。标题或动作含「摸底/测试」时默认打开。
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={testDay}
          aria-label="测试日开关"
          onClick={() => setTestDay((v) => !v)}
          className={`min-h-11 shrink-0 rounded-lg px-4 py-2 text-sm font-bold ${
            testDay ? "bg-[var(--accent)] text-[var(--cta-ink)]" : "bg-[var(--surface2)]"
          }`}
        >
          {testDay ? "已开启" : "开启"}
        </button>
      </div>
      {exercises.map((ex, i) => (
        <section key={i} className="glass-card p-4">
          <div className="flex items-center gap-2">
            <input
              {...FIELDS.savePlan.exercises.name}
              aria-label={`动作 ${i + 1} 名称`}
              value={ex.name}
              onChange={(e) => updateEx(i, { name: e.target.value })}
              placeholder="动作名称，如 深蹲"
              className={`${inputCls} flex-1 font-medium`}
            />
            <button
              type="button"
              aria-label={`删除动作 ${i + 1}`}
              className="min-h-10 rounded-lg px-2 text-sm text-red-600"
              onClick={() => setExercises((prev) => prev.filter((_, idx) => idx !== i))}
            >
              删除
            </button>
          </div>
          <input
            aria-label={`动作 ${i + 1} 备注`}
            value={ex.note}
            onChange={(e) => updateEx(i, { note: e.target.value })}
            placeholder="备注（可选）：动作要点、安全提醒…"
            className={`${inputCls} mt-2 w-full`}
          />
          <div className="mt-2 space-y-2">
            {ex.sets.map((s, si) => (
              <div key={si} className="flex flex-wrap items-center gap-2">
                <span className="num w-10 shrink-0 text-sm text-[var(--dim)]">{s.warmup ? "热身" : `组${si + 1}`}</span>
                <input
                  aria-label={`动作 ${i + 1} 第 ${si + 1} 组重量公斤`}
                  inputMode="decimal"
                  value={s.weightKg}
                  onChange={(e) => updateSet(i, si, "weightKg", e.target.value)}
                  placeholder="kg"
                  className={`${inputCls} num w-28 shrink-0 text-base`}
                />
                <span className="text-[var(--dim)]">×</span>
                <input
                  {...FIELDS.savePlan.exercises.sets.reps}
                  aria-label={`动作 ${i + 1} 第 ${si + 1} 组次数`}
                  value={s.reps}
                  onChange={(e) => updateSet(i, si, "reps", e.target.value)}
                  placeholder="次数"
                  className={`${inputCls} num w-20 shrink-0`}
                />
                <input
                  {...FIELDS.savePlan.exercises.sets.restSeconds}
                  aria-label={`动作 ${i + 1} 第 ${si + 1} 组休息秒数`}
                  inputMode="numeric"
                  value={s.restSeconds}
                  onChange={(e) => updateSet(i, si, "restSeconds", e.target.value)}
                  placeholder="休息s"
                  className={`${inputCls} num w-20 shrink-0`}
                />
                <button
                  type="button"
                  aria-pressed={s.warmup}
                  aria-label={`动作 ${i + 1} 第 ${si + 1} 组${s.warmup ? "取消热身标记" : "标为热身组"}`}
                  className={`min-h-10 shrink-0 rounded-lg px-2 text-xs font-bold ${
                    s.warmup ? "bg-[var(--lime-18)] text-[var(--lime)]" : "bg-[var(--surface2)] text-[var(--dim)]"
                  }`}
                  onClick={() =>
                    updateEx(i, { sets: ex.sets.map((x, j) => (j === si ? { ...x, warmup: !x.warmup } : x)) })
                  }
                >
                  热身
                </button>
                <button
                  type="button"
                  aria-label={`删除动作 ${i + 1} 第 ${si + 1} 组`}
                  className="min-h-10 px-1 text-sm text-[var(--dim)]"
                  onClick={() => updateEx(i, { sets: ex.sets.filter((_, j) => j !== si) })}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            className="mt-2 min-h-10 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-medium"
            onClick={() => {
              const last = ex.sets[ex.sets.length - 1] ?? { weightKg: "", reps: "8", restSeconds: "90", warmup: false };
              updateEx(i, { sets: [...ex.sets, { ...last }] });
            }}
          >
            + 加一组
          </button>
        </section>
      ))}
      <button
        type="button"
        className="min-h-11 w-full rounded-lg border border-dashed border-[var(--border)] px-4 py-2 text-sm font-medium"
        onClick={() =>
          setExercises((prev) => [...prev, { name: "", note: "", sets: [{ weightKg: "", reps: "8", restSeconds: "90", warmup: false }] }])
        }
      >
        + 加一个动作
      </button>
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button
        type="button"
        disabled={save.isPending}
        onClick={doSave}
        className="min-h-12 w-full rounded-lg bg-[var(--accent)] px-4 text-base font-bold text-white disabled:opacity-50"
      >
        {save.isPending ? "保存中…" : "保存计划"}
      </button>
    </div>
  );
}

/* ---------------- 训练总结 ---------------- */

function SessionSummary({ session, sets }: { session: SessionT; sets: SetLog[] }) {
  const queryClient = useQueryClient();
  const groups = groupSets(sets);
  // 组数口径与服务端一致：只计工作组，热身组另计
  const doneSets = sets.filter((s) => s.done && !s.warmup);
  const totalWorkSets = sets.filter((s) => !s.warmup).length;
  const warmupDone = sets.filter((s) => s.warmup && s.done).length;
  const warmupTotal = sets.filter((s) => s.warmup).length;
  // 结果数字一律取服务端：训练量/时长/组数来自 listSessions 的服务端结算，
  // 平均休息逐字取自服务端生成的 summaryMd；本地只做展示派生（顶组取已完成组里的最大实际重量行）。
  const sessionsQ = useQuery({ queryKey: ["sessions"], queryFn: () => api.listSessions({ limit: 50 }) });
  const serverRow = (sessionsQ.data?.sessions ?? []).find((x) => x.id === session.id) ?? null;
  const volume = serverRow?.volumeKg ?? Math.round(sets.reduce((a, s) => a + (s.warmup ? 0 : setVolume(s)), 0));
  const durationMin = serverRow?.durationMin ?? null;
  const avgRestFromMd = (() => {
    const m = session.summaryMd?.match(/平均组间休息（仅力量组）：(\d+) 秒/);
    return m ? Number(m[1]) : null;
  })();
  const rests = sets
    .filter((s) => s.restSeconds != null && s.targetRestSeconds > 0)
    .map((s) => s.restSeconds ?? 0);
  const avgRest = avgRestFromMd ?? (rests.length ? Math.round(rests.reduce((a, b) => a + b, 0) / rests.length) : null);
  const topSet = doneSets
    .filter((s) => s.actualWeightKg != null)
    .sort((a, b) => (b.actualWeightKg ?? 0) - (a.actualWeightKg ?? 0))[0] ?? null;
  const regen = useMutation({
    mutationFn: () => api.regenerateAdvice({ sessionId: session.id }),
    onSuccess: () => void queryClient.invalidateQueries(),
  });
  const undoMut = useMutation({
    mutationFn: (setId: number) => api.undoProposal({ setId }),
    onSuccess: () => void queryClient.invalidateQueries(),
  });
  // 训练后营养提示文案（服务端下发）
  const ev = useQuery({ queryKey: ["evidence"], queryFn: () => api.getEvidence({}) });
  // 第二层「本次重要变化」的数据：只认服务端真正生效/留痕的状态
  const acceptedList = sets.filter((s) => s.proposalStatus === "accepted" && s.appliedNote);
  const anomalyList = sets.filter(
    (s) =>
      (s.aiAction ?? "").includes("停止") ||
      (s.rir === 0 && !!s.deform) ||
      (s.joint ?? "").includes("刺痛") ||
      s.sorenessOver72,
  );
  const uneffectiveList = sets.filter(
    (s) =>
      s.aiSuggestion &&
      (s.proposalStatus === "dismissed" || s.proposalStatus === "undone" || s.proposalStatus === "pending"),
  );
  const expiredCount = uneffectiveList.filter((s) => s.proposalStatus === "pending").length;
  const [l2Sheet, setL2Sheet] = useState<"accepted" | "anomaly" | "uneffective" | null>(null);
  const [l3Open, setL3Open] = useState<"review" | "next" | null>(null);
  const shortLine = (t: string) => {
    const first = t.split(/[。\n]/)[0] ?? t;
    return first.length > 24 ? `${first.slice(0, 24)}…` : first;
  };
  const groupHasChange = (items: SetLog[]) =>
    items.some(
      (s) =>
        s.proposalStatus === "accepted" ||
        s.proposalStatus === "pending" ||
        (s.aiAction ?? "").includes("停止") ||
        (s.rir === 0 && !!s.deform) ||
        (s.origWeightKg !== s.targetWeightKg || s.origReps !== s.targetReps),
    );

  const resultCard = (
    <div className="glass-result p-4">
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="num text-[28px] font-bold leading-8">{doneSets.length} / {totalWorkSets}</p>
          <p className="mt-0.5 text-[11px] text-[var(--text-3)]">{warmupTotal ? `工作组 · 热身 ${warmupDone}/${warmupTotal}` : "组"}</p>
        </div>
        <div>
          <p className="num text-[28px] font-bold leading-8">{durationMin != null ? durationMin : "—"}</p>
          <p className="mt-0.5 text-[11px] text-[var(--text-3)]">分钟</p>
        </div>
        <div>
          <p className="num text-[28px] font-bold leading-8">{volume > 0 ? volume.toLocaleString() : "—"}</p>
          <p className="mt-0.5 text-[11px] text-[var(--text-3)]">kg</p>
        </div>
      </div>
      <div className="num mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[rgba(255,255,255,0.08)] pt-3 text-[13px] text-[var(--text-2)]">
        <span>平均休息 {avgRest != null ? `${avgRest} 秒` : "—"}</span>
        {topSet ? <span>{topSet.exerciseName}顶组 {topSet.actualWeightKg}×{topSet.actualReps}</span> : null}
      </div>
      {expiredCount > 0 || anomalyList.length > 0 ? (
        <p className="mt-2 text-[13px]">
          {expiredCount > 0 ? <span style={{ color: "var(--st-pending)" }}>{expiredCount} 条建议已失效</span> : null}
          {expiredCount > 0 && anomalyList.length > 0 ? <span className="text-[var(--text-3)]"> · </span> : null}
          {anomalyList.length > 0 ? <span style={{ color: "var(--st-stop)" }}>安全停止提醒 {anomalyList.length} 次</span> : null}
        </p>
      ) : null}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* L1 结果卡 + Drive 常显 */}
      {resultCard}
      <section className="glass-card p-4">
        <h3 className="font-semibold">训练日志存档</h3>
        <div className="mt-3">
          <DriveButton session={session} />
        </div>
      </section>

      {/* L2 三行摘要：点开各自独立抽屉 */}
      <section aria-label="本次重要变化" className="glass-card divide-y divide-[rgba(255,255,255,0.06)]">
        {[
          {
            key: "accepted" as const,
            color: "var(--st-maintain)",
            label: acceptedList.length ? `已确认调整（${acceptedList.length} 条）` : "已确认调整（0 条）",
          },
          {
            key: "anomaly" as const,
            color: "var(--st-stop)",
            label: anomalyList.length ? `安全停止信号（${anomalyList.length} 条）` : "安全停止信号（0 条）",
          },
          {
            key: "uneffective" as const,
            color: "var(--st-pending)",
            label: uneffectiveList.length ? `未处理已失效（${uneffectiveList.length} 条）` : "未生效建议（0 条）",
          },
        ].map((row) => (
          <button
            key={row.key}
            type="button"
            onClick={() => setL2Sheet(row.key)}
            className="pressable flex min-h-11 w-full items-center gap-3 px-4 py-2 text-left"
          >
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: row.color }} aria-hidden="true" />
            <span className="flex-1 text-[15px] font-medium">{row.label}</span>
            <span className="text-[var(--text-3)]" aria-hidden="true">▸</span>
          </button>
        ))}
      </section>
      <Sheet
        open={l2Sheet != null}
        title={l2Sheet === "accepted" ? "已确认的调整" : l2Sheet === "anomaly" ? "安全停止信号" : "未生效的建议"}
        onClose={() => setL2Sheet(null)}
      >
        {l2Sheet === "accepted" ? (
          acceptedList.length ? (
            <ul className="space-y-3">
              {acceptedList.map((s) => (
                <li key={s.id} className="text-sm leading-relaxed">
                  <p className="font-medium">{s.exerciseName} 第 {s.setIdx + 1} 组后</p>
                  <p className="num mt-0.5">{s.appliedNote}</p>
                  <button
                    type="button"
                    disabled={undoMut.isPending}
                    onClick={() => undoMut.mutate(s.id)}
                    className="glass-btn pressable mt-2 min-h-12 px-4 py-2 text-sm font-medium disabled:opacity-50"
                  >
                    {undoMut.isPending ? "撤销中…" : "撤销这条调整"}
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-[var(--dim)]">本次没有接受任何调整，后续组目标与原始计划一致。</p>
          )
        ) : l2Sheet === "anomaly" ? (
          anomalyList.length ? (
            <ul className="space-y-2">
              {anomalyList.map((s) => (
                <li key={s.id} className="text-sm leading-relaxed">
                  {s.exerciseName} 第 {s.setIdx + 1} 组：
                  {[
                    s.rir === 0 && s.deform ? "RIR 0 且动作变形" : "",
                    (s.joint ?? "").includes("刺痛") ? `关节${s.joint}` : "",
                    s.sorenessOver72 ? "酸痛持续超过 72 小时" : "",
                    (s.aiAction ?? "").includes("停止") ? "裁决为停止" : "",
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                  {s.aiSuggestion ? <span className="mt-1 block text-[var(--dim)]">{shortSuggestion(s.aiSuggestion)}</span> : null}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-[var(--dim)]">本次没有安全停止信号记录。</p>
          )
        ) : uneffectiveList.length ? (
          <ul className="space-y-3">
            {uneffectiveList.map((s) => (
              <li key={s.id} className="text-sm leading-relaxed">
                <p className="font-medium">
                  {s.exerciseName} 第 {s.setIdx + 1} 组：
                  {s.proposalStatus === "dismissed"
                    ? "已忽略"
                    : s.proposalStatus === "undone"
                      ? "曾接受、后已撤销"
                      : "未处理，已失效"}
                </p>
                <p className="mt-0.5 whitespace-pre-line text-[var(--dim)]">{shortSuggestion(s.aiSuggestion)}</p>
                {s.proposalStatus === "pending" ? (
                  <button
                    type="button"
                    disabled
                    aria-disabled="true"
                    className="mt-2 min-h-12 cursor-not-allowed px-4 text-sm font-bold"
                    style={{ background: "var(--lime-18)", color: "var(--text-4)", borderRadius: 12 }}
                  >
                    接受
                  </button>
                ) : null}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-[var(--dim)]">没有未生效的建议。</p>
        )}
      </Sheet>

      {/* L3 复盘与下次建议：一行短版，点开就地展开原文 */}
      {session.review ? (
        <section className="glass-card p-4">
          <button
            type="button"
            aria-expanded={l3Open === "review"}
            onClick={() => setL3Open(l3Open === "review" ? null : "review")}
            className="flex min-h-11 w-full items-center gap-2 text-left"
          >
            <span className="flex-1 text-[15px] font-medium">{shortLine(session.review)}</span>
            <span className="shrink-0 text-xs text-[var(--text-3)]">读完整复盘 ▸</span>
          </button>
          <div className={`fold ${l3Open === "review" ? "open" : ""}`}>
            <div className="fold-body">
              <p className="whitespace-pre-line pt-2 text-[15px] leading-[26px]">{session.review}</p>
            </div>
          </div>
        </section>
      ) : null}
      {session.nextSuggestion ? (
        <section className="glass-card p-4">
          <button
            type="button"
            aria-expanded={l3Open === "next"}
            onClick={() => setL3Open(l3Open === "next" ? null : "next")}
            className="flex min-h-11 w-full items-center gap-2 text-left"
          >
            <span className="flex-1 text-[15px] font-medium">{shortLine(session.nextSuggestion)}</span>
            <span className="shrink-0 text-xs text-[var(--text-3)]">读下次建议全文 ▸</span>
          </button>
          <div className={`fold ${l3Open === "next" ? "open" : ""}`}>
            <div className="fold-body">
              <p className="whitespace-pre-line pt-2 text-[15px] leading-[26px]">{session.nextSuggestion}</p>
              <p className="mt-2 text-xs text-[var(--dim)]">
                这是建议，不是已经创建好的训练计划；看建议不会自动改任何未来计划，要用时再去对应日期建计划。
              </p>
            </div>
          </div>
        </section>
      ) : (
        <button
          type="button"
          disabled={regen.isPending}
          onClick={() => regen.mutate()}
          className="glass-btn pressable min-h-12 w-full px-4 py-2 text-sm font-medium disabled:opacity-50"
        >
          {regen.isPending ? "Muse 正在复盘…" : "让 Muse 生成复盘与下次建议"}
        </button>
      )}

      {ev.data ? (
        <section className="glass-card p-4">
          <h3 className="font-semibold">训练后提示（饮食与补水）</h3>
          <p className="mt-1 text-sm leading-relaxed">{ev.data.nutritionNote.copy}</p>
        </section>
      ) : null}

      {/* L4 卡片式逐组明细：按动作分卡，有改动/异常默认展开，无改动折叠成一行 */}
      <section aria-label="逐组明细" className="space-y-3">
        <h3 className="text-[15px] font-semibold">逐组明细（{sets.length} 组）</h3>
        {groups.map((g) => {
          const changed = groupHasChange(g.items);
          const cardBody = (
            <div className="mt-2 space-y-2">
              {g.items.map((s) => (
                <div key={s.id} className="glass-inner px-3 py-2 text-sm">
                  <div className="num grid grid-cols-3 gap-2">
                    <span>
                      <span className="block text-[10px] text-[var(--text-3)]\">第 {s.setIdx + 1} 组 · 原始计划{s.warmup ? " · 热身组" : ""}</span>
                      {fmtPair(s.origWeightKg, s.origReps)}
                    </span>
                    <span>
                      <span className="block text-[10px] text-[var(--text-3)]">调整后目标</span>
                      {fmtPair(s.targetWeightKg, s.targetReps)}
                    </span>
                    <span className={s.done ? "font-semibold" : "text-[var(--dim)]"}>
                      <span className="block text-[10px] font-normal text-[var(--text-3)]">实际</span>
                      {s.skipped
                        ? s.skippedBy === "ai"
                          ? "跳过（Muse 建议·已确认）"
                          : "跳过（本人决定）"
                        : s.done
                          ? s.durationMin != null
                            ? `${s.durationMin} 分钟${s.distanceKm != null ? ` · ${s.distanceKm}km` : ""}`
                            : fmtPair(s.actualWeightKg ?? s.targetWeightKg, s.actualReps ?? s.targetReps)
                          : "未完成"}
                    </span>
                  </div>
                  {s.pace ? <p className="num mt-0.5 text-xs text-[var(--dim)]">配速 {s.pace} 分/公里</p> : null}
                  {(() => {
                    const feelParts = [
                      s.rir != null ? `RIR ${s.rir >= 3 ? "3+" : Math.round(s.rir)}` : (s.difficulty ?? ""),
                      s.deform ? `动作${s.deform}` : "",
                      s.joint ? `关节${s.joint}` : "",
                      s.sorenessOver72 ? "酸痛>72h" : "",
                      s.pump != null ? `泵感${s.pump}（参考）` : "",
                      s.fatigue != null ? `疲劳${s.fatigue}（参考）` : "",
                      s.note ?? "",
                    ].filter(Boolean);
                    return feelParts.length ? (
                      <p className="mt-0.5 text-xs text-[var(--dim)]">
                        感受：{feelParts.join(" · ")}
                        {s.restSeconds != null ? ` · 休息 ${s.restSeconds}s` : ""}
                      </p>
                    ) : s.done ? (
                      <p className="mt-0.5 text-xs text-[var(--dim)]">
                        未填感受（正常状态）
                        {s.restSeconds != null ? ` · 休息 ${s.restSeconds}s` : ""}
                      </p>
                    ) : null;
                  })()}
                  {s.aiSuggestion ? (
                    <p className="mt-0.5 text-xs leading-relaxed text-[var(--dim)]">
                      <span className="font-semibold text-[var(--accent)]">Muse 建议：</span>
                      {shortSuggestion(s.aiSuggestion)}
                      {s.proposalStatus === "accepted" && s.appliedNote ? (
                        <span className="block font-medium" style={{ color: "var(--st-maintain)" }}>{s.appliedNote}</span>
                      ) : null}
                      {s.proposalStatus === "dismissed" ? <span className="block">（这条建议已被忽略，未改动后续组）</span> : null}
                      {s.proposalStatus === "pending" ? <span className="block">（未处理，已失效：{s.proposal ? proposalConclusion(s.proposal) : ""}，未改动后续组）</span> : null}
                      {s.proposalStatus === "undone" ? <span className="block">（这条调整曾接受、后已撤销，后续组已恢复）</span> : null}
                    </p>
                  ) : null}
                </div>
              ))}
            </div>
          );
          return changed ? (
            <div key={g.name + String(g.items[0]?.id)} className="glass-card p-4">
              <p className="text-sm font-semibold">{g.name} · {g.items.length} 组</p>
              {cardBody}
            </div>
          ) : (
            <details key={g.name + String(g.items[0]?.id)} className="glass-card p-4">
              <summary className="min-h-11 cursor-pointer text-sm font-medium">
                ▸ {g.name} · {g.items.length} 组（无改动）
              </summary>
              {cardBody}
            </details>
          );
        })}
      </section>
    </div>
  );
}

/* ---------------- D4 已结束（今日页） ---------------- */

function DayDoneCard({
  session,
  sets,
  onViewSummary,
}: {
  session: SessionT;
  sets: SetLog[];
  onViewSummary: () => void;
}) {
  const sessionsQ = useQuery({ queryKey: ["sessions"], queryFn: () => api.listSessions({ limit: 50 }) });
  const row = (sessionsQ.data?.sessions ?? []).find((x) => x.id === session.id) ?? null;
  // 组数口径与服务端一致：只计工作组，热身组另计
  const doneSets = sets.filter((s) => s.done && !s.warmup);
  const totalWorkSets = sets.filter((s) => !s.warmup).length;
  const warmupDone = sets.filter((s) => s.warmup && s.done).length;
  const warmupTotal = sets.filter((s) => s.warmup).length;
  const expiredCount = sets.filter(
    (s) => s.aiSuggestion && s.proposalStatus === "pending",
  ).length;
  const anomalyCount = sets.filter(
    (s) => (s.aiAction ?? "").includes("停止") || (s.rir === 0 && !!s.deform) || (s.joint ?? "").includes("刺痛") || s.sorenessOver72,
  ).length;
  const avgRestFromMd = (() => {
    const m = session.summaryMd?.match(/平均组间休息（仅力量组）：(\d+) 秒/);
    return m ? Number(m[1]) : null;
  })();
  const topSet = doneSets
    .filter((s) => s.actualWeightKg != null)
    .sort((a, b) => (b.actualWeightKg ?? 0) - (a.actualWeightKg ?? 0))[0] ?? null;
  const endedTime = session.endedAt
    ? new Date(session.endedAt).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
    : "";
  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="text-xl font-bold">今日训练已完成</h2>
        {endedTime ? <span className="num text-sm text-[var(--text-2)]">{endedTime}</span> : null}
      </div>
      <p className="-mt-2 text-sm text-[var(--dim)]">
        {session.title}
        {session.planId != null ? "" : ""}
      </p>
      <div className="glass-result p-4">
        <div className="grid grid-cols-3 gap-2 text-center">
          <div>
            <p className="num text-[28px] font-bold leading-8">{doneSets.length} / {totalWorkSets}</p>
            <p className="mt-0.5 text-[11px] text-[var(--text-3)]">{warmupTotal ? `工作组 · 热身 ${warmupDone}/${warmupTotal}` : "组"}</p>
          </div>
          <div>
            <p className="num text-[28px] font-bold leading-8">{row?.durationMin ?? "—"}</p>
            <p className="mt-0.5 text-[11px] text-[var(--text-3)]">分钟</p>
          </div>
          <div>
            <p className="num text-[28px] font-bold leading-8">{row ? row.volumeKg.toLocaleString() : "—"}</p>
            <p className="mt-0.5 text-[11px] text-[var(--text-3)]">kg</p>
          </div>
        </div>
        <div className="num mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[rgba(255,255,255,0.08)] pt-3 text-[13px] text-[var(--text-2)]">
          <span>平均休息 {avgRestFromMd != null ? `${avgRestFromMd} 秒` : "—"}</span>
          {topSet ? <span>{topSet.exerciseName}顶组 {topSet.actualWeightKg}×{topSet.actualReps}</span> : null}
        </div>
        {expiredCount > 0 || anomalyCount > 0 ? (
          <p className="mt-2 text-[13px]">
            {expiredCount > 0 ? <span style={{ color: "var(--st-pending)" }}>{expiredCount} 条建议已失效</span> : null}
            {expiredCount > 0 && anomalyCount > 0 ? <span className="text-[var(--text-3)]"> · </span> : null}
            {anomalyCount > 0 ? <span style={{ color: "var(--st-stop)" }}>安全停止提醒 {anomalyCount} 次</span> : null}
          </p>
        ) : null}
      </div>
      <section className="glass-card p-4">
        <DriveButton session={session} />
      </section>
      <button
        type="button"
        onClick={onViewSummary}
        className="cta-lime pressable flex min-h-[72px] w-full items-center justify-center px-4 text-lg"
      >
        查看总结 →
      </button>
    </div>
  );
}

/* ---------------- 今日页 ---------------- */

function TodayView() {
  const [date, setDate] = useState(todayStr());
  const [editing, setEditing] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const day = useQuery({
    queryKey: ["day", date],
    queryFn: () => api.getDay({ date }),
  });

  return (
    <div>
      <div className="mb-4 flex items-center justify-between gap-2">
        <button
          type="button"
          aria-label="前一天"
          className="min-h-11 rounded-lg bg-[var(--glass-l1-bg)] px-3 text-lg font-bold"
          onClick={() => {
            setDate(shiftDate(date, -1));
            setEditing(false);
            setShowSummary(false);
          }}
        >
          ‹
        </button>
        <div className="text-center">
          <p className="text-base font-bold">{dateLabel(date)}</p>
          <label className="text-xs text-[var(--dim)]">
            换一天：
            <input
              type="date"
              aria-label="选择日期"
              value={date}
              onChange={(e) => {
                if (e.target.value) {
                  setDate(e.target.value);
                  setEditing(false);
                  setShowSummary(false);
                }
              }}
              className="ml-1 rounded bg-transparent text-xs"
            />
          </label>
        </div>
        <button
          type="button"
          aria-label="后一天"
          className="min-h-11 rounded-lg bg-[var(--glass-l1-bg)] px-3 text-lg font-bold"
          onClick={() => {
            setDate(shiftDate(date, 1));
            setEditing(false);
            setShowSummary(false);
          }}
        >
          ›
        </button>
      </div>

      {day.isPending ? (
        <Skeleton rows={4} />
      ) : day.isError ? (
        <div className="py-10 text-center">
          <p className="text-sm text-red-600">加载失败</p>
          <button type="button" className="mt-2 min-h-10 rounded-lg bg-[var(--surface2)] px-4 py-2 text-sm" onClick={() => void day.refetch()}>
            重试
          </button>
        </div>
      ) : editing ? (
        <PlanEditor date={date} initial={day.data.plan} onClose={() => setEditing(false)} />
      ) : day.data.session?.status === "in_progress" ? (
        <TrainingView date={date} session={day.data.session} sets={day.data.sets} plan={day.data.plan} />
      ) : day.data.session?.status === "completed" ? (
        showSummary ? (
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => setShowSummary(false)}
              className="glass-btn pressable min-h-11 px-4 py-2 text-sm font-medium"
            >
              ← 回到今日结果
            </button>
            <SessionSummary session={day.data.session} sets={day.data.sets} />
          </div>
        ) : (
          <DayDoneCard session={day.data.session} sets={day.data.sets} onViewSummary={() => setShowSummary(true)} />
        )
      ) : day.data.plan ? (
        <PlanOverview date={date} plan={day.data.plan} onEdit={() => setEditing(true)} />
      ) : day.data.plannerDay?.kind === "rest" ? (
        <div className="glass-card p-6 text-center">
          <p className="text-base font-semibold">休息日 · 整休</p>
          <p className="mt-1 text-sm leading-relaxed text-[var(--dim)]">
            这一天在当前生效计划（v{day.data.plannerDay.version}）里定为整休，没有安排训练——这是计划的一部分，不是计划丢了。当天好好吃饭、睡够，散步可以，不用补练。
          </p>
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="glass-btn pressable mt-4 min-h-11 px-4 py-2 text-sm font-medium"
          >
            还是想练？临时新建这一天的计划
          </button>
        </div>
      ) : day.data.plannerDay ? (
        <div className="glass-card p-6 text-center">
          <p className="text-base font-semibold">这一天在周安排里是训练日，但每日计划没找到</p>
          <p className="mt-1 text-sm leading-relaxed text-[var(--dim)]">
            当前生效计划 v{day.data.plannerDay.version} 的周安排里，这一天是「{day.data.plannerDay.title}」，但每日计划数据不一致。可以先新建这一天的计划，或到「训练规划」页核对版本。
          </p>
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="mt-4 min-h-12 w-full rounded-lg bg-[var(--accent)] px-4 text-base font-bold text-white"
          >
            新建这一天的计划
          </button>
        </div>
      ) : (
        <div className="glass-card p-6 text-center">
          <p className="text-base font-semibold">这一天还没有训练计划</p>
          <p className="mt-1 text-sm text-[var(--dim)]">建一份计划，练的时候逐组记、组间写感受，Muse 会实时帮你调后续组。</p>
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="mt-4 min-h-12 w-full rounded-lg bg-[var(--accent)] px-4 text-base font-bold text-white"
          >
            新建这一天的计划
          </button>
        </div>
      )}
    </div>
  );
}

/* ---------------- 历史页 ---------------- */

function HistoryView() {
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const list = useQuery({
    queryKey: ["sessions"],
    queryFn: () => api.listSessions({ limit: 50 }),
  });
  const detail = useQuery({
    queryKey: ["session-detail", selectedId],
    queryFn: () => api.getSessionDetail({ sessionId: selectedId ?? 0 }),
    enabled: selectedId != null,
  });
  const del = useMutation({
    mutationFn: (id: number) => api.deleteSession({ sessionId: id }),
    onSuccess: () => {
      setSelectedId(null);
      setConfirmDeleteId(null);
      void queryClient.invalidateQueries();
    },
  });

  if (list.isPending) return <Skeleton rows={4} />;
  if (list.isError)
    return (
      <div className="py-10 text-center">
        <p className="text-sm text-red-600">历史记录暂时无法读取，这不代表记录丢失。</p>
        <button type="button" className="mt-2 min-h-10 rounded-lg bg-[var(--surface2)] px-4 py-2 text-sm" onClick={() => void list.refetch()}>
          重试读取
        </button>
      </div>
    );
  const sessions = list.data.sessions;
  if (sessions.length === 0) {
    return (
      <div className="glass-card p-6 text-center">
        <p className="font-semibold">还没有训练记录</p>
        <p className="mt-1 text-sm text-[var(--dim)]">完成第一次训练后，这里会按时间列出每一次的完成情况。</p>
      </div>
    );
  }
  return (
    <div className="space-y-3">
      {sessions.map((s) => (
        <div key={s.id} className="glass-card p-4">
          <button
            type="button"
            className="block w-full text-left"
            onClick={() => setSelectedId(selectedId === s.id ? null : s.id)}
            aria-expanded={selectedId === s.id}
          >
            <div className="flex min-h-[72px] flex-col justify-center">
              <div className="flex items-baseline justify-between gap-2">
                <p className="truncate text-[17px] font-semibold">{s.title}</p>
                <span className="num shrink-0 text-[13px] text-[var(--text-3)]">
                  {dateLabel(s.date)}
                  {s.endedAt
                    ? ` ${new Date(s.endedAt).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}`
                    : ""}
                </span>
              </div>
              <p className="num mt-0.5 flex flex-wrap items-center gap-x-2 text-[13px] text-[var(--text-2)]">
                <span>
                  {s.doneSets}/{s.totalSets} 组{s.volumeKg > 0 ? ` · ${s.volumeKg.toLocaleString()}kg` : ""}
                  {s.durationMin != null ? ` · ${s.durationMin} 分钟` : ""}
                  {s.status !== "completed" ? " · 进行中" : ""}
                </span>
                <span className="inline-flex items-center gap-1">
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{
                      background:
                        s.driveStatus === "uploaded"
                          ? "var(--st-up)"
                          : s.driveStatus === "pending"
                            ? "var(--st-pending)"
                            : s.driveStatus === "failed"
                              ? "var(--st-stop)"
                              : "var(--text-4)",
                    }}
                    aria-hidden="true"
                  />
                  {s.driveStatus === "uploaded"
                    ? "已归档"
                    : s.driveStatus === "pending"
                      ? "归档中"
                      : s.driveStatus === "failed"
                        ? "归档失败，可点开重试"
                        : "未归档"}
                </span>
              </p>
            </div>
          </button>
          {selectedId === s.id ? (
            <div className="mt-3 border-t border-[var(--border)] pt-3">
              <div className="mb-3 flex items-center justify-between gap-2">
                <p className="text-sm font-semibold">正在查看 {s.date} 的训练记录</p>
                <button
                  type="button"
                  onClick={() => setSelectedId(null)}
                  className="min-h-10 shrink-0 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-medium"
                >
                  返回列表
                </button>
              </div>
              <p className="mb-3 text-xs text-[var(--dim)]">
                下一步：先看训练结果与存档状态；要改感受请展开下方详情里的对应组，改完如需更新存档，点存档区的「上传修正版」（旧文件不会被覆盖）。
              </p>
              {detail.isPending ? (
                <p className="text-sm text-[var(--dim)]">加载详情…</p>
              ) : detail.data ? (
                <>
                  <SessionSummary session={detail.data.session} sets={detail.data.sets} />
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteId(s.id)}
                    className="mt-3 min-h-10 rounded-lg px-2 py-2 text-sm text-[var(--dim)]"
                  >
                    删除这次训练记录
                  </button>
                  <Sheet
                    open={confirmDeleteId === s.id}
                    title="删除这次训练记录？"
                    onClose={() => setConfirmDeleteId(null)}
                  >
                    <p className="text-sm leading-relaxed text-[var(--dim)]">删除后这次训练的逐组记录会一并删除，无法恢复。</p>
                    <button
                      type="button"
                      disabled={del.isPending}
                      onClick={() => del.mutate(s.id)}
                      className="pressable mt-4 min-h-14 w-full px-4 text-base font-bold text-white disabled:opacity-50"
                      style={{ background: "var(--st-stop)", borderRadius: 12 }}
                    >
                      {del.isPending ? "删除中…" : "确认删除"}
                    </button>
                  </Sheet>
                </>
              ) : (
                <p className="text-sm text-red-600">详情加载失败</p>
              )}
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

/* ---------------- 趋势页 ---------------- */

function StatsView() {
  const stats = useQuery({
    queryKey: ["stats"],
    queryFn: () => api.getStats({}),
  });
  const ev = useQuery({ queryKey: ["evidence"], queryFn: () => api.getEvidence({}) });
  const [exName, setExName] = useState<string>("");
  const [weekStart, setWeekStart] = useState<string>("");
  const [helpKey, setHelpKey] = useState<"volume" | "avgRest" | "rirDist" | "est1rm" | null>(null);
  if (stats.isPending) return <Skeleton rows={4} />;
  if (stats.isError)
    return (
      <div className="py-10 text-center">
        <p className="text-sm text-red-600">统计暂时无法读取，下面不会拿 0 来冒充真实数据。</p>
        <button type="button" className="mt-2 min-h-10 rounded-lg bg-[var(--surface2)] px-4 py-2 text-sm" onClick={() => void stats.refetch()}>
          重试读取
        </button>
      </div>
    );
  const d: StatsT = stats.data;
  const maxRir = Math.max(1, ...d.rirCounts.map((x) => x.count));
  const progress = d.exerciseProgress.find((e) => e.name === exName) ?? d.exerciseProgress[0];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "已完成训练", num: d.completedSessions, unit: "场", help: "volume" as const },
          { label: "累计完成组", num: d.totalDoneSets, unit: "组", help: "volume" as const },
          { label: "累计总容量", num: d.totalVolumeKg, unit: "kg", help: "volume" as const },
          { label: "平均组间休息", num: d.avgRestSeconds, unit: "秒", help: "avgRest" as const },
        ].map((it) => (
          <div key={it.label} className="glass-card relative px-3 py-3">
            <p className="text-[28px] font-bold leading-8">
              {it.num != null ? <CountUp value={it.num} /> : <span className="num">--</span>}
              <span className="ml-1 text-[13px] font-medium text-[var(--text-3)]">{it.unit}</span>
            </p>
            <p className="mt-0.5 text-xs text-[var(--dim)]">{it.label}</p>
            <button
              type="button"
              aria-label={`${it.label}的定义`}
              onClick={() => setHelpKey(it.help)}
              className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center text-[11px] text-[var(--text-3)]"
              style={{ minHeight: 24 }}
            >
              <span className="flex h-[11px] w-[11px] items-center justify-center rounded-full border border-current text-[9px]">?</span>
            </button>
          </div>
        ))}
      </div>
      <Sheet
        open={helpKey != null}
        title={helpKey === "avgRest" ? "平均组间休息" : helpKey === "rirDist" ? "余量分布（RIR）" : helpKey === "est1rm" ? "估算 1RM" : "总训练量"}
        onClose={() => setHelpKey(null)}
      >
        {helpKey && ev.data?.metricEvidence[helpKey] ? (
          <>
            <p className="text-[15px] leading-[26px]">{ev.data.metricEvidence[helpKey].definition}</p>
            {helpKey === "avgRest" ? (
              <p className="num mt-2 text-sm text-[var(--dim)]">本人口径样本：{d.restSamples} 个有效休息样本（服务端统计）。</p>
            ) : null}
            {helpKey === "rirDist" ? (
              <p className="num mt-2 text-sm text-[var(--dim)]">分母为已填写 RIR 的组数：{d.feedbackSets} 组；未填感受的组不计入分母。</p>
            ) : null}
          </>
        ) : (
          <p className="text-sm text-[var(--dim)]">定义加载中…</p>
        )}
      </Sheet>

      <section className="glass-card p-4">
        <h3 className="font-semibold">近 8 周训练量（kg）</h3>
        {d.weekly.length === 0 ? (
          <p className="mt-2 text-sm text-[var(--dim)]">还没有已完成的训练，完成一次后这里会出现周趋势。</p>
        ) : (
          <div className="mt-2 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={d.weekly} margin={{ top: 8, right: 8, bottom: 0, left: 8 }}>
                <XAxis dataKey="weekStart" tickFormatter={(v: string) => v.slice(5)} tick={{ fontSize: 11, fill: "var(--text-3)" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  formatter={(value) => [`${value ?? 0} kg`, "训练量"]}
                  labelFormatter={(v) => `周一 ${String(v)}`}
                />
                <Bar
                  dataKey="volumeKg"
                  fill="#B9F27D"
                  radius={[4, 4, 0, 0]}
                  onClick={(entry: unknown) => {
                    const ws = (entry as { weekStart?: string } | null)?.weekStart;
                    if (ws) setWeekStart(ws);
                  }}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
        {d.weekly.length ? (
          <>
            <div className="mt-2 flex flex-wrap gap-2" role="group" aria-label="按周查看训练量详情">
              {d.weekly.map((w) => (
                <button
                  key={w.weekStart}
                  type="button"
                  aria-pressed={(weekStart || d.weekly[d.weekly.length - 1]?.weekStart) === w.weekStart}
                  onClick={() => setWeekStart(w.weekStart)}
                  className={`num min-h-10 rounded-lg px-3 py-2 text-xs font-medium ${
                    (weekStart || d.weekly[d.weekly.length - 1]?.weekStart) === w.weekStart
                      ? "bg-[var(--accent)] text-[var(--cta-ink)]"
                      : "bg-[var(--surface2)]"
                  }`}
                >
                  {w.weekStart.slice(5)} 那周
                </button>
              ))}
            </div>
            {(() => {
              const w = d.weekly.find((x) => x.weekStart === (weekStart || d.weekly[d.weekly.length - 1]?.weekStart));
              return w ? (
                <p className="num mt-2 text-sm" role="status">
                  {w.weekStart} 那周：{w.sessions} 场训练 / {w.sets} 组 / 训练量 {w.volumeKg}kg
                  {w.sessions === 0 ? "（这一周没有训练记录，不是数据丢失）" : ""}
                </p>
              ) : null;
            })()}
          </>
        ) : null}
      </section>

      <section className="glass-card relative p-4">
        <h3 className="font-semibold">余量分布（RIR，按组）</h3>
        <button
          type="button"
          aria-label="余量分布的定义与分母说明"
          onClick={() => setHelpKey("rirDist")}
          className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center text-[11px] text-[var(--text-3)]"
          style={{ minHeight: 24 }}
        >
          <span className="flex h-[11px] w-[11px] items-center justify-center rounded-full border border-current text-[9px]">?</span>
        </button>
        <div className="mt-3 space-y-2">
          {d.rirCounts.map((it, i) => (
            <div key={it.label} className="flex items-center gap-2 text-sm">
              <span className="w-44 shrink-0">{it.label}</span>
              <div className="h-4 flex-1 overflow-hidden rounded bg-[var(--surface2)]">
                <div
                  className={`h-full ${["bg-[var(--green)]", "bg-[var(--green)]", "bg-[var(--accent)]", "bg-[var(--st-down)]", "bg-[var(--st-stop)]"][i] ?? "bg-[var(--green)]"}`}
                  style={{ width: `${(it.count / maxRir) * 100}%` }}
                />
              </div>
              <span className="num w-10 text-right text-[var(--dim)]">{it.count} 组</span>
            </div>
          ))}
        </div>
        <p className="num mt-2 text-xs text-[var(--dim)]">基于 {d.feedbackSets} 组有反馈的记录</p>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">动作重量进步</h3>
        {d.exerciseProgress.length === 0 ? (
          <p className="mt-2 text-sm text-[var(--dim)]">还没有负重动作的完成记录。</p>
        ) : (
          <>
            <div className="mt-2 flex flex-wrap gap-2">
              {d.exerciseProgress.map((e) => (
                <button
                  key={e.name}
                  type="button"
                  onClick={() => setExName(e.name)}
                  className={`min-h-10 rounded-lg px-3 py-2 text-sm font-medium ${
                    progress?.name === e.name ? "bg-[var(--accent)] text-[var(--cta-ink)]" : "bg-[var(--surface2)]"
                  }`}
                >
                  {e.name}
                </button>
              ))}
            </div>
            {progress ? (
              progress.points.length === 1 ? (
                <p className="num mt-3 text-sm text-[var(--dim)]">
                  暂无足够历史数据连成曲线。{progress.points[0]?.date}：最大重量 {progress.points[0]?.maxWeightKg}kg，估算 1RM {progress.points[0]?.est1RmKg}kg（估算值，不是实测最大值；再练一次同动作就能连成趋势线）
                </p>
              ) : (
                <>
                  <div className="mt-2 h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={progress.points} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
                        <XAxis dataKey="date" tickFormatter={(v: string) => v.slice(5)} tick={{ fontSize: 11, fill: "var(--text-3)" }} axisLine={false} tickLine={false} />
                        <YAxis domain={["dataMin - 5", "dataMax + 5"]} tick={{ fontSize: 11, fill: "var(--text-3)" }} axisLine={false} tickLine={false} width={36} />
                        <Tooltip
                          formatter={(value, name) => [
                            `${value ?? 0} kg`,
                            name === "est1RmKg" ? "估算 1RM" : "当日最大重量",
                          ]}
                        />
                        <Line type="monotone" dataKey="maxWeightKg" stroke="#B9F27D" strokeWidth={2.5} dot={{ r: 3.5 }} />
                        <Line type="monotone" dataKey="est1RmKg" stroke="#6E9BC7" strokeWidth={2} strokeDasharray="5 3" dot={{ r: 3 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-1 text-xs text-[var(--dim)]">青柠线：当日最大实际重量；钢蓝虚线：估算 1RM。估算 1RM 由 Epley 公式反推，非实测。</p>
                </>
              )
            ) : null}
          </>
        )}
      </section>

      {ev.data ? (
        <section className="glass-card p-4">
          <h3 className="font-semibold">指标定义</h3>
          <p className="mt-1 text-xs leading-relaxed text-[var(--dim)]">
            这里只解释每个指标的口径。
          </p>
          <div className="mt-2 space-y-2">
            {(
              [
                ["volume", "累计总容量 / 周训练量"],
                ["avgRest", "平均组间休息"],
                ["rirDist", "余量分布（RIR）"],
                ["est1rm", "当日最大重量与估算 1RM"],
              ] as const
            ).map(([key, label]) => {
              const m = ev.data.metricEvidence[key];
              return m ? (
                <div key={key}>
                  <p className="text-sm font-medium">{label}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-[var(--dim)]">{m.definition}</p>
                </div>
              ) : null;
            })}
          </div>
        </section>
      ) : null}
    </div>
  );
}

/* ---------------- 训练原则 ---------------- */

// 参考页内容由服务端 getPrinciples 下发：ATI 决策体系（循环、裁决动作、
// 休息表、恢复分层、准备度权重、安全边界）与训练原则、RIR 标尺都是
// 服务端同一套常量，页面与决策协调器口径一致，可以逐条对照核查。
function PrinciplesView() {
  const q = useQuery({ queryKey: ["principles"], queryFn: () => api.getPrinciples({}) });
  if (q.isPending) return <Skeleton rows={4} />;
  if (q.isError || !q.data) return <p className="py-10 text-center text-sm text-red-600">加载失败，请重试。</p>;
  const { principles, rirScale, ati, v2Layers } = q.data;
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold">训练原则与 ATI 决策体系</h2>
        <p className="mt-1 text-sm leading-relaxed text-[var(--dim)]">
          每组反馈都走同一个 ATI 决策循环：观察 → 构建上下文 → 检索原书证据 → AI 综合裁决 → 安全校验 → 执行。
          没有写死的规则路径——加重、降重、减组、换动作都是同一次裁决的不同结果；只有安全边界是确定性的，模型不能越过。
        </p>
      </div>

      <section className="glass-card p-4">
        <h3 className="font-semibold">ATI 统一决策循环（每组反馈都走这一圈）</h3>
        <ol className="mt-2 space-y-1.5">
          {ati.loop.map((step, i) => (
            <li key={step} className="flex gap-2 text-sm leading-relaxed">
              <span className="num mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold" style={{ background: "var(--lime-08)", color: "var(--lime)" }}>{i + 1}</span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">裁决动作空间（14 个，可组合）</h3>
        <p className="mt-1 text-xs leading-relaxed text-[var(--dim)]">
          模型每次从这里选一个或多个动作组合成裁决（例如保持重量 + 延长休息）。它们是可执行的动作，不是十四套判断程序。
        </p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {ati.actions.map((a) => (
            <div key={a.id} className="glass-inner px-3 py-2">
              <p className="text-sm font-semibold">{a.name}</p>
              <p className="num text-[10px] text-[var(--text-3)]">{a.id}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-[var(--dim)]">{a.detail}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">智能休息基础表</h3>
        <p className="mt-1 text-xs leading-relaxed text-[var(--dim)]">
          休息不再有「完成就固定加 60 秒」：模型在这张表的基础上，结合 RIR、完成情况、动作质量与主观恢复动态决定。
          完成目标次数、RIR 3+、动作稳定时，不得超过原定休息（回归测试 T16 由服务端校验）。
        </p>
        <div className="mt-2 divide-y divide-[var(--border)]">
          {ati.restTable.map((r) => (
            <div key={r.category} className="flex items-baseline justify-between gap-3 py-1.5 text-sm">
              <span>{r.category}</span>
              <span className="num shrink-0 font-semibold">{r.min}–{r.max} 秒</span>
            </div>
          ))}
        </div>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">恢复分层（只展示状态，不是判定程序）</h3>
        <div className="mt-2 space-y-2">
          {ati.recoveryLevels.map((l) => (
            <div key={l.level} className="flex gap-2 text-sm leading-relaxed">
              <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: RECOVERY_COLORS[l.level] ?? "var(--text-3)" }} aria-hidden="true" />
              <p>
                <span className="num font-semibold">{l.level} · {l.name}</span>
                <span className="block text-xs text-[var(--dim)]">{l.detail}</span>
              </p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs leading-relaxed text-[var(--dim)]">
          睡眠不看单个小时数开关：裁决会区分偶发不足、连续不足、质量下降，以及是否伴随表现下降。睡眠与营养没有记录时按「未记录」处理，不会被假设成正常。
        </p>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">准备度评分（只辅助，不裁决）</h3>
        <div className="mt-2 divide-y divide-[var(--border)]">
          {ati.readiness.map((d) => (
            <div key={d.name} className="flex items-baseline justify-between gap-3 py-1.5 text-sm">
              <span>{d.name}</span>
              <span className="num shrink-0 font-semibold">{d.weight}%</span>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs leading-relaxed text-[var(--dim)]">
          总分由服务端按已提供维度加权重算：没数据的维度不记 0 分、也不补默认分；疼痛与安全问题不会被其他维度的高分抵消。
          每条裁决另有置信度——置信度低时系统优先保守方案或先向你提问。
        </p>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">确定性安全边界（不交给模型）</h3>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm leading-relaxed">
          {ati.safetyBoundaries.map((b) => (
            <li key={b}>{b}</li>
          ))}
        </ul>
        <p className="mt-2 text-xs leading-relaxed text-[var(--dim)]">
          模型裁决与这些边界冲突时，服务端会拒绝执行并要求重新生成；两次仍不安全就走保守缺省（有停止信号先停，其余按原计划、休息不加时），并在裁决里如实标注。
        </p>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">v2.0 三层分离：决策动词 ≠ 动作库 ≠ 器械快照</h3>
        <p className="mt-1 text-sm leading-relaxed text-[var(--dim)]">{v2Layers.note}</p>
        <p className="mt-2 text-sm leading-relaxed">
          器械快照 {v2Layers.equipmentSnapshotId} · 动作库共 {v2Layers.libraryCounts.total}{" "}
          个唯一动作/变式（力量 {v2Layers.libraryCounts.exercises} + 跑步机有氧{" "}
          {v2Layers.libraryCounts.cardio} 单列；ACTIVE {v2Layers.libraryCounts.active} /
          CONDITIONAL {v2Layers.libraryCounts.conditional} / PROVISIONAL{" "}
          {v2Layers.libraryCounts.provisional}），计划只能用 ACTIVE 条目。
        </p>
        <p className="mt-2 text-sm font-semibold">反锚定（强制）</p>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm leading-relaxed text-[var(--text-2)]">
          {v2Layers.antiAnchoring.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">常用概念 · RIR 标尺（统一口径）</h3>
        <p className="mt-1 text-xs leading-relaxed text-[var(--dim)]">
          记录时只问「还能标准地做几个」，不问累不累：
        </p>
        <div className="mt-2 divide-y divide-[var(--border)]">
          {rirScale.map((s) => (
            <div key={s.key} className="py-1.5 text-sm">
              <span className="num font-semibold">RIR {s.rirLabel}</span>
              <span className="ml-2">{s.meaning}</span>
              <span className="block text-xs text-[var(--dim)]">对应操作：{s.action}</span>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs leading-relaxed text-[var(--dim)]">
          RIR 与完成次数矛盾时（例如报 RIR 3+ 却只完成目标的一半），以完成次数为准，RIR 视为估计错误。
        </p>
      </section>

      <section className="glass-card p-4">
        <h3 className="font-semibold">训练原则（点开看全文）</h3>
        <div className="mt-2 space-y-2">
          {principles.map((p, i) => (
            <details key={p.name} className="rounded-lg bg-[var(--surface2)] px-3 py-2">
              <summary className="min-h-11 cursor-pointer text-sm font-semibold">
                <span className="num mr-2 inline-flex h-6 w-6 items-center justify-center rounded-full text-xs" style={{ background: "var(--lime-08)", color: "var(--lime)" }}>{i + 1}</span>
                {p.name}
                <span className="ml-2 font-normal text-[var(--dim)]">{p.summary.length > 20 ? `${p.summary.slice(0, 20)}…` : p.summary}</span>
                <span className="float-right text-[var(--text-3)]" aria-hidden="true">▸</span>
              </summary>
              <p className="mt-1 text-sm leading-relaxed">{p.summary}</p>
              <p className="mt-1 text-sm leading-relaxed text-[var(--dim)]">{p.detail}</p>
            </details>
          ))}
        </div>
      </section>

    </div>
  );
}


/* ---------------- App 框架 ---------------- */

/* ---------------- 训练规划（ATI Planner） ----------------
   与实时决策共用一个循环的规划视角：只保留一个「生成 / 更新训练计划」
   入口、一个当前计划视图、一个「为什么这样安排」展开区。计划以版本
   （工作假设）维护：新提案先展示差异与理由，确认后才写入每日计划，
   历史版本不覆盖。 */

type PlannerData = ApiResponse<typeof api, "getPlanner">;
type PlanVersionT = NonNullable<PlannerData["current"]>;

const VERSION_STATUS_LABEL: Record<string, string> = {
  current: "当前生效",
  proposed: "待确认",
  superseded: "已被新版本取代",
  rejected: "已拒绝",
};
const EVENT_KIND_LABEL: Record<string, string> = {
  ati_modify_next_session: "实时裁决 · 修改下次训练",
  ati_stop_signal: "实时裁决 · 停止信号",
  plan_generated: "生成提案",
  plan_confirmed: "确认生效",
  plan_rejected: "拒绝提案",
};

function SnapshotList({ data }: { data: Record<string, string> }) {
  return (
    <dl className="space-y-2">
      {Object.values(data).map((v, i) => (
        <div key={i} className="glass-inner px-3 py-2 text-sm leading-relaxed text-[var(--text-2)]">
          {v}
        </div>
      ))}
    </dl>
  );
}

function VersionDetail({ v, fractionalNote }: { v: PlanVersionT; fractionalNote: string }) {
  return (
    <div className="space-y-3">
      <div>
        <p className="mb-1 text-sm font-semibold">本周安排</p>
        <ul className="space-y-1">
          {v.weeklySchedule.map((d) => (
            <li
              key={d.date}
              className="glass-inner flex items-center justify-between gap-2 px-3 py-2 text-sm"
            >
              <span className="font-medium">
                {dateLabel(d.date)}
                <span className="ml-2 text-[var(--text-2)]">{d.title}</span>
              </span>
              {d.kind === "training" || d.kind === "unchanged" ? (
                <span className="num shrink-0 text-[var(--text-3)]">
                  {d.totalSets} 组 · 约 {d.estimatedMinutes} 分钟
                </span>
              ) : (
                <span className="shrink-0 text-[var(--text-3)]">休息</span>
              )}
            </li>
          ))}
        </ul>
        <p className="mt-1 text-xs text-[var(--text-3)]">
          全周 {v.totalWorkSets} 个工作组；时长为按计划组数与休息的估算，实际执行通常更长。
        </p>
      </div>

      <div>
        <p className="mb-1 text-sm font-semibold">各肌群组数（直接 / 间接 / 折算估计）</p>
        <ul className="space-y-1">
          {v.muscleVolume.map((m) => (
            <li
              key={m.muscle}
              className="glass-inner flex items-center justify-between gap-2 px-3 py-2 text-sm"
            >
              <span className="font-medium">{m.muscle}</span>
              <span className="num text-[var(--text-2)]">
                直接 {m.directSets} · 间接 {m.indirectSets} · 折算 {m.fractionalEstimate}
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-1 text-xs leading-relaxed text-[var(--text-3)]">{fractionalNote}</p>
      </div>

      <details>
        <summary className="min-h-11 cursor-pointer py-2 text-sm font-semibold">
          动作处方（模式 · 主次肌群 · 目标强度）
        </summary>
        <ul className="space-y-1 pb-1">
          {v.exercisePrescriptions.map((p, i) => (
            <li key={i} className="glass-inner px-3 py-2 text-sm leading-relaxed">
              <span className="font-medium">
                {p.name}
                <span className="ml-2 text-xs text-[var(--lime)]">{p.movementPattern}</span>
              </span>
              <span className="mt-0.5 block text-[var(--text-2)]">
                {p.plannedSets} 组 × {p.repRange} · 休息 {p.restRange} · 主要：
                {p.primaryMuscles.join("、") || "—"}
                {p.secondaryMuscles.length
                  ? ` · 次要：${p.secondaryMuscles
                      .map((s) => `${s.muscle}${s.credit > 0 ? `（${s.credit}）` : "（极轻）"}`)
                      .join("、")}`
                  : ""}
              </span>
              <span className="block text-[var(--text-3)]">
                努力目标：{p.effortTarget} · 疲劳成本：{p.fatigueCostEstimate}
                {p.substitutionCandidates.length
                  ? ` · 可替代：${p.substitutionCandidates.join("、")}`
                  : ""}
              </span>
            </li>
          ))}
        </ul>
      </details>

      <details>
        <summary className="min-h-11 cursor-pointer py-2 text-sm font-semibold">
          为什么这样安排（理由 · 假设 · 证据）
        </summary>
        <div className="space-y-3 pb-1 text-sm leading-relaxed text-[var(--text-2)]">
          {v.rationale.split("\n").filter(Boolean).map((line, i) => (
            <p key={i}>{line}</p>
          ))}
          {v.progressionHypotheses.length ? (
            <div>
              <p className="font-semibold text-[var(--text-1)]">进阶假设</p>
              <ul className="list-disc space-y-1 pl-5">
                {v.progressionHypotheses.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </div>
          ) : null}
          {v.recoveryAssumptions.length ? (
            <div>
              <p className="font-semibold text-[var(--text-1)]">恢复假设</p>
              <ul className="list-disc space-y-1 pl-5">
                {v.recoveryAssumptions.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </div>
          ) : null}
          {v.uncertainties.length ? (
            <div>
              <p className="font-semibold text-[var(--text-1)]">不确定性（未记录的数据不补默认值）</p>
              <ul className="list-disc space-y-1 pl-5">
                {v.uncertainties.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </div>
          ) : null}
          {v.safetyNotes.length ? (
            <div>
              <p className="font-semibold text-[var(--text-1)]">安全注意事项</p>
              <ul className="list-disc space-y-1 pl-5">
                {v.safetyNotes.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </details>
    </div>
  );
}

function PlannerView() {
  const queryClient = useQueryClient();
  const planner = useQuery({ queryKey: ["planner"], queryFn: () => api.getPlanner({}) });
  const versions = useQuery({ queryKey: ["planVersions"], queryFn: () => api.getPlanVersions({}) });
  const [sheetOpen, setSheetOpen] = useState(false);
  const [note, setNote] = useState("");
  const [weekStart, setWeekStart] = useState("");
  const [daysAvailable, setDaysAvailable] = useState<string>("");
  const [minutes, setMinutes] = useState<string>("");
  const [genError, setGenError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [confirmingId, setConfirmingId] = useState<number | null>(null);

  const invalidateAll = () => {
    void queryClient.invalidateQueries({ queryKey: ["planner"] });
    void queryClient.invalidateQueries({ queryKey: ["planVersions"] });
    void queryClient.invalidateQueries({ queryKey: ["day"] });
  };

  const generate = useMutation({
    mutationFn: async () =>
      await api.generatePlan({
        weekStart: weekStart || undefined,
        requestNote: note.trim() ? note.trim() : undefined,
        daysAvailable: daysAvailable ? Number(daysAvailable) : null,
        minutesPerSession: minutes ? Number(minutes) : null,
      }),
    onSuccess: (res) => {
      if (res.ok) {
        setSheetOpen(false);
        setGenError(null);
        setToast(res.message);
        invalidateAll();
      } else {
        setGenError(res.message);
      }
    },
    onError: (e) => setGenError(e instanceof Error ? e.message : "生成失败，请重试。"),
  });
  const confirm = useMutation({
    mutationFn: async (id: number) => await api.confirmPlan({ versionId: id }),
    onSuccess: () => {
      setConfirmingId(null);
      setToast("提案已生效，每日计划已按新版本更新；旧版本保留在版本历史里。");
      invalidateAll();
    },
    onError: (e) => setToast(e instanceof Error ? e.message : "确认失败，请重试。"),
  });
  const reject = useMutation({
    mutationFn: async (id: number) => await api.rejectPlan({ versionId: id }),
    onSuccess: () => {
      setToast("已拒绝这份提案，每日计划保持不变。");
      invalidateAll();
    },
    onError: (e) => setToast(e instanceof Error ? e.message : "操作失败，请重试。"),
  });

  if (planner.isPending) return <Skeleton rows={5} />;
  if (planner.isError || !planner.data) {
    return (
      <div className="py-10 text-center">
        <p className="text-sm text-red-400">规划加载失败</p>
        <button
          type="button"
          className="glass-btn pressable mt-3 min-h-11 px-4 py-2 text-sm"
          onClick={() => void planner.refetch()}
        >
          重试
        </button>
      </div>
    );
  }
  const data = planner.data;
  const current = data.current;
  const proposal = data.proposal;

  return (
    <div className="space-y-4">
      {toast ? <Toast text={toast} onClose={() => setToast(null)} /> : null}

      {proposal ? (
        <section
          className="glass-card anim-card-in p-4"
          style={{ border: "1px solid rgba(185,242,125,0.45)" }}
          aria-label="待确认的计划提案"
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-bold">待确认提案 · v{proposal.version}</h2>
            {proposal.confidence != null ? (
              <span className="num text-sm text-[var(--text-3)]">
                置信度 {Math.round(proposal.confidence * 100)}%
              </span>
            ) : null}
          </div>
          <p className="mt-1 text-sm leading-relaxed text-[var(--text-2)]">
            {proposal.weekStart} 至 {proposal.weekEnd} · 全周 {proposal.totalWorkSets} 个工作组。
            确认前不会改动任何一天的计划；旧版本会保留在下方版本历史里。
          </p>
          <div className="glass-inner mt-3 px-3 py-2">
            <p className="text-sm font-semibold">与现行计划的差异</p>
            <ul className="mt-1 space-y-1 text-sm leading-relaxed text-[var(--text-2)]">
              {proposal.diffSummary.split("\n").filter(Boolean).map((line, i) => (
                <li key={i}>{line}</li>
              ))}
            </ul>
          </div>
          <div className="mt-3">
            <VersionDetail v={proposal} fractionalNote={data.fractionalNote} />
          </div>
          {confirmingId === proposal.id ? (
            <div className="mt-4 space-y-2">
              <p className="text-sm font-medium text-[var(--st-pending)]">
                确认后，上面的差异会立即写进每日计划（有训练记录的日期会被整体拒绝）。再点一次确认生效，或取消。
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  className="cta-lime pressable min-h-12 flex-1 px-4 text-base"
                  disabled={confirm.isPending}
                  onClick={() => confirm.mutate(proposal.id)}
                >
                  {confirm.isPending ? "正在生效…" : "确认生效"}
                </button>
                <button
                  type="button"
                  className="glass-btn pressable min-h-12 px-4 text-base"
                  onClick={() => setConfirmingId(null)}
                >
                  取消
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                className="cta-lime pressable min-h-12 flex-1 px-4 text-base"
                onClick={() => setConfirmingId(proposal.id)}
              >
                确认生效
              </button>
              <button
                type="button"
                className="glass-btn pressable min-h-12 px-4 text-base"
                disabled={reject.isPending}
                onClick={() => reject.mutate(proposal.id)}
              >
                拒绝提案
              </button>
            </div>
          )}
        </section>
      ) : null}

      <section className="glass-card p-4" aria-label="生成或更新训练计划">
        <h2 className="text-lg font-bold">训练规划</h2>
        <p className="mt-1 text-sm leading-relaxed text-[var(--text-2)]">
          Planner 与训练中的实时裁决是同一个循环：它按你的目标、实测状态和约束，结合最新证据（ACSM
          2026、Pelland 2026 与原书账本）现判分化、动作组合与容量，生成新版本提案——你确认后才生效。
        </p>
        <button
          type="button"
          className="cta-lime pressable mt-3 min-h-12 w-full px-4 text-base"
          onClick={() => {
            setWeekStart(current?.weekStart ?? todayStr());
            setGenError(null);
            setSheetOpen(true);
          }}
        >
          生成 / 更新训练计划
        </button>
      </section>

      <section className="glass-card p-4" aria-label="器械快照与动作库">
        <details>
          <summary className="min-h-11 cursor-pointer py-1 text-base font-bold">
            器械快照 {data.equipmentSnapshot.id} · 动作库（v2.0）
          </summary>
          <div className="space-y-3 pt-2 text-sm leading-relaxed text-[var(--text-2)]">
            <p>
              三层分开：决策动词（系统裁决）≠ 动作库（有出处的动作条目）≠ 器械快照（已确认器械）。
              计划只能从动作库 ACTIVE 条目里选、且必须通过这份快照；没有有效快照不生成计划。
            </p>
            <div>
              <p className="font-semibold text-[var(--text-1)]">
                已确认器械（{data.equipmentSnapshot.confirmedAt} 现场确认）
              </p>
              <ul className="mt-1 space-y-1">
                {data.equipmentSnapshot.items.map((i) => (
                  <li key={i.name} className="glass-inner px-3 py-2">
                    <span className="font-medium text-[var(--text-1)]">{i.name}</span>
                    <span className="block text-xs text-[var(--text-3)]">{i.detail}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-semibold text-[var(--text-1)]">尚未确认（不得自动假设）</p>
              <ul className="mt-1 list-disc space-y-1 pl-5">
                {data.equipmentSnapshot.unconfirmed.map((u, i) => (
                  <li key={i}>{u}</li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-semibold text-[var(--text-1)]">
                动作库共 {data.librarySummary.total} 个唯一动作/变式（力量{" "}
                {data.librarySummary.exercises} + 跑步机有氧 {data.librarySummary.cardio}{" "}
                单列）：ACTIVE {data.librarySummary.active} · CONDITIONAL{" "}
                {data.librarySummary.conditional} · PROVISIONAL{" "}
                {data.librarySummary.provisional}
              </p>
              <p className="mt-1">{data.librarySummary.note}</p>
              <ul className="mt-2 space-y-1">
                {data.library.map((e) => (
                  <li key={e.id} className="glass-inner px-3 py-2">
                    <details>
                      <summary className="cursor-pointer">
                        <span className="font-medium text-[var(--text-1)]">
                          {e.id} {e.name}
                          {e.kind === "cardio" ? "（有氧，单列）" : ""}
                        </span>
                        <span className="ml-2 text-xs text-[var(--st-pending)]">
                          {e.sourceStatus}
                        </span>
                        <span className="ml-2 text-xs text-[var(--text-3)]">
                          变式 {e.variationId}
                        </span>
                      </summary>
                      <div className="mt-1 space-y-1 text-xs leading-relaxed text-[var(--text-3)]">
                        <p>模式：{e.patterns.join(" / ")}｜主肌：{e.primary.join("、")}｜次肌：{e.secondary.join("、") || "无"}｜稳定肌：{e.stabilizers.join("、")}</p>
                        <p>设备：{e.equipment.join("、")}｜快照对齐：{e.equipmentSnapshotMatch}</p>
                        <p>技术要点：{e.techniqueCues}</p>
                        <p>常见错误：{e.commonErrors.join("；")}</p>
                        <p>适用人群：{e.populationScope}｜技能：{e.skill}</p>
                        <p>停止条件：{e.stop}</p>
                        <p>时间/设置成本：{e.timeSetupCost}</p>
                        <p>疲劳成本：{e.fatigueCost}</p>
                        <p>进阶选项：{e.progressionOptions.join("；")}</p>
                        <p>替换链：{e.replacements.join(" → ") || "无"}</p>
                        <p>来源状态 source_status：{e.sourceStatus}｜数据版本 {e.version}｜最近核对 {e.lastReviewedAt}</p>
                      </div>
                    </details>
                  </li>
                ))}
              </ul>
              {data.librarySummary.nonActive.length ? (
                <ul className="mt-1 space-y-1">
                  {data.librarySummary.nonActive.map((e) => (
                    <li key={e.id} className="glass-inner px-3 py-2">
                      <span className="font-medium text-[var(--text-1)]">
                        {e.id} {e.name}
                        <span className="ml-2 text-xs text-[var(--st-pending)]">{e.status}</span>
                      </span>
                      <span className="block text-xs text-[var(--text-3)]">{e.reason}</span>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          </div>
        </details>
      </section>

      {current ? (
        <section className="glass-card p-4" aria-label="当前计划">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-lg font-bold">当前计划 · v{current.version}</h2>
            <span
              className="shrink-0 px-2 py-1 text-xs font-semibold"
              style={{
                background: "var(--lime-08)",
                border: "1px solid rgba(185,242,125,0.35)",
                borderRadius: 8,
                color: "var(--lime)",
              }}
            >
              {VERSION_STATUS_LABEL[current.status] ?? current.status}
            </span>
          </div>
          <p className="mt-1 text-sm text-[var(--text-2)]">
            {current.title} · {current.weekStart} 至 {current.weekEnd}
          </p>
          <div className="mt-3">
            <VersionDetail v={current} fractionalNote={data.fractionalNote} />
          </div>
        </section>
      ) : null}

      <section className="glass-card p-4" aria-label="规划目标与约束">
        <details>
          <summary className="min-h-11 cursor-pointer py-1 text-base font-bold">
            目标与约束（成人处方快照）
          </summary>
          <div className="space-y-3 pt-2">
            <p className="text-sm font-semibold">目标</p>
            <SnapshotList data={data.goals} />
            <p className="text-sm font-semibold">约束与当前状态</p>
            <SnapshotList data={data.constraints} />
          </div>
        </details>
      </section>

      {data.events.length ? (
        <section className="glass-card p-4" aria-label="反馈对规划的影响">
          <h2 className="text-base font-bold">反馈如何影响规划</h2>
          <ul className="mt-2 space-y-2">
            {data.events.map((e) => (
              <li key={e.id} className="glass-inner px-3 py-2 text-sm leading-relaxed">
                <span className="font-medium text-[var(--lime)]">
                  {EVENT_KIND_LABEL[e.kind] ?? e.kind}
                </span>
                <span className="mt-0.5 block text-[var(--text-2)]">{e.note}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="glass-card p-4" aria-label="计划版本历史">
        <h2 className="text-base font-bold">版本历史</h2>
        {versions.isPending ? (
          <Skeleton rows={2} />
        ) : versions.data ? (
          <ul className="mt-2 space-y-2">
            {versions.data.versions.map((v) => (
              <li key={v.id} className="glass-inner px-3 py-2 text-sm leading-relaxed">
                <span className="font-medium">
                  v{v.version} · {v.title}
                </span>
                <span className="ml-2 text-xs text-[var(--text-3)]">
                  {VERSION_STATUS_LABEL[v.status] ?? v.status} · {v.totalWorkSets} 组
                </span>
                <details>
                  <summary className="min-h-11 cursor-pointer py-1 text-xs text-[var(--text-2)]">
                    查看差异与理由
                  </summary>
                  <div className="space-y-2 pb-1 text-[var(--text-2)]">
                    <ul className="space-y-1">
                      {v.diffSummary.split("\n").filter(Boolean).map((line, i) => (
                        <li key={i}>{line}</li>
                      ))}
                    </ul>
                    {v.rationale.split("\n").filter(Boolean).map((line, i) => (
                      <p key={i}>{line}</p>
                    ))}
                  </div>
                </details>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-[var(--text-3)]">暂无版本记录。</p>
        )}
      </section>

      <Sheet open={sheetOpen} title="生成 / 更新训练计划" onClose={() => setSheetOpen(false)}>
        <div className="space-y-3">
          <p className="text-sm leading-relaxed text-[var(--text-2)]">
            用一句话说清这次想调整什么（可留空，Planner 会按目标、实测状态与最新证据现判）。生成的是提案，确认后才生效。
          </p>
          <label className="block text-sm font-medium">
            本次说明（可选）
            <textarea
              {...FIELDS.generatePlan.requestNote}
              aria-label="本次规划说明"
              className="glass-input mt-1 min-h-24 w-full px-3 py-2 text-base"
              placeholder="例如：下周考试只能练 3 天；肩最近有点紧；想多练背……"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </label>
          <label className="block text-sm font-medium">
            目标周（周一）
            <input
              type="date"
              aria-label="目标周周一日期"
              className="glass-input mt-1 min-h-11 w-full px-3 py-2 text-base"
              value={weekStart}
              onChange={(e) => setWeekStart(e.target.value)}
            />
          </label>
          <div className="flex gap-2">
            <label className="flex-1 text-sm font-medium">
              可训练天数（可选）
              <select
                aria-label="可训练天数"
                className="glass-input mt-1 min-h-11 w-full px-2 py-2 text-base"
                value={daysAvailable}
                onChange={(e) => setDaysAvailable(e.target.value)}
              >
                <option value="">不限</option>
                {[2, 3, 4, 5, 6, 7].map((n) => (
                  <option key={n} value={n}>
                    {n} 天
                  </option>
                ))}
              </select>
            </label>
            <label className="flex-1 text-sm font-medium">
              单次时长上限（可选）
              <select
                aria-label="单次时长上限"
                className="glass-input mt-1 min-h-11 w-full px-2 py-2 text-base"
                value={minutes}
                onChange={(e) => setMinutes(e.target.value)}
              >
                <option value="">默认 95 分钟</option>
                {[55, 70, 85, 95].map((n) => (
                  <option key={n} value={n}>
                    {n} 分钟
                  </option>
                ))}
              </select>
            </label>
          </div>
          {genError ? (
            <p className="text-sm leading-relaxed text-[var(--st-stop)]">{genError}</p>
          ) : null}
          <button
            type="button"
            className="cta-lime pressable min-h-12 w-full px-4 text-base"
            disabled={generate.isPending}
            onClick={() => generate.mutate()}
          >
            {generate.isPending ? "正在检索证据并重排计划…（约半分钟）" : "生成提案"}
          </button>
        </div>
      </Sheet>
    </div>
  );
}

export function App() {
  const queryClient = useQueryClient();
  // 回到前台就刷新数据：切后台/息屏期间页面可能被系统冻结甚至回收，
  // 在途请求的结果与裁决状态都以服务端为准重新拉取，不再靠手动刷新。
  useEffect(() => {
    const refresh = () => void queryClient.invalidateQueries();
    const onVis = () => {
      if (document.visibilityState === "visible") refresh();
    };
    const onShow = (e: PageTransitionEvent) => {
      if (e.persisted) refresh();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pageshow", onShow);
    window.addEventListener("focus", refresh);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pageshow", onShow);
      window.removeEventListener("focus", refresh);
    };
  }, [queryClient]);
  const [tab, setTab] = useState<"today" | "history" | "stats" | "principles" | "planner">("today");
  const [landscapeDismissed, setLandscapeDismissed] = useState(false);
  const tabs: { key: "today" | "history" | "stats" | "principles" | "planner"; label: string }[] = [
    { key: "today", label: "今日训练" },
    { key: "history", label: "历史记录" },
    { key: "stats", label: "趋势统计" },
    { key: "principles", label: "训练原则" },
    { key: "planner", label: "训练规划" },
  ];
  const tabIdx = tabs.findIndex((t) => t.key === tab);
  const indicatorRef = useRef<HTMLDivElement | null>(null);
  // ⑩ 底栏切页滑标：从当前位置出发滑到目标页签
  useEffect(() => {
    const el = indicatorRef.current;
    if (!el) return;
    const target = tabIdx * 100;
    playAnim(
      el,
      [{ transform: `translateX(${el.dataset.x ?? 0}%)` }, { transform: `translateX(${target}%)` }],
      { duration: 240, easing: "cubic-bezier(0.22,1,0.36,1)" },
    );
    el.style.transform = `translateX(${target}%)`;
    el.dataset.x = String(target);
  }, [tabIdx]);
  return (
    <div className="text-[var(--text)]" style={{ minHeight: "100dvh", background: "transparent" }}>
      <SafeAreaTopScrim backgroundColor="var(--bg)" />
      <main className="anim-enter mx-auto w-full max-w-2xl px-4 pb-24 pt-3" key={tab}>
        {tab === "today" ? (
          <TodayView />
        ) : tab === "history" ? (
          <HistoryView />
        ) : tab === "stats" ? (
          <StatsView />
        ) : tab === "principles" ? (
          <PrinciplesView />
        ) : (
          <PlannerView />
        )}
      </main>
      <nav
        aria-label="主导航"
        className="fixed inset-x-0 bottom-0 pb-safe"
        style={{
          background: "var(--sheet-bg)",
          backdropFilter: "var(--sheet-blur)",
          WebkitBackdropFilter: "var(--sheet-blur)",
          borderTop: "var(--sheet-border)",
        }}
      >
        <div className="relative mx-auto flex max-w-2xl">
          <div
            ref={indicatorRef}
            aria-hidden="true"
            className="absolute left-0 top-0 h-[3px] w-1/5"
            style={{ background: "var(--lime)", transform: "translateX(0%)" }}
          />
          {tabs.map((t) => (
            <button
              key={t.key}
              type="button"
              aria-current={tab === t.key ? "page" : undefined}
              onClick={(e) => {
                animPress(e.currentTarget);
                setTab(t.key);
              }}
              className={`min-h-14 flex-1 py-3 text-base [-webkit-tap-highlight-color:transparent] ${
                tab === t.key ? "font-bold text-[var(--text-1)]" : "font-medium text-[var(--text-3)]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </nav>
      {!landscapeDismissed ? (
        <div
          className="landscape-overlay fixed inset-0 z-[60] flex-col items-center justify-center gap-4 px-6 text-center"
          style={{ background: "var(--bg)" }}
          role="alertdialog"
          aria-label="请竖屏使用"
        >
          <p className="text-lg font-bold">请竖屏使用</p>
          <p className="text-sm text-[var(--text-2)]">一只手扶器械时横屏更容易掉</p>
          <button
            type="button"
            onClick={() => setLandscapeDismissed(true)}
            className="cta-lime pressable min-h-14 px-6 text-base"
          >
            回到竖屏
          </button>
        </div>
      ) : null}
    </div>
  );
}
