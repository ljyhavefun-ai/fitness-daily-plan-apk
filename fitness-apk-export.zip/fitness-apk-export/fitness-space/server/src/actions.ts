// 每日健身计划的服务端动作。
// - 计划按天存（plans），开始训练后生成 session + 逐组 set_logs
// - 感受提交走「统一训练决策协调器」（ATI · Adaptive Training Intelligence，
//   设计 V1.0 第十章）：所有正常训练调整都走同一个决策循环——观察状态 →
//   构建上下文（10.3 结构）→ 检索 44 条原书证据 → AI 综合判断（14 个可
//   组合裁决动作）→ 确定性安全校验 → 执行决策 → 记录结果。旧的规则 A–G
//   硬编码裁决函数（evaluateRules）已废除：加重/维持/降重/延长休息/减组
//   不再是独立程序，而是同一次 AI 裁决的不同结果。安全边界留在确定性层：
//   明确停止信号（关节刺痛、动作变形且无法纠正、RIR 0 且变形、持续酸痛
//   >72h）出现时必须停止相关动作；重量/休息/组数越界的模型输出被拒绝并
//   要求重新生成，仍不安全则走保守缺省；测试日不下调测试重量、不减组、
//   不替换测试动作。裁决只存为「待确认建议」（建议制）：用户点接受
//   （respondProposal）才改写后续组，点忽略不改；已接受的可用 undoProposal
//   按快照撤销。appliedNote 由服务端按实际 diff 逐项生成，与真实改动严格
//   一致；总结只收录已接受的调整。
// - 智能休息：取消「完成目标次数就固定加 60 秒」；休息由模型在动作基础
//   休息表（深蹲/硬拉 180–300 秒、卧推/划船/肩推 120–180 秒、孤立 60–90
//   秒等）内结合 RIR、完成情况、动作质量与主观恢复给出，安全校验含 T16
//   回归：完成目标次数、RIR 3+、动作稳定时不得超过原定休息。
// - 恢复模型：GREEN/BLUE/AMBER/RED 只作展示分层；准备度评分（表现 30%/
//   睡眠 20%/疲劳 15%/酸痛 10%/营养 15%/心理 10%）由服务端按已提供维度
//   加权重算，只辅助判断、不直接裁决；缺失维度不记 0 分；疼痛与安全不被
//   其他维度高分抵消（停止信号直接把恢复层级定为 RED）。缺失的 RIR/睡眠/
//   营养在上下文里明确标「未记录」，绝不自动补成正常值。
// - Drive 上传经 ctx.agent.spawnTask 调用用户已连接的 Google Drive CLI 完成，
//   结果由 recordDriveUpload 回写；同日重复上传文件名带时间后缀避免同名。

import { defineAction, z, type ActionsModule, type Ctx, type SpaceDb } from "@hatch/space-sdk";
import { asc, desc, eq } from "drizzle-orm";
import * as schema from "./schema";

// ---------------- 训练原则（建议引用的唯一口径，参考页与提示词共用） ----------------
// 内容为通用训练科学常识的自述总结（渐进超负荷、RIR/RPE、容量频率等为业界
// 通行概念），措辞与「训练原则」页保持一致；每条反馈建议必须注明引用了哪条。
export const PRINCIPLES = [
  {
    name: "渐进超负荷",
    summary: "默认按计划执行：在能完成目标次数、动作不变形的前提下，逐步小幅增加重量、次数或组数，刺激才持续。",
    detail:
      "完成目标且还留有约 2 次余量时，下次同动作可加重 2.5–5% 或多做 1–2 次；一次只推进一个变量。没有客观失败证据时，不因为「感觉累」就往回退——退步不是默认选项。",
  },
  {
    name: "RIR/RPE 与力竭",
    summary: "用剩余次数余量（RIR）标定强度，统一标尺五档：3+（还能标准地做 3 个以上）/ 2 / 1 / 0（1 个也做不了）/ 0 且动作变形（技术力竭，安全边界：停该动作）。",
    detail:
      "记录 RIR 时只问「还能标准地做几个」，不问累不累。RIR 2 与 1 是目标区间；RIR 0 可以接受，但同动作不要连续两组都到 0。RIR 是主观估计，必须和完成次数交叉验证：两者矛盾时以完成次数为准，RIR 视为估计错误；次数达标时，单凭 RIR 或疲劳感不构成降重理由。",
  },
  {
    name: "容量与频率",
    summary: "每个肌群每周约 10–20 个有效组、每周练 2 次左右，是增肌的主流区间；恢复期从区间下限起步。容量 landmarks：MEV（最低有效容量）/ MAV（最大可适应容量）/ MRV（最大可恢复容量），超过 MRV 的组数只添疲劳不添刺激。",
    detail:
      "单次训练堆太多组，后半程多是低质量的「垃圾容量」。Schoenfeld《Science and Development of Muscle Hypertrophy》的容量口径是每节训练每肌群约 40–70 次总重复，不是每周组数，两者别混。减组只针对明显做不完或恢复跟不上的情况，且要说明减的是哪些组、为什么减。",
  },
  {
    name: "强度与次数区间",
    summary: "NSCA《Essentials of Strength Training and Conditioning》第 5 版口径：增肌 67–80% 1RM、8–12 次；力量 1–5 次大重量；12 次以上偏耐力与代谢压力。",
    detail:
      "判断一组是否「太轻/太重」先看落点在哪个区间、是否完成目标次数，而不是看感觉。NSCA 负荷对照：增肌多关节 2–3 组起、组间休息多关节 2–3 分钟、单关节 60–90 秒。测试日的重量是测出来的数据点，不是训练负担，不因主观感受取消。",
  },
  {
    name: "组间休息",
    summary: "复合动作休息 2–5 分钟、孤立动作 1–3 分钟（NSCA 第 5 版：多关节 2–3 分钟、单关节 60–90 秒）；状态波动时先延长休息，而不是先降重量。",
    detail:
      "休息不足会直接拉低下一组次数，看起来像「力量下降」。疲劳高、泵感强但次数达标时，第一选择是把休息延长 30–90 秒，保持重量与组数不变。深蹲、硬拉这类大动作严格按 2–4 分钟执行（恢复排查的核查项之一）。",
  },
  {
    name: "热身与动作技术",
    summary: "正式组前用递增重量热身；动作标准优先于重量，关节刺痛、动作变形是立即停下或换动作的信号。",
    detail:
      "关节刺痛（区别于肌肉酸胀）与动作明显变形属于客观触发：一旦出现，可以降载、减组或替换动作，并优先排查热身与动作轨迹，而不是硬顶。",
  },
  {
    name: "恢复与减载",
    summary: "睡眠、总热量与蛋白质管够是恢复的前提；蛋白质 1.6–2.2g/kg 体重（本人目标 120g/天）、热量 2500–2700kcal；连续数周表现系统性下滑时才安排减载周（容量与强度明显下调一周）。",
    detail:
      "恢复训练期先把动作模式与训练节奏找回来，前两周以完成计划、积累信心为主。减载是整周的计划性安排，不是某一组感觉不好就临时大幅下调。连续失败时先逐项排查恢复：睡眠时长与质量（区分偶发还是连续不足）、蛋白与热量是否达标、大动作休息是否够 2–4 分钟、是否连续多天无休息日。",
  },
] as const;

export type PrincipleName = (typeof PRINCIPLES)[number]["name"];

// RIR 标尺：知识库统一口径（3+ / 2 / 1 / 0 / 0 且动作变形五档），界面、
// 提示词、总结共用同一套说法。记录时只问「还能标准地做几个」；存储值
// 3 表示 3+，旧数据的 4 同样按 3+ 显示。
export const RIR_SCALE: Array<{ key: string; rirLabel: string; meaning: string; action: string }> = [
  { key: "3+", rirLabel: "3+", meaning: "还能标准地做 3 个以上", action: "重量偏轻，ATI 会结合跨课趋势判断下次是否加重" },
  { key: "2", rirLabel: "2", meaning: "还能做 2 个", action: "目标区间，维持" },
  { key: "1", rirLabel: "1", meaning: "只能再做 1 个", action: "目标区间，维持；下一组注意休息" },
  { key: "0", rirLabel: "0", meaning: "1 个也做不了，动作未变形", action: "可以接受，但同动作不要连续两组都到 0" },
  { key: "0-deform", rirLabel: "0 且动作变形", meaning: "技术力竭", action: "安全边界：停该动作并评估" },
];

export function fmtRir(rir: number): string {
  return rir >= 3 ? "3+" : String(Math.max(0, Math.round(rir)));
}

// ---------------- ATI 统一裁决空间（设计 V1.0 第四章） ----------------
// 旧的规则 A–G 已废除：加重、维持、降重、延长休息、减组等不再是独立的
// 硬编码程序，而是同一次 AI 裁决从下面 14 个可组合动作里选出的结果。
// 模型可以组合多个动作（例如保持重量同时延长休息、降低重量同时保持
// 剩余组数）。服务端只保留确定性职责：上下文构建、证据检索、安全校验、
// 裁决执行与记录——不预设任何「什么情况必须怎么练」的训练路径。
export const ATI_ACTIONS = [
  { id: "CONTINUE", name: "按计划继续", detail: "不做任何调整，按原计划执行下一组" },
  { id: "INCREASE_LOAD", name: "增加负重", detail: "提高后续组或下次训练的负重" },
  { id: "MAINTAIN_LOAD", name: "保持负重", detail: "重量不变（可与休息、组数等其他动作组合）" },
  { id: "DECREASE_LOAD", name: "降低负重", detail: "降低后续组负重，幅度由综合证据决定，不写死百分比" },
  { id: "EXTEND_REST", name: "延长休息", detail: "在动作基础休息表内延长组间休息" },
  { id: "SHORTEN_REST", name: "缩短休息", detail: "表现轻松且恢复充分时缩短组间休息" },
  { id: "REDUCE_SETS", name: "减少组数", detail: "减少剩余组数（边际收益不足或疲劳成本过高时）" },
  { id: "ADD_SET", name: "增加组数", detail: "增加训练组（只在长期适应与恢复证据支持时）" },
  { id: "SUBSTITUTE_EXERCISE", name: "更换动作", detail: "用提供相似刺激、疲劳成本更低的动作替代" },
  { id: "STOP_EXERCISE", name: "停止当前动作", detail: "停止该动作当日剩余组" },
  { id: "STOP_SESSION", name: "结束本次训练", detail: "整体状态或安全不允许继续时结束训练" },
  { id: "DELOAD", name: "进入减载", detail: "多项恢复指标持续恶化时安排减载（只作建议，不直接改计划）" },
  { id: "MODIFY_NEXT_SESSION", name: "修改下次训练", detail: "只给下次训练的起点建议，不直接改写任何计划" },
  { id: "GATHER_INFORMATION", name: "先补充信息", detail: "关键信息不足时先向用户提问，不擅自假定安全或状态正常" },
] as const;

export type AtiActionId = (typeof ATI_ACTIONS)[number]["id"];
export const ATI_ACTION_IDS = ATI_ACTIONS.map((a) => a.id) as [AtiActionId, ...AtiActionId[]];

export function atiActionName(id: string): string {
  const a = ATI_ACTIONS.find((x) => x.id === id);
  return a ? a.name : id;
}

// 智能休息基础表（设计 V1.0 §5.1）：这是给模型的参考配置与安全校验的
// 锚点，不是硬停表——实际休息由模型结合 RIR、完成情况、动作质量与
// 主观恢复在表内（必要时略超）动态决定。
export const REST_TABLE: Array<{ category: string; min: number; max: number; match: RegExp | null }> = [
  { category: "深蹲、硬拉等高负荷复合动作", min: 180, max: 300, match: /深蹲|硬拉/ },
  { category: "卧推、划船、肩推、引体等常规工作组", min: 120, max: 180, match: /卧推|划船|肩推|推举|引体|双杠/ },
  { category: "上斜卧推、腿举等中高强度动作", min: 120, max: 180, match: /上斜|腿举|腿推|保加利亚|分腿蹲/ },
  { category: "腹部训练", min: 45, max: 90, match: /腹|卷腹|举腿|平板支撑/ },
  { category: "弯举、下压、侧平举等孤立动作", min: 60, max: 90, match: null },
];

export function baseRestRange(exerciseName: string): { category: string; min: number; max: number } {
  for (const row of REST_TABLE) {
    if (row.match && row.match.test(exerciseName)) {
      return { category: row.category, min: row.min, max: row.max };
    }
  }
  const iso = REST_TABLE[REST_TABLE.length - 1];
  return { category: iso?.category ?? "孤立动作", min: iso?.min ?? 60, max: iso?.max ?? 90 };
}

// 恢复分层（设计 V1.0 §6.2）：颜色只是展示状态，由模型在评估里给出、
// 安全校验只在停止信号时强制 RED——不是四个新的硬编码判定程序。
export const RECOVERY_LEVELS = [
  { level: "GREEN", name: "正常恢复", detail: "训练表现稳定，睡眠正常，酸痛可接受，技术稳定——按计划训练" },
  { level: "BLUE", name: "轻度恢复不足", detail: "睡眠略差、轻微疲劳，但主要训练表现稳定——保持训练，必要时调整负荷或密度" },
  { level: "AMBER", name: "明显恢复不足", detail: "多项指标恶化，训练表现持续下降，酸痛或压力增加——重新安排训练压力，考虑减量或恢复日" },
  { level: "RED", name: "安全风险", detail: "新发明显疼痛、异常症状或无法维持安全动作质量——停止相关动作，必要时停止训练并接受专业评估" },
] as const;

// 准备度评分（设计 V1.0 §9.1）：只辅助判断、不直接裁决。权重是服务端
// 常量；总分由服务端按「已提供维度」加权重算，缺失维度不记 0 分。
export const READINESS_DIMENSIONS = [
  { key: "performance", name: "近期训练表现", weight: 0.3 },
  { key: "sleep", name: "睡眠恢复", weight: 0.2 },
  { key: "fatigue", name: "主观疲劳", weight: 0.15 },
  { key: "soreness", name: "肌肉酸痛", weight: 0.1 },
  { key: "nutrition", name: "营养恢复", weight: 0.15 },
  { key: "psychology", name: "心理状态", weight: 0.1 },
] as const;
export type ReadinessKey = (typeof READINESS_DIMENSIONS)[number]["key"];
export type ReadinessScores = Record<ReadinessKey, number | null>;

export function computeReadinessOverall(scores: ReadinessScores): number | null {
  let wSum = 0;
  let acc = 0;
  for (const d of READINESS_DIMENSIONS) {
    const s = scores[d.key];
    if (s != null && Number.isFinite(s)) {
      wSum += d.weight;
      acc += d.weight * s;
    }
  }
  if (wSum === 0) return null;
  return Math.round((acc / wSum) * 10) / 10;
}

// 确定性安全边界（设计 V1.0 §10.6）：这些不交给模型——模型输出与之
// 冲突时服务端拒绝执行、要求重新生成，仍不安全则走保守缺省方案。
export const SAFETY_BOUNDARIES = [
  "训练重量不得为负，不得超出计划支持的负荷范围（单次上调不超过当前参考重量的 10%）",
  "明确停止信号（关节刺痛、动作变形且无法纠正、RIR 0 且动作变形、同一部位持续酸痛超过 72 小时）出现时，必须停止相关动作",
  "未经验证的模型输出不得直接修改长期训练计划——裁决只生成待确认建议，下次训练的调整也只以建议形式给出",
  "不得把不存在的训练记录当成真实数据；未记录的 RIR、睡眠、营养一律按「未记录」处理，不补默认值",
  "缺少必要保护措施时不得安排高风险极限测试；测试日不下调测试重量、不减组、不替换测试动作（停止信号除外）",
  "完成目标次数、RIR 3+、动作质量稳定时，不得在原定休息之外无理由加时（回归测试 T16）",
] as const;


// ---------------- 原书证据层（muse-fitness-evidence-skills-v1 接入） ----------------
// 44 条证据逐字转录自知识包 references/claim-ledger.json（构建时由脚本
// 从账本生成，未经人工改写命题）；书籍全名按 references/source-registry.md
// 的版本登记补齐。核验状态统一为 SOURCE_LIMITED：账本 verification 原文
// 为「章节与关键片段已定位核验；非整书逐页人工审计」——按
// fitness-evidence-guardian 的置信标记定义，这只能标 SOURCE_LIMITED：
// 允许按需展开解释，不升格为核验过的裁决依据。ATI 改造后，本层是决策
// 循环的证据检索来源：每次裁决由服务端按上下文从账本检索相关条目提供
// 给模型，模型引用后在裁决里注明来源；证据本身不构成硬编码裁决路径，
// 任何代码路径都不得用证据条目直接改写目标或 RIR。
export const EVIDENCE_SOURCE_STATUS = "SOURCE_LIMITED";
export const EVIDENCE_VERIFICATION_NOTE =
  "章节与关键片段已定位核验；非整书逐页人工审计。证据只用于解释，不参与自动裁决；未核对的数字不用于自动训练调整。";

export const EVIDENCE_CLAIMS = [
  {
    id: "E01",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1212–1213; Ch18 Training Frequency",
    fact: "周频率不能脱离总训练量、恢复能力与并行活动解释；等周训练量下频率影响不应被夸大。",
    guardrail: "不能仅凭一周训练次数少就判定计划无效。",
    scope: "计划安排、频率建议",
  },
  {
    id: "E02",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1237–1238; Ch18 Loading",
    fact: "RM 连续谱是按训练目标的典型处方，不是增肌适应的硬边界。",
    guardrail: "不得把传统区间外的训练自动判为无效。",
    scope: "强度解释",
  },
  {
    id: "E03",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF p.1238, Table 18.11; p.1243 scenario B",
    fact: "67–80% 1RM、8–12 次作为经典增肌目标区间，位于目标化处方表和示例中。",
    guardrail: "不是唯一可增肌区间；百分比需基于有质量的测量或估算。",
    scope: "经典模板说明",
  },
  {
    id: "E04",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1241–1242; Ch18 Timing Load Increases",
    fact: "2-for-2：相邻两次训练课、同一动作末组，各自超过指定重复次数至少 2 次，才考虑下次加重。",
    guardrail: "同一次课内连续两组不算；不能根据非末组断言。",
    scope: "跨会话进阶核对",
  },
  {
    id: "E05",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF p.1242; Ch18 2-for-2 limitations",
    fact: "原书提示该法不直接考虑动作技术、训练阶段与相对强度，可能促使逼近力竭。",
    guardrail: "技术不达标或恢复不佳时不能机械加重。",
    scope: "进阶守门",
  },
  {
    id: "E06",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF p.1253; Ch18 Step 7 Rest Periods",
    fact: "休息时长取决于训练目标、相对负荷与训练水平；较高负荷及恢复较差时可能需更多休息。",
    guardrail: "不能把固定秒数当适合所有动作和组的普遍定律。",
    scope: "休息目标解释",
  },
  {
    id: "E07",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1253–1254, Table 18.15",
    fact: "增肌方向示例：多关节 2–3 分钟、单关节 60–90 秒；力量/爆发力训练另有不同区间。",
    guardrail: "是指南而非硬停表，实际需结合表现与动作。",
    scope: "默认休息模板",
  },
  {
    id: "E08",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1218–1220; Ch18 Exercise Order",
    fact: "需要较高神经肌肉质量的动力性/核心复合动作通常应先于辅助动作；交替推/拉可提高效率，但高强度配对会额外疲劳。",
    guardrail: "不要为了节省时间强制高风险超组。",
    scope: "动作排序",
  },
  {
    id: "E09",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1249–1250; Ch18 Volume",
    fact: "计划组数随训练目标、经验和承受能力变化；初期不必机械堆高组数。",
    guardrail: "不得因疲劳感主观信号单独修改既有 A–G 规则。",
    scope: "计划容量审查",
  },
  {
    id: "E10",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF p.1251; Ch18 Hypertrophy",
    fact: "增肌并非只能通过中等负荷；对较轻/较重负荷需结合总量、次数与技术解读。",
    guardrail: "不要照搬高重量高组数的竞技示例给恢复训练者。",
    scope: "负荷范围冲突处理",
  },
  {
    id: "E11",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.394,400; Ch7 Youth Populations",
    fact: "青少年/技术尚未成熟者需按技术能力、成熟度与恢复个体化安排，不能直接套成人项目。",
    guardrail: "不得用竞技成年人的重负荷模板自动处方给所有年龄层。",
    scope: "适用人群筛选",
  },
  {
    id: "E12",
    bookCode: "HTr",
    book: "Helms《The Muscle and Strength Pyramid: Training》第 2 版（2019）",
    location: "PDF p.72; RPE Based on RIR",
    fact: "RIR 是估计还能完成的规范重复次数；RPE10≈RIR0、RPE9≈RIR1、RPE8≈RIR2。",
    guardrail: "主观估算不等同实际失败事实，不能替代记录次数。",
    scope: "反馈量表解释",
  },
  {
    id: "E13",
    bookCode: "HTr",
    book: "Helms《The Muscle and Strength Pyramid: Training》第 2 版（2019）",
    location: "PDF p.73; Measuring Intensity",
    fact: "有经验训练者对 RIR 的自评往往更准确，新手可能偏差较大，需要反馈与校准。",
    guardrail: "未采集不应虚构 RIR；不建议仅为了校准而训练到力竭。",
    scope: "数据质量提示",
  },
  {
    id: "E14",
    bookCode: "HTr",
    book: "Helms《The Muscle and Strength Pyramid: Training》第 2 版（2019）",
    location: "PDF pp.95–97; Sample Strength Routine",
    fact: "示例项目间存在肌群重叠，硬拉、划船等也对背部训练负担有贡献；不宜只按孤立动作逐项简单求和。",
    guardrail: "示例不是必须严格照抄的万能分化。",
    scope: "训练量去重说明",
  },
  {
    id: "E15",
    bookCode: "HTr",
    book: "Helms《The Muscle and Strength Pyramid: Training》第 2 版（2019）",
    location: "PDF pp.172–176; Rest Periods",
    fact: "作者讨论长休息维持表现与训练量的机制，指出不能简单假定短休息更利于增肌。",
    guardrail: "不能将缩短休息自动视为训练进步。",
    scope: "休息质量解释",
  },
  {
    id: "E16",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; section 37, Volume",
    fact: "区分 sets×reps、以及 sets×reps×load 的容量负荷；不同指标回答不同问题。",
    guardrail: "容量负荷不等于肌肥大效果，也不是万能跨动作评分。",
    scope: "趋势统计语义",
  },
  {
    id: "E17",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; sections 37,40, Volume",
    fact: "增大容量可能增加刺激，但存在个体上限，睡眠、压力和恢复可改变可耐受训练量。",
    guardrail: "不能把单调加组作为唯一进步策略。",
    scope: "容量调整说明",
  },
  {
    id: "E18",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; sections 42–44, Frequency",
    fact: "训练频率是分配周训练量的一种手段；全身与分化各有适用性。",
    guardrail: "不能宣称某种分化形式普遍最优。",
    scope: "计划选择",
  },
  {
    id: "E19",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; sections 45–47, Load",
    fact: "1RM百分比到重复次数仅是粗略对应，个体与动作差异明显；肌肥大可出现于多种负荷区间。",
    guardrail: "不得用一次组表现无条件反推精准 1RM。",
    scope: "负荷与e1RM解读",
  },
  {
    id: "E20",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; sections 56–57, Rest Interval Length",
    fact: "短休息可能增加代谢压力但损害后续次数和容量，较长休息能保护质量；2016版讨论至少约2分钟的实用解释。",
    guardrail: "与NSCA2026表格口径不同：必须标注年份与适用场景，不自动改写服务端休息规则。",
    scope: "证据冲突说明",
  },
  {
    id: "E21",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch3; sections 66–68, Intensity of Effort",
    fact: "接近力竭程度影响刺激与疲劳，RIR/RPE 是可用但有误差的主观尺度。",
    guardrail: "不应追求每组力竭，也不能把RIR作为客观重复次数。",
    scope: "强度反馈",
  },
  {
    id: "E22",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch6; sections 92–105, Periodization/Deload",
    fact: "训练周期与减载是管理长期适应的工具，书中含不同模型和例子。",
    guardrail: "不能根据某次疲劳感直接诊断过度训练或硬性减载。",
    scope: "长期计划复盘",
  },
  {
    id: "E23",
    bookCode: "Sch",
    book: "Schoenfeld《Science and Development of Muscle Hypertrophy》（2016）",
    location: "EPUB Ch4; sections 74–75, Concurrent Training",
    fact: "有氧与力量的搭配需要关注训练模式、总量及安排，存在相互影响的可能。",
    guardrail: "不是“做有氧就妨碍增肌”，也不应强推取消有氧。",
    scope: "周计划有氧安排",
  },
  {
    id: "E24",
    bookCode: "RP",
    book: "Renaissance Periodization《Scientific Principles of Strength Training》",
    location: "PDF pp.26–27; Ch3 Specificity",
    fact: "适应具有目标特异性；力量举重点不同于普通增肌和整体体能。",
    guardrail: "不得把力量举周期规划直接作为用户增肌强制流程。",
    scope: "训练目标匹配",
  },
  {
    id: "E25",
    bookCode: "RP",
    book: "Renaissance Periodization《Scientific Principles of Strength Training》",
    location: "PDF pp.72–73; Ch4 Overload",
    fact: "超负荷需相对近期刺激且处于可产生适应的条件，单次更重并不必然更好。",
    guardrail: "不得鼓励失控动作或短时间大幅加重。",
    scope: "渐进超负荷解释",
  },
  {
    id: "E26",
    bookCode: "RP",
    book: "Renaissance Periodization《Scientific Principles of Strength Training》",
    location: "PDF pp.104–105; Ch5 Fatigue Management",
    fact: "训练会产生多维疲劳，需要放在跨次恢复中管理。",
    guardrail: "不因主观疲劳分值单独下调既定 A–G 目标。",
    scope: "疲劳指标参考",
  },
  {
    id: "E27",
    bookCode: "RP",
    book: "Renaissance Periodization《Scientific Principles of Strength Training》",
    location: "PDF pp.186–187; Ch6 SRA",
    fact: "刺激—恢复—适应描述跨次变化，恢复窗口与训练刺激相互关联。",
    guardrail: "不能用休息计时器长度代替跨天恢复判断。",
    scope: "周计划安排",
  },
  {
    id: "E28",
    bookCode: "RP",
    book: "Renaissance Periodization《Scientific Principles of Strength Training》",
    location: "PDF pp.308–309; Ch9 Individual Difference",
    fact: "个体间与同一个体不同时间的训练反应都可能不同。",
    guardrail: "不为所有用户写死统一的最佳训练量和休息时间。",
    scope: "个体化框架",
  },
  {
    id: "E29",
    bookCode: "Zat",
    book: "Zatsiorsky《Science and Practice of Strength Training》第 3 版（2021）",
    location: "PDF pp.79–96; Ch4 Training Intensity",
    fact: "训练强度有训练目标与负荷、主观/客观测量层面的区别。",
    guardrail: "单个百分比不能脱离动作、测量条件与能力解读。",
    scope: "强度指标词典",
  },
  {
    id: "E30",
    bookCode: "Zat",
    book: "Zatsiorsky《Science and Practice of Strength Training》第 3 版（2021）",
    location: "PDF pp.195–211; Ch9 Overreaching, Overtraining, Recovery",
    fact: "过度训练是涉及恢复与表现变化的长期问题，不能仅以一日疲劳确定。",
    guardrail: "应用不可给出医学诊断。",
    scope: "恢复趋势",
  },
  {
    id: "E31",
    bookCode: "Zat",
    book: "Zatsiorsky《Science and Practice of Strength Training》第 3 版（2021）",
    location: "PDF pp.213–230; Ch10 Monitoring Athletes",
    fact: "训练监测需要明确所测对象、采样方法与其随时间变化的解释。",
    guardrail: "无数据不能假定安全或已经进步。",
    scope: "趋势测量质量",
  },
  {
    id: "E32",
    bookCode: "Zat",
    book: "Zatsiorsky《Science and Practice of Strength Training》第 3 版（2021）",
    location: "PDF pp.177–194; Ch8 Injury Prevention",
    fact: "负荷、动作环境与训练技术等因素与受伤风险管理有关。",
    guardrail: "界面不能取代现场指导和专业评估。",
    scope: "停止提示",
  },
  {
    id: "E33",
    bookCode: "SS",
    book: "《Starting Strength: Basic Barbell Training》第 3 版（2011）",
    location: "EPUB Chapter 8: Programming; section 4 in archive",
    fact: "该初学者力量训练体系依赖简单大动作、适度渐增负荷与充足恢复；书内包含特定线性进阶方法。",
    guardrail: "仅限其项目假设；不可作为所有增肌用户的自动加重算法。",
    scope: "进阶方法参考",
  },
  {
    id: "E34",
    bookCode: "SS",
    book: "《Starting Strength: Basic Barbell Training》第 3 版（2011）",
    location: "EPUB Chapter 2: The Squat; section 18",
    fact: "深蹲技术学习涉及杠铃路径、站位及深度等多个相互关联的要素。",
    guardrail: "不能凭App仅有重量/次数就判定技术正确；不生成大重量挑战。",
    scope: "动作技术教育",
  },
  {
    id: "E35",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF pp.84–86; Level 2 Gaining Phase",
    fact: "作者对增肌阶段成年训练者给出蛋白质常用范围约1.6–2.2g/kg/day，并讨论摄入量与饱腹感个体差异。",
    guardrail: "非对所有年龄和身体状况的强制饮食处方；不与减脂章节高蛋白范围混用。",
    scope: "营养证据说明",
  },
  {
    id: "E36",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF p.68; Energy Availability",
    fact: "即使体重稳定，也可能存在运动与身体正常功能所需的可用能量不足。",
    guardrail: "不能只凭体重变化说营养充足；不提倡极端限制。",
    scope: "恢复与能量可用性",
  },
  {
    id: "E37",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF pp.112–114; Fluid Intake",
    fact: "液体需求存在个体差异，口渴与尿液颜色等可提供有限的日常参考。",
    guardrail: "单靠尿色不能诊断水合状态；维生素、疾病等会干扰。",
    scope: "补水提醒",
  },
  {
    id: "E38",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF pp.128–130; Meal Frequency",
    fact: "进餐规律性与可坚持性通常比苛刻固定餐次更重要，原书讨论常见3–6餐但并非强制。",
    guardrail: "不应对用户执行固定时刻进食或处罚漏餐。",
    scope: "饮食习惯建议",
  },
  {
    id: "E39",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF pp.132–136; Peri-Workout Nutrition",
    fact: "训练前后摄入蛋白与总体每日摄入相互关联，严格1小时窗口的必要性有限。",
    guardrail: "不能宣传错过训练后立刻补充就没有增肌效果。",
    scope: "训练后营养提示",
  },
  {
    id: "E40",
    bookCode: "HNu",
    book: "Helms《The Muscle and Strength Pyramid: Nutrition》第 2 版（2018）",
    location: "PDF pp.77–84; Cutting Phase",
    fact: "减脂阶段宏量营养分配与增肌阶段不同，书中对减脂运动员另行讨论。",
    guardrail: "不得把减脂的上下限直接搬到增肌档案，更不得作为未成年人减脂指导。",
    scope: "场景排除",
  },
  {
    id: "E41",
    bookCode: "SN",
    book: "Jeukendrup、Gleeson《Sport Nutrition》第 2 版（2010）",
    location: "PDF pp.193–196; Protein and Amino Acids",
    fact: "力量与耐力运动蛋白需要的研究背景不同，书中同时讨论训练适应及不同人群。",
    guardrail: "2010教材数字可能过时；不作为唯一最新摄入量标准。",
    scope: "历史依据交叉检验",
  },
  {
    id: "E42",
    bookCode: "SN",
    book: "Jeukendrup、Gleeson《Sport Nutrition》第 2 版（2010）",
    location: "PDF pp.211–229; Water Requirements",
    fact: "出汗、环境热负荷、时长与个体差异影响补水需求，高温环境下风险上升。",
    guardrail: "不生成统一高剂量灌水策略，亦不把长时间耐力赛事补给直接用于日常力量训练。",
    scope: "补水与热环境提醒",
  },
  {
    id: "E43",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1679–1726; Ch24 Overreaching/Recovery",
    fact: "训练恢复需综合负荷、表现、生活压力与时间跨度分析。",
    guardrail: "不得按单次疲劳自我诊断“过度训练综合征”。",
    scope: "复盘风险提示",
  },
  {
    id: "E44",
    bookCode: "N5",
    book: "NSCA《Essentials of Strength Training and Conditioning》第 5 版",
    location: "PDF pp.1226–1228; Ch18 Testing",
    fact: "当不适合最大力量测试时，规范的3RM/5RM观察可用于估算，但也要求技术质量。",
    guardrail: "不得要求用户单独冒险测试1RM。",
    scope: "最大力量估算解释",
  },
] as const;

export type EvidenceClaim = (typeof EVIDENCE_CLAIMS)[number];

// 旧规则 → 证据映射（历史兼容保留）：旧建议卡与旧总结里的规则编号仍可
// 经此查到当时的解释依据；新裁决不再产生规则编号，改用下面的 ATI 主题
// 映射与裁决自带的 evidenceIds。
export const RULE_EVIDENCE: Record<string, string[]> = {
  A: ["E32", "E34", "E44"],
  B: ["E06", "E07", "E15", "E26"],
  C: ["E04", "E05", "E25"],
  D: ["E06", "E26", "E21"],
  E: ["E26", "E27", "E17"],
  F: ["E22", "E30", "E43"],
  G: ["E36", "E26", "E06"],
};

// ATI 主题 → 证据：证据库按裁决主题筛选、以及决策循环检索的主题锚点。
// 停止取技术安全（E32 风险管理、E34 深蹲技术要素、E44 估算以技术合格
// 为前提）；加重取 2-for-2 原文（E04）与其限制（E05）、超负荷条件
// （E25）；休息取 NSCA 休息口径（E06/E07）与 Helms/Schoenfeld 的讨论。
export const ATI_TOPIC_EVIDENCE: Record<string, { label: string; ids: string[] }> = {
  CONTINUE: { label: "按计划继续", ids: ["E06", "E07", "E15", "E26"] },
  INCREASE_LOAD: { label: "增加负重", ids: ["E04", "E05", "E25", "E28"] },
  DECREASE_LOAD: { label: "降低负重", ids: ["E06", "E21", "E26"] },
  REST: { label: "休息调整", ids: ["E06", "E07", "E15", "E20"] },
  SETS: { label: "组数调整", ids: ["E09", "E17", "E26", "E27"] },
  SUBSTITUTE_EXERCISE: { label: "更换动作", ids: ["E08", "E14", "E32"] },
  STOP: { label: "安全停止", ids: ["E32", "E34", "E44"] },
  RECOVERY: { label: "恢复与减载", ids: ["E22", "E26", "E27", "E30", "E36", "E43"] },
};

// 原则 → 证据：原则页每条原则按需展开的原书定位。
export const PRINCIPLE_EVIDENCE: Record<string, string[]> = {
  "渐进超负荷": ["E25", "E28", "E04"],
  "RIR/RPE 与力竭": ["E12", "E13", "E21"],
  "容量与频率": ["E01", "E09", "E16", "E17", "E18"],
  "强度与次数区间": ["E02", "E03", "E10", "E19"],
  "组间休息": ["E06", "E07", "E15", "E20"],
  "热身与动作技术": ["E08", "E32", "E34", "E11"],
  "恢复与减载": ["E26", "E27", "E30", "E43", "E22"],
};

// 趋势页指标 → 证据：统计数字仍以 getStats 为唯一来源，这里只给定义
// 与口径的原书解释（fitness-trend-analytics 路由）。
export const METRIC_EVIDENCE: Record<string, { definition: string; evidenceIds: string[] }> = {
  volume: {
    definition: "容量负荷 = Σ（已完成且未跳过的力量组 实际重量 × 实际次数），只算有重量的组；它回答「做了多少功」，不等于增肌效果，也不能跨动作直接排名。",
    evidenceIds: ["E16", "E31"],
  },
  avgRest: {
    definition: "平均组间休息只统计力量组中实际记录且 > 0 秒的休息样本，分母是有效样本数；有氧组的 0 秒不计入，没有样本时显示 -- 而不是 0。",
    evidenceIds: ["E06", "E07", "E31"],
  },
  rirDist: {
    definition: "RIR 分布只统计已完成且填了 RIR 的力量组，分母是有效 RIR 样本数；未填感受的组单列、不补 0 也不补默认值。RIR 是主观估计，与完成次数矛盾时以完成次数为准。",
    evidenceIds: ["E12", "E13", "E31"],
  },
  est1rm: {
    definition: "当日最大重量是实际做过的最大重量，不等于实测 1RM；估算 1RM 由服务端按 Epley 公式（重量 ×(1 + 次数/30)）从当日最佳组推算，只是粗略对应，不能反推成下次必须完成的处方。",
    evidenceIds: ["E19", "E44"],
  },
};

// 下次训练建议的原书解释（fitness-progressions + fitness-recovery 路由）：
// 建议由 finishSession 的 ATI 复盘流程（模型综合本次记录与历史事实）
// 产生，这组证据只解释「为什么这样进阶、为什么先看恢复」。
export const NEXT_SUGGESTION_EVIDENCE: string[] = ["E04", "E05", "E25", "E26", "E30", "E43"];

// 总结页的训练后提示（fitness-nutrition 路由）：只给一般性说明，不把
// 任何历史个人设定写成普遍强制目标，不给强制热量/水量数字。
export const NUTRITION_NOTE = {
  copy: "训练完成。建议按平时规律正常进餐、注意补水；想记录的话，可以把今天的饮食情况记在训练备注里。没有饮食记录时这里只会显示「未记录」，不会推断达标或不达标。",
  evidenceIds: ["E35", "E38", "E39", "E37", "E42"] as string[],
};

// 计划总览的编排审查依据（fitness-hypertrophy-programming 路由）：只读
// 解释计划为什么这样编，不在此处改计划；改计划仍走既有编辑/保存流程。
export const PLAN_REVIEW_EVIDENCE: string[] = ["E01", "E08", "E03", "E09", "E07"];

// Skills 路由表（与 MUSE_INSTALL_PROMPT 第二步一一对应）：getEvidence
// 下发给原则页展示，让「哪个环节用了哪个 Skill」在页面上可核查。
// fitness-evidence-guardian 是总守门：所有科学解释先过它——只从账本
// 选证据、标注 SOURCE_LIMITED、原书与系统规则分列。
export const SKILL_ROUTES = [
  { skill: "fitness-evidence-guardian", where: "全部科学解释的总守门：证据只从 44 条账本中选，状态标 SOURCE_LIMITED，原书命题与系统口径分列" },
  { skill: "fitness-session-flow", where: "今日训练页：一步一屏、休息计时、建议卡生命周期与 8 秒未返回先核验再重试" },
  { skill: "fitness-rir-feedback", where: "组后反馈表单与建议卡：RIR 五档与实际次数分开记录，缺失不补默认值" },
  { skill: "fitness-hypertrophy-programming", where: "计划总览「编排依据」：频率、动作顺序、负荷区间、容量与休息的只读解释" },
  { skill: "fitness-progressions", where: "下次训练建议的进阶解释：进阶要看跨课趋势（如 2-for-2 须连续两次训练课末组），单组表现不推导处方" },
  { skill: "fitness-recovery", where: "恢复分层与减载解释：恢复看多维趋势（睡眠区分偶发/连续/质量下降），单次疲劳不诊断过度训练" },
  { skill: "fitness-nutrition", where: "总结页训练后提示：正常进餐与补水的一般说明，不设强制热量/水量目标" },
  { skill: "fitness-trend-analytics", where: "趋势统计页「指标定义」：分母、空值与估算 1RM 的口径，数字以 getStats 为准" },
  { skill: "fitness-technique-safety", where: "ATI 安全停止裁决与停止提示的技术安全解释：停止信号由服务端确定性安全层执行，永不被解释层推翻" },
];

// 下肢/上肢判定（规则 C 的加重幅度不同）：按动作名关键词粗分，其余默认上肢。
export function isLowerBody(name: string): boolean {
  return /深蹲|硬拉|腿|臀|提踵|弓步|蹲|髋/.test(name);
}

export type BasisKind = "客观触发" | "主观感受参考";

// ---------------- ATI 统一训练决策协调器（设计 V1.0 第十章） ----------------
// evaluateRules 的替代：只留一个决策循环——观察状态 → 构建上下文 →
// 检索证据 → AI 综合判断 → 安全校验 → 执行决策 → 记录结果 → 更新状态。
// 所有正常训练调整都走这一个入口；加重/维持/降重/延长休息/减组不再是
// 独立程序。服务端只做确定性的事：组装事实、检索证据、校验安全边界、
// 把通过校验的裁决翻译成待确认建议；训练判断本身交给模型。
export type DeformValue = "未变形" | "变形" | "变形且无法纠正";

// 本组反馈的事实层整理（不是裁决）：完成次数、RIR、动作是否变形、
// 关节感受与持续酸痛标记。缺项明确列出，绝不补默认值；RIR 与完成
// 次数矛盾时以完成次数为准（事实标注，不据此自动下任何结论）。
export interface FeedbackFacts {
  repsKnown: boolean;
  target: number;
  actual: number;
  diff: number; // >0 = 少做的次数
  over: number; // >0 = 多做的次数
  shortfall2: boolean; // 本组少于目标 ≥2 次
  jointPain: boolean;
  jointTight: boolean;
  deformed: boolean;
  deformUncorrectable: boolean;
  rirZeroDeform: boolean;
  stopSignal: boolean;
  stopWhy: string | null;
  missing: string[];
  evidenceText: string;
  objectiveTrigger: boolean;
}

export function analyzeFeedback(input: {
  targetReps: string;
  actualReps: string | null;
  rir: number | null;
  deform: string | null;
  joint: string | null;
  sorenessOver72: boolean;
  note: string | null;
}): FeedbackFacts {
  const target = Number.parseInt(input.targetReps, 10);
  const actual = input.actualReps != null ? Number.parseInt(input.actualReps, 10) : Number.NaN;
  const repsKnown = Number.isFinite(target) && Number.isFinite(actual);
  const diff = repsKnown ? target - actual : 0;
  const over = repsKnown ? actual - target : 0;
  const jointText = input.joint ?? "";
  const jointPain = jointText.includes("刺痛");
  const jointTight = jointText.includes("发紧") || jointText.includes("紧");
  const noteDeform = /变形|做不起来|做不动|起不来|推不起来|拉不起来/.test(input.note ?? "");
  const deform: DeformValue | null =
    input.deform === "未变形" || input.deform === "变形" || input.deform === "变形且无法纠正"
      ? input.deform
      : noteDeform
        ? "变形"
        : null;
  const deformed = deform === "变形" || deform === "变形且无法纠正";
  const deformUncorrectable = deform === "变形且无法纠正";
  const rirZeroDeform = input.rir === 0 && deformed;

  const missing: string[] = [];
  if (!repsKnown) missing.push("完成次数");
  if (input.rir == null) missing.push("RIR");
  if (deform == null) missing.push("动作是否变形");
  if (!jointText.trim()) missing.push("关节感受");

  const rirContradiction =
    input.rir != null && repsKnown && input.rir >= 2 && diff >= 2
      ? `RIR 报 ${fmtRir(input.rir)} 但实际只完成 ${actual}/${target} 次，两者矛盾，以完成次数为准，RIR 视为估计错误`
      : null;

  const parts: string[] = [];
  parts.push(
    repsKnown
      ? `完成次数 ${actual}/${target}${diff > 0 ? `（少 ${diff} 次）` : over > 0 ? `（多 ${over} 次）` : ""}`
      : `完成次数未记录（目标 ${input.targetReps}）`,
  );
  parts.push(
    input.rir != null
      ? `RIR ${fmtRir(input.rir)}（还能标准地做 ${input.rir >= 3 ? "3 个以上" : `${Math.round(input.rir)} 个`}）`
      : "RIR 未记录",
  );
  parts.push(deform != null ? `动作${deform}` : "动作是否变形未记录");
  parts.push(jointText.trim() ? `关节${jointText}` : "关节感受未记录");
  if (input.sorenessOver72) parts.push("同一部位持续酸痛超过 72 小时仍在训练");
  if (rirContradiction) parts.push(rirContradiction);

  const stopSignal = jointPain || deformUncorrectable || rirZeroDeform || input.sorenessOver72;
  const stopWhy = jointPain
    ? "关节刺痛"
    : deformUncorrectable
      ? "动作变形且无法纠正"
      : rirZeroDeform
        ? "RIR 0 且动作变形（技术力竭）"
        : input.sorenessOver72
          ? "同一部位持续酸痛超过 72 小时仍训练"
          : null;

  return {
    repsKnown,
    target: repsKnown ? target : 0,
    actual: repsKnown ? actual : 0,
    diff,
    over,
    shortfall2: repsKnown && diff >= 2,
    jointPain,
    jointTight,
    deformed,
    deformUncorrectable,
    rirZeroDeform,
    stopSignal,
    stopWhy,
    missing,
    evidenceText: parts.join("；"),
    objectiveTrigger: stopSignal || (repsKnown && diff >= 2) || deformed,
  };
}

// 决策循环的统一输入（设计 V1.0 §10.3 的落地形状）：由 submitFeedback
// 从真实记录组装；睡眠与营养当前没有采集入口，恒为「未记录」，不推测。
export interface AtiDecisionInput {
  exerciseName: string;
  setIdx: number;
  isLastSetOfExercise: boolean;
  plannedSetsTotal: number;
  targetWeightKg: number | null;
  targetReps: string;
  plannedRestSeconds: number; // 下一组（剩余第一组）的原定休息；无剩余组时为本组原定休息
  actualWeightKg: number | null;
  actualReps: string | null;
  rir: number | null;
  deform: string | null;
  joint: string | null;
  sorenessOver72: boolean;
  pump: number | null;
  fatigue: number | null;
  note: string | null;
  testDay: boolean;
  remaining: Array<{ setIdx: number; targetWeightKg: number | null; targetReps: string; targetRestSeconds: number }>;
  earlierToday: Array<{
    setIdx: number;
    targetWeightKg: number | null;
    targetReps: string;
    actualWeightKg: number | null;
    actualReps: string | null;
    rir: number | null;
    deform: string | null;
    joint: string | null;
  }>;
  prevSession: {
    date: string;
    sets: Array<{ targetWeightKg: number | null; targetReps: string; actualWeightKg: number | null; actualReps: string | null; rir: number | null }>;
  } | null;
  recentSessions: Array<{ date: string; summary: string }>;
  laterExercises: string[];
  sessionElapsedMin: number | null;
}

// 模型的结构化裁决（设计 V1.0 §10.4）：动作可组合，评估带恢复分层、
// 准备度分项与置信度，证据只允许引用服务端检索后给出的条目 ID。
const atiActionParam = z.object({
  type: z.enum(ATI_ACTION_IDS),
  targetWeightKg: z.number().nullable(),
  targetReps: z.string().nullable(),
  setsDelta: z.number().int().min(-10).max(2),
  substituteName: z.string().nullable(),
  nextSessionWeightKg: z.number().nullable(),
  note: z.string(),
});

const atiDecisionOut = z.object({
  primaryAction: z.enum(ATI_ACTION_IDS),
  actions: z.array(atiActionParam).min(1).max(5),
  restSeconds: z.number().int().nullable(),
  assessment: z.object({
    performance: z.string(),
    recoveryLevel: z.enum(["GREEN", "BLUE", "AMBER", "RED", "UNKNOWN"]),
    technique: z.string(),
    jointStatus: z.string(),
    confidence: z.number().min(0).max(1),
    readiness: z.object({
      performance: z.number().min(0).max(100).nullable(),
      sleep: z.number().min(0).max(100).nullable(),
      fatigue: z.number().min(0).max(100).nullable(),
      soreness: z.number().min(0).max(100).nullable(),
      nutrition: z.number().min(0).max(100).nullable(),
      psychology: z.number().min(0).max(100).nullable(),
    }),
  }),
  evidenceIds: z.array(z.string()),
  reasoningSummary: z.string(),
  nextObservation: z.array(z.string()),
  questionForUser: z.string().nullable(),
});
type AtiDecisionRaw = z.infer<typeof atiDecisionOut>;

// 安全校验并归一化后的可执行裁决：字段直接映射到待确认建议的执行层。
export interface AtiOutcome {
  primaryAction: AtiActionId;
  actionIds: AtiActionId[];
  actionNotes: Array<{ type: AtiActionId; note: string }>;
  nextWeightKg: number | null;
  nextReps: string | null;
  restSeconds: number | null;
  setsDelta: number;
  replaceWith: string | null;
  nextSessionWeightKg: number | null;
  stopSession: boolean;
  recoveryLevel: "GREEN" | "BLUE" | "AMBER" | "RED" | "UNKNOWN";
  confidence: number;
  readiness: ReadinessScores;
  readinessOverall: number | null;
  evidenceIds: string[];
  reasoningSummary: string;
  nextObservation: string[];
  questionForUser: string | null;
  guardNotes: string[];
  fromModel: boolean;
}

// 证据检索：按本次上下文的话题从 44 条账本里选相关条目给模型。
// 话题由事实触发（停止信号→安全停止、次数缺口→降重/恢复、达标且有
// 余力→加重…），休息话题恒定包含；结果按账本顺序、最多 7 条。
function retrieveEvidence(input: AtiDecisionInput, facts: FeedbackFacts): EvidenceClaim[] {
  const topics = new Set<string>(["CONTINUE", "REST"]);
  if (facts.stopSignal) topics.add("STOP");
  if (facts.shortfall2 || facts.deformed) {
    topics.add("DECREASE_LOAD");
    topics.add("RECOVERY");
  }
  if (facts.repsKnown && facts.diff <= 0 && input.rir != null && input.rir >= 2) topics.add("INCREASE_LOAD");
  if (input.remaining.length > 0 && (facts.shortfall2 || input.rir === 0)) topics.add("SETS");
  if ((input.fatigue ?? 0) >= 7) topics.add("RECOVERY");
  if (facts.deformed && !facts.stopSignal) topics.add("SUBSTITUTE_EXERCISE");
  const wanted = new Set<string>();
  for (const t of topics) {
    for (const id of ATI_TOPIC_EVIDENCE[t]?.ids ?? []) wanted.add(id);
  }
  return EVIDENCE_CLAIMS.filter((c) => wanted.has(c.id)).slice(0, 7);
}

// 参考重量：本次实际、本组目标与剩余组目标里的最大值（安全上限的锚）。
function referenceWeight(input: AtiDecisionInput): number {
  const cands = [
    input.actualWeightKg ?? 0,
    input.targetWeightKg ?? 0,
    ...input.remaining.map((r) => r.targetWeightKg ?? 0),
  ];
  return Math.max(...cands, 0);
}

// 确定性安全校验（设计 V1.0 §10.6）：返回违规清单；空 = 通过。
// 只查安全与数据边界，不查「练得对不对」——那是模型的判断。
function validateDecision(
  raw: AtiDecisionRaw,
  input: AtiDecisionInput,
  facts: FeedbackFacts,
): string[] {
  const violations: string[] = [];
  const remainingCount = input.remaining.length;
  const types = raw.actions.map((a) => a.type);
  const ref = referenceWeight(input);
  const weightCap = ref > 0 ? Math.round(ref * 1.1 * 2) / 2 : 400;

  // 明确停止信号出现时必须停止相关动作
  if (facts.stopSignal && !types.includes("STOP_EXERCISE") && !types.includes("STOP_SESSION")) {
    violations.push(`出现明确停止信号（${facts.stopWhy ?? "停止信号"}），裁决必须包含 STOP_EXERCISE 或 STOP_SESSION`);
  }
  if (facts.stopSignal) {
    const totalDelta = raw.actions.reduce((acc, a) => acc + a.setsDelta, 0);
    const stopsAll =
      types.includes("STOP_SESSION") || totalDelta <= -remainingCount;
    if (!stopsAll && remainingCount > 0) {
      violations.push("停止信号下必须停掉该动作当日全部剩余组（setsDelta 需覆盖全部剩余组）");
    }
  }

  for (const a of raw.actions) {
    if (a.targetWeightKg != null) {
      if (!(a.targetWeightKg > 0)) violations.push(`动作 ${a.type} 的目标重量 ${a.targetWeightKg}kg 不合法：重量不得为负或零`);
      else if (a.targetWeightKg > weightCap) {
        violations.push(`动作 ${a.type} 的目标重量 ${a.targetWeightKg}kg 超出计划支持的负荷范围（参考重量 ${ref}kg，单次上调上限约 ${weightCap}kg）`);
      }
    }
    if (a.nextSessionWeightKg != null && !(a.nextSessionWeightKg > 0)) {
      violations.push(`动作 ${a.type} 的下次训练建议重量不合法：重量不得为负或零`);
    }
    if (a.setsDelta < -remainingCount) {
      violations.push(`动作 ${a.type} 的减组数超过剩余组数（剩余 ${remainingCount} 组）`);
    }
  }

  if (raw.restSeconds != null && (raw.restSeconds < 30 || raw.restSeconds > 600)) {
    violations.push(`休息 ${raw.restSeconds} 秒超出可执行范围（30–600 秒）`);
  }
  // 回归测试 T16：完成目标次数、RIR 3+、动作稳定、无停止信号时，
  // 不得在原定休息之外无理由加时。
  const t16 =
    !facts.stopSignal &&
    facts.repsKnown &&
    facts.diff <= 0 &&
    input.rir != null &&
    input.rir >= 3 &&
    !facts.deformed;
  if (t16 && raw.restSeconds != null && raw.restSeconds > input.plannedRestSeconds) {
    violations.push(
      `回归 T16：完成目标次数、RIR 3+、动作稳定时，休息不得超过原定 ${input.plannedRestSeconds} 秒（模型给了 ${raw.restSeconds} 秒）`,
    );
  }

  // 测试日保护：测试重量不下调、测试组不减、测试动作不替换（停止信号除外）
  if (input.testDay && !facts.stopSignal) {
    for (const a of raw.actions) {
      if (a.type === "DECREASE_LOAD") violations.push("测试日：不得降低测试重量");
      if (a.setsDelta < 0) violations.push("测试日：不得减少测试组数");
      if (a.type === "SUBSTITUTE_EXERCISE") violations.push("测试日：不得替换测试动作");
    }
  }
  return violations;
}

// 把通过校验的模型裁决归一化成可执行结果：组合动作逐项落到执行字段，
// 证据 ID 只保留账本里真实存在的，准备度总分由服务端按已提供维度
// 加权重算（模型给的总分不采信），置信度过低时剥离进取型动作改保守。
function normalizeDecision(
  raw: AtiDecisionRaw,
  input: AtiDecisionInput,
  facts: FeedbackFacts,
): AtiOutcome {
  const guardNotes: string[] = [];
  const remainingCount = input.remaining.length;
  let actions = [...raw.actions];
  let primary = raw.primaryAction as AtiActionId;
  let confidence = raw.assessment.confidence;

  // 置信度低：优先保守——剥离加重/加组，改为维持并说明（设计 §9.3）
  if (confidence < 0.5 && !facts.stopSignal) {
    const aggressive = actions.filter((a) => a.type === "INCREASE_LOAD" || a.type === "ADD_SET");
    if (aggressive.length) {
      actions = actions.filter((a) => a.type !== "INCREASE_LOAD" && a.type !== "ADD_SET");
      if (primary === "INCREASE_LOAD" || primary === "ADD_SET") primary = "MAINTAIN_LOAD";
      if (!actions.length) {
        actions = [{ type: "CONTINUE", targetWeightKg: null, targetReps: null, setsDelta: 0, substituteName: null, nextSessionWeightKg: null, note: "置信度不足，保守按计划继续" }];
        primary = "CONTINUE";
      }
      guardNotes.push(`决策置信度偏低（${Math.round(confidence * 100)}%）：已剥离加重/加组等进取动作，改走保守方案`);
    }
  }

  let nextWeightKg: number | null = null;
  let nextReps: string | null = null;
  let setsDelta = 0;
  let replaceWith: string | null = null;
  let nextSessionWeightKg: number | null = null;
  let stopSession = false;
  for (const a of actions) {
    if (
      (a.type === "INCREASE_LOAD" || a.type === "DECREASE_LOAD" || a.type === "MAINTAIN_LOAD") &&
      a.targetWeightKg != null
    ) {
      nextWeightKg = a.targetWeightKg;
    }
    if (a.targetReps != null) nextReps = a.targetReps;
    if (a.type === "REDUCE_SETS" || a.type === "ADD_SET" || a.type === "STOP_EXERCISE") {
      setsDelta += a.setsDelta;
    }
    if (a.type === "STOP_EXERCISE") setsDelta = remainingCount > 0 ? -remainingCount : 0;
    if (a.type === "STOP_SESSION") {
      stopSession = true;
      setsDelta = remainingCount > 0 ? -remainingCount : 0;
    }
    if (a.type === "SUBSTITUTE_EXERCISE" && a.substituteName) replaceWith = a.substituteName;
    if (a.nextSessionWeightKg != null) nextSessionWeightKg = a.nextSessionWeightKg;
  }
  setsDelta = Math.max(-Math.max(remainingCount, 0), Math.min(2, setsDelta));
  // MAINTAIN_LOAD 若给出的重量与剩余组目标相同，执行层视为无改动
  if (nextWeightKg != null && input.remaining.length && input.remaining.every((r) => r.targetWeightKg === nextWeightKg)) {
    nextWeightKg = null;
  }
  if (nextReps != null && input.remaining.length && input.remaining.every((r) => r.targetReps === nextReps)) {
    nextReps = null;
  }

  const restSeconds = raw.restSeconds;
  const validIds = new Set<string>(EVIDENCE_CLAIMS.map((c) => c.id));
  const evidenceIds = [...new Set(raw.evidenceIds)].filter((id) => validIds.has(id));
  if (evidenceIds.length !== raw.evidenceIds.length) {
    guardNotes.push("裁决引用了账本之外的证据编号，已剔除，只保留 44 条账本内的来源");
  }

  const readiness: ReadinessScores = {
    performance: raw.assessment.readiness.performance,
    sleep: raw.assessment.readiness.sleep,
    fatigue: raw.assessment.readiness.fatigue,
    soreness: raw.assessment.readiness.soreness,
    nutrition: raw.assessment.readiness.nutrition,
    psychology: raw.assessment.readiness.psychology,
  };
  // 恢复分层：停止信号直接定为 RED（疼痛与安全不被其他维度抵消）
  const recoveryLevel = facts.stopSignal ? "RED" : raw.assessment.recoveryLevel;

  return {
    primaryAction: primary,
    actionIds: [...new Set(actions.map((a) => a.type))],
    actionNotes: actions.map((a) => ({ type: a.type, note: a.note })),
    nextWeightKg,
    nextReps,
    restSeconds,
    setsDelta,
    replaceWith,
    nextSessionWeightKg,
    stopSession,
    recoveryLevel,
    confidence,
    readiness,
    readinessOverall: computeReadinessOverall(readiness),
    evidenceIds,
    reasoningSummary: raw.reasoningSummary,
    nextObservation: raw.nextObservation,
    questionForUser: raw.questionForUser,
    guardNotes,
    fromModel: true,
  };
}

// 保守缺省裁决：模型不可用、或两次裁决都通不过安全校验时使用。
// 它不是一条「训练规则」，只是执行层的安全缺省：有停止信号就停，
// 其余按原计划继续、休息按原定值（绝不 +60 秒），并如实标注来源。
function fallbackOutcome(input: AtiDecisionInput, facts: FeedbackFacts, reason: string): AtiOutcome {
  const readiness: ReadinessScores = {
    performance: null,
    sleep: null,
    fatigue: null,
    soreness: null,
    nutrition: null,
    psychology: null,
  };
  if (facts.stopSignal) {
    return {
      primaryAction: "STOP_EXERCISE",
      actionIds: ["STOP_EXERCISE"],
      actionNotes: [{ type: "STOP_EXERCISE", note: reason }],
      nextWeightKg: null,
      nextReps: null,
      restSeconds: null,
      setsDelta: input.remaining.length > 0 ? -input.remaining.length : 0,
      replaceWith: null,
      nextSessionWeightKg: null,
      stopSession: false,
      recoveryLevel: "RED",
      confidence: 1,
      readiness,
      readinessOverall: null,
      evidenceIds: (ATI_TOPIC_EVIDENCE.STOP?.ids ?? []).slice(0, 3),
      reasoningSummary: reason,
      nextObservation: ["确认不适部位与性质，恢复后再评估是否继续今天剩余训练"],
      questionForUser: null,
      guardNotes: [reason],
      fromModel: false,
    };
  }
  return {
    primaryAction: "CONTINUE",
    actionIds: ["CONTINUE"],
    actionNotes: [{ type: "CONTINUE", note: reason }],
    nextWeightKg: null,
    nextReps: null,
    restSeconds: input.remaining.length ? input.plannedRestSeconds : null,
    setsDelta: 0,
    replaceWith: null,
    nextSessionWeightKg: null,
    stopSession: false,
    recoveryLevel: "UNKNOWN",
    confidence: 0.5,
    readiness,
    readinessOverall: null,
    evidenceIds: [],
    reasoningSummary: reason,
    nextObservation: ["记录下一组的完成次数、RIR 与动作质量"],
    questionForUser: null,
    guardNotes: [reason],
    fromModel: false,
  };
}

// 把可执行裁决翻成一句话结论（执行层文案本身不做任何判断）
function describeOutcome(o: AtiOutcome, exerciseName: string, remainingCount: number): string {
  const parts: string[] = [];
  if (o.actionIds.includes("STOP_SESSION")) parts.push("结束本次训练");
  else if (o.actionIds.includes("STOP_EXERCISE")) parts.push(`停止 ${exerciseName} 当日剩余 ${remainingCount} 组`);
  if (o.replaceWith) parts.push(`剩余组换成「${o.replaceWith}」`);
  if (o.nextWeightKg != null) parts.push(`剩余组重量改为 ${o.nextWeightKg}kg`);
  if (o.nextReps != null) parts.push(`剩余组次数改为 ${o.nextReps}`);
  if (o.setsDelta < 0 && !o.actionIds.includes("STOP_EXERCISE") && !o.actionIds.includes("STOP_SESSION")) {
    parts.push(`减少 ${-o.setsDelta} 组`);
  }
  if (o.setsDelta > 0) parts.push(`增加 ${o.setsDelta} 组`);
  if (o.restSeconds != null && remainingCount > 0) parts.push(`休息 ${o.restSeconds} 秒`);
  if (o.nextSessionWeightKg != null) parts.push(`下次训练建议 ${o.nextSessionWeightKg}kg 起步`);
  if (o.actionIds.includes("GATHER_INFORMATION")) parts.push("先补充关键信息再定后续强度");
  if (o.actionIds.includes("DELOAD")) parts.push("建议安排减载（只作建议，不直接改计划）");
  return parts.length ? parts.join("，") : "按原计划继续，重量、组数、休息都不变";
}

// 给模型的上下文（§10.3）：结构化 JSON。未记录的数据显式写 null 并在
// prompt 里声明「null = 未记录，不得假设为正常」。
function buildContextJson(input: AtiDecisionInput, facts: FeedbackFacts): string {
  const rest = baseRestRange(input.exerciseName);
  const ctx = {
    event: {
      type: "set_completed",
      exercise: input.exerciseName,
      set_number: input.setIdx + 1,
      sets_total: input.plannedSetsTotal,
      is_last_set_of_exercise: input.isLastSetOfExercise,
    },
    goal: {
      primary: "hypertrophy（增肌优先：2027 年 8 月前 60kg → 70kg）",
      secondary: "strength（卧推 120kg、深蹲 130kg 做组为长期参考目标）",
      training_phase: "reconditioning（恢复训练期，分化训练、一周可练 6 天，容量从低量渐进爬坡）",
    },
    planned: {
      load_kg: input.targetWeightKg,
      target_reps: input.targetReps,
      planned_rest_seconds: input.plannedRestSeconds,
      remaining_sets: input.remaining.map((r) => ({
        set_number: r.setIdx + 1,
        load_kg: r.targetWeightKg,
        target_reps: r.targetReps,
        rest_seconds: r.targetRestSeconds,
      })),
    },
    actual: {
      load_kg: input.actualWeightKg,
      reps: input.actualReps,
      rir: input.rir,
      technique: input.deform,
      joint_feedback: input.joint,
      user_note: input.note,
    },
    recovery: {
      sleep_hours: null,
      sleep_note: "未记录",
      fatigue_1_10: input.fatigue,
      pump_1_5: input.pump,
      soreness_over_72h: input.sorenessOver72,
      nutrition_status: "未记录",
    },
    history: {
      earlier_sets_today: input.earlierToday.map((s) => ({
        set_number: s.setIdx + 1,
        planned: `${s.targetWeightKg ?? "未设"}kg×${s.targetReps}`,
        actual: `${s.actualWeightKg ?? "未设"}kg×${s.actualReps ?? "未记录"}`,
        rir: s.rir,
        technique: s.deform,
        joint: s.joint,
      })),
      previous_session_same_exercise: input.prevSession
        ? {
            date: input.prevSession.date,
            sets: input.prevSession.sets.map((s) => ({
              planned: `${s.targetWeightKg ?? "未设"}kg×${s.targetReps}`,
              actual: `${s.actualWeightKg ?? "未设"}kg×${s.actualReps ?? "未记录"}`,
              rir: s.rir,
            })),
          }
        : null,
      recent_sessions_same_exercise: input.recentSessions,
    },
    constraints: {
      test_day: input.testDay,
      later_exercises_today: input.laterExercises,
      session_elapsed_min: input.sessionElapsedMin,
      base_rest_range_seconds: { category: rest.category, min: rest.min, max: rest.max },
      safety_protocol: "active（停止信号与负荷边界由服务端确定性校验，见任务说明）",
    },
    facts_digest: facts.evidenceText,
    missing_data: facts.missing,
  };
  return JSON.stringify(ctx, null, 1);
}

// 决策循环主体：检索证据 → 模型裁决 → 安全校验（违规时带原因重试
// 一次）→ 归一化执行结果。模型不可用或两次都违规时走保守缺省。
async function runAtiDecision(
  ctx: Ctx,
  input: AtiDecisionInput,
  facts: FeedbackFacts,
): Promise<AtiOutcome> {
  const evidence = retrieveEvidence(input, facts);
  const rest = baseRestRange(input.exerciseName);
  const contextJson = buildContextJson(input, facts);
  const actionCatalog = ATI_ACTIONS.map((a) => `- ${a.id}（${a.name}）：${a.detail}`).join("\n");
  const restTableText = REST_TABLE.map((r) => `- ${r.category}：${r.min}–${r.max} 秒`).join("\n");
  const evidenceText = evidence.length
    ? evidence
        .map((c) => `- ${c.id}｜${c.book}｜${c.location}｜命题：${c.fact}｜边界：${c.guardrail}`)
        .join("\n")
    : "（本次没有检索到直接相关的账本证据，可以不引用证据，但要在 reasoningSummary 里说明依据来自上下文与训练常识）";

  const basePrompt = [
    "你正在为一个训练者做组间裁决。他刚完成一组训练并提交了反馈，你要综合目标、计划、实际表现、恢复状态与历史，决定接下来怎么练。",
    "",
    "== 训练上下文（JSON；null 表示未记录，绝不能假设为正常值）==",
    contextJson,
    "",
    "== 本次动作的基础休息参考 ==",
    `${input.exerciseName} 属于「${rest.category}」，基础休息 ${rest.min}–${rest.max} 秒。完整基础表：\n${restTableText}`,
    "休息不是固定值：结合 RIR、是否完成目标次数、动作质量与主观恢复（呼吸、局部疲劳）在基础表内决定；表现轻松（完成目标、RIR 3+、动作稳定）时按原定休息执行，不要额外加时；接近力竭或恢复不足时才延长。重负荷深蹲/硬拉即使 RIR 较高，呼吸未恢复也可以用足基础休息上限。",
    "",
    "== 可引用的专业证据（只能从这里选 evidenceIds）==",
    evidenceText,
    "证据状态为 SOURCE_LIMITED（章节与关键片段已定位核验，非整书逐页审计）：可以引用支持判断，但不要把单条命题说成普遍定律。另有最新共识可作背景：ACSM 2026 抗阻训练立场声明（Currier et al.，综合 137 篇综述、3 万余人）——每周每肌群至少约 10 组总体有利增肌；训练至瞬时力竭不是必需，2–3 RIR 是实用的努力程度参考；每周至少两次训练主要肌群。",
    "",
    "== 裁决动作空间（可组合多个）==",
    actionCatalog,
    "组合示例：保持重量同时延长休息；降低重量同时保持剩余组数；停止某个动作但保留其他无不适的训练；今天不调整、只修改下次训练起点。每个动作在 note 里用一句话写清执行要点；涉及剩余组的重量/次数/组数变化写进对应参数（targetWeightKg / targetReps / setsDelta，减组为负、加组为正、停止动作用 STOP_EXERCISE 且 setsDelta 覆盖全部剩余组）。下次训练的重量建议写 nextSessionWeightKg（只写建议，系统不会直接改计划）。",
    "",
    "== 判断要点 ==",
    "1. 安全第一但不要过度停止：正常肌肉疲劳与酸胀通常可继续评估；轻微僵硬先观察、询问或调整；新出现的锐痛、明显关节疼痛、动作变形且无法纠正、持续酸痛超过 72 小时仍训练——必须停止相关动作。上下文 facts_digest 若标注了停止信号，裁决必须包含 STOP_EXERCISE 或 STOP_SESSION。",
    "2. 表现决定负荷：RIR 是主要强度指标，但要结合是否完成目标次数、动作质量、同重量下 RIR 的逐组变化与历史趋势。复合动作优先保留余力；不必追求力竭。",
    "3. 睡眠不能只看一个阈值：要区分偶发不足、连续不足、质量下降、以及是否伴随表现下降——历史与备注里没有的信息就当未记录，不要编造。单日表现波动不等于过度训练；多项恢复指标（表现趋势、酸痛、睡眠、意愿）持续恶化才考虑 DELOAD。",
    "4. 准备度评分（readiness）：六个维度各 0–100 分——表现 30%、睡眠 20%、疲劳 15%、酸痛 10%、营养 15%、心理 10%。只能给有数据支撑的维度打分：睡眠与营养未记录时必须填 null（系统按已提供维度加权重算总分，缺失不记 0）；评分只辅助你组织判断，不许用总分机械决定练不练。",
    "5. 恢复分层（recoveryLevel）：GREEN 正常恢复 / BLUE 轻度恢复不足 / AMBER 明显恢复不足 / RED 安全风险 / UNKNOWN 信息不足。它是展示用的状态描述，不是判定程序；有疼痛或安全问题时不能被其他维度的好状态抵消。",
    "6. 置信度（confidence）：你对本次裁决的把握（0–1）。信息缺失多、信号矛盾时如实给低分，并优先用 GATHER_INFORMATION 在 questionForUser 里问清关键问题（部位、性质、严重程度），同时给出一个保守的当下方案，不要擅自假定安全。",
    "7. 测试日（constraints.test_day=true）：测试重量与组数是测数据用的，不因主观感受下调、减组或替换；只有停止信号能停测试。",
    "8. RIR 与完成次数矛盾时以完成次数为准（facts_digest 已标注）。",
    "",
    "reasoningSummary 用简体中文写 2–3 句：先说你怎么理解这一组（结合历史与恢复），再说为什么这样裁决。nextObservation 列出下一组要重点观察什么。所有文字用简体中文。",
  ].join("\n");

  const system =
    "你是 ATI（Adaptive Training Intelligence）自适应训练智能系统的决策核心。系统只保留一个决策循环：观察状态、检索证据、综合判断；不存在任何写死的训练规则路径，你的裁决就是判断本身。同时你受确定性安全边界约束：停止信号必须停、重量与休息不得越界、不得编造未记录的数据——违反的裁决会被服务端拒绝并要求重生成。";

  let lastViolations: string[] = [];
  for (let attempt = 0; attempt < 2; attempt++) {
    let raw: AtiDecisionRaw;
    try {
      raw = await ctx.inference.complete(
        attempt === 0
          ? basePrompt
          : `${basePrompt}\n\n== 上一次裁决未通过安全校验，必须修正 ==\n${lastViolations.map((v) => `- ${v}`).join("\n")}\n请重新给出完整裁决：保留合理的训练判断，只修正上面列出的安全与边界问题。`,
        { system, schema: atiDecisionOut, timeout_secs: 90 },
      );
    } catch {
      return fallbackOutcome(
        input,
        facts,
        facts.stopSignal
          ? `安全边界：出现明确停止信号（${facts.stopWhy ?? "停止信号"}），先停止该动作当日剩余组；本次 AI 裁决不可用，已按确定性安全方案执行`
          : "本次 AI 裁决暂时不可用，已按保守缺省执行：按原计划继续，休息按原定时间，不额外加时；下一组反馈会重新进入决策循环",
      );
    }
    const violations = validateDecision(raw, input, facts);
    if (!violations.length) {
      return normalizeDecision(raw, input, facts);
    }
    lastViolations = violations;
  }
  const fb = fallbackOutcome(
    input,
    facts,
    facts.stopSignal
      ? `安全边界：出现明确停止信号（${facts.stopWhy ?? "停止信号"}），先停止该动作当日剩余组；AI 裁决两次未通过安全校验（${lastViolations.join("；")}），已按确定性安全方案执行`
      : `AI 裁决两次未通过安全校验（${lastViolations.join("；")}），已按保守缺省执行：按原计划继续，休息按原定时间`,
  );
  fb.guardNotes = [...fb.guardNotes, ...lastViolations.map((v) => `安全校验未通过：${v}`)];
  return fb;
}

const exerciseSchema = z.object({
  name: z.string().min(1),
  note: z.string().default(""),
  // 动作类别：显式存储优先，缺失时按名称/次数形式自动识别（跑步机等为 cardio）
  category: z.enum(["strength", "cardio"]).optional(),
  sets: z
    .array(
      z.object({
        weightKg: z.number().nullable(),
        reps: z.string().min(1),
        restSeconds: z.number().int().min(0).max(3600),
        // 热身组：排在工作组前面、组间歇 120 秒、可记录，但不计入工作组数
        warmup: z.boolean().default(false),
      }),
    )
    .min(1),
});
type Exercise = z.infer<typeof exerciseSchema>;

// 工作组口径（全站统一）：热身组（warmup=true）排在工作组前、可记录，
// 但不计入当天总组数、每周总组数与各肌群折算组数。
function workSetCount(ex: Exercise): number {
  return ex.sets.filter((s) => !s.warmup).length;
}
function warmupSetCount(ex: Exercise): number {
  return ex.sets.filter((s) => s.warmup).length;
}

// 配重取整（用户 2026-11-23 纠正、2026-11-24 定版）：杠铃片有 2.5kg 档、
// 杠 20kg，杠铃总重可配重量为 5 的倍数（25、30…65、70、75…），计划重量
// 向下取整到最近的 5 的倍数（如 65 保持 65、62.5→60、102.5→100；
// 62.5、102.5 这类带 .5 的仍配不出来）；哑铃 2.5kg 一档向下取整；
// 其他器械（固定器械/绳索等档位自有刻度）不取整。生成计划与保存计划共用。
function loadableWeight(exerciseName: string, w: number | null): number | null {
  if (w == null) return null;
  if (exerciseName.includes("杠铃")) {
    if (w <= 20) return 20;
    return Math.floor(w / 5) * 5;
  }
  if (exerciseName.includes("哑铃")) return Math.max(0, Math.floor(w / 2.5) * 2.5);
  return w;
}
function normalizeExerciseWeights(exercises: Exercise[]): Exercise[] {
  return exercises.map((e) => ({
    ...e,
    sets: e.sets.map((s) => ({ ...s, weightKg: loadableWeight(e.name, s.weightKg) })),
  }));
}

// ATI 裁决落成的一份待确认调整建议（不含建议文案，文案存在 aiSuggestion）。
// basisPrinciple / basisKind 是「依据注记」：这条裁决主要依据什么、是客观
// 触发（次数缺口/停止信号/动作变形）还是主观感受参考，必须随建议一起
// 展示与存档，不允许只给结论。ATI 字段（atiActions 起）为新裁决写入；
// 旧记录的 proposal 没有这些字段，靠 default 兜底解析，不影响历史展示。
const proposalSchema = z.object({
  nextWeightKg: z.number().nullable(),
  nextReps: z.string().nullable(),
  restSeconds: z.number().int().nullable(),
  // 停止动作时需要跳过当日全部剩余组，故下限放宽到 -10
  setsDelta: z.number().int().min(-10).max(2),
  replaceWith: z.string().nullable(),
  stopWarning: z
    .object({ message: z.string(), affectedExercises: z.array(z.string()) })
    .nullable(),
  guardNotes: z.array(z.string()),
  basisPrinciple: z.string(),
  basisKind: z.enum(["客观触发", "主观感受参考"]),
  // rule 保留字段名兼容旧记录：新裁决写入「ATI · 主裁决动作中文名」；
  // evidence 是本组反馈事实摘要；action 是主裁决动作的中文名。
  rule: z.string(),
  evidence: z.string(),
  action: z.string(),
  nextSessionWeightKg: z.number().nullable(),
  // 新裁决里存「下一步观察」（next_observation）；旧记录里是恢复排查清单
  recoveryChecklist: z.array(z.string()),
  // ATI 扩展：组合裁决动作 ID、决策置信度、恢复分层、准备度总分与引用证据
  atiActions: z.array(z.string()).default([]),
  confidence: z.number().nullable().default(null),
  recoveryLevel: z.string().nullable().default(null),
  readinessOverall: z.number().nullable().default(null),
  evidenceIds: z.array(z.string()).default([]),
});
type Proposal = z.infer<typeof proposalSchema>;

const alertSchema = z.object({
  id: z.string(),
  exerciseIdx: z.number(),
  exerciseName: z.string(),
  message: z.string(),
  acknowledged: z.boolean(),
});
type AlertT = z.infer<typeof alertSchema>;

const setLogOut = z.object({
  id: z.number(),
  sessionId: z.number(),
  exerciseName: z.string(),
  exerciseIdx: z.number(),
  setIdx: z.number(),
  targetWeightKg: z.number().nullable(),
  targetReps: z.string(),
  targetRestSeconds: z.number(),
  origWeightKg: z.number().nullable(),
  origReps: z.string(),
  origRestSeconds: z.number(),
  actualWeightKg: z.number().nullable(),
  actualReps: z.string().nullable(),
  durationMin: z.number().nullable(),
  pace: z.string().nullable(),
  distanceKm: z.number().nullable(),
  restSeconds: z.number().nullable(),
  done: z.boolean(),
  skipped: z.boolean(),
  skippedBy: z.string().nullable(),
  // 热身组（从计划组表快照）：可记录，但不计入工作组数与统计口径
  warmup: z.boolean(),
  // 旧版记录兼容：legacyRecord=已标记为旧版原样保留（不参与连续失败判定）；
  // needsRir=旧版已完成组缺 RIR/变形/关节三项证据，等用户在横幅里处理
  legacyRecord: z.boolean(),
  needsRir: z.boolean(),
  difficulty: z.string().nullable(),
  rir: z.number().nullable(),
  deform: z.string().nullable(),
  sorenessOver72: z.boolean(),
  joint: z.string().nullable(),
  pump: z.number().nullable(),
  fatigue: z.number().nullable(),
  note: z.string().nullable(),
  aiSuggestion: z.string().nullable(),
  aiRule: z.string().nullable(),
  aiEvidence: z.string().nullable(),
  aiAction: z.string().nullable(),
  aiBasisPrinciple: z.string().nullable(),
  aiBasisKind: z.string().nullable(),
  aiAdjustments: z.array(
    z.object({
      type: z.string(),
      detail: z.string(),
      kind: z.enum(["客观触发", "主观感受参考", "信息性"]),
    }),
  ),
  proposalStatus: z.string().nullable(),
  proposal: proposalSchema.nullable(),
  appliedNote: z.string().nullable(),
  // 裁决在途状态：running（裁决进行中）| done（已落库）| failed（中断）|
  // null（从未提交过裁决）。客户端据此在刷新/回前台后恢复裁决状态。
  adjudicationStatus: z.string().nullable(),
  adjudicationStartedAt: z.number().nullable(),
});
type SetLogOut = z.infer<typeof setLogOut>;

const sessionOut = z.object({
  id: z.number(),
  planId: z.number().nullable(),
  date: z.string(),
  title: z.string(),
  status: z.string(),
  startedAt: z.string().nullable(),
  endedAt: z.string().nullable(),
  summaryMd: z.string().nullable(),
  review: z.string().nullable(),
  nextSuggestion: z.string().nullable(),
  driveStatus: z.string(),
  driveFileName: z.string().nullable(),
  driveLink: z.string().nullable(),
  alerts: z.array(alertSchema),
});
type SessionOut = z.infer<typeof sessionOut>;

type Db = SpaceDb<typeof schema>;

function parseAlerts(json: string | null): AlertT[] {
  if (!json) return [];
  try {
    const parsed = z.array(alertSchema).safeParse(JSON.parse(json));
    return parsed.success ? parsed.data : [];
  } catch {
    return [];
  }
}

function parseProposal(json: string | null): Proposal | null {
  if (!json) return null;
  try {
    const parsed = proposalSchema.safeParse(JSON.parse(json));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

function toSetLogOut(row: typeof schema.setLogs.$inferSelect): SetLogOut {
  let adjustments: SetLogOut["aiAdjustments"] = [];
  if (row.aiAdjustments) {
    try {
      const parsed: unknown = JSON.parse(row.aiAdjustments);
      if (Array.isArray(parsed)) {
        adjustments = parsed
          .filter(
            (a): a is { type: string; detail: string; kind?: unknown } =>
              typeof a === "object" && a !== null &&
              typeof (a as { type?: unknown }).type === "string" &&
              typeof (a as { detail?: unknown }).detail === "string",
          )
          .map((a) => ({
            type: a.type,
            detail: a.detail,
            kind:
              a.kind === "客观触发" || a.kind === "主观感受参考" || a.kind === "信息性"
                ? a.kind
                : ("信息性" as const),
          }));
      }
    } catch {
      adjustments = [];
    }
  }
  return {
    id: row.id,
    sessionId: row.sessionId,
    exerciseName: row.exerciseName,
    exerciseIdx: row.exerciseIdx,
    setIdx: row.setIdx,
    targetWeightKg: row.targetWeightKg,
    targetReps: row.targetReps,
    targetRestSeconds: row.targetRestSeconds,
    // 旧数据没有原始快照时回退到当前目标（未被调整过即等同原始计划）
    origWeightKg: row.origWeightKg ?? row.targetWeightKg,
    origReps: row.origReps ?? row.targetReps,
    origRestSeconds: row.origRestSeconds ?? row.targetRestSeconds,
    actualWeightKg: row.actualWeightKg,
    actualReps: row.actualReps,
    durationMin: row.durationMin,
    pace: row.pace,
    distanceKm: row.distanceKm,
    restSeconds: row.restSeconds,
    done: row.done === 1,
    skipped: row.skipped === 1,
    skippedBy: row.skippedBy,
    warmup: row.warmup === 1,
    // 旧版记录识别：已完成、有旧版难度字段、但新版三项证据（RIR/变形/关节）
    // 全缺。读侧一律空值安全：rir 原样可为 null，deform/joint 由前端兜底显示。
    legacyRecord:
      row.legacy === 1 ||
      (row.done === 1 && row.rir == null && row.deform == null && row.joint == null && row.difficulty != null),
    needsRir:
      row.legacy !== 1 &&
      row.done === 1 &&
      row.rir == null &&
      row.deform == null &&
      row.joint == null &&
      row.difficulty != null,
    difficulty: row.difficulty,
    rir: row.rir,
    deform: row.deform,
    sorenessOver72: row.sorenessOver72 === 1,
    joint: row.joint,
    pump: row.pump,
    fatigue: row.fatigue,
    note: row.note,
    aiSuggestion: row.aiSuggestion,
    aiRule: row.aiRule,
    aiEvidence: row.aiEvidence,
    aiAction: row.aiAction,
    aiBasisPrinciple: row.aiBasisPrinciple,
    aiBasisKind: row.aiBasisKind,
    aiAdjustments: adjustments,
    proposalStatus: row.proposalStatus,
    proposal: parseProposal(row.proposalJson),
    appliedNote: row.appliedNote,
    adjudicationStatus: row.adjudicationStatus,
    adjudicationStartedAt: row.adjudicationStartedAt ? row.adjudicationStartedAt.getTime() : null,
  };
}

function toSessionOut(row: typeof schema.sessions.$inferSelect): SessionOut {
  return {
    id: row.id,
    planId: row.planId,
    date: row.date,
    title: row.title,
    status: row.status,
    startedAt: row.startedAt ? row.startedAt.toISOString() : null,
    endedAt: row.endedAt ? row.endedAt.toISOString() : null,
    summaryMd: row.summaryMd,
    review: row.review,
    nextSuggestion: row.nextSuggestion,
    driveStatus: row.driveStatus,
    driveFileName: row.driveFileName,
    driveLink: row.driveLink,
    alerts: parseAlerts(row.alertJson),
  };
}

function parseExercises(json: string): Exercise[] {
  try {
    const parsed = z.array(exerciseSchema).safeParse(JSON.parse(json));
    return parsed.success ? parsed.data : [];
  } catch {
    return [];
  }
}

// 测试日判定：开关显式开（1）→ 是；显式关（-1）→ 否；未设置（0）→ 标题或
// 任一动作的名称/备注含「摸底」或「测试」时自动算测试日。
function effectiveTestDay(
  flag: number,
  title: string,
  exercises: Exercise[],
): boolean {
  if (flag === 1) return true;
  if (flag === -1) return false;
  const hay = title + exercises.map((e) => `${e.name} ${e.note}`).join(" ");
  return /摸底|测试/.test(hay);
}

function repsNumber(reps: string | null): number {
  if (!reps) return 0;
  const n = Number.parseInt(reps, 10);
  return Number.isFinite(n) ? n : 0;
}

function setVolume(s: SetLogOut): number {
  if (!s.done) return 0;
  const w = s.actualWeightKg ?? s.targetWeightKg;
  if (w == null) return 0;
  return w * repsNumber(s.actualReps ?? s.targetReps);
}

function fmtWeight(w: number | null): string {
  return w == null ? "未设" : `${w}kg`;
}

// 摘要表格用：重量未定且次数不是纯数字（如「20分钟」）时只显示次数本身
function fmtPairS(w: number | null, reps: string): string {
  if (w == null && !/^\d/.test(reps.trim())) return reps;
  return `${fmtWeight(w)} × ${reps}`;
}

// 平均休息只计力量组：目标休息为 0 的有氧组（如跑步机）不进分母。
function strengthAvgRest(sets: SetLogOut[]): number | null {
  const rests = sets
    .filter((s) => s.restSeconds != null && s.targetRestSeconds > 0)
    .map((s) => s.restSeconds ?? 0);
  return rests.length ? Math.round(rests.reduce((a, b) => a + b, 0) / rests.length) : null;
}

function buildSummaryMd(session: SessionOut, sets: SetLogOut[]): string {
  // 完成组数与训练量只计工作组：热身组单列，不计入工作组口径
  const workRows = sets.filter((s) => !s.warmup);
  const warmupRows = sets.filter((s) => s.warmup);
  const doneSets = workRows.filter((s) => s.done);
  const doneWarmups = warmupRows.filter((s) => s.done);
  const volume = Math.round(workRows.reduce((acc, s) => acc + setVolume(s), 0));
  const avgRest = strengthAvgRest(sets);
  const durationMin =
    session.startedAt && session.endedAt
      ? Math.max(1, Math.round((new Date(session.endedAt).getTime() - new Date(session.startedAt).getTime()) / 60000))
      : null;

  const lines: string[] = [];
  lines.push(`# 健身日志 ${session.date}｜${session.title}`);
  lines.push("");
  lines.push(
    `- 完成组数：${doneSets.length}/${workRows.length}` +
      (warmupRows.length ? `（另有热身组 ${doneWarmups.length}/${warmupRows.length}，不计入工作组）` : "") +
      (durationMin != null ? `｜总时长：约 ${durationMin} 分钟（按起止时间四舍五入到分钟）` : "｜总时长：未记录") +
      `｜训练量估算（负重组）：约 ${volume} kg` +
      (avgRest != null ? `｜平均组间休息（仅力量组）：${avgRest} 秒` : ""),
  );
  lines.push("");
  lines.push("## 计划 vs 实际");
  lines.push("");
  lines.push("| 动作 | 组 | 原始计划 | 调整后目标 | 实际 | 休息 | 配速 | 感受 |");
  lines.push("| --- | --- | --- | --- | --- | --- | --- | --- |");
  for (const s of sets) {
    const orig = fmtPairS(s.origWeightKg, s.origReps);
    const target = fmtPairS(s.targetWeightKg, s.targetReps);
    let actual: string;
    if (s.skipped) {
      actual = s.skippedBy === "ai" ? "跳过（Muse 建议，经本人确认）" : "跳过（本人决定）";
    } else if (s.done) {
      actual =
        s.durationMin != null
          ? `${s.durationMin} 分钟${s.distanceKm != null ? ` · ${s.distanceKm} km` : ""}`
          : fmtPairS(s.actualWeightKg ?? s.targetWeightKg, s.actualReps ?? s.targetReps);
    } else {
      actual = "未完成";
    }
    const feel = [
      s.rir != null
        ? `RIR ${fmtRir(s.rir)}`
        : (s.difficulty ?? ""),
      s.deform ? `动作：${s.deform}` : "",
      s.joint ? `关节：${s.joint}` : "",
      s.sorenessOver72 ? "持续酸痛>72h" : "",
      s.pump != null ? `泵感 ${s.pump}/5（参考）` : "",
      s.fatigue != null ? `疲劳 ${s.fatigue}/10（参考）` : "",
      s.note ?? "",
    ].filter(Boolean).join("；");
    lines.push(
      `| ${s.exerciseName} | ${s.warmup ? "热身" : s.setIdx + 1} | ${orig} | ${target} | ${actual} | ${s.restSeconds != null ? `${s.restSeconds}s` : "—"} | ${s.pace ?? "—"} | ${feel} |`,
    );
  }
  // 只收录用户已确认接受、且服务端记录了实际改动的调整；被忽略/撤销的不进总结，
  // 更不会把 AI 的跳组建议写成用户自己的决定。每条都带依据注记（引用原则 +
  // 依据性质），与训练原则页口径一致。
  const applied = sets.filter((s) => s.proposalStatus === "accepted" && s.appliedNote);
  if (applied.length) {
    lines.push("");
    lines.push("## 训练中经本人确认的调整");
    lines.push("");
    for (const s of applied) {
      const basis =
        s.aiRule && s.aiBasisPrinciple
          ? `（${s.aiRule}；依据原则：${s.aiBasisPrinciple} · ${s.aiBasisKind ?? "主观感受参考"}${s.aiEvidence ? `；证据：${s.aiEvidence}` : ""}）`
          : s.aiBasisPrinciple && s.aiBasisKind
            ? `（依据：${s.aiBasisPrinciple} · ${s.aiBasisKind}）`
            : "";
      lines.push(`- ${s.exerciseName} 第 ${s.setIdx + 1} 组后：${s.appliedNote ?? ""}${basis}`);
    }
  }
  // 未被接受、但留有建议文案的组：单列「建议与依据」存档，注明未生效，
  // 让历史复盘时能看到当时建议的理由，而不是只有一个结论。
  const noted = sets.filter(
    (s) => s.aiSuggestion && s.proposalStatus !== "accepted" && s.aiBasisPrinciple,
  );
  if (noted.length) {
    lines.push("");
    lines.push("## 未采纳/仅供参考的建议与依据");
    lines.push("");
    for (const s of noted) {
      lines.push(
        `- ${s.exerciseName} 第 ${s.setIdx + 1} 组：${s.aiSuggestion}（${s.aiRule ? `${s.aiRule}；` : ""}依据原则：${s.aiBasisPrinciple} · ${s.aiBasisKind ?? "主观感受参考"}；状态：${s.proposalStatus === "dismissed" ? "已忽略，未生效" : "无需改动后续组"}）`,
      );
    }
  }
  if (session.review) {
    lines.push("");
    lines.push("## 本次复盘");
    lines.push("");
    lines.push(session.review);
  }
  if (session.nextSuggestion) {
    lines.push("");
    lines.push("## 下次训练建议");
    lines.push("");
    lines.push(session.nextSuggestion);
  }
  lines.push("");
  return lines.join("\n");
}

// 组装摘要并启动 Drive 上传任务（用户 agent 经已连接的 Drive CLI 执行）。
// 返回是否成功启动；结果由 recordDriveUpload 回写。
// 同一天重复上传（已有文件名记录）视为新建副本：文件名加 HHmm 时间后缀，
// 避免 Drive 里出现两个同名文件分不清哪份是新的。
async function startDriveUpload(
  ctx: Ctx,
  db: Db,
  row: typeof schema.sessions.$inferSelect,
): Promise<boolean> {
  const sets = await loadSessionSets(db, row.id);
  const session = toSessionOut(row);
  const md = row.summaryMd ?? buildSummaryMd(session, sets);
  if (!row.summaryMd) {
    await db
      .update(schema.sessions)
      .set({ summaryMd: md })
      .where(eq(schema.sessions.id, row.id));
  }
  const hhmmss = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Shanghai",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  })
    .format(new Date())
    .replace(/:/g, "");
  const fileName = row.driveFileName
    ? `健身日志-${row.date}-${hhmmss}.md`
    : `健身日志-${row.date}.md`;
  await db
    .update(schema.sessions)
    .set({ driveStatus: "pending", driveFileName: fileName })
    .where(eq(schema.sessions.id, row.id));

  const message = [
    `请把下面这份健身训练摘要上传到用户的 Google Drive：`,
    `0. 先调用本空间的 getSessionDetail 动作核对：sessionId=${row.id} 的训练必须真实存在、status 为 completed、date 为 ${row.date}、title 为「${row.title}」。核对不上就立即中止，不要上传，也不要回写成功。`,
    `1. 把摘要全文原样写入本地文件 /home/hatch/${fileName}（内容见下方，逐字写入，不要改动）。`,
    `2. 用 /opt/hatch/bin/hatch_gws_cli drive files list 查询名为「健身日志」的文件夹（mimeType = 'application/vnd.google-apps.folder'）；若不存在，用 drive files create 在根目录新建该文件夹（mimeType 同上，parents 为 ["root"]，params 带 ignoreDefaultVisibility: true）。`,
    `3. 用 hatch_gws_cli drive files +upload /home/hatch/${fileName} 上传到该文件夹（--parent <文件夹ID> --name ${fileName}）；如不确定参数，先跑 --help 查看。`,
    `4. 用 drive files get 读取上传后文件的 webViewLink。`,
    `5. 最后调用本空间的 recordDriveUpload 动作回写结果：sessionId=${row.id}，成功时 ok=true、fileName="${fileName}"、link=<webViewLink>；失败时 ok=false、error 写明失败原因。`,
    ``,
    `--- 摘要内容开始 ---`,
    md,
    `--- 摘要内容结束 ---`,
  ].join("\n");

  const spawned = await ctx.agent.spawnTask(message, {
    expectsAction: "recordDriveUpload",
    dedupeKey: `drive-upload-${row.id}`,
  });
  if (!spawned.ok) {
    await db
      .update(schema.sessions)
      .set({ driveStatus: "failed" })
      .where(eq(schema.sessions.id, row.id));
    return false;
  }
  return true;
}

async function loadSessionSets(db: Db, sessionId: number): Promise<SetLogOut[]> {
  const rows = await db
    .select()
    .from(schema.setLogs)
    .where(eq(schema.setLogs.sessionId, sessionId))
    .orderBy(asc(schema.setLogs.exerciseIdx), asc(schema.setLogs.setIdx));
  return rows.map(toSetLogOut);
}

async function loadSessionRow(db: Db, sessionId: number) {
  const rows = await db
    .select()
    .from(schema.sessions)
    .where(eq(schema.sessions.id, sessionId))
    .limit(1);
  return rows[0] ?? null;
}

// 生成总结前的校验：已接受的调整必须有逐项 appliedNote（由接受动作按实际
// diff 生成）；万一缺失，补一条兜底说明，绝不凭空编造改动明细。
async function verifyAppliedNotes(db: Db, sessionId: number): Promise<void> {
  const rows = await db
    .select()
    .from(schema.setLogs)
    .where(eq(schema.setLogs.sessionId, sessionId));
  for (const r of rows) {
    if (r.proposalStatus === "accepted" && !r.appliedNote) {
      await db
        .update(schema.setLogs)
        .set({ appliedNote: "已接受 Muse 的调整建议（改动明细见逐组「调整后目标」列）" })
        .where(eq(schema.setLogs.id, r.id));
    }
  }
}

const adviceOut = z.object({
  review: z.string(),
  nextSuggestion: z.string(),
});

// 跨课历史事实（给复盘模型的上下文，不是裁决）：按动作汇总最近几课的
// 完成情况、同重量重复未完成的事实、以及两周维度的最大重量对比。
// 只陈述数据发生了什么——是否减载、如何调整下次训练，由模型在 ATI
// 框架下综合判断，服务端不再像旧规则 F/G 那样先行下结论再拼注记。
async function historyFactsText(db: Db): Promise<string> {
  const sessionRows = await db
    .select()
    .from(schema.sessions)
    .where(eq(schema.sessions.status, "completed"))
    .orderBy(asc(schema.sessions.date), asc(schema.sessions.id));
  if (!sessionRows.length) return "（暂无已完成训练的历史记录）";
  type ExSession = { date: string; weight: number | null; failed: boolean; maxWeight: number | null };
  const byExercise = new Map<string, ExSession[]>();
  for (const row of sessionRows) {
    const sets = await loadSessionSets(db, row.id);
    const perEx = new Map<string, SetLogOut[]>();
    for (const s of sets) {
      const arr = perEx.get(s.exerciseName) ?? [];
      arr.push(s);
      perEx.set(s.exerciseName, arr);
    }
    for (const [name, exSets] of perEx) {
      // 热身组不参与失败判定（只看工作组）
      const done = exSets.filter((s) => s.done && !s.warmup);
      if (!done.length) continue;
      let failed = false;
      for (const s of done) {
        const t = Number.parseInt(s.targetReps, 10);
        const a = s.actualReps != null ? Number.parseInt(s.actualReps, 10) : Number.NaN;
        if (Number.isFinite(t) && Number.isFinite(a) && t - a >= 2) failed = true;
      }
      const weights = done
        .map((s) => s.targetWeightKg ?? s.actualWeightKg)
        .filter((w): w is number => w != null);
      const entry: ExSession = {
        date: row.date,
        weight: weights.length ? Math.max(...weights) : null,
        failed,
        maxWeight: weights.length ? Math.max(...weights) : null,
      };
      const arr = byExercise.get(name) ?? [];
      arr.push(entry);
      byExercise.set(name, arr);
    }
  }
  const lines: string[] = [`已完成训练共 ${sessionRows.length} 次（${sessionRows[0]?.date} 至 ${sessionRows[sessionRows.length - 1]?.date}）。`];
  for (const [name, list] of byExercise) {
    const recent = list.slice(-3);
    lines.push(
      `「${name}」最近 ${recent.length} 课：${recent
        .map((e) => `${e.date} 最大重量 ${e.maxWeight ?? "未设"}kg${e.failed ? "，有组少于目标 2 次以上" : "，无明显未完成组"}`)
        .join("；")}`,
    );
    const last2 = list.slice(-2);
    if (
      last2.length === 2 &&
      last2.every((e) => e.failed) &&
      last2[0]?.weight != null &&
      last2.every((e) => e.weight === last2[0]?.weight)
    ) {
      lines.push(
        `事实：「${name}」在 ${last2[0]?.weight}kg 已连续两次训练课出现未完成组（${last2.map((e) => e.date).join("、")}）——Starting Strength 官网 FAQ 的处理口径是先同重量重试、再失败则该动作减载 8–10% 后小幅爬回，供你判断时参考，不是必须执行的结论。`,
      );
    }
  }
  return lines.join("\n");
}

// 结束训练/重新生成建议共用的 ATI 复盘口径：同一个决策循环在「课后」
// 尺度的应用——模型综合本次记录与跨课历史事实形成复盘与下次建议，
// 不存在规则编号式的固定路径；服务端只提供事实与背景，不先行下结论。
const ATI_REVIEW_SYSTEM =
  "你是 ATI（Adaptive Training Intelligence）自适应训练智能系统的复盘核心。系统没有写死的进阶/降重规则：你综合本次训练记录与跨课历史事实，自主判断下次训练怎么安排。要求：每条关键建议写明依据的事实（哪一组、什么数据、什么趋势）；不编造未记录的数据（没记的 RIR、睡眠、营养就明说未记录，不假设达标或不达标）；安全问题（关节刺痛、动作变形、技术力竭、异常疼痛）必须点名并给出停止或评估建议；归因必须与记录一致。";

function atiReviewPrompt(summaryMd: string, historyFacts: string, when: string): string {
  return [
    `这是用户${when}训练的完整记录（原始计划 vs 调整后目标 vs 实际、每组反馈：完成次数/RIR/动作是否变形/关节感受/自由文字）：`,
    "",
    summaryMd,
    "",
    "== 跨课历史事实（只陈述数据，不含结论）==",
    historyFacts,
    "",
    "请写：review —— 2-4 句简体中文复盘，指出完成情况、表现变化（结合历史趋势，不要只看今天）与需要注意的安全问题；nextSuggestion —— 下次训练的具体建议（练什么、关键动作的重量/组数起点、组间休息、注意事项），简体中文，可分行。",
    "判断框架（ATI）：目标增肌优先（2027 年 8 月前 60kg → 70kg），力量为长期参考目标（卧推 120kg、深蹲 130kg 做组）。用户背景：60kg、170cm，恢复训练期，分化训练、一周可练 6 天，容量正从低量渐进爬坡（当前分化周约 65 组/周）——目标是足够刺激且能恢复，不是堆组数。",
    "进阶与回退都看证据组合：完成情况、RIR 趋势、动作质量、恢复状态与跨课趋势，单组的好坏不直接推出处方；同重量连续两次训练课未完成时，可参考历史事实里的 Starting Strength FAQ 口径考虑该动作减载重试，但要结合技术、睡眠、营养一起判断，不机械执行。恢复判断不要用「睡眠 7 小时」一个开关：区分偶发不足、连续不足、质量下降、是否伴随表现下降；睡眠与营养没有记录就明说未记录。",
    "组间休息按动作类型给：深蹲/硬拉 180–300 秒、卧推/划船/肩推 120–180 秒、上斜/腿举 120–180 秒、孤立 60–90 秒、腹部 45–90 秒，再按表现微调；不要给「一律多休 60 秒」这类固定加时。",
    "注意归因：记录里标注「跳过（Muse 建议，经本人确认）」的组是 AI 提议、用户确认后跳过的，不要写成用户自己临时决定的；只有标注「跳过（本人决定）」的才算用户自己的决定。下次建议只是建议、不会直接改动任何计划，措辞不要写成已经安排好了。",
  ].join("\n");
}

// ---------------- ATI v2.0：三层词表分离（设计 v2.0 + v2.0.1 + v2.0.2） ----------------
// v2.0 把三层对象彻底分开，互不混用：
//   A. Decision Vocabulary —— 上面的 ATI_ACTIONS 14 个决策动词（系统裁决类型，
//      不是动作清单）；
//   B. Exercise Library —— 下面 EXERCISE_LIBRARY：有出处登记的动作条目
//      （kb_v2.0.md 第六节去重后 50 个 + 2026-11-15 新增 EX52/EX53 = 52 个
//      唯一动作/变式，跑步机有氧单列），状态分
//      ACTIVE / CONDITIONAL / PROVISIONAL，CONDITIONAL 与 PROVISIONAL 只用于
//      检索核验，绝不得进入正式计划；
//   C. Equipment Snapshot —— EQUIPMENT_SNAPSHOT ATI-EQ-1.1（用户 2026-11-14
//      在健身房现场逐项确认）：没有有效快照不得生成计划；计划只能从 ACTIVE
//      库中选动作且必须通过当前快照硬过滤。未确认细节不得自动假设。
// 成人处方（用户 2026-11-14 21:50 定）：本系统从立项起仅面向成年人，不存在
// 未成年用户与青少年使用场景——系统内没有青少年配置、青少年默认处方与任何
// 年龄分支判断；用户画像只记成年人与成人处方配置，所有处方、目标、证据
// 一律按成年人处理（ACSM 2026 成人证据，适用人群 ≥18 岁）。

export const EQUIPMENT_SNAPSHOT = {
  id: "ATI-EQ-1.1",
  version: "1.1",
  confirmedAt: "2026-11-14",
  confirmationSource: "用户 2026-11-14 在健身房现场逐项口述确认（龙门架等器械逐项报出，髋铰链固定器械按其现场描述登记）",
  items: [
    { name: "龙门架/绳索站", detail: "已确认存在；站数、滑轮独立性、附件与配重范围未确认" },
    { name: "高位下拉", detail: "已确认" },
    { name: "牧师椅", detail: "已确认" },
    { name: "卧推架", detail: "已确认；保护条件（安全杠/保护者配置）未确认" },
    { name: "史密斯机", detail: "已确认" },
    { name: "深蹲架", detail: "已确认；安全杠配置未确认" },
    { name: "坐姿划船", detail: "已确认（固定器械）" },
    { name: "坐姿反手下拉", detail: "器械存在已确认；实际运动轨迹（垂直下拉还是水平划船）未核验，不得擅自认定模式" },
    { name: "固定推肩器械", detail: "已确认" },
    { name: "固定推胸器械（平板、上斜）", detail: "已确认两种配置" },
    { name: "蝴蝶机", detail: "已确认" },
    { name: "倒蹬腿举", detail: "已确认" },
    { name: "坐姿腿伸展", detail: "已确认（用户描述：坐姿压着脚踝把腿伸直）" },
    { name: "髋外展/内收器械", detail: "已确认" },
    {
      name: "髋主导/硬拉类固定器械",
      detail:
        "按用户现场描述登记：臀部后方有靠垫，向前髋铰链，双手拉动可装杠铃片的把手完成类似硬拉的动作；商品名、品牌、型号均未知，不得擅自命名；动作模式与肌群映射待实物核验",
    },
    { name: "哑铃", detail: "2.5kg 一档；最小/最大重量未知" },
    { name: "杠铃", detail: "5kg 一档；空杆重量与最大负重未知" },
    { name: "可调角度训练椅", detail: "已确认" },
    { name: "引体单杠", detail: "已确认" },
    { name: "跑步机", detail: "已确认；数量、速度/坡度范围未知" },
  ] as Array<{ name: string; detail: string }>,
  unconfirmed: [
    "绳索站数量、滑轮是否独立可调、附件种类（直杆/短杆/绳把/单把手）与配重范围",
    "各固定器械的品牌/型号",
    "深蹲架与卧推架的安全杠、保护者配置",
    "哑铃最小/最大重量；杠铃空杆重量与最大负重",
    "跑步机数量、速度与坡度范围",
    "场地拥挤度、器械等待情况与携重行走空间",
    "坐姿反手下拉与髋铰链固定器械的实际运动轨迹",
  ] as string[],
  gateRule:
    "硬性前置：无有效快照时不得生成计划，第一个输出必须是器械确认问题；「不确定」视为不可用，未确认细节不得自动假设。",
};

// 证据分级（v2.0.1）：动作/器械优劣由证据决定，不由助手主观或用户随口
// 印象决定。正反观点冲突时并列呈现。E5 视频证据当前仅登记 1 条（EX52
// 高卷腿引用的东哥视频，已实际观看核验）；E6 当前未登记任何条目——
// 未找到或未核验的视频不得编造频道、标题或引语。
export const EVIDENCE_GRADES: Array<{ grade: string; label: string; note: string }> = [
  { grade: "E1", label: "立场声明 / 系统综述 / Meta 分析", note: "最高等级；如 ACSM 2026 立场声明、Haugen 2023 机器与自由重量 Meta 分析" },
  { grade: "E2", label: "长期随机对照训练研究", note: "直接干预证据" },
  { grade: "E3", label: "机制 / 生物力学 / 肌电研究", note: "只用于解释机制，不单独证明长期优势" },
  { grade: "E4", label: "九本指定教材", note: "记版本、章节、页码/行范围；「教材列出该动作」只证明它是常用且有技术描述的选项，不证明比其他动作更有效" },
  { grade: "E5", label: "可核验学术/专业人士公开视频", note: "须记作者/频道、资历、标题、URL、时间戳、观点原文或准确转述、引用研究与利益冲突；补充解释，不与 E1/E2 等权。当前登记：EX52 高卷腿引用的东哥《练腹肌，我只推荐这个动作！》（Bilibili BV17noEYhEUU，2025-04-14，已实际观看核验）" },
  { grade: "E6", label: "一般博主 / 论坛 / 个人案例", note: "低可信度线索，不得独立决定动作评级。当前登记：无" },
];

type LibraryStatus = "ACTIVE" | "CONDITIONAL" | "PROVISIONAL";
// source_status（kb_v2.0.md §5）是独立于计划可用性 status 的来源核验字段：
// 一般条目沿用与 status 同值的登记口径（ACTIVE/CONDITIONAL/PROVISIONAL）；
// 来源已逐项核验的条目单独登记为 "verified"（目前仅 EX52 高卷腿，见
// EXERCISE_LIBRARY 构建处的独立登记）。代码库没有为 CONDITIONAL 条目另设
// 「未完全核验」的 source_status 约定值，故 EX53 保持 CONDITIONAL，不得
// 写成 verified。
type SourceStatus = LibraryStatus | "verified";
// kb_v2.0.md 第五节 §5 要求每个动作条目必须具有的全部字段（逐项对应）：
// exercise_id / canonical_name / variation_id / aliases / movement_patterns /
// primary_muscles / secondary_muscles / stabilizers / equipment_requirements /
// equipment_snapshot_match / technique_cues / common_errors / skill_level /
// population_scope / contraindications_stop_conditions / time_setup_cost /
// fatigue_cost / progression_options / replacement_chain / evidence_sources /
// evidence_appraisal / source_status / last_reviewed_at / version。
// 下面的 LibraryExerciseBase 是先期已转录的字段；其余 §5 字段在
// LIBRARY_SECTION5 里按条目补齐（内容逐条取自 kb 第六节的技术/适用/评价
// 原文或其直接引申，未核验处如实标注），合并后才是完整的 LibraryExercise。
interface LibraryExerciseBase {
  id: string; // exercise_id
  name: string; // canonical_name
  aliases: string[];
  patterns: string[]; // movement_patterns
  primary: string[]; // primary_muscles
  secondary: string[]; // secondary_muscles
  equipment: string[]; // equipment_requirements
  skill: string; // skill_level
  status: LibraryStatus; // 计划可用性口径（与 source_status 独立，见 SourceStatus）
  source: string; // evidence_sources
  appraisal: string; // evidence_appraisal
  stop: string; // contraindications_stop_conditions
  replacements: string[]; // replacement_chain
}
interface LibrarySection5 {
  variationId: string; // variation_id：该变式在动作族内的标识
  stabilizers: string[]; // stabilizers
  equipmentSnapshotMatch: string; // equipment_snapshot_match：与 ATI-EQ-1.1 的对齐情况
  techniqueCues: string; // technique_cues（技术要点，kb 第六节「技术」原文）
  commonErrors: string[]; // common_errors（常见错误，由技术要点与停止条件直接引申）
  populationScope: string; // population_scope（适用人群）
  timeSetupCost: string; // time_setup_cost（时间/设置成本）
  fatigueCost: string; // fatigue_cost（疲劳成本：局部/全身代价及确定性）
  progressionOptions: string[]; // progression_options（进阶选项）
}
interface LibraryExercise extends LibraryExerciseBase, LibrarySection5 {
  sourceStatus: SourceStatus; // source_status（§5 独立字段；一般与 status 同值，EX52 单独登记 verified）
  kind: "exercise" | "cardio"; // 跑步机有氧条目单列，不计入力量动作数
  lastReviewedAt: string; // last_reviewed_at
  version: string; // version（条目数据版本，对齐 kb 文档版本）
}

// Exercise Library v2.0（kb_v2.0.md 第六节逐条转录登记；出处与页码均取自
// 该文档，未核验项如实标注；不得虚构页码、DOI、视频与引语）。
// 设备依赖用快照口径命名；依赖未确认附件/空间/轨迹的条目标 CONDITIONAL
// 或 PROVISIONAL——它们只用于检索核验，绝不进入正式计划。
// 计数口径（kb_v2.0.1 数据清理说明）：原始条目行 51 行中，条目 21 与 25 是
// 同一台「坐姿反手下拉」器械，不得重复计数——已合并为单一 canonical 条目
// EX21；去重后唯一动作/变式共 50 个，其中跑步机有氧（EX51）单列为 cardio，
// 不计入力量动作数（49 个力量动作/变式 + 1 条有氧 = 50）。
// 2026-11-15 核心动作更新新增 2 条：EX52 高卷腿（ACTIVE）、EX53 绳索卷腹
// （CONDITIONAL，绳索把手附件未确认）——现库共 52 个（力量 51 + 有氧 1）。
const EXERCISE_LIBRARY_RAW: LibraryExerciseBase[] = [
  { id: "EX01", name: "杠铃平板卧推", aliases: ["杠铃卧推", "平板卧推", "卧推"], patterns: ["水平推"], primary: ["胸大肌"], secondary: ["前三角", "肱三头"], equipment: ["杠铃", "卧推架"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.430；Starting Strength 3e Ch5", appraisal: "E4 有明确技术章节；E1 设备类型比较不支持自由重量对肌肥大普遍更优。若目标是杠铃卧推专项力量，专项性支持其训练价值。不能称其对所有胸部目标绝对最佳。", stop: "无保护条件、肩腕疼痛或无法控制动作时不执行", replacements: ["固定平板胸推", "哑铃平板卧推"] },
  { id: "EX02", name: "哑铃平板卧推", aliases: ["哑铃卧推"], patterns: ["水平推"], primary: ["胸大肌"], secondary: ["前三角", "肱三头"], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.430（哑铃变式）；Helms Training 2e 水平推/动作选择", appraisal: "E4 支持其为卧推变式；E1/E2 未证明其普遍优于杠铃或机器。可提供独立侧控制和不同活动范围，具体优势结合个体与目标判断。", stop: "控制失稳或肩部不适时降低复杂度并评估", replacements: ["固定平板胸推", "杠铃平板卧推"] },
  { id: "EX03", name: "史密斯平板卧推", aliases: ["史密斯卧推"], patterns: ["水平推"], primary: ["胸大肌"], secondary: ["前三角", "肱三头"], equipment: ["史密斯机", "可调角度训练椅"], skill: "低", status: "ACTIVE", source: "Helms Training 2e Exercise Selection/机器与自由重量选择；ACSM 2026 设备类型比较", appraisal: "E1 不支持机器类在肌肥大上天然低效；固定轨迹个体适配差异较大。与自由卧推的直接长期比较证据不足。", stop: "固定轨迹不适配或不熟悉安全钩时不执行", replacements: ["固定平板胸推", "哑铃平板卧推"] },
  { id: "EX04", name: "固定平板胸推", aliases: ["固定胸推", "器械胸推"], patterns: ["水平推"], primary: ["胸大肌"], secondary: ["前三角", "肱三头"], equipment: ["固定推胸器械（平板）"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.434（Vertical Chest Press Machine）；Haugen 2023 机器/自由重量 Meta 分析（E1）", appraisal: "E1 设备类型比较未发现肌肥大普遍差异；固定轨迹可能降低稳定要求、便于快速设置。没有证据证明它对所有人比自由重量更高效。", stop: "轨迹引发疼痛则调整或替换", replacements: ["哑铃平板卧推", "杠铃平板卧推"] },
  { id: "EX05", name: "上斜哑铃卧推", aliases: ["上斜哑铃推举"], patterns: ["上斜水平推"], primary: ["胸大肌锁骨部"], secondary: ["前三角", "肱三头"], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.432；Schoenfeld《Science and Development of Muscle Hypertrophy》Ch3 exercise selection/ROM", appraisal: "E4 支持动作技术与目标肌群思路；特定上斜角度的长期最优角度证据有限。适合补充不同推举方向，不可宣称必然优于平板推胸。", stop: "肩前侧不适时调整角度或停止", replacements: ["固定上斜胸推", "杠铃上斜卧推"] },
  { id: "EX06", name: "固定上斜胸推", aliases: [], patterns: ["上斜水平推"], primary: ["胸大肌锁骨部"], secondary: ["前三角", "肱三头"], equipment: ["固定推胸器械（上斜）"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.434 胸推机器技术；ACSM 2026 设备类型综述（E1）", appraisal: "E1 机器与自由重量肌肥大未显示一致差异；该特定上斜机器相对哑铃上斜的直接比较证据不足。", stop: "轨迹不适配则换哑铃变式", replacements: ["上斜哑铃卧推", "杠铃上斜卧推"] },
  { id: "EX07", name: "杠铃上斜卧推", aliases: ["上斜杠铃卧推"], patterns: ["上斜水平推"], primary: ["胸大肌锁骨部"], secondary: ["前三角", "肱三头"], equipment: ["杠铃", "卧推架", "可调角度训练椅"], skill: "中高", status: "ACTIVE", source: "NSCA 5e Ch16 p.432（barbell variation）；Starting Strength 3e Ch5 技术原则", appraisal: "E4 技术来源；专项力量价值高于泛化机器替代，肌肥大方面无普遍优越证据。", stop: "须有保护条件和熟练技术，否则优先固定上斜胸推", replacements: ["固定上斜胸推", "上斜哑铃卧推"] },
  { id: "EX08", name: "蝴蝶机夹胸", aliases: ["蝴蝶机", "Pec Deck"], patterns: ["水平内收（胸部孤立）"], primary: ["胸大肌"], secondary: ["前三角"], equipment: ["蝴蝶机"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.435", appraisal: "E4 明确列出；单关节胸部补充可提供局部刺激，但单位时间覆盖肌群较少，通常不取代主要推举。没有证据证明它普遍优于绳索夹胸。", stop: "肩前侧不适或设备轴心不匹配时缩小范围/停止", replacements: ["绳索夹胸", "哑铃飞鸟"] },
  { id: "EX09", name: "绳索夹胸", aliases: ["龙门架夹胸"], patterns: ["水平内收（胸部孤立）"], primary: ["胸大肌"], secondary: ["前三角"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "中", status: "CONDITIONAL", source: "NSCA 5e Ch17 Variable Resistance Training；Helms Training 2e 水平推/孤立动作选择", appraisal: "E4 动作模式依据；直接比较长期增肌证据有限。双侧滑轮布置可能增加设置/占位成本，效率取决于场地。附件未确认，CONDITIONAL。", stop: "需确认两侧滑轮和把手；肩部不适时不做", replacements: ["蝴蝶机夹胸", "哑铃飞鸟"] },
  { id: "EX10", name: "固定器械肩推", aliases: ["器械肩推", "固定推肩"], patterns: ["垂直推"], primary: ["三角肌前束/中束"], secondary: ["肱三头"], equipment: ["固定推肩器械"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.457；ACSM 2026（E1）", appraisal: "E4 明确动作技术；E1 机器与自由重量没有肌肥大普遍差异。稳定轨迹可能减少平衡/设置要求，但不代表刺激必然更高。", stop: "轨迹引发疼痛时停止", replacements: ["坐姿哑铃肩推", "站姿杠铃推举"] },
  { id: "EX11", name: "坐姿哑铃肩推", aliases: ["哑铃肩推"], patterns: ["垂直推"], primary: ["三角肌前束/中束"], secondary: ["肱三头"], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.458（dumbbell variation）", appraisal: "E4 支持变式；机器/自由重量肌肥大无普遍差异。哑铃拿放与稳定成本可能高于固定器械，需计入时间效率。", stop: "肩部活动受限时不强迫幅度", replacements: ["固定器械肩推", "站姿杠铃推举"] },
  { id: "EX12", name: "站姿杠铃推举", aliases: ["杠铃推举", "站姿推举"], patterns: ["垂直推"], primary: ["三角肌前束/中束"], secondary: ["肱三头", "躯干稳定肌"], equipment: ["杠铃", "深蹲架"], skill: "高", status: "ACTIVE", source: "Starting Strength 3e Ch6 The Press；NSCA 5e Ch16 p.458", appraisal: "E4 有完整技术教学；对推举专项力量有特异性价值。若目标是节省时间并减少技术成本，固定肩推可能更方便；没有普遍肌肥大优势证据。", stop: "腰肩不适或无法控制时不安排", replacements: ["固定器械肩推", "坐姿哑铃肩推"] },
  { id: "EX13", name: "哑铃侧平举", aliases: ["侧平举"], patterns: ["肩外展孤立"], primary: ["三角肌中束"], secondary: ["冈上肌", "上斜方肌"], equipment: ["哑铃"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.460", appraisal: "E4 支持动作类别；作为中束定向补充有合理性，但没有充分证据证明其比所有绳索/器械侧平举更优。局部刺激目标明确，时间效率低于多关节动作但可能补足目标肌群。", stop: "肩部疼痛时停止或由专业人员评估动作范围", replacements: ["绳索侧平举", "固定器械肩推"] },
  { id: "EX14", name: "绳索侧平举", aliases: [], patterns: ["肩外展孤立"], primary: ["三角肌中束"], secondary: ["冈上肌", "上斜方肌"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "低", status: "CONDITIONAL", source: "NSCA 5e Ch17 Variable Resistance；NSCA 5e Ch16 p.460 侧平举动作模式", appraisal: "E4 模式支持；不同阻力曲线的长期优势尚不能仅凭急性肌电推断。单把手附件未确认，CONDITIONAL。", stop: "先确认单把手；肩部疼痛时停止", replacements: ["哑铃侧平举"] },
  { id: "EX15", name: "杠铃俯身划船", aliases: ["杠铃划船", "俯身划船"], patterns: ["水平拉"], primary: ["背阔肌", "菱形肌", "中斜方肌"], secondary: ["后三角", "肱二头", "躯干稳定肌"], equipment: ["杠铃"], skill: "中高", status: "ACTIVE", source: "NSCA 5e Ch16 p.420；Schoenfeld《肌肥大》背部训练章节（水平面划船）", appraisal: "E4 动作技术来源；多关节、单位动作覆盖多肌群，可能有时间效率优势；但躯干等长负荷较高，刺激/疲劳比因人而异。无证据证明它应永远作为背日首项。", stop: "腰背疲劳或技术不稳时选胸托/器械划船", replacements: ["坐姿器械划船", "胸托哑铃划船", "低位绳索坐姿划船"] },
  { id: "EX16", name: "Pendlay划船", aliases: [], patterns: ["水平拉"], primary: ["背阔肌", "中背"], secondary: ["肱二头", "躯干稳定肌"], equipment: ["杠铃"], skill: "高", status: "ACTIVE", source: "NSCA 5e Ch16 p.421", appraisal: "E4 有动作技术说明；更偏向严格起始与力量输出练习，不能假设比常规俯身划船更增肌或更省时。直接长期对照证据不足。", stop: "无法稳定控制起始位时不选", replacements: ["杠铃俯身划船", "坐姿器械划船"] },
  { id: "EX17", name: "单臂哑铃划船", aliases: ["哑铃单臂划船", "哑铃划船"], patterns: ["水平拉", "单侧"], primary: ["背阔肌", "中背"], secondary: ["后三角", "肱二头", "躯干抗旋转肌"], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.422；Helms Training 2e horizontal pull 选择", appraisal: "E4 明确列出；单侧训练可处理两侧差异，但逐侧完成会增加总用时。没有证据证明其总体优于双侧划船。", stop: "腰背不适时改胸托或坐姿器械", replacements: ["坐姿器械划船", "胸托哑铃划船"] },
  { id: "EX18", name: "胸托哑铃划船", aliases: [], patterns: ["水平拉"], primary: ["背阔肌", "中背"], secondary: ["后三角", "肱二头"], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "Helms Training 2e horizontal pull/bench-supported row 讨论；NSCA 5e Ch16 划船技术原则", appraisal: "E4 支持作为划船变式；减少躯干稳定需求是生物力学特点，但缺少其比坐姿划船更增肌的直接证据。时间成本需计入凳子设置。", stop: "凳子角度与支撑稳定性不满足时不选", replacements: ["坐姿器械划船", "单臂哑铃划船"] },
  { id: "EX19", name: "坐姿器械划船", aliases: ["坐姿划船", "坐姿绳索划船", "器械划船"], patterns: ["水平拉"], primary: ["背阔肌", "菱形肌", "中斜方肌"], secondary: ["后三角", "肱二头"], equipment: ["坐姿划船器械"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.424", appraisal: "E4 明确动作；机器训练在肌肥大方面未显示普遍劣势。设置较快、躯干稳定要求较低，可能具备较好的时间/疲劳效率；是否优于绳索或哑铃划船没有直接结论。", stop: "机器轨迹与握把不适配时调整握法/范围或替换", replacements: ["单臂哑铃划船", "杠铃俯身划船"] },
  { id: "EX20", name: "低位绳索坐姿划船", aliases: ["低位绳索划船"], patterns: ["水平拉"], primary: ["背阔肌", "中背"], secondary: ["后三角", "肱二头"], equipment: ["龙门架/绳索站", "绳索附件（未确认）", "坐姿固定方式（未确认）"], skill: "中", status: "CONDITIONAL", source: "NSCA 5e Ch16 p.425（Low-Pulley Seated Row）；Helms Training 2e horizontal pull", appraisal: "E4 明确列出类似动作；绳索阻力形式可行，但设置与占位成本可能高于固定坐姿划船。无直接证据证明更优。附件/座位未确认，CONDITIONAL。", stop: "需确认低位滑轮、附件和坐姿空间", replacements: ["坐姿器械划船", "单臂哑铃划船"] },
  { id: "EX21", name: "坐姿反手下拉器械动作（轨迹未核验）", aliases: ["反手坐姿划船", "坐姿反手下拉", "反手坐姿背部下拉"], patterns: ["待核验"], primary: ["背阔肌/中背（取决于设备轨迹）"], secondary: ["肱二头", "后三角"], equipment: ["坐姿反手下拉器械"], skill: "未核验", status: "PROVISIONAL", source: "NSCA 5e Ch16 水平/垂直拉动作技术目录；Helms Training 2e vertical/horizontal pull 分类。具体机器型号未知；本条已按 kb_v2.0.1 数据清理说明合并原条目 21 与 25（同一台器械）", appraisal: "PROVISIONAL：设备存在已确认，但动作模式、目标肌群与技术指导尚未核验；不得在确认运动轨迹前用于计划或与其他动作做优劣排名。", stop: "未核验前不进入计划", replacements: [] },
  { id: "EX22", name: "正握引体向上", aliases: ["自重引体向上", "引体向上", "正握引体"], patterns: ["垂直拉"], primary: ["背阔肌", "大圆肌"], secondary: ["肱二头", "肱肌", "肩胛控制肌"], equipment: ["引体单杠"], skill: "中高", status: "ACTIVE", source: "Starting Strength 3e Ch7 Chin-ups and Pull-ups；NSCA 5e Ch17 自重训练", appraisal: "E4 明确教授引体类；多关节垂直拉，可作为背部与上肢拉力候选。其相对高位下拉的肌肥大优势未被证明；自重负荷与技术门槛可能使其不易精细调节。它不是背部训练的默认首项——用户曾提过一次不构成排序依据。", stop: "肩肘疼痛或无法控制时停止并评估", replacements: ["高位下拉（常规握法）", "反握引体向上"] },
  { id: "EX23", name: "反握引体向上", aliases: ["反握引体", "Chin-up"], patterns: ["垂直拉"], primary: ["背阔肌"], secondary: ["肱二头", "肱肌"], equipment: ["引体单杠"], skill: "中高", status: "ACTIVE", source: "Starting Strength 3e Ch7；NSCA 5e Ch17 bodyweight exercise", appraisal: "E4 有技术依据；反握会改变肘屈肌参与，但不能仅凭握法宣称更有效增肌。与正握的长期肌肥大比较证据有限。", stop: "肘腕肩不适时停止；无法稳定完成时选择可调负荷下拉", replacements: ["高位下拉（常规握法）", "正握引体向上"] },
  { id: "EX24", name: "高位下拉（常规握法）", aliases: ["高位下拉"], patterns: ["垂直拉"], primary: ["背阔肌", "大圆肌"], secondary: ["肱二头", "肱肌", "肩胛控制肌"], equipment: ["高位下拉器械"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.423；Helms Training 2e vertical pull", appraisal: "E4 明确列出；负荷易调、设置相对快，可能比自重引体更易匹配不同能力。没有证据证明它普遍比引体更有效或更无效。", stop: "肩部不适时调整范围或停止", replacements: ["正握引体向上"] },
  { id: "EX26", name: "单臂绳索高位下拉", aliases: [], patterns: ["垂直拉", "单侧"], primary: ["背阔肌"], secondary: ["肱二头", "躯干抗侧屈肌"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "中", status: "CONDITIONAL", source: "NSCA 5e Ch17 Variable Resistance；Helms Training 2e vertical pull", appraisal: "E4 支持绳索阻力与垂直拉模式；单侧完成会增加时间。缺乏其优于双侧下拉的长期证据。附件未确认，CONDITIONAL。", stop: "确认单把手与高位滑轮后才可用", replacements: ["高位下拉（常规握法）", "正握引体向上"] },
  { id: "EX27", name: "绳索直臂下压", aliases: ["直臂下压"], patterns: ["肩伸展（垂直拉辅助）"], primary: ["背阔肌"], secondary: ["大圆肌", "肱三头长头"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "低", status: "CONDITIONAL", source: "Helms Training 2e pull-over/lat pushdown 讨论；NSCA 5e Ch17 variable resistance", appraisal: "E4 模式依据；单关节/辅助动作可补充肩伸展刺激，但单位时间覆盖肌群有限，不能替代主要垂直拉。没有证据证明其必需。附件未确认，CONDITIONAL。", stop: "需确认附件；肩部活动受限或疼痛时不强行拉伸", replacements: ["高位下拉（常规握法）"] },
  { id: "EX28", name: "杠铃后蹲", aliases: ["深蹲", "杠铃深蹲", "后蹲"], patterns: ["膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["内收肌", "躯干稳定肌"], equipment: ["杠铃", "深蹲架"], skill: "中高", status: "ACTIVE", source: "NSCA 5e Ch16 p.439；Starting Strength 3e Ch2 The Squat", appraisal: "E4 有完整技术指导；多关节动作单位时间覆盖肌群较多。若目标是杠铃深蹲专项表现，专项性价值明显；不代表它对每个人的肌肥大都优于腿举。", stop: "疼痛、失控或安全设施不足时不执行", replacements: ["史密斯深蹲", "倒蹬腿举", "哑铃高脚杯深蹲"] },
  { id: "EX29", name: "杠铃前蹲", aliases: ["前蹲"], patterns: ["膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["上背稳定肌", "躯干稳定肌"], equipment: ["杠铃", "深蹲架"], skill: "高", status: "ACTIVE", source: "NSCA 5e Ch16 p.441", appraisal: "E4 有技术依据；可作为不同躯干角度与负荷分布的蹲类变式，但直接证明其普遍优于后蹲的长期证据不足。", stop: "前架活动度或技术不足时不强行使用", replacements: ["杠铃后蹲", "史密斯深蹲", "倒蹬腿举"] },
  { id: "EX30", name: "史密斯深蹲", aliases: [], patterns: ["膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["内收肌", "躯干稳定肌"], equipment: ["史密斯机"], skill: "中", status: "ACTIVE", source: "Helms Training 2e Exercise Selection/机器与自由重量讨论；NSCA 5e Ch16 squat technique", appraisal: "E1 机器与自由重量肌肥大没有普遍差异；固定轨迹可降低平衡需求，但具体史密斯深蹲对比其他蹲类的优势未证实。", stop: "固定轨迹舒适且熟悉安全钩；轨迹不适配则替换", replacements: ["杠铃后蹲", "倒蹬腿举", "哑铃高脚杯深蹲"] },
  { id: "EX31", name: "倒蹬腿举", aliases: ["腿举", "器械腿举", "倒蹬"], patterns: ["膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["内收肌"], equipment: ["倒蹬腿举器械"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.438 Hip Sled (Machine)；Helms Training 2e squat/leg press alternatives", appraisal: "E4 明确列出髋 sled/腿举；E1 设备类别证据不支持机器天然低效。稳定性要求低、设置快，可能适合在有限时间内增加下肢训练量；但不能替代杠铃深蹲专项技术。", stop: "髋膝不适或腰盆失控时缩小范围/停止", replacements: ["史密斯深蹲", "杠铃后蹲", "哑铃高脚杯深蹲"] },
  { id: "EX32", name: "哑铃高脚杯深蹲", aliases: ["高脚杯深蹲"], patterns: ["膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["核心", "上背稳定肌"], equipment: ["哑铃"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 squat principles；NSCA PTQ 2023 基础动作教学", appraisal: "E4 支持基础蹲模式；对新手的技术学习成本可能较低，但可用负重上限受哑铃区限制（最大重量未知）。没有证据证明其比腿举/史密斯更有效。", stop: "哑铃重量或握持成为限制时换器械", replacements: ["倒蹬腿举", "史密斯深蹲", "杠铃后蹲"] },
  { id: "EX33", name: "哑铃反向弓步", aliases: ["反向弓步", "箭步蹲"], patterns: ["单侧", "膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["内收肌", "核心稳定肌"], equipment: ["哑铃", "地面空间（未确认）"], skill: "中", status: "CONDITIONAL", source: "NSCA 5e Ch16 p.447 reverse step lunge；Ch17 unilateral training", appraisal: "E4 动作依据；单侧训练可提供左右独立刺激，但单位训练时间较高，平衡/空间成本需纳入效率判断。无证据证明它普遍优于双侧蹲。空间未确认，CONDITIONAL。", stop: "空间不足或膝髋疼痛时不排", replacements: ["史密斯深蹲", "倒蹬腿举"] },
  { id: "EX34", name: "哑铃分腿蹲", aliases: ["分腿蹲", "保加利亚蹲", "保加利亚分腿蹲"], patterns: ["单侧", "膝主导"], primary: ["股四头肌", "臀大肌"], secondary: ["内收肌", "核心稳定肌"], equipment: ["哑铃", "地面空间（未确认）"], skill: "中", status: "CONDITIONAL", source: "NSCA 5e Ch17 unilateral training；NSCA PTQ 2023 fundamental movement progressions", appraisal: "E4 支持单侧模式；可处理单侧能力差异，但每侧分别完成带来时间成本。无直接证据证明比腿举更高效。空间条件未确认，CONDITIONAL。", stop: "空间或平衡条件不满足时不排", replacements: ["倒蹬腿举", "史密斯深蹲"] },
  { id: "EX35", name: "坐姿腿伸展", aliases: ["腿屈伸", "器械腿伸展", "腿伸展"], patterns: ["伸膝孤立"], primary: ["股四头肌"], secondary: [], equipment: ["坐姿腿伸展器械"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.455", appraisal: "E4 明确列出；孤立训练能直接针对股四头肌，但单位时间刺激的肌群覆盖低于复合动作。适合作为补充，不是所有下肢训练的必需动作。", stop: "轴心无法适配或膝部不适时不使用", replacements: ["倒蹬腿举", "史密斯深蹲"] },
  { id: "EX36", name: "杠铃传统硬拉", aliases: ["传统硬拉", "硬拉"], patterns: ["髋主导"], primary: ["臀大肌", "腘绳肌", "竖脊肌"], secondary: ["股四头肌", "背阔肌", "握力肌群"], equipment: ["杠铃"], skill: "高", status: "ACTIVE", source: "NSCA 5e Ch16 p.452；Starting Strength 3e Ch4 Deadlift", appraisal: "E4 有完整技术依据；多关节、覆盖肌群多，但全身疲劳与技术成本也可能较高。若目标为硬拉专项力量，其特异性高；不自动成为所有后链训练的最高效率选项。", stop: "腰背不适或动作控制不足时停止并评估", replacements: ["杠铃罗马尼亚硬拉"] },
  { id: "EX37", name: "杠铃罗马尼亚硬拉", aliases: ["罗马尼亚硬拉", "杠铃RDL", "RDL"], patterns: ["髋主导（髋铰链）"], primary: ["腘绳肌", "臀大肌"], secondary: ["竖脊肌", "背阔肌（稳定）"], equipment: ["杠铃"], skill: "中高", status: "ACTIVE", source: "NSCA 5e Ch16 p.454；Helms Training 2e hip hinge variants", appraisal: "E4 明确列出；可用相对简单的器械设置训练髋铰链与后链，但躯干等长负荷不可忽视。没有证据证明其普遍优于固定髋铰链器械。", stop: "腰背不适或动作失控时停止", replacements: ["哑铃罗马尼亚硬拉"] },
  { id: "EX38", name: "哑铃罗马尼亚硬拉", aliases: ["哑铃RDL"], patterns: ["髋主导（髋铰链）"], primary: ["腘绳肌", "臀大肌"], secondary: ["竖脊肌", "背阔肌（稳定）"], equipment: ["哑铃"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.454 RDL 变式；Helms Training 2e hip hinge", appraisal: "E4 动作模式支持；较容易细调负荷，但拿放与握力限制可能影响时间效率。未证明比杠铃 RDL 更增肌。", stop: "握力先疲劳时需重新评估", replacements: ["杠铃罗马尼亚硬拉"] },
  { id: "EX39", name: "可装片髋铰链固定器械（用户描述）", aliases: ["髋铰链固定器械"], patterns: ["暂定髋主导（待核验）"], primary: ["待核验"], secondary: [], equipment: ["髋主导/硬拉类固定器械"], skill: "未核验", status: "PROVISIONAL", source: "用户现场描述（仅证明设备外观/操作特征）；髋铰链生物力学需待设备核验后匹配 NSCA/Helms 相关章节", appraisal: "PROVISIONAL：设备身份与技术未核验前不得排入训练计划。当前无法给出效率或优劣评级；不允许根据「看起来像硬拉」推断其与传统硬拉等效。", stop: "未核验前不进入计划", replacements: [] },
  { id: "EX40", name: "龙门架 Pull-through", aliases: ["Pull-through", "绳索髋铰链"], patterns: ["髋主导（髋铰链）"], primary: ["臀大肌", "腘绳肌"], secondary: ["躯干稳定肌"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "中", status: "CONDITIONAL", source: "Helms Training 2e hip hinge/cable exercise selection；NSCA 5e Ch17 variable resistance", appraisal: "E4 动作模式依据；设置/占位成本可能高于杠铃 RDL 或固定器械。缺少直接证据证明其长期肌肥大优越。附件与滑轮位置未确认，CONDITIONAL。", stop: "附件、低位滑轮与活动空间确认后才可用", replacements: ["哑铃罗马尼亚硬拉", "杠铃罗马尼亚硬拉"] },
  { id: "EX41", name: "髋外展器械", aliases: ["髋外展"], patterns: ["髋外展孤立"], primary: ["臀中肌/臀小肌", "髋外展肌群"], secondary: [], equipment: ["髋外展/内收器械（外展配置）"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 运动模式/髋部肌群训练原则；NSCA 5e Ch18 exercise selection（具体器械未在动作目录单列，标记 E4 模式依据）", appraisal: "可作为髋外展肌群的局部补充；不应取代主要下肢复合训练。缺少与深蹲/腿举直接比较长期效果的证据。", stop: "髋部疼痛或设备轴心不适配时停止", replacements: [] },
  { id: "EX42", name: "髋内收器械", aliases: ["髋内收"], patterns: ["髋内收孤立"], primary: ["髋内收肌群"], secondary: [], equipment: ["髋外展/内收器械（内收配置）"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16/18 髋部训练与动作选择原则；具体机器型号未核验", appraisal: "作为内收肌局部训练有明确目标，但是否对当前目标有额外收益需要评估；缺少直接比较证明其普遍必要。", stop: "腹股沟或髋部疼痛时停止并评估", replacements: [] },
  { id: "EX43", name: "牧师椅弯举", aliases: ["牧师椅哑铃/杠铃弯举"], patterns: ["肘屈孤立"], primary: ["肱二头肌"], secondary: ["肱肌", "肱桡肌"], equipment: ["牧师椅", "哑铃或杠铃（握杆/哑铃配置需确认）"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.426 barbell biceps curl；Helms Training 2e biceps isolation", appraisal: "E4 支持弯举类；支撑可限制身体借力，但没有证据证明牧师椅比所有站姿弯举更有效。局部刺激明确，时间效率低于复合拉动作。", stop: "肘部不适或支撑角度不适配时停止", replacements: ["哑铃弯举", "龙门架弯举"] },
  { id: "EX44", name: "哑铃锤式弯举", aliases: ["锤式弯举"], patterns: ["肘屈孤立"], primary: ["肱肌", "肱桡肌"], secondary: ["肱二头肌"], equipment: ["哑铃"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.427 Hammer Curl", appraisal: "E4 明确列出；握法改变前臂/肘屈肌参与，但不证明其全面优于旋后弯举。适合作为肱肌/前臂屈肌补充。", stop: "肘腕疼痛时停止", replacements: ["牧师椅弯举", "哑铃弯举"] },
  { id: "EX45", name: "哑铃弯举", aliases: ["弯举"], patterns: ["肘屈孤立"], primary: ["肱二头肌"], secondary: ["肱肌", "肱桡肌"], equipment: ["哑铃"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch16 p.426 biceps curl；Helms Training 2e isolation exercise selection", appraisal: "E4 动作依据；单关节补充，局部目标清楚但单位时间覆盖低。没有直接证据证明它优于牧师椅弯举。", stop: "肘腕不适时调整握法或停止", replacements: ["牧师椅弯举", "哑铃锤式弯举"] },
  { id: "EX46", name: "龙门架弯举", aliases: ["绳索弯举"], patterns: ["肘屈孤立"], primary: ["肱二头肌"], secondary: ["肱肌"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "低", status: "CONDITIONAL", source: "NSCA 5e Ch17 variable resistance；Helms Training 2e biceps isolation", appraisal: "E4 阻力模式依据；可能提供不同阻力曲线，但缺少其优于哑铃/牧师椅的长期比较。设置时间须计入效率。附件未确认，CONDITIONAL。", stop: "确认附件与滑轮位置后才可用", replacements: ["牧师椅弯举", "哑铃弯举"] },
  { id: "EX47", name: "龙门架肱三头下压", aliases: ["绳索下压", "肱三头下压", "绳索臂屈伸"], patterns: ["肘伸孤立"], primary: ["肱三头肌"], secondary: [], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "低", status: "CONDITIONAL", source: "NSCA 5e Ch16 p.462 triceps pushdown machine；NSCA 5e Ch17 variable resistance", appraisal: "E4 有下压动作依据；局部刺激明确，适合作为推举后的补充；无证据证明绳索版本优于固定机器。附件未确认，CONDITIONAL。", stop: "确认附件；肘部疼痛时停止", replacements: ["哑铃仰卧肱三头伸展"] },
  { id: "EX48", name: "哑铃仰卧肱三头伸展", aliases: ["仰卧臂屈伸", "哑铃臂屈伸"], patterns: ["肘伸孤立"], primary: ["肱三头肌"], secondary: [], equipment: ["哑铃", "可调角度训练椅"], skill: "中", status: "ACTIVE", source: "NSCA 5e Ch16 p.461 lying barbell triceps extension（哑铃变式标记为变式推导）；Helms Training 2e triceps isolation", appraisal: "E4 支持肱三头伸展动作类别；具体哑铃版本的直接比较证据不足。可作为局部补充，需考虑肘关节舒适度。", stop: "肘肩不适时停止或换动作", replacements: ["龙门架肱三头下压"] },
  { id: "EX49", name: "平板支撑", aliases: [], patterns: ["核心抗伸展"], primary: ["腹壁稳定肌群"], secondary: [], equipment: ["自重/地面"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch17 core stability", appraisal: "E4 支持核心稳定训练；适合基础控制练习，但静态支撑不是腹肌肌肥大的唯一或普遍最佳方案。", stop: "肩腕不适时改前臂或高位支撑", replacements: ["死虫"] },
  { id: "EX50", name: "死虫", aliases: [], patterns: ["核心抗伸展"], primary: ["躯干深层稳定肌"], secondary: [], equipment: ["自重/地面"], skill: "低", status: "ACTIVE", source: "NSCA 5e Ch17 core stability principles（具体动作需按该章教学原文复核）", appraisal: "E4 模式依据；技术学习成本较低，适合控制训练；没有证据证明其比负重核心动作更有效增肌。", stop: "腰盆控制不足时缩小范围", replacements: ["平板支撑"] },
  { id: "EX51", name: "跑步机轻松跑/快走", aliases: ["轻松跑", "跑步机跑步", "跑步"], patterns: ["有氧"], primary: ["心肺耐力"], secondary: ["下肢反复周期性运动"], equipment: ["跑步机"], skill: "低", status: "ACTIVE", source: "Jeukendrup《Sport Nutrition》运动训练与能量代谢章节；并行训练证据（Held 2026，摘要级）另行登记；本条不声称跑步机优于户外跑", appraisal: "设备存在已确认；跑步机只是可控场地工具，不自动等于最有效跑步训练。跑步速度、坡度、设备上限未知。", stop: "出现疼痛、眩晕或异常不适时停止", replacements: [] },
  // EX52/EX53 为 2026-11-15 核心动作更新新增（用户 2026-11-15 00:05 确认核心
  // 最终定法后入库）：EX51 已被跑步机有氧条目占用，新条目顺延编号，不改动
  // 任何已有条目的编号与字段。
  { id: "EX52", name: "高卷腿", aliases: ["仰卧高卷腿", "躺姿卷腿", "反向卷腹（躺姿抛腿版）"], patterns: ["核心（脊柱屈曲/骨盆后倾）"], primary: ["腹直肌（下部）"], secondary: ["腹外斜肌", "腹横肌（稳定）"], equipment: ["平板凳（可调角度训练椅调平）", "杠铃杆（头后上方固定双手用）"], skill: "中", status: "ACTIVE", source: "E3：Escamilla et al. 2006（Physical Therapy）——反向卷腹（30° 斜板）为下腹直肌激活最高之列，悬垂屈膝举腿（吊带版）亦高；本条支持的是反向卷腹动作模式，高卷腿即其躺姿固定版。E5：Bilibili UP主「东哥」（账号名「烧毁一切就是美」，东京健美公开赛冠军）视频《练腹肌，我只推荐这个动作！》https://www.bilibili.com/video/BV17noEYhEUU/（2025-04-14 发布，已实际观看核验）——画面字幕原话「练腹肌高卷腿最有效」，技术要点与离心理由来自该视频观看带回。解剖依据：腹直肌起止于肋骨–骨盆，不跨髋关节，只在脊柱屈曲/骨盆后倾时工作；0–90° 举腿主要为髋屈肌（髂腰肌、股直肌）", appraisal: "E3 机制证据支持反向卷腹模式对下腹直肌的高激活（肌电只解释机制，不单独证明长期优势）；E5 视频证据提供技术要点与离心做法（补充解释，不与 E1/E2 等权）。与龙旗的区别：龙旗屁股不着地、腰椎负担大；高卷腿屁股先着地，是为了保护腰椎、给腰椎的负担最小。与悬垂举腿的关系：高卷腿是躺姿固定版反向卷腹，去掉了悬吊不稳与握力限制；悬垂举腿本身已降级为条件变式、不进正式计划（本次不入库）。东哥称「悬垂举腿最差」是其个人观点（他本人在视频里自认「这只是我个人的观点，仅供大家做个参考」），不作为本条目的证据。source_status 已核验（verified）。用户 2026-11-15 确认：核心主项 = 绳索卷腹（上腹）+ 高卷腿（下腹），每周 2 次、每次各 3 组；平板支撑不再计腹肌组数（EX49 条目本身不改动）。", stop: "动作中腰部出现尖锐刺痛或力量骤掉即停", replacements: ["悬垂举腿（器械椅/吊带固定版）", "仰卧起坐", "绳索卷腹"] },
  { id: "EX53", name: "绳索卷腹", aliases: ["龙门架卷腹", "跪姿绳索卷腹", "加权卷腹"], patterns: ["核心（脊柱屈曲）"], primary: ["腹直肌（上部）"], secondary: ["腹外斜肌"], equipment: ["龙门架/绳索站", "绳索附件（未确认）"], skill: "中", status: "CONDITIONAL", source: "Jeff Nippard 加权卷腹为首选上腹动作（2026-11-14 23:20 核查结论登记；该结论所依据的具体视频标题/URL/时间戳本次未复核，标未核验）；NSCA 5e Ch17 核心训练与 variable resistance 原则（动作模式依据，E4）", appraisal: "上腹可加载卷腹的动作模式有教材原则支持；Nippard「首选上腹动作」的结论按 2026-11-14 核查登记转述、未在本次复核原文，不单独作为评级依据。状态判定：绳索站（龙门架）本身已在 ATI-EQ-1.1 确认，但绳索把手附件仍在快照未确认项内 → CONDITIONAL；待用户确认绳索把手附件后转 ACTIVE。用户 2026-11-15 确认其为核心主项之一（上腹、可加载，与高卷腿搭配，每周 2 次、每次 3 组），附件确认前不得进入正式计划。", stop: "确认绳索把手附件后才可用；动作中腰部尖锐刺痛即停", replacements: ["高卷腿", "平板支撑", "死虫"] },
];

// §5 字段补齐（kb_v2.0.md 第五节）：上面原始转录缺的 variation_id、
// stabilizers、equipment_snapshot_match、technique_cues、common_errors、
// population_scope、time_setup_cost、fatigue_cost、progression_options 在此
// 逐条补齐。内容来源：technique_cues 为 kb 第六节各条目「技术」原文；
// common_errors 由该条目的技术要点与停止条件直接引申（做错的样子就是
// 技术要点反面），不引入文档外的新断言；population_scope 以系统成人定位
// 为底 + 该条目「适用/停止」原文条件；fatigue_cost / time_setup_cost 取自
// 该条目证据评价里的疲劳与时间表述，无表述处按器械类型作定性登记并标
// 确定性低；progression_options 按器械快照已确认的档位口径（哑铃 2.5kg
// 一档、杠铃 5kg 一档）登记。PROVISIONAL 条目未核验的字段如实写「未核验」。
const ADULT_SCOPE = "已通过独立准入审核的健康成年人（≥18 岁）";
const LIBRARY_SECTION5: Record<string, LibrarySection5> = {
  EX01: { variationId: "bench-press/barbell-flat", stabilizers: ["肩胛与躯干稳定肌（技术要点要求建立稳定支撑）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃、卧推架（保护配置细节未确认，执行时须现场确认）", techniqueCues: "建立稳定支撑，腕肘与杠铃路径协调，控制下降和推起；必须满足安全保护条件", commonErrors: ["下降失控、杠铃弹胸借力", "腕肘与杠铃路径不一致、推起轨迹漂移", "无保护条件时尝试接近极限的重量"], populationScope: `${ADULT_SCOPE}；已掌握杠铃卧推技术且具备保护条件者`, timeSetupCost: "需装片并设置卧推架与保护，设置成本中等；组间休息 120–180 秒", fatigueCost: "局部：胸大肌/前三角/肱三头，中高；全身：低-中；确定性：中（多关节复合，条目评价未给出与其他推类动作的直接疲劳比较）", progressionOptions: ["杠铃按 5kg 一档加重（快照口径）", "同重量先增加次数再加重", "增加组数（受周容量与恢复约束）"] },
  EX02: { variationId: "bench-press/dumbbell-flat", stabilizers: ["肩胛稳定肌", "躯干稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅", techniqueCues: "双侧独立控制，腕肘对齐，下降幅度以肩部舒适和控制为界", commonErrors: ["两侧发力不对称、哑铃轨迹失稳", "下降幅度强行过大、超出肩部舒适范围", "拿起/放下哑铃时失去控制"], populationScope: `${ADULT_SCOPE}；能独立控制两侧哑铃者`, timeSetupCost: "取放哑铃与就位成本中等；无需装片", fatigueCost: "局部：胸大肌/前三角/肱三头，中；全身：低；确定性：中（稳定需求高于固定器械，条目评价提及拿放与稳定成本）", progressionOptions: ["哑铃按 2.5kg 一档加重（快照口径）", "同重量增加次数", "增加组数"] },
  EX03: { variationId: "bench-press/smith-flat", stabilizers: ["由固定轨迹提供路径约束，主动稳定需求低于自由重量"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：史密斯机、可调角度训练椅", techniqueCues: "先调整座椅/凳位，使固定轨迹符合肩肘舒适路径；熟悉安全钩", commonErrors: ["凳位未对准固定轨迹、被迫扭曲肩肘位置迁就轨迹", "不熟悉安全钩操作就加重"], populationScope: `${ADULT_SCOPE}；固定轨迹适配本人肩肘路径者`, timeSetupCost: "调整凳位与安全钩后设置较快", fatigueCost: "局部：胸大肌/前三角/肱三头，中；全身：低；确定性：低（与自由卧推的直接长期比较证据不足，条目评价原文）", progressionOptions: ["按史密斯机装片档位加重", "同重量增加次数", "增加组数"] },
  EX04: { variationId: "bench-press/machine-flat", stabilizers: ["器械靠背提供躯干支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：固定推胸器械（平板）", techniqueCues: "座椅高度使把手起始位与胸部匹配，肩胛和躯干稳定，控制回程", commonErrors: ["座椅高度不匹配、把手起始位过高或过低", "回程失控、配重撞击", "耸肩代偿推起"], populationScope: `${ADULT_SCOPE}；设备轨迹适配且无痛者`, timeSetupCost: "调整座椅即可，设置快（条目评价：便于快速设置）", fatigueCost: "局部：胸大肌/前三角/肱三头，中；全身：低；确定性：中（固定轨迹可能降低稳定要求，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX05: { variationId: "bench-press/dumbbell-incline", stabilizers: ["肩胛稳定肌", "躯干稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅", techniqueCues: "椅背角度适中，肩胛稳定，避免过度耸肩和强行深拉伸", commonErrors: ["椅背角度过大、动作实际变成肩推主导", "过度耸肩", "强行深拉伸追求幅度（本人有飞鸟拉伸撕痛史，尤须控制拉伸幅度）"], populationScope: `${ADULT_SCOPE}；肩前侧无不适者`, timeSetupCost: "调整椅背角度并取放哑铃，设置成本中等", fatigueCost: "局部：胸大肌锁骨部/前三角，中；全身：低；确定性：中", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "在舒适范围内调整椅背角度改变刺激角度"] },
  EX06: { variationId: "bench-press/machine-incline", stabilizers: ["器械靠背提供躯干支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：固定推胸器械（上斜）", techniqueCues: "座椅/起始把手位置适配；控制底部活动范围", commonErrors: ["座椅位置不适配、底部范围失控", "强行扩大底部活动范围"], populationScope: `${ADULT_SCOPE}；器械轨迹舒适者`, timeSetupCost: "调整座椅即可，设置快", fatigueCost: "局部：胸大肌锁骨部/前三角，中；全身：低；确定性：低（与哑铃上斜的直接比较证据不足，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX07: { variationId: "bench-press/barbell-incline", stabilizers: ["肩胛与躯干稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃、卧推架、可调角度训练椅（保护配置细节未确认）", techniqueCues: "设置安全保护；握距与触胸点稳定", commonErrors: ["无保护条件时尝试大重量", "握距与触胸点逐组漂移不一致"], populationScope: `${ADULT_SCOPE}；有保护条件且技术熟练者`, timeSetupCost: "需装片并设置架位与保护，设置成本中等", fatigueCost: "局部：胸大肌锁骨部/前三角/肱三头，中高；全身：低-中；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX08: { variationId: "chest-fly/pec-deck", stabilizers: ["器械支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：蝴蝶机", techniqueCues: "座椅与轴心位置匹配，肘/前臂支撑舒适，控制离心，不强迫肩部过度后伸", commonErrors: ["座椅与轴心不匹配、借惯性甩动", "强迫肩部过度后伸追求幅度", "离心阶段失控"], populationScope: `${ADULT_SCOPE}；肩前侧无不适者`, timeSetupCost: "调整座椅即可，设置快", fatigueCost: "局部：胸大肌，中；全身：低；确定性：中（单关节孤立，单位时间覆盖肌群较少，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX09: { variationId: "chest-fly/cable", stabilizers: ["肩胛稳定肌", "躯干稳定肌（站姿抗晃动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架/绳索站已确认，把手附件未确认 → CONDITIONAL", techniqueCues: "肩胛稳定、肘角固定、控制回程；避免以过度拉伸追求幅度", commonErrors: ["肘角在动作中不断变化、实际变成推的动作", "以过度拉伸追求幅度", "回程失控"], populationScope: `${ADULT_SCOPE}；两侧滑轮与把手附件确认后、肩部无不适者`, timeSetupCost: "双侧滑轮布置增加设置/占位成本（条目评价原文），效率取决于场地", fatigueCost: "局部：胸大肌，中；全身：低；确定性：低（直接比较长期增肌证据有限，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX10: { variationId: "shoulder-press/machine", stabilizers: ["器械靠背提供躯干支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：固定推肩器械", techniqueCues: "座椅和把手起始高度匹配；躯干稳定；不强迫肩关节进入疼痛范围", commonErrors: ["座椅/把手起始高度不匹配", "强行推入疼痛范围", "躯干过度后仰代偿"], populationScope: `${ADULT_SCOPE}；轨迹舒适且设备适配者`, timeSetupCost: "调整座椅即可，设置快", fatigueCost: "局部：三角肌前束/中束/肱三头，中；全身：低；确定性：中（稳定轨迹可能减少平衡/设置要求，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX11: { variationId: "shoulder-press/dumbbell-seated", stabilizers: ["躯干稳定肌", "肩胛稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅", techniqueCues: "肋骨不过度外翻，前臂保持可控，肩部活动范围舒适", commonErrors: ["肋骨外翻、腰椎过伸代偿", "前臂失控、哑铃轨迹晃动", "强迫超出舒适范围的幅度"], populationScope: `${ADULT_SCOPE}；能安全拿放哑铃者`, timeSetupCost: "取放哑铃成本中等，高于固定器械（条目评价原文）", fatigueCost: "局部：三角肌前束/中束/肱三头，中；全身：低；确定性：中（拿放与稳定成本高于固定器械，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX12: { variationId: "overhead-press/barbell-standing", stabilizers: ["躯干稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃、深蹲架", techniqueCues: "建立躯干张力，杠铃沿可控路径通过头部，避免腰椎过伸", commonErrors: ["腰椎过伸借力推起", "杠铃路径绕远、通过头部时失控", "躯干张力不足、身体晃动"], populationScope: `${ADULT_SCOPE}；已掌握推举技术且有安全放置条件者`, timeSetupCost: "需装片并设置架位，设置成本中等", fatigueCost: "局部：三角肌前束/中束/肱三头，中；全身：中（站姿全身稳定参与）；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX13: { variationId: "lateral-raise/dumbbell", stabilizers: ["躯干稳定肌（抗摆动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃", techniqueCues: "负荷轻到能控制；肘腕自然；避免躯干摆动和耸肩代偿", commonErrors: ["负荷过重、躯干摆动借力", "耸肩代偿、上斜方肌主导", "手臂甩动而非受控抬起"], populationScope: `${ADULT_SCOPE}；肩部无疼痛者`, timeSetupCost: "取放哑铃即可，设置快；单关节覆盖低，单位时间刺激有限（条目评价原文）", fatigueCost: "局部：三角肌中束，中；全身：低；确定性：中（孤立动作，时间效率低于多关节动作，条目评价原文）", progressionOptions: ["先同重量增加次数，再按哑铃 2.5kg 一档加重", "增加组数"] },
  EX14: { variationId: "lateral-raise/cable", stabilizers: ["躯干稳定肌（抗侧倾）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，单把手附件未确认 → CONDITIONAL", techniqueCues: "滑轮高度和站位适配；控制躯干，不用摆动完成", commonErrors: ["躯干摆动借力", "滑轮高度/站位不适配、轨迹被拉扯"], populationScope: `${ADULT_SCOPE}；单把手附件确认后、肩部无疼痛者`, timeSetupCost: "需设置滑轮高度与站位，设置成本中等", fatigueCost: "局部：三角肌中束，中；全身：低；确定性：低（长期优势不能仅凭急性肌电推断，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX15: { variationId: "row/barbell-bent-over", stabilizers: ["躯干稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃", techniqueCues: "髋铰链保持躯干位置，脊柱受控，拉动时不借腰弹起", commonErrors: ["借腰弹起、躯干角度不断抬高", "脊柱失控（圆背或过伸）", "拉动轨迹逐组漂移"], populationScope: `${ADULT_SCOPE}；已掌握髋铰链与躯干等长控制者`, timeSetupCost: "需装片，设置成本中等；多关节覆盖多肌群，可能有时间效率优势（条目评价原文）", fatigueCost: "局部：背阔肌/中背，中高；全身：中（躯干等长负荷较高，条目评价原文）；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX16: { variationId: "row/pendlay", stabilizers: ["躯干稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃（地面放置空间按现场情况）", techniqueCues: "每次从静止位置启动；躯干角度一致；不靠腰部反弹", commonErrors: ["靠腰部反弹启动", "逐组躯干角度不一致", "杠铃未回到地面静止就连续拉动"], populationScope: `${ADULT_SCOPE}；能稳定控制起始位者（技术要求较高）`, timeSetupCost: "需装片与地面空间，设置成本中等", fatigueCost: "局部：背阔肌/中背，中高；全身：中；确定性：低（直接长期对照证据不足，条目评价原文）", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX17: { variationId: "row/dumbbell-one-arm", stabilizers: ["躯干抗旋转肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅", techniqueCues: "支撑稳定，躯干不旋转借力，控制肩胛移动", commonErrors: ["躯干旋转借力", "肩胛移动失控、耸肩拉动", "支撑不稳、身体晃动"], populationScope: `${ADULT_SCOPE}；腰背无不适者（不适时改胸托或坐姿器械）`, timeSetupCost: "逐侧完成，总用时高于双侧动作（条目评价原文）", fatigueCost: "局部：背阔肌/中背，中；全身：低-中；确定性：中", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX18: { variationId: "row/dumbbell-chest-supported", stabilizers: ["由胸托支撑替代躯干等长稳定，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅（支撑稳定性现场确认）", techniqueCues: "胸部支撑稳定；颈部中立；控制肩胛前伸/后缩", commonErrors: ["胸部离垫借力", "颈部过度后仰", "肩胛移动失控"], populationScope: `${ADULT_SCOPE}；适合希望降低躯干等长负荷者；凳子角度与支撑稳定性需确认`, timeSetupCost: "需设置凳子角度，时间成本计入凳子设置（条目评价原文）", fatigueCost: "局部：背阔肌/中背，中；全身：低（胸托降低躯干等长负荷，条目评价原文）；确定性：中", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX19: { variationId: "row/machine-seated", stabilizers: ["器械提供躯干支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：坐姿划船器械", techniqueCues: "躯干保持稳定，肘按目标方向移动，回程受控，不大幅后仰", commonErrors: ["大幅后仰借力", "回程失控、被配重拉走", "耸肩拉动"], populationScope: `${ADULT_SCOPE}；机器轨迹与握把舒适者`, timeSetupCost: "设置较快（条目评价原文）", fatigueCost: "局部：背阔肌/中背，中；全身：低；确定性：中（躯干稳定要求较低，可能具备较好的时间/疲劳效率，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX20: { variationId: "row/cable-low-pulley-seated", stabilizers: ["躯干稳定肌（坐姿抗拉）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，低位滑轮附件与坐姿固定方式未确认 → CONDITIONAL", techniqueCues: "躯干稳定，回程不被配重拉走，肘路径符合目标", commonErrors: ["回程被配重拉走、躯干前倾失控", "后仰借力", "肘路径偏离目标"], populationScope: `${ADULT_SCOPE}；低位滑轮、附件与坐姿空间确认后`, timeSetupCost: "设置与占位成本可能高于固定坐姿划船（条目评价原文）", fatigueCost: "局部：背阔肌/中背，中；全身：低；确定性：低（无直接证据证明更优，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX21: { variationId: "back-machine/underhand-seated-unverified", stabilizers: ["未核验（kb 未锁定，不臆测）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认器械存在（坐姿反手下拉）；实际运动轨迹未核验 → PROVISIONAL", techniqueCues: "先观察器械把手轨迹和关节活动方向；不得根据「反手下拉」名称擅自认定为垂直拉或水平拉（kb 原条目 21/25 技术原文合并）", commonErrors: ["未核验轨迹前按名称臆测动作模式并排入计划", "未核验前与其他拉类动作做优劣排名"], populationScope: `${ADULT_SCOPE}；且须先在现场确认其真实运动轨迹——未核验前不进入任何正式计划`, timeSetupCost: "未核验：待现场确认轨迹后登记", fatigueCost: "未核验：轨迹与肌群映射未定，疲劳代价不可评估（不臆测）", progressionOptions: ["轨迹核验后按核验结果登记，当前无"] },
  EX22: { variationId: "pull-up/pronated", stabilizers: ["肩胛控制肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：引体单杠", techniqueCues: "身体不摆荡，肩胛和肘部运动受控；不以颈部前探完成动作", commonErrors: ["身体摆荡借力", "以颈部前探凑数完成动作", "离心阶段失控、直接掉落"], populationScope: `${ADULT_SCOPE}；具备控制自重能力、肩肘无疼痛者`, timeSetupCost: "无器械设置成本；自重负荷不易精细调节，能力不足时单组有效次数低（条目评价原文）", fatigueCost: "局部：背阔肌/肱二头，中高；全身：中；确定性：中", progressionOptions: ["先增加次数与组数", "外加负重需负重设备（未确认）——未确认前只用次数/组数进阶"] },
  EX23: { variationId: "pull-up/supinated-chin-up", stabilizers: ["肩胛控制肌", "躯干稳定肌（抗摆动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：引体单杠", techniqueCues: "反握自然宽度，控制身体摆动和离心阶段", commonErrors: ["身体摆动借力", "离心阶段失控掉落", "握距过窄导致肘腕不适仍强行完成"], populationScope: `${ADULT_SCOPE}；肘腕肩无不适、能稳定完成者`, timeSetupCost: "无器械设置成本", fatigueCost: "局部：背阔肌/肱二头，中高；全身：中；确定性：中", progressionOptions: ["先增加次数与组数", "外加负重设备未确认前不以外加负重进阶"] },
  EX24: { variationId: "lat-pulldown/standard-grip", stabilizers: ["肩胛控制肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：高位下拉器械", techniqueCues: "躯干稳定，向上胸方向拉动，避免颈后拉和过度后仰", commonErrors: ["颈后拉", "过度后仰借力", "回程失控、配重撞击"], populationScope: `${ADULT_SCOPE}；按机器轨迹与握把适配、肩部无不适者`, timeSetupCost: "设置相对快（条目评价原文）", fatigueCost: "局部：背阔肌，中；全身：低；确定性：中（负荷易调，条目评价原文）", progressionOptions: ["按器械配重档位加重（负荷易调）", "同重量增加次数", "增加组数"] },
  EX26: { variationId: "lat-pulldown/cable-one-arm", stabilizers: ["躯干抗侧屈肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，单把手附件未确认 → CONDITIONAL", techniqueCues: "骨盆和胸廓稳定，肘向髋方向移动，控制回程", commonErrors: ["躯干侧倾或旋转代偿", "回程失控", "肘路径偏离髋方向"], populationScope: `${ADULT_SCOPE}；单把手与高位滑轮确认后`, timeSetupCost: "单侧完成会增加时间（条目评价原文）", fatigueCost: "局部：背阔肌，中；全身：低；确定性：低（缺乏优于双侧下拉的长期证据，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX27: { variationId: "lat-pushdown/cable-straight-arm", stabilizers: ["躯干稳定肌（抗摆动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，直杆/绳把附件未确认 → CONDITIONAL", techniqueCues: "肘角基本固定，髋躯干稳定，不用腰部摆动", commonErrors: ["用腰部摆动完成动作", "肘角不断变化、实际变成下压动作", "强行拉伸超出肩部活动范围"], populationScope: `${ADULT_SCOPE}；附件确认后、肩部活动无受限或疼痛者`, timeSetupCost: "需设置高位滑轮与附件，设置成本中等", fatigueCost: "局部：背阔肌，中；全身：低；确定性：中（单关节/辅助动作，单位时间覆盖肌群有限，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX28: { variationId: "squat/barbell-back", stabilizers: ["躯干稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃、深蹲架（安全杠配置未确认，执行时须现场确认）", techniqueCues: "建立安全架高度和保护条件，脚掌稳定，膝髋协调，深度以动作质量为准", commonErrors: ["深度超出动作质量可控范围", "膝髋不协调（膝内扣、臀部先起）", "安全设施不足时尝试大重量", "脚掌不稳、重心漂移"], populationScope: `${ADULT_SCOPE}；已掌握架位与深蹲技术、有保护条件者`, timeSetupCost: "需装片并设置架位与保护，设置成本较高；组间休息 180–300 秒", fatigueCost: "局部：股四头肌/臀大肌，中高；全身：高（多关节大负荷，单位时间覆盖肌群较多，条目评价原文）；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX29: { variationId: "squat/barbell-front", stabilizers: ["上背稳定肌（次肌，kb 原文）", "躯干稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃、深蹲架", techniqueCues: "前架位置稳定，肘部抬起，躯干保持受控", commonErrors: ["肘部下沉、前架位置滑落", "躯干前倾失控", "前架活动度不足时强行使用"], populationScope: `${ADULT_SCOPE}；前架活动度与技术满足者`, timeSetupCost: "需装片并设置架位，设置成本较高", fatigueCost: "局部：股四头肌/臀大肌，中高；全身：中高；确定性：低（普遍优于后蹲的长期证据不足，条目评价原文）", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX30: { variationId: "squat/smith", stabilizers: ["躯干稳定肌（次肌，kb 原文）；固定轨迹降低平衡需求（条目评价原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：史密斯机", techniqueCues: "站位需适配固定轨迹；使用安全钩；不为迁就轨迹而扭曲关节位置", commonErrors: ["为迁就固定轨迹扭曲关节位置", "不熟悉安全钩就加重", "站位与轨迹不适配仍强行完成"], populationScope: `${ADULT_SCOPE}；固定轨迹舒适且熟悉安全钩者`, timeSetupCost: "调整站位与安全钩后设置较快", fatigueCost: "局部：股四头肌/臀大肌，中高；全身：中；确定性：低（对比其他蹲类的优势未证实，条目评价原文）", progressionOptions: ["按史密斯机装片档位加重", "同重量增加次数", "增加组数"] },
  EX31: { variationId: "leg-press/incline-sled", stabilizers: ["器械靠垫提供躯干支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：倒蹬腿举器械", techniqueCues: "腰背贴靠垫，下降深度不引起骨盆明显卷曲，膝盖方向稳定", commonErrors: ["下降过深导致骨盆卷曲", "膝盖方向不稳（内扣）", "蹬起时膝关节完全锁死撞击"], populationScope: `${ADULT_SCOPE}；设备轨迹适配且无痛者`, timeSetupCost: "设置快（条目评价原文），适合在有限时间内增加下肢训练量", fatigueCost: "局部：股四头肌/臀大肌，中高；全身：低-中；确定性：中（稳定性要求低，条目评价原文）", progressionOptions: ["按器械装片档位加重", "同重量增加次数", "增加组数"] },
  EX32: { variationId: "squat/dumbbell-goblet", stabilizers: ["核心（次肌，kb 原文）", "上背稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃（最大重量未知，负重上限待确认）", techniqueCues: "负重靠近躯干，脚掌稳定，蹲起过程膝髋协调", commonErrors: ["负重远离躯干、重心前移", "膝髋不协调", "哑铃重量或握持已成为限制仍强行加重"], populationScope: `${ADULT_SCOPE}；适合技术学习阶段者`, timeSetupCost: "取放哑铃即可，设置快", fatigueCost: "局部：股四头肌/臀大肌，中；全身：中；确定性：中（可用负重上限受哑铃区限制，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重（受哑铃最大重量限制）", "同重量增加次数", "增加组数"] },
  EX33: { variationId: "lunge/dumbbell-reverse", stabilizers: ["核心稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：哑铃已确认，可用地面空间未确认 → CONDITIONAL", techniqueCues: "后撤步受控，前脚稳定，骨盆不明显摇摆", commonErrors: ["后撤步失控、骨盆明显摇摆", "前脚不稳、膝方向漂移", "空间不足时强行排入"], populationScope: `${ADULT_SCOPE}；地面空间确认后、平衡满足者（不足先徒手并扶支撑）`, timeSetupCost: "单侧逐侧完成，单位训练时间较高；平衡/空间成本需计入（条目评价原文）", fatigueCost: "局部：股四头肌/臀大肌，中；全身：中；确定性：中", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX34: { variationId: "split-squat/dumbbell", stabilizers: ["核心稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：哑铃已确认，地面空间未确认 → CONDITIONAL", techniqueCues: "双脚前后固定，垂直下降，前脚稳定", commonErrors: ["身体前后晃动而非垂直下降", "前脚不稳", "平衡条件不满足时强行排入"], populationScope: `${ADULT_SCOPE}；地面空间与平衡条件满足者（不足先扶支撑）`, timeSetupCost: "逐侧完成，时间成本较高（条目评价原文）", fatigueCost: "局部：股四头肌/臀大肌，中；全身：中；确定性：中（每侧分别完成带来时间成本，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX35: { variationId: "leg-extension/seated-machine", stabilizers: ["器械支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：坐姿腿伸展器械", techniqueCues: "膝关节轴与机器旋转轴对齐，控制活动范围和离心，不甩动配重", commonErrors: ["甩动配重借惯性", "膝轴与机器旋转轴不对齐", "离心阶段失控"], populationScope: `${ADULT_SCOPE}；轴心可适配、膝部无不适者`, timeSetupCost: "调整座椅与轴心即可，设置快", fatigueCost: "局部：股四头肌，中；全身：低；确定性：中（孤立动作，单位时间刺激覆盖低于复合动作，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX36: { variationId: "deadlift/barbell-conventional", stabilizers: ["竖脊肌（主肌，kb 原文）", "躯干稳定肌"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃（安全地面空间按现场情况）", techniqueCues: "杠铃贴近身体，脊柱位置稳定，起拉前建立躯干张力", commonErrors: ["杠铃远离身体起拉", "脊柱位置失控（圆背拉起）", "未建立躯干张力就起拉", "腰背不适时仍强行完成"], populationScope: `${ADULT_SCOPE}；技术要求较高、需合格指导且动作控制满足者`, timeSetupCost: "需装片与地面空间，设置成本较高；组间休息 180–300 秒", fatigueCost: "局部：臀大肌/腘绳肌/竖脊肌，中高；全身：高（全身疲劳与技术成本较高，条目评价原文）；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX37: { variationId: "deadlift/barbell-romanian", stabilizers: ["竖脊肌（次肌，kb 原文）", "背阔肌（稳定，次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：杠铃", techniqueCues: "髋向后移动，膝微屈且角度相对稳定，杠铃沿腿部下行，脊柱受控", commonErrors: ["用膝屈伸代替髋铰链（变成深蹲式下放）", "杠铃远离腿部下行", "脊柱失控", "下放深度超出髋铰链可控范围"], populationScope: `${ADULT_SCOPE}；已掌握髋铰链者`, timeSetupCost: "需装片，设置成本中等（相对简单的器械设置，条目评价原文）", fatigueCost: "局部：腘绳肌/臀大肌，中高；全身：中（躯干等长负荷不可忽视，条目评价原文）；确定性：中", progressionOptions: ["杠铃按 5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX38: { variationId: "deadlift/dumbbell-romanian", stabilizers: ["竖脊肌（次肌，kb 原文）", "背阔肌（稳定，次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃", techniqueCues: "哑铃贴近腿部，髋向后折叠，控制下降深度", commonErrors: ["哑铃远离腿部下行", "下降深度失控", "握力先疲劳导致动作变形仍继续"], populationScope: `${ADULT_SCOPE}；适合负荷较轻或希望独立控制两侧者`, timeSetupCost: "取放哑铃即可，设置较快；握力限制可能影响效率（条目评价原文）", fatigueCost: "局部：腘绳肌/臀大肌，中；全身：中；确定性：中（拿放与握力限制可能影响时间效率，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX39: { variationId: "hip-hinge/plate-loaded-machine-unverified", stabilizers: ["待核验（kb 未锁定，不臆测）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认器械存在（按用户现场描述登记）；商品名/型号与轨迹未核验 → PROVISIONAL", techniqueCues: "先核验设备说明、起始位、支点、阻力方向、安全限位和动作轨迹；不自行猜测品牌或常见商品名", commonErrors: ["根据外观臆测商品名或动作等效性（如断言等同于传统硬拉）", "未核验前排入计划"], populationScope: `${ADULT_SCOPE}；设备身份与技术未核验前不进入任何正式计划`, timeSetupCost: "未核验：待设备核验后登记", fatigueCost: "未核验：设备身份未定，疲劳代价不可评估（不臆测）", progressionOptions: ["设备核验后按核验结果登记，当前无"] },
  EX40: { variationId: "hip-hinge/cable-pull-through", stabilizers: ["躯干稳定肌（次肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，绳把附件与低位滑轮位置未确认 → CONDITIONAL", techniqueCues: "髋向后移动，站起时髋伸展，避免用手臂拉动", commonErrors: ["用手臂拉动配重代替髋伸展", "髋未后移、用腰拉起"], populationScope: `${ADULT_SCOPE}；附件、低位滑轮与活动空间确认后`, timeSetupCost: "设置/占位成本可能高于杠铃 RDL 或固定器械（条目评价原文）", fatigueCost: "局部：臀大肌/腘绳肌，中；全身：低-中；确定性：低（缺少直接证据证明其长期肌肥大优越，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX41: { variationId: "hip-abduction/machine", stabilizers: ["器械支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：髋外展/内收器械（外展配置）", techniqueCues: "座椅和活动范围适配，控制回程，不借躯干摆动", commonErrors: ["借躯干摆动完成", "回程失控", "座椅与活动范围不适配仍强行完成"], populationScope: `${ADULT_SCOPE}；髋部无疼痛、设备轴心适配者`, timeSetupCost: "调整座椅即可，设置快", fatigueCost: "局部：臀中肌/臀小肌及髋外展肌群，中；全身：低；确定性：低（缺少与深蹲/腿举直接比较长期效果的证据，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX42: { variationId: "hip-adduction/machine", stabilizers: ["器械支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：髋外展/内收器械（内收配置）", techniqueCues: "轴心位置适配，控制内收和回程，不使用弹震", commonErrors: ["使用弹震借力", "回程失控", "轴心不适配仍强行完成"], populationScope: `${ADULT_SCOPE}；腹股沟或髋部无疼痛者`, timeSetupCost: "调整座椅即可，设置快", fatigueCost: "局部：髋内收肌群，中；全身：低；确定性：低（缺少直接比较证明其普遍必要，条目评价原文）", progressionOptions: ["按器械配重档位加重", "同重量增加次数", "增加组数"] },
  EX43: { variationId: "curl/preacher-bench", stabilizers: ["牧师椅垫提供上臂支撑，稳定需求低"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：牧师椅（实际握杆/哑铃配置细节需现场确认）", techniqueCues: "上臂支撑稳定，避免肩部前后摆动，控制离心", commonErrors: ["肩部前后摆动借力", "离心阶段失控", "支撑角度不适配仍强行完成"], populationScope: `${ADULT_SCOPE}；肘部无不适、支撑角度适配者`, timeSetupCost: "调整牧师椅即可，设置快", fatigueCost: "局部：肱二头肌，中；全身：低；确定性：中（局部刺激明确，时间效率低于复合拉动作，条目评价原文）", progressionOptions: ["按实际配置加重：哑铃 2.5kg 一档或杠铃 5kg 一档", "同重量增加次数", "增加组数"] },
  EX44: { variationId: "curl/dumbbell-hammer", stabilizers: ["躯干稳定肌（抗摆动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃", techniqueCues: "中立握，肘部稳定，避免身体摆动", commonErrors: ["身体摆动借力", "肘部前后移动", "握持不稳"], populationScope: `${ADULT_SCOPE}；肘腕无疼痛者`, timeSetupCost: "取放哑铃即可，设置快", fatigueCost: "局部：肱肌/肱桡肌，中；全身：低；确定性：中", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX45: { variationId: "curl/dumbbell-supinated", stabilizers: ["躯干稳定肌（抗摆动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃", techniqueCues: "肘部位置稳定，避免躯干摆动，旋后动作可控", commonErrors: ["躯干摆动借力", "肘部前后移动", "旋后失控"], populationScope: `${ADULT_SCOPE}；肘腕无不适者`, timeSetupCost: "取放哑铃即可，设置快", fatigueCost: "局部：肱二头肌，中；全身：低；确定性：中（单关节补充，单位时间覆盖低，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX46: { variationId: "curl/cable", stabilizers: ["躯干稳定肌（站姿抗拉）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，把手附件未确认 → CONDITIONAL", techniqueCues: "上臂位置稳定，滑轮路径不拉扯肩肘，控制离心", commonErrors: ["上臂位置漂移", "滑轮路径拉扯肩肘仍强行完成", "离心阶段失控"], populationScope: `${ADULT_SCOPE}；附件与滑轮位置确认后`, timeSetupCost: "设置时间须计入效率（条目评价原文）", fatigueCost: "局部：肱二头肌，中；全身：低；确定性：低（缺少优于哑铃/牧师椅的长期比较，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX47: { variationId: "triceps-pushdown/cable", stabilizers: ["躯干稳定肌（站姿抗晃动）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架已确认，直杆/绳把附件未确认 → CONDITIONAL", techniqueCues: "上臂相对稳定，肘关节完成伸展，避免肩部代偿", commonErrors: ["肩部代偿、上臂大幅摆动", "身体前压借力", "肘部疼痛时仍强行完成"], populationScope: `${ADULT_SCOPE}；附件确认后、肘部无疼痛者`, timeSetupCost: "需设置高位滑轮与附件，设置成本中等", fatigueCost: "局部：肱三头肌，中；全身：低；确定性：中（局部刺激明确，适合作为推举后的补充，条目评价原文）", progressionOptions: ["按绳索配重档位加重", "同重量增加次数", "增加组数"] },
  EX48: { variationId: "triceps-extension/dumbbell-lying", stabilizers: ["肩部稳定肌（上臂定位）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：哑铃、可调角度训练椅", techniqueCues: "上臂位置稳定，肘部活动范围舒适，不强行追求极深拉伸", commonErrors: ["上臂位置漂移", "强行追求极深拉伸", "肘肩不适时仍继续"], populationScope: `${ADULT_SCOPE}；肘肩无不适者`, timeSetupCost: "取放哑铃与躺位设置，设置成本中等", fatigueCost: "局部：肱三头肌，中；全身：低；确定性：低（具体哑铃版本的直接比较证据不足，条目评价原文）", progressionOptions: ["哑铃按 2.5kg 一档加重", "同重量增加次数", "增加组数"] },
  EX49: { variationId: "core/plank", stabilizers: ["腹壁稳定肌群本身即训练目标（主肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：自重/地面，无需器械", techniqueCues: "头、躯干、骨盆保持整体，正常呼吸，不塌腰", commonErrors: ["塌腰", "憋气", "头颈过度抬起或低垂、破坏整体线"], populationScope: `${ADULT_SCOPE}；肩腕不适时改前臂或高位支撑`, timeSetupCost: "无器械设置成本；以时长计量", fatigueCost: "局部：腹壁稳定肌群，低-中；全身：低；确定性：中（静态支撑不是腹肌肌肥大的唯一或普遍最佳方案，条目评价原文）", progressionOptions: ["延长单组时长", "增加组数", "按技术掌握程度进阶变式"] },
  EX50: { variationId: "core/dead-bug", stabilizers: ["躯干深层稳定肌本身即训练目标（主肌，kb 原文）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：自重/地面，无需器械", techniqueCues: "骨盆保持稳定，对侧手脚缓慢伸展，正常呼吸", commonErrors: ["骨盆失稳、腰椎离地拱起", "动作过快", "憋气"], populationScope: `${ADULT_SCOPE}；腰盆控制不足时缩小范围`, timeSetupCost: "无器械设置成本", fatigueCost: "局部：躯干深层稳定肌，低-中；全身：低；确定性：中（技术学习成本较低，条目评价原文）", progressionOptions: ["扩大伸展范围", "增加次数或组数", "按控制质量进阶变式"] },
  EX51: { variationId: "cardio/treadmill-easy-run-walk", stabilizers: ["不适用（周期性有氧动作，kb 未列稳定肌）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：跑步机（数量、速度/坡度范围未知）", techniqueCues: "速度从可对话强度开始，先确认设备急停和安全使用方法", commonErrors: ["未确认急停与安全使用方法就开始", "轻松有氧定位下强度超出可对话范围", "出现疼痛、眩晕或异常不适仍继续"], populationScope: `${ADULT_SCOPE}；作为轻松有氧选项（kb 原文：经适龄安全评估后）`, timeSetupCost: "跑步机设置快；以时长计量（本条为有氧条目，与力量动作库分开计数）", fatigueCost: "局部：下肢反复周期性负荷，低-中（轻松强度）；全身：心肺，中（按时长累积）；确定性：中（速度、坡度与设备上限未知，条目评价原文）", progressionOptions: ["延长时长", "在可对话强度内小幅提速或加坡度（设备上限未确认，不预设数值）"] },
  EX52: { variationId: "core/gao-juan-tui-lying-fixed", stabilizers: ["腹横肌（稳定）", "双手握杠铃杆固定上身（外部固定）"], equipmentSnapshotMatch: "ATI-EQ-1.1 已确认：可调角度训练椅（调平作平板凳）、杠铃杆（头后上方固定双手用），两项均在已确认项内", techniqueCues: "躺平板凳，双手握头后上方杠铃杆固定身体；半个屁股在凳外；先落屁股、屁股先着凳，再把脚往远抛、慢慢落下、脚尖轻触地；抬起时往斜前方/斜上方顶屁股（骨盆后倾），只顶一下就下来、收缩一下再重复；脚越往远抛、越慢落越好，脚尖轻触地时腹肌离心张力最大；不是龙旗（龙旗屁股不着地），屁股先着地是为了保护腰椎、给腰椎的负担最小", commonErrors: ["做成龙旗（屁股不着地、腰椎负担大）", "只做 0–90° 抬腿不顶骨盆（变成髋屈肌主导）", "下放过快、失去离心控制", "借惯性甩腿"], populationScope: `${ADULT_SCOPE}；健康成年人（本系统仅面向成年人），需掌握骨盆后倾`, timeSetupCost: "把可调角度训练椅调平并固定杠铃杆即可，设置快；自重动作、无需装片", fatigueCost: "局部：腹直肌（下部），低-中（小肌群，局部疲劳为主）；全身：低；确定性：中（E3 机制证据 + E5 视频技术要点，长期肌肥大直接比较证据有限）", progressionOptions: ["放慢下放速度、加大抛腿距离（提高离心难度）", "同难度增加次数（做到接近力竭）", "增加组数"] },
  EX53: { variationId: "core/cable-crunch", stabilizers: ["髋部固定（跪姿/坐姿锚定，稳定需求低-中）"], equipmentSnapshotMatch: "ATI-EQ-1.1 部分未确认：龙门架/绳索站已确认，绳索把手附件未确认 → CONDITIONAL；待用户确认绳索把手附件后转 ACTIVE", techniqueCues: "跪对绳索站、双手在头侧握绳索把手，髋部位置固定不动，只做脊柱屈曲把肋骨卷向骨盆；全程可控、底部收缩停顿，靠配重加载（Nippard 加权卷腹要点按 2026-11-14 核查结论登记，原文未复核）", commonErrors: ["髋部前后移动借力、变成髋屈曲主导", "用手臂下拉代替脊柱屈曲", "下放失控、未做全程屈曲"], populationScope: `${ADULT_SCOPE}；绳索把手附件确认后`, timeSetupCost: "需设置高位滑轮与绳索把手附件，设置成本中等（附件未确认前不可用）", fatigueCost: "局部：腹直肌（上部），低-中（小肌群，局部疲劳为主）；全身：低；确定性：低（Nippard 结论未复核原文，附件未确认）", progressionOptions: ["按绳索配重档位加重（可加载是本动作相对自重卷腹的主要价值）", "同重量增加次数", "增加组数"] },
};

// 完整动作库 = 原始转录 + §5 字段补齐 + source_status 独立登记。
// 缺任何一条 §5 补齐数据都会在这里直接抛错（构建期暴露），不允许半成品入库。
export const EXERCISE_LIBRARY: LibraryExercise[] = EXERCISE_LIBRARY_RAW.map((e) => {
  const s5 = LIBRARY_SECTION5[e.id];
  if (!s5) throw new Error(`Exercise Library 条目 ${e.id} 缺少 kb_v2.0.md §5 字段补齐数据`);
  return {
    ...e,
    ...s5,
    // source_status 独立登记（kb_v2.0.md §5）：EX52 高卷腿的证据（Escamilla
    // 2006、东哥视频、解剖依据）均已核验 → verified，其 status 仍为 ACTIVE
    // 不变；EX53 绳索卷腹无独立约定值、保持与其 status 同值的 CONDITIONAL
    // （绳索把手附件未确认，不得写 verified）。其余条目沿用与 status 同值。
    sourceStatus: e.id === "EX52" ? ("verified" as const) : e.status,
    kind: e.id === "EX51" ? ("cardio" as const) : ("exercise" as const),
    // EX52/EX53 是 2026-11-15 核心动作更新新增条目，复核日期与版本单独登记；
    // 其余条目沿用 kb_v2.0.1 的登记口径，不回改。
    lastReviewedAt: e.id === "EX52" || e.id === "EX53" ? "2026-11-15" : "2026-11-14",
    version: e.id === "EX52" || e.id === "EX53" ? "2.0.2" : "2.0.1",
  };
});

// 动作库计数口径（唯一动作/变式总数；跑步机有氧单列，不并入力量动作数）。
// ACTIVE/CONDITIONAL/PROVISIONAL 计数按计划可用性 status 统计（source_status
// 是独立的来源核验字段，如 EX52 的 verified 不改变其 ACTIVE 可用性计数）。
export const LIBRARY_COUNTS = {
  total: EXERCISE_LIBRARY.length,
  exercises: EXERCISE_LIBRARY.filter((e) => e.kind === "exercise").length,
  cardio: EXERCISE_LIBRARY.filter((e) => e.kind === "cardio").length,
  active: EXERCISE_LIBRARY.filter((e) => e.status === "ACTIVE").length,
  conditional: EXERCISE_LIBRARY.filter((e) => e.status === "CONDITIONAL").length,
  provisional: EXERCISE_LIBRARY.filter((e) => e.status === "PROVISIONAL").length,
};

// 按 canonical 名或别名查库条目（计划/提案里的动作名与库名不完全一致时
// 靠别名对齐；查不到返回 null，表示未入库——提案中未入库的动作按
// 「无可核验出处」处理，不得进入正式计划）。
export function findLibraryExercise(name: string): LibraryExercise | null {
  const n = name.trim();
  for (const e of EXERCISE_LIBRARY) {
    if (e.name === n || e.aliases.includes(n)) return e;
  }
  // 宽松对齐：动作名包含库名/别名，或库名包含动作名（如「深蹲（轻量）」）
  for (const e of EXERCISE_LIBRARY) {
    const keys = [e.name, ...e.aliases];
    if (keys.some((k) => k.length >= 2 && (n.includes(k) || k.includes(n)))) return e;
  }
  return null;
}

// 提案的 v2.0 硬过滤（设计 §3 Step 4 / §8）：计划只能从 ACTIVE 库选动作，
// 且必须通过当前快照（条目设备依赖已在入库时按快照口径登记；CONDITIONAL
// 条目依赖的附件/空间未确认，PROVISIONAL 条目轨迹/身份未核验）。
// 返回违规列表（非空 = 提案不得保存），与既有确定性校验同级。
export function validateLibrarySelection(
  days: Array<{ date: string; kind: string; exercises: Array<{ name: string }> }>,
): string[] {
  const violations: string[] = [];
  for (const day of days) {
    if (day.kind !== "training") continue;
    for (const ex of day.exercises) {
      const entry = findLibraryExercise(ex.name);
      if (!entry) {
        violations.push(
          `${day.date}「${ex.name}」不在 Exercise Library 中（无可核验出处登记）：计划只能从动作库 ACTIVE 条目中选动作，请改用同模式已入库动作`,
        );
        continue;
      }
      if (entry.status !== "ACTIVE") {
        violations.push(
          `${day.date}「${ex.name}」命中库条目 ${entry.id}「${entry.name}」，状态为 ${entry.status}：${entry.status === "CONDITIONAL" ? "依赖未确认的附件/空间/配置" : "设备轨迹或动作身份尚未核验"}，不得进入正式计划；请改用其替换链中的 ACTIVE 动作（${entry.replacements.join("、") || "同模式 ACTIVE 动作"}）`,
        );
      }
    }
  }
  return violations;
}

// 反锚定审计（设计 §6.5/§6.6，生成前强制）：检查同一肌群是否连续以同一
// 动作起手——命中时产出 ROTATION_REVIEW 记录行（写入提案 rationale 与
// evidence_manifest），要求在动作选择说明里给出继续使用或轮换的证据理由；
// 轮换不是为变化而变化，最适配的动作可以保留，但必须说明理由。
export function anchoringAuditLines(
  days: Array<{ date: string; kind: string; exercises: Array<{ name: string }> }>,
  currentByDate: Map<string, { title: string; exercises: Array<{ name: string }> }>,
): string[] {
  const lines: string[] = [];
  const openerByMuscle = new Map<string, string[]>();
  const note = (muscle: string, opener: string) => {
    const arr = openerByMuscle.get(muscle) ?? [];
    arr.push(opener);
    openerByMuscle.set(muscle, arr);
  };
  for (const day of days) {
    if (day.kind !== "training") continue;
    const first = day.exercises[0];
    if (!first) continue;
    const entry = findLibraryExercise(first.name);
    const cls = classifyExercise(first.name);
    const muscles = entry?.primary.length ? entry.primary : cls.primary;
    for (const m of muscles) note(m, first.name);
    // 与现行计划同日首动作对照：同肌群、同起手 = 锚定延续，必须有轮换审查
    const curFirst = currentByDate.get(day.date)?.exercises[0];
    if (curFirst && curFirst.name === first.name) {
      lines.push(
        `ROTATION_REVIEW：${day.date} 仍以「${first.name}」起手，与现行计划同日首动作相同——已在动作选择说明中要求给出与同模式替代候选的比较理由；若它确实最适配可保留，但理由必须是证据与约束，不是「一直这么练」。`,
      );
    }
  }
  for (const [muscle, openers] of openerByMuscle) {
    const counts = new Map<string, number>();
    for (const o of openers) counts.set(o, (counts.get(o) ?? 0) + 1);
    for (const [opener, c] of counts) {
      if (c >= 2) {
        lines.push(
          `ROTATION_REVIEW：本周 ${muscle} 有 ${c} 天以「${opener}」起手——已触发轮换审查，动作选择说明须写明继续使用它的证据与约束理由，或改用同模式其他 ACTIVE 候选起手。`,
        );
      }
    }
  }
  return lines;
}

// 动作选择的七问记录（设计 §6.2 + v2.0.1 每次规划必答的 7 个问题）：
// 由模型在 selectionRationale 里逐动作给出，服务端在此与库条目、出处、
// 证据评价合并成 evidence_manifest 条目。唯一依据是「用户提过一次」时
// 标记 EVIDENCE_INSUFFICIENT 并判违规（validatePlanProposal 内执行）。
export interface SelectionRationaleT {
  name: string;
  why: string;
  evidenceView: string;
  alternative: string;
  whyNotAlternative: string;
  timeFatigue: string;
  opposing: string;
  historyRole: string;
}

export function buildSelectionManifest(
  days: Array<{ date: string; kind: string; exercises: Array<{ name: string }> }>,
  rationale: SelectionRationaleT[],
): ManifestEntry[] {
  const byName = new Map(rationale.map((r) => [r.name, r]));
  const entries: ManifestEntry[] = [];
  const seen = new Set<string>();
  for (const day of days) {
    if (day.kind !== "training") continue;
    for (const ex of day.exercises) {
      if (seen.has(ex.name)) continue;
      seen.add(ex.name);
      const entry = findLibraryExercise(ex.name);
      const r = byName.get(ex.name);
      entries.push({
        sourceType: "动作选择记录（v2.0 七问 + 反锚定）",
        ref: entry ? `${entry.id} · ${entry.status}` : "未入库",
        title: entry ? entry.name : ex.name,
        location: entry
          ? `Exercise Library ${entry.id}｜模式：${entry.patterns.join("/")}｜设备依赖：${entry.equipment.join("、")}（快照 ${EQUIPMENT_SNAPSHOT.id}）｜出处：${entry.source}`
          : "未在 Exercise Library 登记",
        fullTextStatus: entry
          ? `库条目证据评价：${entry.appraisal}`
          : "无可核验出处登记",
        usedFor: r
          ? [
              `①为什么选它：${r.why}`,
              `②书/文献评价：${r.evidenceView}`,
              `③同模式替代候选：${r.alternative}`,
              `④为什么没选替代：${r.whyNotAlternative}`,
              `⑤时间效率与疲劳代价：${r.timeFatigue}`,
              `⑥相反结论：${r.opposing}`,
              `⑦用户历史的作用：${r.historyRole}`,
            ].join("；")
          : "模型未给出该动作的选择说明（已在校验中标记）",
      });
    }
  }
  return entries;
}

// ---------------- ATI Planner（目标导向规划层，设计 v1.0 → v2.0） ----------------
// Planner 与上面的实时决策协调器是同一个循环在不同时间尺度下的两个视角：
// 共用上下文（目标/约束/历史/反馈事件）、共用 44 条证据账本、共用安全边界。
// v2.0 起叠加三层分离：决策动词（ATI_ACTIONS）≠ 动作库（EXERCISE_LIBRARY，
// 仅 ACTIVE 可进计划）≠ 器械快照（ATI-EQ-1.1 硬过滤）；每次提案附动作
// 选择七问与生成前反锚定审计，证据按 E1–E6 分级陈述。
// 规划不生成一张写死的固定周计划，而是持续维护一份「当前最合理」的计划
// 版本（工作假设）：v1 是既有分化周的登记基线；之后每次 generatePlan 由
// 模型按目标、当前状态、约束与本次检索的最新证据（ACSM 2026 立场声明、
// Pelland 2026 剂量 Meta 回归、账本原书条目）现判分化、动作组合与容量，
// 先落为 proposed 提案并附差异与 evidence_manifest，用户确认才写入 plans。
// 服务端只做确定性职责：数据完整性（有会话的日期绝不被提案覆盖）、时间
// 预算与容量爬坡的安全边界校验、版本管理与事件留痕——不写死任何分化
// 模板、容量百分比或动作路径；旧规则 A–G 与「每周固定 +10%」不进 Planner。

// 成人处方目标快照（用户 2026-11-14 确认并于 21:50 定版：本系统仅面向
// 成年人，无青少年配置与年龄分支；70kg 与体形目标保留为优化方向，
// 不转译、不承诺结果）。
export const PLANNER_GOALS: Record<string, string> = {
  prescriptionProfile:
    "成人处方（本系统仅面向成年人，无青少年配置与年龄分支判断）：ACSM 2026 等健康成年人证据适用（适用人群 ≥18 岁）；70kg、卧推做组 120kg、深蹲做组 130kg 与「强壮威武」体形为正式优化目标，跑步为次要目标",
  primaryGoal:
    "肌肥大（主目标）：2027 年 8 月前体重 60kg → 70kg；身形强壮威武，面试时一眼看起来特别壮实",
  strengthGoal:
    "力量参考目标（次于增肌）：卧推做组 120kg、深蹲做组 130kg（做组重量，非 1RM 测试）",
  runningGoal:
    "跑步（次要）：800 米 2:00、400 米 53 秒（现 800 米最佳 2:07），偶尔练；不把目标时间直接转成高强度间歇处方",
  currentState:
    "现 60kg、170cm；停训约两个月后恢复初期（2026-11-11 起恢复训练，已完成 3 次训练）",
  nutrition:
    "蛋白目标 120g/天、热量 2500–2700kcal（随体重上涨需上调）；无逐日饮食记录时按「未记录」处理，不补默认值",
  promiseNote: "目标是规划的优化方向与工作假设，不承诺某个体重或体型结果",
};

// v2.0 器械约束口径（与快照 ATI-EQ-1.1 同源；旧版本快照里的笼统表述
// 在读取/生成时统一覆盖为这一条，存量版本行本身不回改）。
const EQUIPMENT_CONSTRAINT_TEXT =
  "器械以正式快照 ATI-EQ-1.1 为准（用户 2026-11-14 现场确认）：龙门架/绳索站、高位下拉、牧师椅、卧推架、史密斯机、深蹲架、坐姿划船、坐姿反手下拉（轨迹未核验）、固定推肩、固定推胸（平板/上斜）、蝴蝶机、倒蹬腿举、坐姿腿伸展、髋外展/内收、髋铰链固定器械（商品名未知）、哑铃 2.5kg 一档、杠铃 5kg 一档、可调角度训练椅、引体单杠、跑步机。绳索附件、配重范围、杠铃空杆重量、哑铃最大重量、跑步机速度坡度、场地拥挤度均未确认，不得自动假设；计划只能从 Exercise Library 的 ACTIVE 条目选动作";

// 恢复状态口径（用户 2026-11-14 更正）：平均睡眠约 7.5 小时；11-14 单晚
// 约 6 小时只是偶发偏短，不得再按「睡眠约 6 小时、不足」作为规划前提。
// 旧版本快照里存的旧口径在读取/生成时统一覆盖为这一条（与器械口径同法），
// 存量版本行本身不回改。
const RECOVERY_STATE_TEXT =
  "睡眠平均约 7.5 小时（用户 2026-11-14 更正；11-14 单晚约 6 小时只是偶发偏短，不按睡眠不足处理）；11-13 摸底后臀/大腿后侧/髂胫束按压酸痛可接受、无关节刺痛，恢复中；飞鸟后的胸部不适已澄清为停练恢复期正常 DOMS（钝痛发僵属正常，动作中尖锐刺痛或力量骤掉才是停的信号）；睡眠与营养无逐日记录，按未记录处理";

export const PLANNER_CONSTRAINTS: Record<string, string> = {
  availableDays: "每天可练；由 Planner 按刺激频率、重叠与恢复现判训练日与休息日安排",
  sessionTime: "单次 55–95 分钟（硬约束）：含热身、组间休息与器械切换余量；时间缩短时重排优先级，不机械每动作减一组",
  equipment: EQUIPMENT_CONSTRAINT_TEXT,
  capacityStart:
    "容量从当前可恢复水平起步：当前周 65 个工作组；停训前峰值约 102 组/周不直接回去；爬坡节奏由反馈决定，没有固定百分比",
  fixedRest:
    "休息日以当前生效版本的周安排为准：现行周（2026-11-16 至 11-22）仅 11-22 周日整休；11-15 不休息（上午高数考试、下午考后轻量计划），11-21 是训练日（腿·轮换次量）",
  recentMeasures:
    "实测锚点：11-13 深蹲 100kg×8（RIR 3+、未变形）、罗马尼亚硬拉 60kg×8×3 完成（末组 RIR 2）；11-14 卧推 70kg×8 完成但 80kg×3 未达目标、上斜 25kg 第二组仅 4 次（RIR 0）、肩推 20kg 仅 5 次而 15kg×10 可完成、单臂划船找到 20kg、飞鸟 12.5kg 拉伸略撕痛后降回 10kg 无痛",
  recoveryState: RECOVERY_STATE_TEXT,
};

// 动作模式与肌群贡献（设计 §5 的建模数据，不是决策路径）：只用于直接/
// 间接组统计与处方展示。直接组=1.0；明显间接参与暂估 0.5（Pelland 2026
// fractional set 研究估算模型，不是生理常数）；极轻参与记 0、不计入。
// 推类动作的三角肌/肱三头只记间接 0.5，杜绝把复合动作整组重复计入每个
// 参与肌群造成的高估。
interface ExerciseClass {
  pattern: string;
  primary: string[];
  secondary: Array<{ muscle: string; credit: number }>;
  fatigue: "高" | "中" | "低";
}
const EXERCISE_CLASS_RULES: Array<{ match: RegExp; cls: ExerciseClass }> = [
  { match: /跑步|慢跑|轻松跑|有氧|单车|椭圆|游泳/, cls: { pattern: "有氧", primary: [], secondary: [], fatigue: "中" } },
  { match: /双杠/, cls: { pattern: "垂直推", primary: ["胸"], secondary: [{ muscle: "肱三头", credit: 0.5 }, { muscle: "前三角", credit: 0.5 }], fatigue: "中" } },
  { match: /卧推|胸推/, cls: { pattern: "水平推", primary: ["胸"], secondary: [{ muscle: "前三角", credit: 0.5 }, { muscle: "肱三头", credit: 0.5 }], fatigue: "高" } },
  { match: /夹胸|飞鸟/, cls: { pattern: "水平推（孤立）", primary: ["胸"], secondary: [{ muscle: "前三角", credit: 0 }], fatigue: "低" } },
  { match: /肩推|推举|过头推/, cls: { pattern: "垂直推", primary: ["前三角"], secondary: [{ muscle: "肱三头", credit: 0.5 }, { muscle: "侧三角", credit: 0 }], fatigue: "中" } },
  { match: /侧平举/, cls: { pattern: "肩部孤立", primary: ["侧三角"], secondary: [{ muscle: "前三角", credit: 0 }], fatigue: "低" } },
  { match: /前平举/, cls: { pattern: "肩部孤立", primary: ["前三角"], secondary: [{ muscle: "侧三角", credit: 0 }], fatigue: "低" } },
  { match: /肩伸|面拉|后束/, cls: { pattern: "肩部孤立", primary: ["后三角"], secondary: [{ muscle: "背阔肌", credit: 0 }], fatigue: "低" } },
  { match: /引体|下拉/, cls: { pattern: "垂直拉", primary: ["背阔肌"], secondary: [{ muscle: "肱二头", credit: 0.5 }, { muscle: "后三角", credit: 0.5 }], fatigue: "高" } },
  { match: /直臂下压/, cls: { pattern: "垂直拉（孤立）", primary: ["背阔肌"], secondary: [], fatigue: "低" } },
  { match: /划船/, cls: { pattern: "水平拉", primary: ["背阔肌", "上背"], secondary: [{ muscle: "肱二头", credit: 0.5 }, { muscle: "后三角", credit: 0.5 }], fatigue: "中" } },
  { match: /保加利亚|分腿蹲|箭步/, cls: { pattern: "单侧", primary: ["股四头", "臀大肌"], secondary: [{ muscle: "内收肌", credit: 0 }], fatigue: "中" } },
  { match: /深蹲|腿举|腿推/, cls: { pattern: "膝主导", primary: ["股四头", "臀大肌"], secondary: [{ muscle: "内收肌", credit: 0.5 }, { muscle: "腘绳肌", credit: 0 }], fatigue: "高" } },
  { match: /硬拉|臀桥|髋推/, cls: { pattern: "髋主导", primary: ["腘绳肌", "臀大肌"], secondary: [{ muscle: "竖脊肌", credit: 0.5 }], fatigue: "高" } },
  { match: /腿弯举|勾腿/, cls: { pattern: "屈膝孤立", primary: ["腘绳肌"], secondary: [{ muscle: "小腿", credit: 0 }], fatigue: "低" } },
  { match: /腿屈伸/, cls: { pattern: "伸膝孤立", primary: ["股四头"], secondary: [], fatigue: "低" } },
  { match: /提踵/, cls: { pattern: "踝关节孤立", primary: ["小腿"], secondary: [], fatigue: "低" } },
  { match: /臂屈伸|颈后臂|绳索下压/, cls: { pattern: "肘伸孤立", primary: ["肱三头"], secondary: [], fatigue: "低" } },
  { match: /弯举/, cls: { pattern: "肘屈孤立", primary: ["肱二头"], secondary: [{ muscle: "前臂", credit: 0 }], fatigue: "低" } },
  { match: /举腿|卷腹|平板|死虫|鸟狗|核心/, cls: { pattern: "核心", primary: ["核心"], secondary: [], fatigue: "低" } },
  { match: /农夫|携重/, cls: { pattern: "携重", primary: ["前臂", "斜方肌"], secondary: [], fatigue: "中" } },
];
const UNCLASSIFIED_CLASS: ExerciseClass = { pattern: "未分类", primary: [], secondary: [], fatigue: "中" };

export function classifyExercise(name: string): ExerciseClass {
  for (const r of EXERCISE_CLASS_RULES) {
    if (r.match.test(name)) return r.cls;
  }
  return UNCLASSIFIED_CLASS;
}

// Planner 规划时从账本检索的证据（设计 §12 的检索步骤在账本层的落地）：
// 计划审查 + 容量/组数 + 恢复 + 并行训练 + 频率，本次实际给模型的条目
// 会逐条写进 evidence_manifest，状态如实标 SOURCE_LIMITED。
export const PLANNER_EVIDENCE_IDS: string[] = [
  ...new Set([
    ...PLAN_REVIEW_EVIDENCE,
    ...(ATI_TOPIC_EVIDENCE.SETS?.ids ?? []),
    ...(ATI_TOPIC_EVIDENCE.RECOVERY?.ids ?? []),
    "E16",
    "E18",
    "E23",
  ]),
].slice(0, 12);

interface ManifestEntry {
  sourceType: string;
  ref: string;
  title: string;
  location: string;
  fullTextStatus: string;
  usedFor: string;
}

// 本次规划的证据清单（设计 §12/知识库规范 §四）：每项决策可追溯到来源与
// 核验状态。账本条目是章节级定位；ACSM 2026 为部分全文；Pelland 2026 与
// Held 2026 只有摘要级——全部如实标注，未核验的绝不声称已完整精读。
function buildEvidenceManifest(ledgerIds: string[]): ManifestEntry[] {
  const entries: ManifestEntry[] = [];
  for (const id of ledgerIds) {
    const c = EVIDENCE_CLAIMS.find((x) => x.id === id);
    if (!c) continue;
    entries.push({
      sourceType: "原书证据账本（muse-fitness-evidence-skills-v1）",
      ref: c.id,
      title: c.book,
      location: c.location,
      fullTextStatus: "SOURCE_LIMITED：章节与关键片段已定位核验，非整书逐页审计",
      usedFor: c.scope,
    });
  }
  entries.push({
    sourceType: "立场声明",
    ref: "ACSM 2026",
    title:
      "Currier BS, et al. (2026). ACSM Position Stand: Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults. DOI: 10.1249/MSS.0000000000003897",
    location: "PMC12965823（全文页面）",
    fullTextStatus:
      "部分全文：设计阶段已读方法、纳入标准、结果与关键处方章节；本次规划未重新回读全文，按问题回读状态标记未核验",
    usedFor: "成人容量、频率、努力程度（2–3 RIR 参考）与并行训练的证据背景；纳入对象为健康成年人 ≥18 岁",
  });
  entries.push({
    sourceType: "Meta 回归",
    ref: "Pelland 2026",
    title:
      "Pelland JC, et al. (2026). The Resistance Training Dose Response: Meta-Regressions Exploring the Effects of Weekly Volume and Frequency on Muscle Hypertrophy and Strength Gains. DOI: 10.1007/s40279-025-02344-w",
    location: "PubMed 41343037",
    fullTextStatus: "摘要级：PubMed 页面摘要、方法、结果已读；Springer 全文未获取——未核验",
    usedFor:
      "直接/间接组统计与 fractional set 估算模型（直接 1.0、明显间接 0.5、极轻 0；0.5 是研究估算模型，不是生理常数）；容量剂量反应存在递减收益",
  });
  entries.push({
    sourceType: "Umbrella Review",
    ref: "Held 2026",
    title: "Held et al. (2026). Maximizing Adaptations in Concurrent Training: An Umbrella Review of Meta-analyses. PubMed 41762427",
    location: "PubMed 41762427",
    fullTextStatus: "摘要级：检索摘要已读，全文未核验",
    usedFor: "力量为主、跑步为次的并行安排；对高水平运动员外推有限",
  });
  entries.push({
    sourceType: "系统综述 / Meta 分析（E1）",
    ref: "Haugen 2023",
    title:
      "Haugen T, et al. (2023). 机器与自由重量训练比较的系统综述与 Meta 分析. DOI: 10.1186/s13102-023-00713-4（题名与 DOI 按 kb_v2.0.md 第十节登记，本条未另行核验英文原文题名）",
    location: "PMC10426227",
    fullTextStatus:
      "设计阶段（v2.0 知识库）登记：结论为机器与自由重量在肌肥大上未发现显著差异、力量表现有测试模式专项性；本次规划未重新回读全文，按登记状态引用——未核验",
    usedFor: "v2.0 动作/器械评价的 E1 背景：设备类别不构成普遍优劣，动作选择回到目标、约束与个体适配（kb_v2.0.md 第二、十节登记）",
  });
  entries.push({
    sourceType: "视频证据（E5/E6）",
    ref: "VIDEO",
    title: "学者/专业人士公开视频（E5）与一般博主视频（E6）",
    location: "—",
    fullTextStatus: "当前未登记任何视频条目：未检索到并核验过符合登记要求（作者/频道、资历、标题、URL、时间戳、原文转述、引用研究、利益冲突）的视频，不编造频道、标题与引语",
    usedFor: "本次规划未使用任何视频证据；E5/E6 仅作补充解释，不与 E1/E2 等权",
  });
  entries.push({
    sourceType: "原书全文（九本）",
    ref: "BOOKS",
    title:
      "NSCA 第 5 版、Starting Strength 第 3 版、Zatsiorsky 第 3 版、Schoenfeld 肌肥大、RP Strength Training、RP Powerlifting、Helms Training 第 2 版、Helms Nutrition、Jeukendrup Sport Nutrition 第 2 版（Drive「运动书籍」全文可检索）",
    location: "全文文件仓 + 章节索引",
    fullTextStatus:
      "未核验（整章级）：本次经证据账本回读了上列章节定位条目，未逐字回读整章连续原文，不声称已完整精读；后续规划应按具体问题回读相关章节、表格与图注",
    usedFor: "动作技术、容量 landmarks、恢复与营养的框架背景",
  });
  return entries;
}

function parseJsonOr<T>(s: string | null, fallback: T): T {
  if (!s) return fallback;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
}

function addDaysStr(dateStr: string, n: number): string {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// 单组做功时长估算（秒）：时长型次数（「20分钟」）按时长计；纯数字次数
// 按每次约 4 秒、20–120 秒封顶；其余按 45 秒。只用于时间预算估算。
function setWorkSeconds(s: { reps: string }): number {
  const dur = s.reps.match(/(\d+(?:\.\d+)?)\s*分钟/);
  if (dur?.[1]) return Math.round(Number.parseFloat(dur[1]) * 60);
  const n = Number.parseInt(s.reps, 10);
  if (Number.isFinite(n)) return Math.min(120, Math.max(20, n * 4));
  return 45;
}

// 单次训练时间预算（设计 §9）：热身 + 做功 + 组间休息 + 器械切换余量，
// 服务端按组表确定性估算，模型给的分钟数不采信。
function estimateDayBudget(exercises: Exercise[]): {
  warmupMin: number;
  workMin: number;
  restMin: number;
  transitionMin: number;
  totalMin: number;
} {
  let workSec = 0;
  let restSec = 0;
  for (const ex of exercises) {
    ex.sets.forEach((s, i) => {
      // 做功 + 每组约 20 秒装卸/就位时间；休息按计划值计（实际执行常更长）
      workSec += setWorkSeconds(s) + 20;
      if (i < ex.sets.length - 1) restSec += s.restSeconds;
    });
  }
  const warmupMin = exercises.length ? 8 : 0;
  const transitionMin = exercises.length * 2;
  const workMin = Math.round(workSec / 60);
  const restMin = Math.round(restSec / 60);
  return {
    warmupMin,
    workMin,
    restMin,
    transitionMin,
    totalMin: warmupMin + workMin + restMin + transitionMin,
  };
}

interface PrescriptionT {
  date: string;
  name: string;
  movementPattern: string;
  primaryMuscles: string[];
  secondaryMuscles: Array<{ muscle: string; credit: number }>;
  plannedSets: number;
  repRange: string;
  effortTarget: string;
  restRange: string;
  techniqueRequirements: string;
  substitutionCandidates: string[];
  fatigueCostEstimate: string;
}

interface DayPlanT {
  date: string;
  kind: "training" | "rest";
  title: string;
  exercises: Exercise[];
  effortTargets?: Record<string, string>;
  substitutions?: Record<string, string[]>;
  droppable?: string[];
}

// 由日计划组装动作处方与肌群组数统计（设计 §5/§13）：原始直接组与折算
// 总量分开记；间接组只统计 credit=0.5 的明显参与，credit=0 的极轻参与不计。
function buildPrescriptionsAndVolume(days: DayPlanT[]): {
  prescriptions: PrescriptionT[];
  muscleVolume: Array<{ muscle: string; directSets: number; indirectSets: number; fractionalEstimate: number }>;
  totalWorkSets: number;
} {
  const prescriptions: PrescriptionT[] = [];
  const vol = new Map<string, { direct: number; indirect: number; frac: number }>();
  let totalWorkSets = 0;
  const bump = (muscle: string, sets: number, credit: number) => {
    const cur = vol.get(muscle) ?? { direct: 0, indirect: 0, frac: 0 };
    if (credit >= 1) cur.direct += sets;
    else if (credit > 0) cur.indirect += sets;
    cur.frac += sets * credit;
    vol.set(muscle, cur);
  };
  for (const day of days) {
    if (day.kind !== "training") continue;
    for (const ex of day.exercises) {
      const cls = classifyExercise(ex.name);
      // 热身组不计入工作组数与肌群折算组数，只统计工作组
      const sets = workSetCount(ex);
      const isCardio = (ex.category ?? "strength") === "cardio" || cls.pattern === "有氧";
      if (!isCardio) {
        totalWorkSets += sets;
        for (const m of cls.primary) bump(m, sets, 1);
        for (const s of cls.secondary) if (s.credit > 0) bump(s.muscle, sets, s.credit);
      }
      const workSets = ex.sets.filter((s) => !s.warmup);
      const repSource = workSets.length ? workSets : ex.sets;
      const repsNums = repSource.map((s) => Number.parseInt(s.reps, 10)).filter((n) => Number.isFinite(n));
      const repRange = repsNums.length
        ? repsNums.length > 1 && Math.min(...repsNums) !== Math.max(...repsNums)
          ? `${Math.min(...repsNums)}–${Math.max(...repsNums)} 次`
          : `${repsNums[0]} 次`
        : repSource[0]?.reps ?? "";
      const rests = repSource.map((s) => s.restSeconds).filter((r) => r > 0);
      const restRange = rests.length
        ? rests.length > 1 && Math.min(...rests) !== Math.max(...rests)
          ? `${Math.min(...rests)}–${Math.max(...rests)} 秒`
          : `${rests[0]} 秒`
        : "—";
      prescriptions.push({
        date: day.date,
        name: ex.name,
        movementPattern: cls.pattern,
        primaryMuscles: cls.primary,
        secondaryMuscles: cls.secondary,
        plannedSets: sets,
        repRange,
        effortTarget: day.effortTargets?.[ex.name] ?? "未单独记录（按各组目标与备注执行）",
        restRange,
        techniqueRequirements: ex.note,
        substitutionCandidates: day.substitutions?.[ex.name] ?? [],
        fatigueCostEstimate: cls.fatigue,
      });
    }
  }
  const muscleVolume = [...vol.entries()]
    .map(([muscle, v]) => ({
      muscle,
      directSets: v.direct,
      indirectSets: v.indirect,
      fractionalEstimate: Math.round(v.frac * 10) / 10,
    }))
    .sort((a, b) => b.fractionalEstimate - a.fractionalEstimate);
  return { prescriptions, muscleVolume, totalWorkSets };
}

// 提案与现行计划的差异（服务端按实际组表逐项比对生成，与真实改动一致）：
// 只比日期、标题、动作增减与每动作的组数/顶组重量，不写模型自述的差异。
function diffProposalDays(
  currentByDate: Map<string, { title: string; exercises: Exercise[] }>,
  days: DayPlanT[],
): string[] {
  const lines: string[] = [];
  const topWeight = (ex: Exercise): number | null => {
    const ws = ex.sets.map((s) => s.weightKg).filter((w): w is number => w != null);
    return ws.length ? Math.max(...ws) : null;
  };
  for (const day of days) {
    const cur = currentByDate.get(day.date);
    if (day.kind === "rest") {
      if (cur) {
        const sets = cur.exercises.reduce((a, e) => a + workSetCount(e), 0);
        lines.push(`${day.date} 改为休息日（原计划「${cur.title}」${sets} 组取消）`);
      }
      continue;
    }
    const sets = day.exercises.reduce((a, e) => a + workSetCount(e), 0);
    if (!cur) {
      lines.push(`${day.date} 新增训练日「${day.title}」（${day.exercises.length} 个动作、${sets} 组）`);
      continue;
    }
    if (cur.title !== day.title) lines.push(`${day.date} 标题「${cur.title}」→「${day.title}」`);
    const curMap = new Map(cur.exercises.map((e) => [e.name, e]));
    const newNames = new Set(day.exercises.map((e) => e.name));
    for (const ex of day.exercises) {
      const old = curMap.get(ex.name);
      if (!old) {
        lines.push(`${day.date} 新增动作「${ex.name}」${workSetCount(ex)} 组`);
        continue;
      }
      const parts: string[] = [];
      if (workSetCount(old) !== workSetCount(ex)) parts.push(`组数 ${workSetCount(old)} → ${workSetCount(ex)}`);
      if (warmupSetCount(old) !== warmupSetCount(ex)) parts.push(`热身组 ${warmupSetCount(old)} → ${warmupSetCount(ex)}`);
      const ow = topWeight(old);
      const nw = topWeight(ex);
      if (ow !== nw) parts.push(`顶组重量 ${ow ?? "未设"}kg → ${nw ?? "未设"}kg`);
      if (parts.length) lines.push(`${day.date}「${ex.name}」${parts.join("、")}`);
    }
    for (const old of cur.exercises) {
      if (!newNames.has(old.name)) lines.push(`${day.date} 去掉动作「${old.name}」（原 ${workSetCount(old)} 组）`);
    }
  }
  return lines;
}

type PlanVersionRow = typeof schema.planVersions.$inferSelect;

const muscleVolumeOut = z.object({
  muscle: z.string(),
  directSets: z.number(),
  indirectSets: z.number(),
  fractionalEstimate: z.number(),
});
const prescriptionOut = z.object({
  date: z.string(),
  name: z.string(),
  movementPattern: z.string(),
  primaryMuscles: z.array(z.string()),
  secondaryMuscles: z.array(z.object({ muscle: z.string(), credit: z.number() })),
  plannedSets: z.number(),
  repRange: z.string(),
  effortTarget: z.string(),
  restRange: z.string(),
  techniqueRequirements: z.string(),
  substitutionCandidates: z.array(z.string()),
  fatigueCostEstimate: z.string(),
});
const scheduleDayOut = z.object({
  date: z.string(),
  planId: z.number().nullable(),
  title: z.string(),
  kind: z.string(),
  totalSets: z.number(),
  estimatedMinutes: z.number(),
});
const timeBudgetOut = z.object({
  date: z.string(),
  warmupMin: z.number(),
  workMin: z.number(),
  restMin: z.number(),
  transitionMin: z.number(),
  totalMin: z.number(),
  droppable: z.array(z.string()),
});
const manifestEntryOut = z.object({
  sourceType: z.string(),
  ref: z.string(),
  title: z.string(),
  location: z.string(),
  fullTextStatus: z.string(),
  usedFor: z.string(),
});
const planVersionOut = z.object({
  id: z.number(),
  version: z.number(),
  status: z.string(),
  origin: z.string(),
  title: z.string(),
  weekStart: z.string().nullable(),
  weekEnd: z.string().nullable(),
  goalSnapshot: z.record(z.string(), z.string()),
  constraintsSnapshot: z.record(z.string(), z.string()),
  weeklySchedule: z.array(scheduleDayOut),
  exercisePrescriptions: z.array(prescriptionOut),
  muscleVolume: z.array(muscleVolumeOut),
  totalWorkSets: z.number(),
  timeBudget: z.array(timeBudgetOut),
  progressionHypotheses: z.array(z.string()),
  recoveryAssumptions: z.array(z.string()),
  evidenceManifest: z.array(manifestEntryOut),
  uncertainties: z.array(z.string()),
  safetyNotes: z.array(z.string()),
  diffSummary: z.string(),
  rationale: z.string(),
  confidence: z.number().nullable(),
  createdAt: z.string(),
  decidedAt: z.string().nullable(),
});
type PlanVersionOut = z.infer<typeof planVersionOut>;

function toPlanVersionOut(row: PlanVersionRow): PlanVersionOut {
  const schedule = parseJsonOr<Array<z.infer<typeof scheduleDayOut>>>(row.weeklySchedule, []);
  return {
    id: row.id,
    version: row.version,
    status: row.status,
    origin: row.origin,
    title: row.title,
    weekStart: row.weekStart,
    weekEnd: row.weekEnd,
    goalSnapshot: parseJsonOr<Record<string, string>>(row.goalSnapshot, {}),
    constraintsSnapshot: parseJsonOr<Record<string, string>>(row.constraintsSnapshot, {}),
    weeklySchedule: schedule,
    exercisePrescriptions: parseJsonOr<Array<z.infer<typeof prescriptionOut>>>(row.exercisePrescriptions, []),
    muscleVolume: parseJsonOr<Array<z.infer<typeof muscleVolumeOut>>>(row.muscleVolume, []),
    totalWorkSets: schedule.reduce(
      (a, d) => a + (d.kind === "training" || d.kind === "unchanged" ? d.totalSets : 0),
      0,
    ),
    timeBudget: parseJsonOr<Array<z.infer<typeof timeBudgetOut>>>(row.timeBudget, []),
    progressionHypotheses: parseJsonOr<string[]>(row.progressionHypotheses, []),
    recoveryAssumptions: parseJsonOr<string[]>(row.recoveryAssumptions, []),
    evidenceManifest: parseJsonOr<ManifestEntry[]>(row.evidenceManifest, []),
    uncertainties: parseJsonOr<string[]>(row.uncertainties, []),
    safetyNotes: parseJsonOr<string[]>(row.safetyNotes, []),
    diffSummary: row.diffSummary,
    rationale: row.rationale,
    confidence: row.confidence,
    createdAt: row.createdAt.toISOString(),
    decidedAt: row.decidedAt ? row.decidedAt.toISOString() : null,
  };
}

// v1 基线：把当前已排的分化周（2026-11-16 至 11-22）登记为第一个计划
// 版本。它只是登记——不改动任何 plans 行；之后 Planner 的新规划以 v2+
// 提案形式出现，旧表完整保留在版本历史里（用户 2026-11-14 追加指示）。
async function ensurePlannerBaseline(db: Db): Promise<void> {
  const existing = await db.select({ id: schema.planVersions.id }).from(schema.planVersions).limit(1);
  if (existing.length) return;
  const weekStart = "2026-11-16";
  const weekEnd = "2026-11-22";
  const planRows = await db.select().from(schema.plans).orderBy(asc(schema.plans.date));
  const inWeek = planRows.filter((p) => p.date >= weekStart && p.date <= weekEnd);
  const days: DayPlanT[] = inWeek.map((p) => ({
    date: p.date,
    kind: "training" as const,
    title: p.title,
    exercises: parseExercises(p.exercisesJson),
  }));
  const { prescriptions, muscleVolume, totalWorkSets } = buildPrescriptionsAndVolume(days);
  const planIdByDate = new Map(inWeek.map((p) => [p.date, p.id]));
  const schedule: Array<z.infer<typeof scheduleDayOut>> = [];
  const budgets: Array<z.infer<typeof timeBudgetOut>> = [];
  for (let i = 0; i < 7; i++) {
    const date = addDaysStr(weekStart, i);
    const day = days.find((d) => d.date === date);
    if (day) {
      const b = estimateDayBudget(day.exercises);
      schedule.push({
        date,
        planId: planIdByDate.get(date) ?? null,
        title: day.title,
        kind: "training",
        totalSets: day.exercises.reduce((a, e) => a + workSetCount(e), 0),
        estimatedMinutes: b.totalMin,
      });
      budgets.push({ date, ...b, droppable: [] });
    } else {
      schedule.push({
        date,
        planId: null,
        title: date === "2026-11-21" ? "休息（用户已定）" : "未安排",
        kind: "rest",
        totalSets: 0,
        estimatedMinutes: 0,
      });
    }
  }
  await db.insert(schema.planVersions).values({
    version: 1,
    status: "current",
    origin: "baseline",
    title: "分化周基线（11-16 至 11-22）",
    weekStart,
    weekEnd,
    goalSnapshot: JSON.stringify(PLANNER_GOALS),
    constraintsSnapshot: JSON.stringify(PLANNER_CONSTRAINTS),
    weeklySchedule: JSON.stringify(schedule),
    exercisePrescriptions: JSON.stringify(prescriptions),
    proposalDays: null,
    muscleVolume: JSON.stringify(muscleVolume),
    timeBudget: JSON.stringify(budgets),
    progressionHypotheses: JSON.stringify([
      "容量起点 = 当前可恢复水平（本周围绕 65 个工作组），不直接回到停训前约 102 组/周的峰值",
      "爬坡节奏由逐组反馈与恢复趋势决定：多次稳定且恢复良好才小幅进阶；一次表现好只记录、不自动加全周容量",
      "进阶一次只动有限变量（次数/负荷/组数/频率择一为主），不要求每周所有变量同时增加",
    ]),
    recoveryAssumptions: JSON.stringify([
      "睡眠近期约 6 小时、不足 7 小时：顶组安排保留睡眠前提（如 11-16 卧推备注），睡眠无逐日记录，按未记录处理",
      "11-13 摸底后的下肢酸痛在恢复中、无关节刺痛；11-18 腿日与 11-13 摸底间隔 5 天",
      "训练量提高但恢复下降时不机械加量；减载可为减组、降负荷、降接近力竭程度、减高疲劳动作或加休息日",
    ]),
    evidenceManifest: JSON.stringify(buildEvidenceManifest(PLAN_REVIEW_EVIDENCE)),
    uncertainties: JSON.stringify([
      "睡眠与营养没有逐日记录，无法据此精细调节单日负荷——计划里以备注形式保留睡眠前提",
      "多个动作目标重量未设（自重或器械档位未定），容量按组数统计、重量锚点只来自已实测动作",
      "Pelland 2026 全文未获取：0.5 间接组折算仅有摘要级证据支持，是研究估算模型、不是生理常数",
      "卧推 1RM 两个估计不一致（70×8 推算约 90kg vs 80×1 未完成），顶组安排以实测做组表现为准、不以推算 1RM 为准",
    ]),
    safetyNotes: JSON.stringify([
      "哑铃飞鸟 12.5kg 曾出现胸肌拉伸略撕痛（11-14）：胸日孤立动作控制拉伸幅度、不超过已验证无痛重量；再出现撕痛立即停止该动作，持续疼痛不靠换动作掩盖，须提示专业评估",
      "深蹲/卧推顶组须用保护杆或有人保护，不独自冲极限；不安排 1RM 测试",
      "出现关节刺痛、动作变形且无法纠正等停止信号时，实时层 ATI 会直接停止相关动作（安全停止不经确认）",
    ]),
    diffSummary: `初始基线：登记 2026-11-16 至 11-20 已排分化周（胸/背/腿/肩/手臂+核心，共 ${totalWorkSets} 个工作组），未改动任何计划；11-21 休息、11-22 未安排。`,
    rationale:
      "v1 是既有分化周的登记基线（工作假设）：它把已经排好的五天计划按动作模式与肌群贡献重新建模，给出直接/间接组统计与时间预算，作为后续 Planner 提案的差异比较基准。",
    confidence: null,
    decidedAt: new Date(),
  });
}

// Planner 提案的结构化输出（决策契约：计划输出十项的机器可读形状）。
const plannerDayOut = z.object({
  date: z.string(),
  kind: z.enum(["training", "rest"]),
  title: z.string(),
  focusNote: z.string().default(""),
  exercises: z.array(
    z.object({
      name: z.string().min(1),
      note: z.string().default(""),
      category: z.enum(["strength", "cardio"]),
      effortTarget: z.string().default(""),
      substitutions: z.array(z.string()).max(3).default([]),
      sets: z
        .array(
          z.object({
            weightKg: z.number().nullable(),
            reps: z.string().min(1),
            restSeconds: z.number().int().min(0).max(3600),
            warmup: z.boolean().default(false),
          }),
        )
        .min(1)
        .max(12),
    }),
  ),
  lowPriorityDroppable: z.array(z.string()).default([]),
  estimatedMinutes: z.number(),
});
// 七问选择记录的单条形状（generatePlan 第二步单独向模型收集，见下）。
const selectionRationaleItem = z.object({
  name: z.string().min(1),
  why: z.string().default(""),
  evidenceView: z.string().default(""),
  alternative: z.string().default(""),
  whyNotAlternative: z.string().default(""),
  timeFatigue: z.string().default(""),
  opposing: z.string().default(""),
  historyRole: z.string().default(""),
});

const plannerProposalOut = z.object({
  summary: z.string(),
  splitRationale: z.string(),
  days: z.array(plannerDayOut).min(1).max(7),
  // v2.0 动作选择七问（设计 §6.2 + v2.0.1）：每个被选动作一条，逐项回答
  // 为什么选它 / 书与文献如何评价 / 同模式替代候选 / 为什么没选替代 /
  // 时间效率与疲劳代价 / 有无相反结论 / 用户历史实际起到的作用。
  // 服务端据此生成 evidence_manifest 的动作选择记录；缺失或唯一依据是
  // 「用户提过一次」时判 EVIDENCE_INSUFFICIENT 违规、提案不得保存。
  // 字段带默认值：模型偶漏字段时先补空字符串通过结构校验，再由服务端
  // 语义校验（validateSelectionRationale）把缺项列为违规、要求重新生成——
  // 避免一次漏字段就让整次生成以「模型调用失败」告终。
  selectionRationale: z.array(selectionRationaleItem).default([]),
  progressionHypotheses: z.array(z.string()),
  recoveryAssumptions: z.array(z.string()),
  uncertainties: z.array(z.string()),
  safetyNotes: z.array(z.string()),
  evidenceIds: z.array(z.string()),
  questionForUser: z.string().nullable(),
  confidence: z.number().min(0).max(1),
});
type PlannerProposalRaw = z.infer<typeof plannerProposalOut>;

// 生成分两步（同一次 generatePlan 内）：第一步只出计划结构（不含七问），
// 第二步只为已选动作补七问选择记录。单次调用同时产出整周组表 + 全部
// 七问时输出体积过大、平台推理超时（2026-11-14 沙箱实测），拆开后每步
// 都在时限内，且第二步能按已确定的动作名单逐条对齐库条目。
const plannerPlanOut = plannerProposalOut.omit({ selectionRationale: true });
const rationaleBatchOut = z.object({ selectionRationale: z.array(selectionRationaleItem) });

// 提案的确定性校验（只查安全与数据边界，不查「练得对不对」）：日期必须
// 落在目标周内且不重复；已有训练记录的日期绝不允许被提案触碰；单次时长
// 按服务端估算不得明显超出 95 分钟硬约束；周工作组不得一下跳到当前可
// 恢复水平的 1.25 倍以上（恢复爬坡的安全边界，与实时层 10% 负荷上限同类）；
// 重量必须落在可执行范围。
function validatePlanProposal(
  raw: PlannerProposalRaw,
  weekDates: string[],
  sessionDates: Set<string>,
  baselineTotalSets: number,
  capMinutes: number,
  checkRationale = true,
): string[] {
  const violations: string[] = [];
  const seen = new Set<string>();
  let totalSets = 0;
  for (const day of raw.days) {
    if (!weekDates.includes(day.date)) {
      violations.push(`日期 ${day.date} 不在目标周（${weekDates[0]} 至 ${weekDates[weekDates.length - 1]}）内`);
      continue;
    }
    if (seen.has(day.date)) violations.push(`日期 ${day.date} 重复出现`);
    seen.add(day.date);
    if (sessionDates.has(day.date)) {
      violations.push(`${day.date} 已有训练记录，提案不得改动这一天`);
    }
    if (day.kind === "training") {
      if (!day.exercises.length) violations.push(`${day.date} 是训练日但没有动作`);
      const b = estimateDayBudget(day.exercises as Exercise[]);
      if (b.totalMin > capMinutes + 10) {
        violations.push(
          `${day.date} 按组表估算约 ${b.totalMin} 分钟，超出单次 ${capMinutes} 分钟硬约束（可留 10 分钟估算余量）：请重排优先级、删减低优先级内容，不要机械压缩主要动作的休息`,
        );
      }
      totalSets += day.exercises.reduce(
        (a, e) => a + ((e.category ?? "strength") === "cardio" ? 0 : workSetCount(e)),
        0,
      );
      for (const ex of day.exercises) {
        for (const s of ex.sets) {
          if (s.weightKg != null && !(s.weightKg > 0 && s.weightKg <= 400)) {
            violations.push(`${day.date}「${ex.name}」重量 ${s.weightKg}kg 不在可执行范围（0–400kg）`);
          }
        }
        // 热身递进只写在备注里 = 组表里没有热身组，照表练等于冷启动：判违规重生成
        if (
          /热身/.test(ex.note) &&
          /\d+(?:\.\d+)?\s*kg/.test(ex.note) &&
          !ex.sets.some((s) => s.warmup)
        ) {
          violations.push(
            `${day.date}「${ex.name}」的热身递进只写在备注里，没有出成组表中的热身组：请把热身递进排进 sets、工作组之前、标 warmup=true、组间歇 120 秒`,
          );
        }
      }
    }
  }
  if (!raw.days.some((d) => d.kind === "training" && weekDates.includes(d.date))) {
    violations.push("提案里没有任何训练日");
  }
  const cap = Math.ceil(baselineTotalSets * 1.25);
  if (baselineTotalSets > 0 && totalSets > cap) {
    violations.push(
      `周工作组 ${totalSets} 组超过恢复爬坡安全边界（当前可恢复水平约 ${baselineTotalSets} 组，上限 ${cap} 组）：容量从可恢复水平起步、按反馈爬坡，不要一次跳回停训前峰值`,
    );
  }
  // v2.0 硬过滤：动作只能来自 Exercise Library 的 ACTIVE 条目（快照口径
  // 已在入库时对齐）；CONDITIONAL/PROVISIONAL 与未入库动作一律拒绝。
  violations.push(...validateLibrarySelection(raw.days));
  if (checkRationale) violations.push(...validateSelectionRationale(raw));
  return violations;
}

// 单个动作的七问记录校验（validateSelectionRationale 与生成补救路径共用）：
// 返回该动作的违规列表（空 = 通过）。
function rationaleItemViolations(
  date: string,
  name: string,
  r: SelectionRationaleT | undefined,
): string[] {
  const violations: string[] = [];
  if (!r) {
    violations.push(
      `${date}「${name}」缺少动作选择记录（selectionRationale）：必须逐动作回答七问——为什么选它、书/文献如何评价、同模式替代候选、为什么没选替代、时间效率与疲劳代价、有无相反结论、用户历史的作用`,
    );
    return violations;
  }
  const fields: Array<[string, string]> = [
    ["为什么选它", r.why],
    ["书/文献评价", r.evidenceView],
    ["同模式替代候选", r.alternative],
    ["为什么没选替代", r.whyNotAlternative],
    ["时间效率与疲劳代价", r.timeFatigue],
    ["用户历史的作用", r.historyRole],
  ];
  for (const [label, val] of fields) {
    if (!val || val.trim().length < 4) {
      violations.push(`${date}「${name}」的选择记录缺少「${label}」实质内容`);
    }
  }
  // historyRole 声明历史「无作用/未起作用」是合法的（反锚定正解）；
  // 只有当它把历史提及当作唯一依据时才判证据不足。
  if (
    /(唯一|只有|仅|就是因为).{0,12}(提过|练过|做过|历史)/.test(r.historyRole) ||
    (/(提过一次|只提过|曾提过)/.test(r.historyRole) && !/(不是|并非|不构成|不能|未|无)/.test(r.historyRole))
  ) {
    violations.push(
      `${date}「${name}」EVIDENCE_INSUFFICIENT：选择依据被写成「用户提过/练过一次」——单次提及永远不能成为默认首选的依据；请重新检索同模式替代动作并以证据与约束定案`,
    );
  }
  return violations;
}

// v2.0 反锚定校验：每个被选动作必须有完整的七问选择记录；唯一依据是
// 「用户提过一次」时标记 EVIDENCE_INSUFFICIENT 并拒绝开计划。
function validateSelectionRationale(raw: {
  days: Array<{ date: string; kind: string; exercises: Array<{ name: string }> }>;
  selectionRationale: SelectionRationaleT[];
}): string[] {
  const violations: string[] = [];
  const rationaleByName = new Map(raw.selectionRationale.map((r) => [r.name, r]));
  for (const day of raw.days) {
    if (day.kind !== "training") continue;
    for (const ex of day.exercises) {
      violations.push(...rationaleItemViolations(day.date, ex.name, rationaleByName.get(ex.name)));
    }
  }
  return violations;
}

// 同模式 ACTIVE 替代候选（服务端按库条目模式字段检索，不靠模型记忆）：
// 生成前锚定审计与 EVIDENCE_INSUFFICIENT 补救定案都用这份名单。
function samePatternActiveAlternatives(entry: LibraryExercise, limit = 3): LibraryExercise[] {
  const chain: LibraryExercise[] = [];
  for (const rn of entry.replacements) {
    const r = findLibraryExercise(rn);
    if (r && r.status === "ACTIVE" && r.id !== entry.id && !chain.some((c) => c.id === r.id)) {
      chain.push(r);
    }
  }
  const byPattern = EXERCISE_LIBRARY.filter(
    (e) =>
      e.status === "ACTIVE" &&
      e.kind === "exercise" &&
      e.id !== entry.id &&
      !chain.some((c) => c.id === e.id) &&
      e.patterns.some((p) => entry.patterns.includes(p)),
  );
  return [...chain, ...byPattern].slice(0, limit);
}

// 生成前锚定审计（写七问之前先拦截）：计划结构定稿后、收集七问记录之前，
// 服务端先按库条目把每个入选动作的同模式 ACTIVE 替代候选算出来，并对
// 当日首项与库内评价已点名「不是默认首选」的条目发出明确警告，注入第二步
// 提示词——锚定式依据在生成七问时就被拦下，而不是等写完再被校验拒绝。
function anchorPrecheckLines(
  days: Array<{ date: string; kind: string; exercises: Array<{ name: string }> }>,
): string[] {
  const lines: string[] = [];
  for (const day of days) {
    if (day.kind !== "training") continue;
    day.exercises.forEach((ex, idx) => {
      const entry = findLibraryExercise(ex.name);
      if (!entry) return;
      const alts = samePatternActiveAlternatives(entry, 3);
      if (!alts.length) return;
      const warned = /(提过一次|不是默认首|默认首项|不构成排序依据)/.test(entry.appraisal);
      lines.push(
        `- ${day.date}「${ex.name}」（${idx === 0 ? "当日首项" : "入选动作"}，模式 ${entry.patterns.join("/")}）：同模式 ACTIVE 替代候选为 ${alts.map((a) => a.name).join("、")}——七问必须在这组候选内以证据与约束定案，historyRole 不得把用户单次提及或单次训练写成选择依据${warned ? "；特别警告：该条目库内评价已明确写明它不是默认首选、单次提及不构成排序依据" : ""}`,
      );
    });
  }
  return lines;
}

// 服务端补正七问：模型的选择记录在定向重生成后仍不合格时，用库条目自身
// 的已登记数据（出处、证据评价、技术要点、时间/疲劳成本、替换链）拼一份
// 以证据与约束定案的记录——内容全部来自库条目，不引入新断言；
// historyRole 明确写「未起作用」。补正事实会随提案 rationale 公开标注。
function buildFallbackRationale(name: string): SelectionRationaleT | null {
  const entry = findLibraryExercise(name);
  if (!entry) return null;
  const alts = samePatternActiveAlternatives(entry, 2);
  const alt = alts[0];
  return {
    name,
    why: `（服务端按库条目补正）按动作模式（${entry.patterns.join("/")}）与本次目标、器械和时间约束定案：主要目标肌群 ${entry.primary.join("、")}，设备依赖 ${entry.equipment.join("、")} 已与快照 ${EQUIPMENT_SNAPSHOT.id} 对齐（${entry.equipmentSnapshotMatch}），技术要点与停止条件在库内有登记。`,
    evidenceView: `出处：${entry.source}。库内证据评价：${entry.appraisal}`,
    alternative: alt
      ? `${alt.name}（${alt.id}，同为「${entry.patterns.join("/")}」模式的 ACTIVE 条目）`
      : "同模式 ACTIVE 候选见动作库替换链",
    whyNotAlternative: alt
      ? `替代候选 ${alt.name} 与本动作同模式，本次以设备设置成本、负荷可调性与当日时间预算定案（见时间/疲劳项）；这不构成对替代动作的优劣排名，后续可按反馈轮换。`
      : "同模式替代候选已在替换链登记，本次以约束定案，不构成优劣排名。",
    timeFatigue: `时间/设置成本：${entry.timeSetupCost}；疲劳成本：${entry.fatigueCost}`,
    opposing: /(未被证明|未证明|不足|有限|未证实|不能|不代表)/.test(entry.appraisal)
      ? `库内评价已并列限制：${entry.appraisal}`
      : "未检索到直接相反结论",
    historyRole: "未起作用：本次排序只依据库内证据评价与器械、时间约束，用户历史提及未参与定案。",
  };
}

function shanghaiToday(): string {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Shanghai" });
}

function mondayOf(dateStr: string): string {
  const d = new Date(`${dateStr}T00:00:00Z`);
  const dow = d.getUTCDay(); // 0=周日
  const delta = dow === 0 ? -6 : 1 - dow;
  return addDaysStr(dateStr, delta);
}

// submitFeedback 与 resumeAdjudication 共用的裁决结果形状：一次 ATI 裁决
// 的文案、调整清单与待确认建议。续跑返回同一形状，客户端用同一套逻辑渲染。
const adjudicationResponse = z.object({
  suggestion: z.string(),
  adjustments: z.array(
    z.object({
      type: z.string(),
      detail: z.string(),
      kind: z.enum(["客观触发", "主观感受参考", "信息性"]),
    }),
  ),
  proposalStatus: z.string(),
  proposal: proposalSchema.nullable(),
  appliedNote: z.string(),
  basisPrinciple: z.string().nullable(),
  basisKind: z.enum(["客观触发", "主观感受参考"]).nullable(),
  rule: z.string().nullable(),
  evidence: z.string().nullable(),
  action: z.string().nullable(),
});
type AdjudicationResult = z.infer<typeof adjudicationResponse>;

// resumeAdjudication 的返回：裁决结果 + stillRunning（裁决刚提交、还在
// 服务端进行中时为 true，此时不重复跑，客户端等轮询拿结果）。
const resumeAdjudicationResponse = adjudicationResponse.extend({
  stillRunning: z.boolean(),
});
type ResumeAdjudicationResult = z.infer<typeof resumeAdjudicationResponse>;

// ATI 裁决主体（submitFeedback 与 resumeAdjudication 共用）：反馈字段必须
// 已经落在 set_logs 行上——submitFeedback 先存反馈再调用，resumeAdjudication
// 续跑时直接读行上已存的反馈。组装上下文 → 跑统一决策循环 → 把裁决与
// 待确认建议写回该行，并把在途状态置 done。在途标记的置位（running）与
// 失败标记（failed）由调用方负责：裁决请求即使被切后台/息屏掐断，状态
// 也留在库里，刷新后能区分「还在裁决」与「被中断」并续跑。
async function adjudicateSavedFeedback(
  ctx: Ctx,
  db: Db,
  setId: number,
): Promise<AdjudicationResult> {
  const savedRows = await db
    .select()
    .from(schema.setLogs)
    .where(eq(schema.setLogs.id, setId))
    .limit(1);
  const row = savedRows[0];
  if (!row) throw new Error("找不到这一组记录。");
  const fb = {
    rir: row.rir,
    deform: row.deform as "未变形" | "变形" | "变形且无法纠正" | null,
    sorenessOver72: row.sorenessOver72 === 1,
    joint: row.joint,
    pump: row.pump,
    fatigue: row.fatigue,
    note: row.note,
  };
      const sessionRow = await loadSessionRow(db, row.sessionId);
      const allSets = await loadSessionSets(db, row.sessionId);
      const sameExercise = allSets.filter((s) => s.exerciseIdx === row.exerciseIdx);
      const current = sameExercise.find((s) => s.id === row.id);
      const remaining = sameExercise.filter(
        (s) => s.setIdx > row.setIdx && !s.done && !s.skipped,
      );
      // 旧版原样保留的组（legacyRecord）不参与连续失败判定与上一组链
      const earlierDone = sameExercise
        .filter((s) => s.setIdx < row.setIdx && s.done && !s.legacyRecord)
        .sort((a, b) => a.setIdx - b.setIdx);
      const laterExercises = [
        ...new Map(
          allSets
            .filter((s) => s.exerciseIdx > row.exerciseIdx)
            .map((s) => [s.exerciseIdx, s.exerciseName] as const),
        ).values(),
      ];

      // 测试日判定（计划开关/标题/动作含摸底测试）
      let testDay = false;
      if (sessionRow?.planId != null) {
        const planRows = await db
          .select()
          .from(schema.plans)
          .where(eq(schema.plans.id, sessionRow.planId))
          .limit(1);
        if (planRows[0]) {
          testDay = effectiveTestDay(
            planRows[0].testDay,
            planRows[0].title,
            parseExercises(planRows[0].exercisesJson),
          );
        }
      } else if (sessionRow) {
        testDay = /摸底|测试/.test(sessionRow.title);
      }

// ===== ATI 决策循环：历史上下文组装 =====
// 上一次训练课同动作的全部已完成组（趋势判断用），以及最近 3 次
// 含该动作的已完成训练课的一行摘要。只给事实，不给结论。
let prevSession: AtiDecisionInput["prevSession"] = null;
const recentSessions: AtiDecisionInput["recentSessions"] = [];
{
const prevSessions = await db
.select()
.from(schema.sessions)
.where(eq(schema.sessions.status, "completed"))
.orderBy(desc(schema.sessions.date), desc(schema.sessions.id));
for (const ps of prevSessions) {
if (ps.id === row.sessionId) continue;
const pSets = await loadSessionSets(db, ps.id);
const same = pSets
.filter((s) => s.exerciseName === row.exerciseName && s.done)
.sort((a, b) => a.setIdx - b.setIdx);
if (!same.length) continue;
const line = same
.map((s) => `${s.warmup ? "热身 " : ""}${s.actualWeightKg?? s.targetWeightKg?? "未设"}kg×${s.actualReps?? s.targetReps}`)
.join("、");
recentSessions.push({ date: ps.date, summary: `${ps.date}：${line}`});
if (!prevSession) {
prevSession = {
date: ps.date,
sets: same.map((s) => ({
targetWeightKg: s.targetWeightKg,
targetReps: s.targetReps,
actualWeightKg: s.actualWeightKg,
actualReps: s.actualReps,
rir: s.rir,
})),
};
}
if (recentSessions.length >= 3) break;
}
}

const facts = analyzeFeedback({
targetReps: row.targetReps,
actualReps: current?.actualReps?? row.actualReps,
rir: fb.rir,
deform: fb.deform,
joint: fb.joint,
sorenessOver72: fb.sorenessOver72,
note: fb.note,
});

const sessionElapsedMin =
sessionRow?.startedAt!= null
? Math.max(0, Math.round((Date.now() - new Date(sessionRow.startedAt).getTime()) / 60000))
: null;

// 唯一的决策入口：上下文 → 证据检索 → AI 裁决 → 安全校验 → 执行
const outcome = await runAtiDecision(
ctx,
{
exerciseName: row.exerciseName,
setIdx: row.setIdx,
isLastSetOfExercise: remaining.length === 0,
plannedSetsTotal: sameExercise.length,
targetWeightKg: row.targetWeightKg,
targetReps: row.targetReps,
plannedRestSeconds: remaining[0]?.targetRestSeconds?? row.targetRestSeconds,
actualWeightKg: current?.actualWeightKg?? row.actualWeightKg,
actualReps: current?.actualReps?? row.actualReps,
rir: fb.rir,
deform: fb.deform,
joint: fb.joint,
sorenessOver72: fb.sorenessOver72,
pump: fb.pump,
fatigue: fb.fatigue,
note: fb.note,
testDay,
remaining: remaining.map((s) => ({
setIdx: s.setIdx,
targetWeightKg: s.targetWeightKg,
targetReps: s.targetReps,
targetRestSeconds: s.targetRestSeconds,
})),
earlierToday: earlierDone.map((s) => ({
setIdx: s.setIdx,
targetWeightKg: s.targetWeightKg,
targetReps: s.targetReps,
actualWeightKg: s.actualWeightKg,
actualReps: s.actualReps,
rir: s.rir,
deform: s.deform,
joint: s.joint,
})),
prevSession,
recentSessions,
laterExercises,
sessionElapsedMin,
},
facts,
);

// ===== 按裁决组装待确认建议（建议制不变） =====
const guardNotes = [...outcome.guardNotes];
if (testDay &&!facts.stopSignal) {
guardNotes.push("测试日：测试重量与组数按计划执行，裁决不下调测试、不减测试组、不替换测试动作；只有停止信号能停测试");
}
let stopWarning: Proposal["stopWarning"] = null;
const isStop =
outcome.actionIds.includes("STOP_EXERCISE") || outcome.actionIds.includes("STOP_SESSION");
if (isStop) {
stopWarning = {
message: `${row.exerciseName} 出现${facts.stopWhy?? "需要停止的信号"}（ATI 安全裁决），后续同类动作开始前请先确认身体状态`,
affectedExercises: laterExercises,
};
if (!laterExercises.length) stopWarning = null;
}
const primaryName = atiActionName(outcome.primaryAction);
const basisKind: BasisKind = facts.objectiveTrigger? "客观触发": "主观感受参考";
const proposal: Proposal = {
nextWeightKg: outcome.nextWeightKg,
nextReps: outcome.nextReps,
restSeconds: outcome.restSeconds,
setsDelta: outcome.setsDelta,
replaceWith: outcome.replaceWith,
stopWarning,
guardNotes,
basisPrinciple: "ATI 综合评估（目标 × 表现 × 恢复 × 历史 × 证据）",
basisKind,
rule: `ATI · ${primaryName}`,
evidence: facts.evidenceText,
action: primaryName,
nextSessionWeightKg: outcome.nextSessionWeightKg,
recoveryChecklist: outcome.nextObservation,
atiActions: outcome.actionIds,
confidence: outcome.confidence,
recoveryLevel: outcome.recoveryLevel,
readinessOverall: outcome.readinessOverall,
evidenceIds: outcome.evidenceIds,
};
// 只给下次训练建议、或纯按计划继续且休息未变时，今天无待确认改动
const hasProposal =
proposal.nextWeightKg!= null ||
proposal.nextReps!= null ||
(proposal.restSeconds!= null &&
remaining.length > 0 &&
remaining.some((s) => s.targetRestSeconds!== proposal.restSeconds)) ||
proposal.setsDelta!== 0 ||
proposal.replaceWith!= null ||
proposal.stopWarning!= null;

// ===== 结构化裁决文案（服务端按 §10.4 形状拼装，缺一不可） =====
const actionText = describeOutcome(outcome, row.exerciseName, remaining.length);
const evidenceLines = outcome.evidenceIds
.map((id) => {
const c = EVIDENCE_CLAIMS.find((x) => x.id === id);
return c? `${id}｜${c.book}｜${c.location}：${c.fact}`: "";
})
.filter(Boolean);
const levelName =
RECOVERY_LEVELS.find((l) => l.level === outcome.recoveryLevel)?.name?? "信息不足";
const suggestion = [
        `【反馈事实】${facts.evidenceText}。`,
        `【ATI 裁决】${outcome.actionIds.map((id) => atiActionName(id)).join(" + ")} —— ${actionText}。`,
        `【评估】恢复状态：${levelName}（${outcome.recoveryLevel}）${
          outcome.readinessOverall != null
            ? `；准备度 ${outcome.readinessOverall}/100（按已提供维度加权重算，只辅助判断）`
            : "；准备度：数据维度不足，未评分"
        }；决策置信度 ${Math.round(outcome.confidence * 100)}%。`,
        `【理由】${outcome.reasoningSummary}`,
        evidenceLines.length
          ? `【证据】${evidenceLines.join("；")}（来源状态 SOURCE_LIMITED：章节与关键片段已定位核验）`
          : "",
        outcome.nextObservation.length ? `【下一步观察】${outcome.nextObservation.join("；")}` : "",
        outcome.questionForUser ? `【需要你补充】${outcome.questionForUser}` : "",
        ...guardNotes.map((g) => `【安全校验】${g}`),
      ]
        .filter(Boolean)
        .join("");

const adjustments: Array<{
type: string;
detail: string;
kind: "客观触发" | "主观感受参考" | "信息性";
}> = [
...outcome.actionNotes.map((a) => ({
type: `裁决动作：${atiActionName(a.type)}（${a.type}）`,
detail: a.note,
kind: basisKind,
})),
...guardNotes.map((g) => ({
type: "安全校验" as const,
detail: g,
kind: "信息性" as const,
})),
];

await db
.update(schema.setLogs)
.set({
aiSuggestion: suggestion,
aiAdjustments: JSON.stringify(adjustments),
aiRule: `ATI · ${primaryName}`,
aiEvidence: facts.evidenceText,
aiAction: primaryName,
aiBasisPrinciple: proposal.basisPrinciple,
aiBasisKind: basisKind,
proposalJson: hasProposal? JSON.stringify(proposal): null,
proposalStatus: hasProposal? "pending": "none",
appliedNote: null,
undoJson: null,
adjudicationStatus: "done",
adjudicationStartedAt: null,
updatedAt: new Date(),
})
.where(eq(schema.setLogs.id, setId));

// Planner 反向输入（设计 §13 FeedbackEvent / §11）：实时层的裁决只追加
// 一条 Planner 事件，供下一次生成/更新计划时读取——不悄悄改动任何计划
// 版本或每日计划；安全停止事件同样留痕，持续疼痛不得被换动作掩盖。
if (outcome.actionIds.includes("MODIFY_NEXT_SESSION") || outcome.nextSessionWeightKg != null) {
  await db.insert(schema.plannerEvents).values({
    kind: "ati_modify_next_session",
    sessionId: row.sessionId,
    setLogId: row.id,
    note: `训练中反馈：「${row.exerciseName}」第 ${row.setIdx + 1} 组裁决包含「修改下次训练」${
      outcome.nextSessionWeightKg != null
        ? `，下次同动作建议起点 ${outcome.nextSessionWeightKg}kg`
        : ""
    }——已记入 Planner 事件，下次生成/更新计划时作为输入，不自动改动任何计划。`,
    payloadJson: JSON.stringify({
      exerciseName: row.exerciseName,
      nextSessionWeightKg: outcome.nextSessionWeightKg,
      actions: outcome.actionIds,
    }),
  });
}
if (facts.stopSignal) {
  await db.insert(schema.plannerEvents).values({
    kind: "ati_stop_signal",
    sessionId: row.sessionId,
    setLogId: row.id,
    note: `训练中反馈：「${row.exerciseName}」第 ${row.setIdx + 1} 组出现停止信号（${facts.stopWhy ?? "停止信号"}），已停止该动作当日剩余组；后续规划须正视该信号，同一动作反复不适或持续疼痛应提示专业评估，不得只靠换动作掩盖。`,
    payloadJson: JSON.stringify({
      exerciseName: row.exerciseName,
      stopWhy: facts.stopWhy,
    }),
  });
}

ctx.invalidateQueries();
return {
suggestion,
adjustments,
proposalStatus: hasProposal? "pending": "none",
proposal: hasProposal? proposal: null,
appliedNote: hasProposal
? "这是待确认建议：点「接受」才会改动后续组，点「忽略」保持不变。"
: outcome.nextSessionWeightKg!= null
? `今天后续组不变；下次训练 ${row.exerciseName} 的建议起点是 ${outcome.nextSessionWeightKg}kg（只是建议，不会自动改动任何计划）。`
: "ATI 裁决：按计划继续，无需改动后续组。",
basisPrinciple: proposal.basisPrinciple,
basisKind,
rule: `ATI · ${primaryName}`,
evidence: facts.evidenceText,
action: primaryName,
};
}


export const Actions = {
  getDay: defineAction({
    description:
      "读取某一天的训练计划、当天训练会话与逐组记录；同时返回该日在当前生效计划版本周安排中的定位（训练日/休息日）与整周安排，使休息日不再显示成「还没有计划」、且新一周生效后在任意一天都能看到整周更新。",
    request: z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }),
    response: z.object({
      date: z.string(),
      plan: z
        .object({
          id: z.number(),
          title: z.string(),
          testDay: z.boolean(),
          exercises: z.array(exerciseSchema),
        })
        .nullable(),
      session: sessionOut.nullable(),
      sets: z.array(setLogOut),
      // 该日在当前生效版本周安排中的条目（不在该周内为 null）
      plannerDay: z
        .object({ kind: z.string(), title: z.string(), version: z.number() })
        .nullable(),
      // 当前生效版本的整周安排（无生效版本时为 null）
      currentWeek: z
        .object({
          version: z.number(),
          title: z.string(),
          weekStart: z.string().nullable(),
          weekEnd: z.string().nullable(),
          totalWorkSets: z.number(),
          days: z.array(scheduleDayOut),
        })
        .nullable(),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const planRows = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, args.date))
        .limit(1);
      const planRow = planRows[0];
      const sessionRows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.date, args.date))
        .orderBy(desc(schema.sessions.id))
        .limit(1);
      const sessionRow = sessionRows[0];
      const sets = sessionRow ? await loadSessionSets(db, sessionRow.id) : [];
      const versionRows = await db
        .select()
        .from(schema.planVersions)
        .where(eq(schema.planVersions.status, "current"))
        .limit(1);
      const currentRow = versionRows[0];
      const current = currentRow ? toPlanVersionOut(currentRow) : null;
      const plannerDayEntry = current?.weeklySchedule.find((d) => d.date === args.date) ?? null;
      return {
        date: args.date,
        plan: planRow
          ? {
              id: planRow.id,
              title: planRow.title,
              testDay: effectiveTestDay(planRow.testDay, planRow.title, parseExercises(planRow.exercisesJson)),
              exercises: parseExercises(planRow.exercisesJson),
            }
          : null,
        session: sessionRow ? toSessionOut(sessionRow) : null,
        sets,
        plannerDay: plannerDayEntry
          ? { kind: plannerDayEntry.kind, title: plannerDayEntry.title, version: current?.version ?? 0 }
          : null,
        currentWeek: current
          ? {
              version: current.version,
              title: current.title,
              weekStart: current.weekStart,
              weekEnd: current.weekEnd,
              totalWorkSets: current.totalWorkSets,
              days: current.weeklySchedule,
            }
          : null,
      };
    },
  }),

  savePlan: defineAction({
    description: "新建或覆盖某一天的训练计划（动作、每组重量/次数/休息、备注、测试日开关）。",
    request: z.object({
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      title: z.string().min(1),
      testDay: z.boolean().optional(),
      exercises: z.array(exerciseSchema).min(1),
    }),
    response: z.object({ id: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      // 类别落库：未显式给定时按名称（跑步/有氧/单车等）或时长型次数自动识别
      // 配重取整：杠铃/哑铃重量向下取整到能配出来的档位（杠铃 5 的倍数、哑铃 2.5 一档）
      const withCategory: Exercise[] = normalizeExerciseWeights(
        args.exercises.map((e) => ({
          ...e,
          category:
            e.category ??
            (/跑步|有氧|单车|椭圆|游泳|划船/.test(e.name) ||
            e.sets.every((s) => s.weightKg == null && !/^\d+$/.test(s.reps.trim()))
              ? "cardio"
              : "strength"),
        })),
      );
      const json = JSON.stringify(withCategory);
      const existing = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, args.date))
        .limit(1);
      // testDay 三态落库铁律：显式传了就按传入值存（true→1 / false→-1）；
      // 没传则沿用原行存量值（新计划为 0=未设置，读时按标题/动作自动判定），
      // 绝不把「没传」默认写成关闭（-1/false）。
      // savePlan 只写 plans 表本身：绝不删除、清空或重置任何会话与逐组记录，
      // 当天进行中/已完成的训练一律原样保留。
      const storedTestDay =
        args.testDay === undefined
          ? (existing[0]?.testDay ?? 0)
          : args.testDay
            ? 1
            : -1;
      let id: number;
      if (existing[0]) {
        await db
          .update(schema.plans)
          .set({
            title: args.title,
            exercisesJson: json,
            testDay: storedTestDay,
            updatedAt: new Date(),
          })
          .where(eq(schema.plans.id, existing[0].id));
        id = existing[0].id;
      } else {
        const inserted = await db
          .insert(schema.plans)
          .values({
            date: args.date,
            title: args.title,
            exercisesJson: json,
            testDay: storedTestDay,
          })
          .returning({ id: schema.plans.id });
        id = inserted[0]?.id ?? 0;
      }
      // 写后回读校验：落库的 testDay 必须与目标值完全一致，不一致直接报错，
      // 不允许出现「调用返回成功、开关却被悄悄改掉」的情况。
      const check = await db
        .select({ testDay: schema.plans.testDay })
        .from(schema.plans)
        .where(eq(schema.plans.id, id))
        .limit(1);
      if (!check[0] || check[0].testDay !== storedTestDay) {
        throw new Error("计划保存后测试日开关回读不一致，请重试保存。");
      }
      ctx.invalidateQueries();
      return { id };
    },
  }),

  setPlanTestDay: defineAction({
    description:
      "只修正某天计划的测试日开关（单列更新 test_day），不改标题、组表与备注，绝不触碰任何会话与逐组记录。",
    request: z.object({
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      testDay: z.boolean(),
    }),
    response: z.object({ ok: z.literal(true), id: z.number(), testDay: z.boolean() }),
    async handler(
      ctx,
      args,
    ): Promise<{ ok: true; id: number; testDay: boolean }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, args.date))
        .limit(1);
      const plan = rows[0];
      if (!plan) throw new Error("这一天还没有计划，无法设置测试日开关。");
      await db
        .update(schema.plans)
        .set({ testDay: args.testDay ? 1 : -1, updatedAt: new Date() })
        .where(eq(schema.plans.id, plan.id));
      const check = await db
        .select({ testDay: schema.plans.testDay })
        .from(schema.plans)
        .where(eq(schema.plans.id, plan.id))
        .limit(1);
      if (!check[0] || check[0].testDay !== (args.testDay ? 1 : -1)) {
        throw new Error("测试日开关回读不一致，请重试。");
      }
      ctx.invalidateQueries();
      return { ok: true, id: plan.id, testDay: check[0].testDay === 1 };
    },
  }),

  deletePlan: defineAction({
    description: "删除某一天尚未开始训练的计划。",
    request: z.object({ date: z.string() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db.delete(schema.plans).where(eq(schema.plans.date, args.date));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  updatePlanSetWeight: defineAction({
    description: "给计划中某一组单独补填/修改目标重量（目标为空时的快捷填入口）。",
    request: z.object({
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      exerciseIdx: z.number().int().min(0),
      setIdx: z.number().int().min(0),
      weightKg: z.number().min(0).max(1000),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, args.date))
        .limit(1);
      const plan = rows[0];
      if (!plan) throw new Error("这一天还没有计划。");
      const exercises = parseExercises(plan.exercisesJson);
      const ex = exercises[args.exerciseIdx];
      const set = ex?.sets[args.setIdx];
      if (!ex || !set) throw new Error("找不到这一组。");
      // 补填的重量同样按可配档位取整（杠铃 5 的倍数、哑铃 2.5 一档，向下取整）
      set.weightKg = loadableWeight(ex.name, args.weightKg);
      await db
        .update(schema.plans)
        .set({ exercisesJson: JSON.stringify(exercises), updatedAt: new Date() })
        .where(eq(schema.plans.id, plan.id));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  startSession: defineAction({
    description: "按当天计划开始一次训练，生成逐组待记录条目（同时快照原始计划目标）。",
    request: z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }),
    response: z.object({ sessionId: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const existing = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.date, args.date))
        .orderBy(desc(schema.sessions.id))
        .limit(1);
      if (existing[0] && existing[0].status === "in_progress") {
        return { sessionId: existing[0].id };
      }
      const planRows = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, args.date))
        .limit(1);
      const plan = planRows[0];
      if (!plan) throw new Error("这一天还没有计划，先新建计划再开始训练。");
      const exercises = parseExercises(plan.exercisesJson);
      const inserted = await db
        .insert(schema.sessions)
        .values({
          planId: plan.id,
          date: args.date,
          title: plan.title,
          status: "in_progress",
          startedAt: new Date(),
        })
        .returning({ id: schema.sessions.id });
      const sessionId = inserted[0]?.id;
      if (sessionId == null) throw new Error("开始训练失败，请重试。");
      const now = new Date();
      for (let ei = 0; ei < exercises.length; ei++) {
        const ex = exercises[ei];
        if (!ex) continue;
        for (let si = 0; si < ex.sets.length; si++) {
          const s = ex.sets[si];
          if (!s) continue;
          await db.insert(schema.setLogs).values({
            sessionId,
            exerciseName: ex.name,
            exerciseIdx: ei,
            setIdx: si,
            warmup: s.warmup ? 1 : 0,
            targetWeightKg: s.weightKg,
            targetReps: s.reps,
            targetRestSeconds: s.restSeconds,
            origWeightKg: s.weightKg,
            origReps: s.reps,
            origRestSeconds: s.restSeconds,
            createdAt: now,
            updatedAt: now,
          });
        }
      }
      ctx.invalidateQueries();
      return { sessionId };
    },
  }),

  logSet: defineAction({
    description: "记录某一组的实际重量、次数、组间休息、有氧数据与完成/跳过状态；返回服务端时间戳供休息计时校准。",
    request: z.object({
      setId: z.number(),
      actualWeightKg: z.number().nullable(),
      actualReps: z.string().nullable(),
      durationMin: z.number().min(0).max(1440).nullable().optional(),
      pace: z.string().max(12).nullable().optional(),
      distanceKm: z.number().min(0).max(1000).nullable().optional(),
      restSeconds: z.number().int().min(0).max(7200).nullable(),
      done: z.boolean(),
      skipped: z.boolean(),
    }),
    response: z.object({ ok: z.literal(true), serverNow: z.number() }),
    async handler(ctx, args): Promise<{ ok: true; serverNow: number }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.id, args.setId))
        .limit(1);
      const row = rows[0];
      // skippedBy 只在跳过状态发生切换时改写：手动跳过记 user，恢复记 null；
      // 仅更新休息时长等字段时不动它，避免把 AI 建议的跳过误记成用户决定。
      let skippedBy = row?.skippedBy ?? null;
      if (row) {
        if (args.skipped && row.skipped !== 1) skippedBy = "user";
        if (!args.skipped && row.skipped === 1) skippedBy = null;
      }
      await db
        .update(schema.setLogs)
        .set({
          actualWeightKg: args.actualWeightKg,
          actualReps: args.actualReps,
          ...(args.durationMin !== undefined ? { durationMin: args.durationMin } : {}),
          ...(args.pace !== undefined ? { pace: args.pace } : {}),
          ...(args.distanceKm !== undefined ? { distanceKm: args.distanceKm } : {}),
          restSeconds: args.restSeconds,
          done: args.done ? 1 : 0,
          skipped: args.skipped ? 1 : 0,
          skippedBy,
          updatedAt: new Date(),
        })
        .where(eq(schema.setLogs.id, args.setId));
      ctx.invalidateQueries();
      return { ok: true, serverNow: Date.now() };
    },
  }),

  submitFeedback: defineAction({
    description: "提交某一组练后反馈（完成次数由记录本身提供，另填 RIR、动作是否变形、关节感受与自由文字；泵感/疲劳为参考信号）：走 ATI 统一决策循环——服务端组装上下文（目标/计划/实际/恢复/历史，缺失项标未记录）、从 44 条原书证据账本检索相关条目、AI 从 14 个可组合动作中综合裁决、服务端做确定性安全校验（停止信号、负荷与休息边界、测试日保护、T16 回归）后存为待确认建议（不直接改目标）；校验两次不过或模型不可用时走保守缺省。quickContinue=true 时只记录反馈、按计划继续，不调用 AI。反馈落库后先写「裁决进行中」标记再跑推理：请求被切后台/息屏/退出掐断时，结果与状态以落库为准，改用 resumeAdjudication 续跑。",
    request: z.object({
      setId: z.number(),
      // RIR 统一标尺：0、1、2、3，其中 3 表示 3+（还能标准地做 3 个以上）
      rir: z.number().min(0).max(3).nullable(),
      deform: z.enum(["未变形", "变形", "变形且无法纠正"]).nullable(),
      sorenessOver72: z.boolean().nullable(),
      joint: z.string().max(60).nullable(),
      pump: z.number().int().min(1).max(5).nullable(),
      fatigue: z.number().int().min(1).max(10).nullable(),
      note: z.string().max(300).nullable(),
      quickContinue: z.boolean().optional(),
    }),
    response: adjudicationResponse,
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.id, args.setId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这一组记录。");

      // 先保存本组反馈（无论走哪条路径都不丢）：四项客观证据中的 RIR、
      // 动作是否变形、关节感受存在这里，完成次数在 logSet 的实际记录里。
      await db
        .update(schema.setLogs)
        .set({
          rir: args.rir,
          deform: args.deform,
          sorenessOver72: args.sorenessOver72 == null ? null : args.sorenessOver72 ? 1 : 0,
          joint: args.joint,
          pump: args.pump,
          fatigue: args.fatigue,
          note: args.note,
          updatedAt: new Date(),
        })
        .where(eq(schema.setLogs.id, args.setId));

      // 一键按计划继续：只记反馈，不生成建议、不动后续组。
      if (args.quickContinue) {
        await db
          .update(schema.setLogs)
          .set({
            proposalStatus: "none",
            proposalJson: null,
            aiSuggestion: null,
            aiAdjustments: null,
            aiRule: null,
            aiEvidence: null,
            aiAction: null,
            aiBasisPrinciple: null,
            aiBasisKind: null,
            adjudicationStatus: null,
            adjudicationStartedAt: null,
          })
          .where(eq(schema.setLogs.id, args.setId));
        ctx.invalidateQueries();
        return {
          suggestion: "",
          adjustments: [],
          proposalStatus: "none",
          proposal: null,
          appliedNote: "已按计划继续，后续组不变。",
          basisPrinciple: null,
          basisKind: null,
          rule: null,
          evidence: null,
          action: null,
        };
      }

      // 裁决在途标记先落库：推理最长可达 2×90 秒，期间切后台、息屏或
      // 退出空间都可能让这条请求回不来；有了落库状态，刷新后客户端能
      // 区分「还在裁决」与「裁决被中断」，并用 resumeAdjudication 续跑，
      // 不再永远卡在「正在综合裁决」。
      await db
        .update(schema.setLogs)
        .set({
          adjudicationStatus: "running",
          adjudicationStartedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(schema.setLogs.id, args.setId));
      try {
        return await adjudicateSavedFeedback(ctx, db, args.setId);
      } catch (e) {
        await db
          .update(schema.setLogs)
          .set({ adjudicationStatus: "failed", updatedAt: new Date() })
          .where(eq(schema.setLogs.id, args.setId));
        throw e;
      }
    },
}),

  resumeAdjudication: defineAction({
    description: "续跑一组被中断的 ATI 裁决：反馈已落在该组记录上、但裁决没写回（切后台/息屏/退出空间掐断了那条长请求）时，用已保存的反馈重新跑统一决策循环并落库；裁决刚提交还在进行中时返回 stillRunning=true 不重复跑；已有裁决结果时原样返回不重跑。",
    request: z.object({ setId: z.number() }),
    response: resumeAdjudicationResponse,
    async handler(ctx, args): Promise<ResumeAdjudicationResult> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.id, args.setId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这一组记录。");
      const out = toSetLogOut(row);

      // 已有裁决结果且不在进行中：原样返回，不重复消耗一次裁决。
      if (row.aiSuggestion && row.adjudicationStatus !== "running") {
        return {
          suggestion: out.aiSuggestion ?? "",
          adjustments: out.aiAdjustments,
          proposalStatus: out.proposalStatus ?? "none",
          proposal: out.proposal,
          appliedNote:
            out.appliedNote ??
            (out.proposalStatus === "pending"
              ? "这是待确认建议：点「接受」才会改动后续组，点「忽略」保持不变。"
              : ""),
          basisPrinciple: out.aiBasisPrinciple,
          basisKind:
            out.aiBasisKind === "客观触发" || out.aiBasisKind === "主观感受参考"
              ? out.aiBasisKind
              : null,
          rule: out.aiRule,
          evidence: out.aiEvidence,
          action: out.aiAction,
          stillRunning: false,
        };
      }

      // 刚提交不久的裁决多半还在服务端跑：不抢跑，等客户端轮询拿结果。
      const startedMs = row.adjudicationStartedAt ? row.adjudicationStartedAt.getTime() : null;
      if (
        row.adjudicationStatus === "running" &&
        startedMs != null &&
        Date.now() - startedMs < 60_000
      ) {
        return {
          suggestion: "",
          adjustments: [],
          proposalStatus: out.proposalStatus ?? "none",
          proposal: null,
          appliedNote: "裁决还在进行中，稍等片刻会自动出现结果。",
          basisPrinciple: null,
          basisKind: null,
          rule: null,
          evidence: null,
          action: null,
          stillRunning: true,
        };
      }

      const hasFeedback =
        row.rir != null ||
        row.deform != null ||
        row.joint != null ||
        row.note != null ||
        row.pump != null ||
        row.fatigue != null;
      if (!hasFeedback && !row.aiSuggestion) {
        throw new Error("这一组还没有保存过反馈，没有可续跑的裁决。");
      }

      // 接管这次裁决：在途标记刷新为本轮开始时间，随后跑与 submitFeedback
      // 完全相同的裁决主体（读行上已保存的反馈），结果落库。
      await db
        .update(schema.setLogs)
        .set({
          adjudicationStatus: "running",
          adjudicationStartedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(schema.setLogs.id, args.setId));
      try {
        const result = await adjudicateSavedFeedback(ctx, db, args.setId);
        ctx.invalidateQueries();
        return { ...result, stillRunning: false };
      } catch (e) {
        await db
          .update(schema.setLogs)
          .set({ adjudicationStatus: "failed", updatedAt: new Date() })
          .where(eq(schema.setLogs.id, args.setId));
        throw e;
      }
    },
  }),

  respondProposal: defineAction({
    description: "对 Muse 的待确认调整建议表态：accept=true 才真正改写后续组并逐项记录改动；accept=false 则忽略不改。",
    request: z.object({ setId: z.number(), accept: z.boolean() }),
    response: z.object({ proposalStatus: z.string(), appliedNote: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.id, args.setId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这一组记录。");
      const proposal = parseProposal(row.proposalJson);
      if (!proposal || row.proposalStatus !== "pending") {
        return { proposalStatus: row.proposalStatus ?? "none", appliedNote: "这条建议已经处理过了。" };
      }

      if (!args.accept) {
        await db
          .update(schema.setLogs)
          .set({ proposalStatus: "dismissed", updatedAt: new Date() })
          .where(eq(schema.setLogs.id, args.setId));
        ctx.invalidateQueries();
        return { proposalStatus: "dismissed", appliedNote: "已忽略这条建议，后续组保持原计划不变。" };
      }

      const allSets = await loadSessionSets(db, row.sessionId);
      const sameExercise = allSets.filter((s) => s.exerciseIdx === row.exerciseIdx);
      const remaining = sameExercise.filter(
        (s) => s.setIdx > row.setIdx && !s.done && !s.skipped,
      );

      // 接受前先快照受影响组，撤销时按快照恢复（含被跳过组的 skipped 状态）
      const snapshot = remaining.map((s) => ({
        id: s.id,
        exerciseName: s.exerciseName,
        targetWeightKg: s.targetWeightKg,
        targetReps: s.targetReps,
        targetRestSeconds: s.targetRestSeconds,
        skipped: s.skipped ? 1 : 0,
      }));
      const changes: string[] = [];
      const addedIds: number[] = [];
      const alertIds: string[] = [];
      const now = new Date();

      let pool = [...remaining];
      if (proposal.replaceWith) {
        let renamed = 0;
        for (const s of pool) {
          if (s.exerciseName !== proposal.replaceWith) {
            await db
              .update(schema.setLogs)
              .set({ exerciseName: proposal.replaceWith, updatedAt: now })
              .where(eq(schema.setLogs.id, s.id));
            renamed += 1;
          }
        }
        if (renamed > 0) changes.push(`剩余 ${renamed} 组动作改为「${proposal.replaceWith}」`);
      }
      if (proposal.setsDelta < 0 && pool.length > 0) {
        const n = Math.min(-proposal.setsDelta, pool.length);
        const toSkip = pool.slice(pool.length - n);
        for (const s of toSkip) {
          await db
            .update(schema.setLogs)
            .set({ skipped: 1, skippedBy: "ai", updatedAt: now })
            .where(eq(schema.setLogs.id, s.id));
          changes.push(`跳过第 ${s.setIdx + 1} 组`);
        }
        pool = pool.slice(0, pool.length - n);
      }
      // 逐组逐项比对，只改真正不同的值，appliedNote 与实际改动严格一致
      for (const s of pool) {
        const parts: string[] = [];
        const patch: Partial<typeof schema.setLogs.$inferInsert> = { updatedAt: now };
        if (proposal.nextWeightKg != null && proposal.nextWeightKg !== s.targetWeightKg) {
          parts.push(`重量 ${fmtWeight(s.targetWeightKg)} → ${proposal.nextWeightKg}kg`);
          patch.targetWeightKg = proposal.nextWeightKg;
        }
        if (proposal.nextReps != null && proposal.nextReps !== s.targetReps) {
          parts.push(`次数 ${s.targetReps} → ${proposal.nextReps}`);
          patch.targetReps = proposal.nextReps;
        }
        if (proposal.restSeconds != null && proposal.restSeconds !== s.targetRestSeconds) {
          parts.push(`休息 ${s.targetRestSeconds} 秒 → ${proposal.restSeconds} 秒`);
          patch.targetRestSeconds = proposal.restSeconds;
        }
        if (parts.length) {
          await db.update(schema.setLogs).set(patch).where(eq(schema.setLogs.id, s.id));
          changes.push(`第 ${s.setIdx + 1} 组${parts.join("、")}`);
        }
      }
      if (proposal.setsDelta > 0) {
        const last = pool[pool.length - 1] ?? sameExercise[sameExercise.length - 1];
        const baseIdx = Math.max(...sameExercise.map((s) => s.setIdx));
        for (let i = 0; i < proposal.setsDelta; i++) {
          const inserted = await db
            .insert(schema.setLogs)
            .values({
              sessionId: row.sessionId,
              exerciseName: proposal.replaceWith ?? row.exerciseName,
              exerciseIdx: row.exerciseIdx,
              setIdx: baseIdx + 1 + i,
              targetWeightKg: proposal.nextWeightKg ?? last?.targetWeightKg ?? null,
              targetReps: proposal.nextReps ?? last?.targetReps ?? row.targetReps,
              targetRestSeconds: proposal.restSeconds ?? last?.targetRestSeconds ?? row.targetRestSeconds,
              origWeightKg: proposal.nextWeightKg ?? last?.targetWeightKg ?? null,
              origReps: proposal.nextReps ?? last?.targetReps ?? row.targetReps,
              origRestSeconds: proposal.restSeconds ?? last?.targetRestSeconds ?? row.targetRestSeconds,
            })
            .returning({ id: schema.setLogs.id });
          const nid = inserted[0]?.id;
          if (nid != null) addedIds.push(nid);
        }
        if (addedIds.length) changes.push(`新增 ${addedIds.length} 组`);
      }

      // 跨动作「停止」提醒：落到后续同类动作上，标红并要求用户确认后才继续
      if (proposal.stopWarning) {
        const sessionRow = await loadSessionRow(db, row.sessionId);
        if (sessionRow) {
          const alerts = parseAlerts(sessionRow.alertJson);
          const affected = new Map<number, string>();
          for (const s of allSets) {
            if (
              s.exerciseIdx > row.exerciseIdx &&
              proposal.stopWarning.affectedExercises.includes(s.exerciseName)
            ) {
              affected.set(s.exerciseIdx, s.exerciseName);
            }
          }
          for (const [exerciseIdx, exerciseName] of affected) {
            const id = `${row.id}-${exerciseIdx}`;
            if (!alerts.some((a) => a.id === id)) {
              alerts.push({
                id,
                exerciseIdx,
                exerciseName,
                message: proposal.stopWarning.message,
                acknowledged: false,
              });
              alertIds.push(id);
              changes.push(`后续动作「${exerciseName}」已标红提醒：${proposal.stopWarning.message}（开始前需你确认）`);
            }
          }
          if (alertIds.length) {
            await db
              .update(schema.sessions)
              .set({ alertJson: JSON.stringify(alerts) })
              .where(eq(schema.sessions.id, row.sessionId));
          }
        }
      }

      const appliedNote = changes.length
        ? `已应用：${changes.join("；")}`
        : "已接受建议，但后续组目标没有实际变化。";
      await db
        .update(schema.setLogs)
        .set({
          proposalStatus: "accepted",
          appliedNote,
          undoJson: JSON.stringify({ sets: snapshot, addedIds, alertIds }),
          updatedAt: new Date(),
        })
        .where(eq(schema.setLogs.id, args.setId));
      ctx.invalidateQueries();
      return { proposalStatus: "accepted", appliedNote };
    },
  }),

  undoProposal: defineAction({
    description: "撤销一条已接受的调整：按接受前的快照恢复后续组目标/跳过状态，删除新增组与停止提醒。",
    request: z.object({ setId: z.number() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.id, args.setId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这一组记录。");
      if (row.proposalStatus !== "accepted" || !row.undoJson) {
        throw new Error("这条调整没有可撤销的记录。");
      }
      type UndoData = {
        sets: Array<{
          id: number;
          exerciseName: string;
          targetWeightKg: number | null;
          targetReps: string;
          targetRestSeconds: number;
          skipped: number;
        }>;
        addedIds: number[];
        alertIds: string[];
      };
      let undo: UndoData | null = null;
      try {
        undo = JSON.parse(row.undoJson) as UndoData;
      } catch {
        undo = null;
      }
      if (!undo) throw new Error("撤销数据损坏，无法撤销。");
      const now = new Date();
      for (const s of undo.sets) {
        await db
          .update(schema.setLogs)
          .set({
            exerciseName: s.exerciseName,
            targetWeightKg: s.targetWeightKg,
            targetReps: s.targetReps,
            targetRestSeconds: s.targetRestSeconds,
            skipped: s.skipped,
            skippedBy: s.skipped ? "user" : null,
            updatedAt: now,
          })
          .where(eq(schema.setLogs.id, s.id));
      }
      for (const id of undo.addedIds) {
        await db.delete(schema.setLogs).where(eq(schema.setLogs.id, id));
      }
      if (undo.alertIds.length) {
        const sessionRow = await loadSessionRow(db, row.sessionId);
        if (sessionRow) {
          const alerts = parseAlerts(sessionRow.alertJson).filter(
            (a) => !undo.alertIds.includes(a.id),
          );
          await db
            .update(schema.sessions)
            .set({ alertJson: JSON.stringify(alerts) })
            .where(eq(schema.sessions.id, row.sessionId));
        }
      }
      await db
        .update(schema.setLogs)
        .set({ proposalStatus: "undone", appliedNote: null, undoJson: null, updatedAt: now })
        .where(eq(schema.setLogs.id, args.setId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  acknowledgeAlert: defineAction({
    description: "确认某条跨动作停止提醒（用户看过并决定是否继续该动作后确认）。",
    request: z.object({ sessionId: z.number(), alertId: z.string() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const sessionRow = await loadSessionRow(db, args.sessionId);
      if (!sessionRow) throw new Error("找不到这次训练。");
      const alerts = parseAlerts(sessionRow.alertJson).map((a) =>
        a.id === args.alertId ? { ...a, acknowledged: true } : a,
      );
      await db
        .update(schema.sessions)
        .set({ alertJson: JSON.stringify(alerts) })
        .where(eq(schema.sessions.id, args.sessionId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  finishSession: defineAction({
    description: "结束本次训练：结算总时长/训练量，校验调整记录后生成摘要、复盘与下次训练建议。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.id, args.sessionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这次训练。");
      await db
        .update(schema.sessions)
        .set({ status: "completed", endedAt: row.endedAt ?? new Date() })
        .where(eq(schema.sessions.id, args.sessionId));

      // 生成总结前先校验调整记录：appliedNote 必须与已接受的改动对应
      await verifyAppliedNotes(db, args.sessionId);
      const sets = await loadSessionSets(db, args.sessionId);
      const provisional = toSessionOut({ ...row, status: "completed", endedAt: row.endedAt ?? new Date() });
      // 跨课历史事实（本次会话已置 completed，事实包含本次）：只给数据，
      // 减载与否、如何调整下次训练由模型在 ATI 框架下综合判断。
      const historyFacts = await historyFactsText(db);
      let review: string | null = null;
      let nextSuggestion: string | null = null;
      try {
        const summaryDraft = buildSummaryMd(provisional, sets);
        const advice = await ctx.inference.complete(atiReviewPrompt(summaryDraft, historyFacts, "今天"), {
          system: ATI_REVIEW_SYSTEM,
          schema: adviceOut,
          timeout_secs: 90,
        });
        review = advice.review;
        nextSuggestion = advice.nextSuggestion;
      } catch {
        review = null;
        nextSuggestion = null;
      }
      const finalSession = toSessionOut({
        ...row,
        status: "completed",
        endedAt: row.endedAt ?? new Date(),
        review,
        nextSuggestion,
      });
      const summaryMd = buildSummaryMd(finalSession, sets);
      await db
        .update(schema.sessions)
        .set({ review, nextSuggestion, summaryMd })
        .where(eq(schema.sessions.id, args.sessionId));
      // 按用户要求：训练结束自动把摘要上传到 Drive「健身日志」文件夹。
      const freshRows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.id, args.sessionId))
        .limit(1);
      if (freshRows[0]) {
        try {
          await startDriveUpload(ctx, db, freshRows[0]);
        } catch {
          await db
            .update(schema.sessions)
            .set({ driveStatus: "failed" })
            .where(eq(schema.sessions.id, args.sessionId));
        }
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  regenerateAdvice: defineAction({
    description: "为一次已结束训练重新生成复盘与下次训练建议。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.id, args.sessionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这次训练。");
      await verifyAppliedNotes(db, args.sessionId);
      const sets = await loadSessionSets(db, args.sessionId);
      const base = toSessionOut({ ...row, review: null, nextSuggestion: null });
      const draft = buildSummaryMd(base, sets);
      const historyFacts = await historyFactsText(db);
      const advice = await ctx.inference.complete(atiReviewPrompt(draft, historyFacts, "这次"), {
        system: ATI_REVIEW_SYSTEM,
        schema: adviceOut,
        timeout_secs: 90,
      });
      const nextSuggestion = advice.nextSuggestion;
      const finalSession = toSessionOut({ ...row, review: advice.review, nextSuggestion });
      await db
        .update(schema.sessions)
        .set({
          review: advice.review,
          nextSuggestion,
          summaryMd: buildSummaryMd(finalSession, sets),
        })
        .where(eq(schema.sessions.id, args.sessionId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  listSessions: defineAction({
    description: "列出历史训练（含进行中），带每场完成组数与训练量。",
    request: z.object({ limit: z.number().int().positive().max(100).default(50) }),
    response: z.object({
      sessions: z.array(
        sessionOut.extend({
          doneSets: z.number(),
          totalSets: z.number(),
          volumeKg: z.number(),
          durationMin: z.number().nullable(),
        }),
      ),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.sessions)
        .orderBy(desc(schema.sessions.date), desc(schema.sessions.id))
        .limit(args.limit);
      const out = [];
      for (const row of rows) {
        const sets = await loadSessionSets(db, row.id);
        const s = toSessionOut(row);
        out.push({
          ...s,
          doneSets: sets.filter((x) => x.done && !x.warmup).length,
          totalSets: sets.filter((x) => !x.warmup).length,
          volumeKg: Math.round(sets.reduce((acc, x) => acc + (x.warmup ? 0 : setVolume(x)), 0)),
          durationMin:
            s.startedAt && s.endedAt
              ? Math.max(1, Math.round((new Date(s.endedAt).getTime() - new Date(s.startedAt).getTime()) / 60000))
              : null,
        });
      }
      return { sessions: out };
    },
  }),

  getSessionDetail: defineAction({
    description: "读取一次训练的完整详情：会话、逐组记录与当日计划（用于计划 vs 实际对照）。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({
      session: sessionOut,
      sets: z.array(setLogOut),
      planExercises: z.array(exerciseSchema),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.id, args.sessionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这次训练。");
      const sets = await loadSessionSets(db, args.sessionId);
      let planExercises: Exercise[] = [];
      if (row.planId != null) {
        const planRows = await db
          .select()
          .from(schema.plans)
          .where(eq(schema.plans.id, row.planId))
          .limit(1);
        if (planRows[0]) planExercises = parseExercises(planRows[0].exercisesJson);
      }
      return { session: toSessionOut(row), sets, planExercises };
    },
  }),

  deleteSession: defineAction({
    description: "删除一次训练及其全部逐组记录。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db.delete(schema.setLogs).where(eq(schema.setLogs.sessionId, args.sessionId));
      await db.delete(schema.sessions).where(eq(schema.sessions.id, args.sessionId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  getStats: defineAction({
    description: "汇总统计：总场次/组数、平均休息（仅力量组）、RIR 余量分布（含分母）、近 8 周训练量、各动作重量进步。",
    request: z.object({}),
    response: z.object({
      completedSessions: z.number(),
      totalDoneSets: z.number(),
      totalVolumeKg: z.number(),
      avgRestSeconds: z.number().nullable(),
      restSamples: z.number(),
      feedbackSets: z.number(),
      totalStrengthSets: z.number(),
      rirCounts: z.array(z.object({ label: z.string(), count: z.number() })),
      weekly: z.array(
        z.object({ weekStart: z.string(), volumeKg: z.number(), sessions: z.number(), sets: z.number() }),
      ),
      exerciseProgress: z.array(
        z.object({
          name: z.string(),
          points: z.array(
            z.object({ date: z.string(), maxWeightKg: z.number(), est1RmKg: z.number() }),
          ),
        }),
      ),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      const sessionRows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.status, "completed"))
        .orderBy(asc(schema.sessions.date));
      let totalDoneSets = 0;
      let totalVolumeKg = 0;
      let totalStrengthSets = 0;
      let feedbackSets = 0;
      const rests: number[] = [];
      // RIR 分布按统一标尺五档分桶：3+ / 2 / 1 / 0 / 0 且变形
      //（rir=0 且动作变形单列第五档；旧数据 4 并入 3+）
      const rirBuckets = { b3plus: 0, b2: 0, b1: 0, b0: 0, b0deform: 0 };
      const weekMap = new Map<string, { volumeKg: number; sessions: number; sets: number }>();
      const progressMap = new Map<string, Map<string, { maxWeightKg: number; est1RmKg: number }>>();

      const weekStartOf = (dateStr: string): string => {
        const d = new Date(`${dateStr}T00:00:00`);
        const dow = (d.getDay() + 6) % 7; // 周一为 0
        d.setDate(d.getDate() - dow);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        return `${y}-${m}-${day}`;
      };

      for (const row of sessionRows) {
        const sets = await loadSessionSets(db, row.id);
        const wk = weekStartOf(row.date);
        const wEntry = weekMap.get(wk) ?? { volumeKg: 0, sessions: 0, sets: 0 };
        wEntry.sessions += 1;
        for (const s of sets) {
          // 热身组不计入完成组数/训练量/进步曲线（与计划工作组口径一致）
          if (s.done && !s.warmup) {
            totalDoneSets += 1;
            wEntry.sets += 1;
            const vol = setVolume(s);
            wEntry.volumeKg += vol;
            totalVolumeKg += vol;
            // 力量组口径与平均休息一致：目标休息 > 0（有氧组为 0，不计）
            if (s.targetRestSeconds > 0) totalStrengthSets += 1;
            const w = s.actualWeightKg ?? s.targetWeightKg;
            if (w != null) {
              const reps = repsNumber(s.actualReps ?? s.targetReps);
              // 估算 1RM（Epley）：w × (1 + reps/30)，仅对有次数的负重组
              const e1rm = reps > 0 ? Math.round(w * (1 + reps / 30) * 10) / 10 : w;
              const perDate =
                progressMap.get(s.exerciseName) ??
                new Map<string, { maxWeightKg: number; est1RmKg: number }>();
              const cur = perDate.get(row.date) ?? { maxWeightKg: 0, est1RmKg: 0 };
              cur.maxWeightKg = Math.max(cur.maxWeightKg, w);
              cur.est1RmKg = Math.max(cur.est1RmKg, e1rm);
              perDate.set(row.date, cur);
              progressMap.set(s.exerciseName, perDate);
            }
          }
          // 平均休息只计力量组（目标休息 > 0），有氧组的 0 秒不进分母
          if (s.restSeconds != null && s.targetRestSeconds > 0) rests.push(s.restSeconds);
          if (s.rir != null && !s.warmup) {
            const idx = Math.min(3, Math.max(0, Math.round(s.rir)));
            if (idx >= 3) rirBuckets.b3plus += 1;
            else if (idx === 2) rirBuckets.b2 += 1;
            else if (idx === 1) rirBuckets.b1 += 1;
            else if (s.deform === "变形" || s.deform === "变形且无法纠正") rirBuckets.b0deform += 1;
            else rirBuckets.b0 += 1;
            feedbackSets += 1;
          }
        }
        weekMap.set(wk, wEntry);
      }

      const weekly = [...weekMap.entries()]
        .map(([weekStart, v]) => ({ weekStart, volumeKg: Math.round(v.volumeKg), sessions: v.sessions, sets: v.sets }))
        .sort((a, b) => a.weekStart.localeCompare(b.weekStart))
        .slice(-8);

      const exerciseProgress = [...progressMap.entries()]
        .map(([name, perDate]) => ({
          name,
          points: [...perDate.entries()]
            .map(([date, v]) => ({ date, maxWeightKg: v.maxWeightKg, est1RmKg: v.est1RmKg }))
            .sort((a, b) => a.date.localeCompare(b.date)),
        }))
        .filter((e) => e.points.length > 0)
        .sort((a, b) => b.points.length - a.points.length);

      return {
        completedSessions: sessionRows.length,
        totalDoneSets,
        totalVolumeKg: Math.round(totalVolumeKg),
        avgRestSeconds: rests.length ? Math.round(rests.reduce((a, b) => a + b, 0) / rests.length) : null,
        restSamples: rests.length,
        feedbackSets,
        totalStrengthSets,
        rirCounts: [
          { label: "3+（还能做 3 个以上）", count: rirBuckets.b3plus },
          { label: "2（还能做 2 个）", count: rirBuckets.b2 },
          { label: "1（还能做 1 个）", count: rirBuckets.b1 },
          { label: "0（1 个也做不了）", count: rirBuckets.b0 },
          { label: "0 且变形（技术力竭）", count: rirBuckets.b0deform },
        ],
        weekly,
        exerciseProgress,
      };
    },
  }),

  uploadToDrive: defineAction({
    description: "把某次训练的摘要上传到 Google Drive「健身日志」文件夹，文件名含日期（重复上传带时间后缀）。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({ started: z.boolean(), message: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.id, args.sessionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这次训练。");
      const started = await startDriveUpload(ctx, db, row);
      ctx.invalidateQueries();
      return started
        ? { started: true, message: "已开始上传到 Drive「健身日志」文件夹，完成后这里会显示链接。" }
        : { started: false, message: "上传任务未能启动，请稍后重试。" };
    },
  }),

  recordDriveUpload: defineAction({
    description: "回写 Drive 上传结果（由上传任务调用）。",
    request: z.object({
      sessionId: z.number(),
      ok: z.boolean(),
      fileName: z.string().nullable(),
      link: z.string().nullable(),
      error: z.string().nullable(),
    }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      await db
        .update(schema.sessions)
        .set({
          driveStatus: args.ok ? "uploaded" : "failed",
          driveFileName: args.fileName,
          driveLink: args.link,
        })
        .where(eq(schema.sessions.id, args.sessionId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  getPrinciples: defineAction({
    description: "返回「训练原则」参考页内容：ATI 决策体系说明（统一决策循环、14 个裁决动作、智能休息基础表、恢复分层、准备度权重、安全边界）、训练原则与 RIR 统一标尺（与服务端决策协调器同一套常量，口径一致）。",
    request: z.object({}),
    response: z.object({
      principles: z.array(
        z.object({ name: z.string(), summary: z.string(), detail: z.string() }),
      ),
      rirScale: z.array(
        z.object({ key: z.string(), rirLabel: z.string(), meaning: z.string(), action: z.string() }),
      ),
      ati: z.object({
        loop: z.array(z.string()),
        actions: z.array(z.object({ id: z.string(), name: z.string(), detail: z.string() })),
        restTable: z.array(z.object({ category: z.string(), min: z.number(), max: z.number() })),
        recoveryLevels: z.array(
          z.object({ level: z.string(), name: z.string(), detail: z.string() }),
        ),
        readiness: z.array(z.object({ name: z.string(), weight: z.number() })),
        safetyBoundaries: z.array(z.string()),
      }),
      v2Layers: z.object({
        note: z.string(),
        equipmentSnapshotId: z.string(),
        libraryCounts: z.object({
          total: z.number(),
          exercises: z.number(),
          cardio: z.number(),
          active: z.number(),
          conditional: z.number(),
          provisional: z.number(),
        }),
        evidenceGrades: z.array(
          z.object({ grade: z.string(), label: z.string(), note: z.string() }),
        ),
        antiAnchoring: z.array(z.string()),
      }),
    }),
    async handler() {
      return {
        principles: PRINCIPLES.map((p) => ({ name: p.name, summary: p.summary, detail: p.detail })),
        rirScale: RIR_SCALE.map((s) => ({ ...s })),
        ati: {
          loop: [
            "观察状态：读取本组实际表现与反馈",
            "构建上下文：目标、计划、实际、恢复、历史组装成统一结构，缺失项标「未记录」",
            "检索证据：从 44 条原书证据账本里按话题选出相关条目",
            "AI 综合判断：从 14 个可组合动作中形成结构化裁决（带评估、置信度与证据引用）",
            "安全校验：确定性边界检查，违规裁决被拒绝并要求重新生成",
            "执行决策：通过校验的裁决落为待确认建议，你接受后才改动后续组",
            "记录结果：裁决、证据与实际改动逐项存档，刷新不丢失",
            "更新状态：本次记录进入历史，成为下一次决策的上下文",
          ],
          actions: ATI_ACTIONS.map((a) => ({ id: a.id, name: a.name, detail: a.detail })),
          restTable: REST_TABLE.map((r) => ({ category: r.category, min: r.min, max: r.max })),
          recoveryLevels: RECOVERY_LEVELS.map((l) => ({ level: l.level, name: l.name, detail: l.detail })),
          readiness: READINESS_DIMENSIONS.map((d) => ({ name: d.name, weight: Math.round(d.weight * 100) })),
          safetyBoundaries: [...SAFETY_BOUNDARIES],
        },
        v2Layers: {
          note: "v2.0 三层词表彻底分开：14 个决策动词是系统裁决类型、不是动作清单；Exercise Library 是有出处登记的动作条目；Equipment Snapshot 是已确认器械能力。三者不得混用。",
          equipmentSnapshotId: EQUIPMENT_SNAPSHOT.id,
          libraryCounts: {
            total: LIBRARY_COUNTS.total,
            exercises: LIBRARY_COUNTS.exercises,
            cardio: LIBRARY_COUNTS.cardio,
            active: LIBRARY_COUNTS.active,
            conditional: LIBRARY_COUNTS.conditional,
            provisional: LIBRARY_COUNTS.provisional,
          },
          evidenceGrades: EVIDENCE_GRADES,
          antiAnchoring: [
            "用户历史只是带权重证据：单次提及、单次训练记录永远不能自动成为默认首选动作",
            "每次动作选择在 evidence_manifest 记录七问：为什么选它、书/文献如何评价、同模式替代候选、为什么没选替代、时间效率与疲劳代价、有无相反结论、用户历史实际起到的作用",
            "唯一依据是「用户提过一次」时标记 EVIDENCE_INSUFFICIENT 并重新检索替代动作，不得开出计划",
            "连续多日同一肌群总以同一动作起手时触发 ROTATION_REVIEW；计划生成前执行历史锚定审计",
            "设备清单决定能不能做，科学证据决定值不值得做，目标与现实约束决定这次做什么",
          ],
        },
      };
    },
  }),

  getEvidence: defineAction({
    description:
      "返回原书证据层（muse-fitness-evidence-skills-v1）：44 条账本证据（claim-ledger.json）及 ATI 主题/旧规则/原则/趋势指标/下次建议/营养提示/计划审查的证据映射与 Skills 路由表。纯只读：证据是 ATI 决策循环的检索来源与解释层，不单独构成裁决，不改任何记录。",
    request: z.object({}),
    response: z.object({
      sourceStatus: z.string(),
      verificationNote: z.string(),
      claims: z.array(
        z.object({
          id: z.string(),
          bookCode: z.string(),
          book: z.string(),
          location: z.string(),
          fact: z.string(),
          guardrail: z.string(),
          scope: z.string(),
        }),
      ),
      atiTopics: z.record(z.string(), z.object({ label: z.string(), ids: z.array(z.string()) })),
      ruleEvidence: z.record(z.string(), z.array(z.string())),
      principleEvidence: z.record(z.string(), z.array(z.string())),
      metricEvidence: z.record(
        z.string(),
        z.object({ definition: z.string(), evidenceIds: z.array(z.string()) }),
      ),
      nextSuggestionEvidence: z.array(z.string()),
      nutritionNote: z.object({ copy: z.string(), evidenceIds: z.array(z.string()) }),
      planReviewEvidence: z.array(z.string()),
      skillRoutes: z.array(z.object({ skill: z.string(), where: z.string() })),
    }),
    async handler() {
      return {
        sourceStatus: EVIDENCE_SOURCE_STATUS,
        verificationNote: EVIDENCE_VERIFICATION_NOTE,
        claims: EVIDENCE_CLAIMS.map((c) => ({ ...c })),
        atiTopics: ATI_TOPIC_EVIDENCE,
        ruleEvidence: RULE_EVIDENCE,
        principleEvidence: PRINCIPLE_EVIDENCE,
        metricEvidence: METRIC_EVIDENCE,
        nextSuggestionEvidence: NEXT_SUGGESTION_EVIDENCE,
        nutritionNote: NUTRITION_NOTE,
        planReviewEvidence: PLAN_REVIEW_EVIDENCE,
        skillRoutes: SKILL_ROUTES.map((r) => ({ ...r })),
      };
    },
  }),

  markLegacySets: defineAction({
    description: "把一次进行中训练里的旧版记录组（已完成但缺 RIR 等新版证据）标记为原样保留：不改任何数值，之后不参与跨组连续失败判定。",
    request: z.object({ sessionId: z.number() }),
    response: z.object({ ok: z.literal(true), marked: z.number() }),
    async handler(ctx, args): Promise<{ ok: true; marked: number }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.setLogs)
        .where(eq(schema.setLogs.sessionId, args.sessionId));
      let marked = 0;
      for (const r of rows) {
        const candidate =
          r.done === 1 && r.rir == null && r.deform == null && r.joint == null && r.difficulty != null;
        if (candidate && r.legacy !== 1) {
          await db
            .update(schema.setLogs)
            .set({ legacy: 1, updatedAt: new Date() })
            .where(eq(schema.setLogs.id, r.id));
          marked += 1;
        }
      }
      ctx.invalidateQueries();
      return { ok: true, marked };
    },
  }),

  seedInitialData: defineAction({
    description: "一次性写入用户已给定的真实数据：2026-11-11 已完成恢复训练与 2026-11-13 摸底计划（已存在则跳过；另把深蹲备注与组表递进口径对齐，只改备注文字不动重量）。",
    request: z.object({}),
    response: z.object({ seededPlan: z.boolean(), seededSession: z.boolean() }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      let seededPlan = false;
      let seededSession = false;

      const squatNoteNew =
        "递进摸底：60kg×5 热身 → 80kg×3 → 90kg×3 测试 → 85kg×3 收尾；90kg 若只能做 3 次，后续就按 80–85kg 做。务必用深蹲架保护杆或有人保护，别独自冲极限。";
      const planDate = "2026-11-13";
      const existingPlanRows = await db
        .select()
        .from(schema.plans)
        .where(eq(schema.plans.date, planDate))
        .limit(1);
      const existingPlanRow = existingPlanRows[0];
      if (!existingPlanRow) {
        const exercises: Exercise[] = [
          {
            name: "深蹲（摸底）",
            category: "strength",
            note: squatNoteNew,
            sets: [
              { weightKg: 60, reps: "5", restSeconds: 120, warmup: false },
              { weightKg: 80, reps: "3", restSeconds: 180, warmup: false },
              { weightKg: 90, reps: "3", restSeconds: 240, warmup: false },
              { weightKg: 85, reps: "3", restSeconds: 240, warmup: false },
            ],
          },
          {
            name: "罗马尼亚硬拉",
            category: "strength",
            note: "先用 60kg×8 找动作、感受腘绳肌拉伸，再视情况加重测试。第 3 组重量练时按状态定。",
            sets: [
              { weightKg: 60, reps: "8", restSeconds: 120, warmup: false },
              { weightKg: 60, reps: "8", restSeconds: 120, warmup: false },
              { weightKg: null, reps: "8", restSeconds: 180, warmup: false },
            ],
          },
          {
            name: "室内跑步机",
            category: "cardio",
            note: "11 月 13 日克拉玛依小雨、道路结冰预警，户外跑改室内。20 分钟能说话的速度，记配速和喘的程度，不测 5 公里。",
            sets: [{ weightKg: null, reps: "20分钟", restSeconds: 0, warmup: false }],
          },
        ];
        await db.insert(schema.plans).values({
          date: planDate,
          title: "下肢摸底 + 室内有氧",
          exercisesJson: JSON.stringify(exercises),
        });
        seededPlan = true;
      } else {
        // 备注与组表对齐：旧备注写「从 90kg 起测」但组表是 60/80/90/85 递进，
        // 只把备注改成递进摸底写法，组表重量一个数都不动。
        const exercises = parseExercises(existingPlanRow.exercisesJson);
        const squat = exercises[0];
        if (squat && squat.note.includes("从 90kg 起测")) {
          squat.note = squatNoteNew;
          await db
            .update(schema.plans)
            .set({ exercisesJson: JSON.stringify(exercises), updatedAt: new Date() })
            .where(eq(schema.plans.id, existingPlanRow.id));
        }
      }

      const histDate = "2026-11-11";
      const existingSession = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.date, histDate))
        .limit(1);
      if (!existingSession[0]) {
        const inserted = await db
          .insert(schema.sessions)
          .values({
            planId: null,
            date: histDate,
            title: "恢复训练 · 胸 + 激活",
            status: "completed",
            startedAt: null,
            endedAt: null,
          })
          .returning({ id: schema.sessions.id });
        const sid = inserted[0]?.id;
        if (sid != null) {
          const seedSets: Array<{
            name: string; ei: number; si: number;
            tw: number | null; tr: string; rest: number;
            aw: number | null; ar: string; note: string | null;
          }> = [
            { name: "杠铃卧推", ei: 0, si: 0, tw: 50, tr: "8", rest: 120, aw: 50, ar: "8", note: null },
            { name: "杠铃卧推", ei: 0, si: 1, tw: 70, tr: "8", rest: 180, aw: 70, ar: "8", note: null },
            { name: "杠铃卧推", ei: 0, si: 2, tw: 80, tr: "1", rest: 240, aw: 80, ar: "1", note: "第 2 个下到一半不敢再下，稳定性与信心还没回来" },
            { name: "上斜哑铃卧推", ei: 1, si: 0, tw: 25, tr: "10", rest: 120, aw: 25, ar: "10", note: null },
            { name: "自重引体向上", ei: 2, si: 0, tw: null, tr: "12", rest: 120, aw: null, ar: "12", note: null },
          ];
          for (const s of seedSets) {
            await db.insert(schema.setLogs).values({
              sessionId: sid,
              exerciseName: s.name,
              exerciseIdx: s.ei,
              setIdx: s.si,
              targetWeightKg: s.tw,
              targetReps: s.tr,
              targetRestSeconds: s.rest,
              origWeightKg: s.tw,
              origReps: s.tr,
              origRestSeconds: s.rest,
              actualWeightKg: s.aw,
              actualReps: s.ar,
              done: 1,
              note: s.note,
            });
          }
          const sets = await loadSessionSets(db, sid);
          const sessRows = await db
            .select()
            .from(schema.sessions)
            .where(eq(schema.sessions.id, sid))
            .limit(1);
          if (sessRows[0]) {
            await db
              .update(schema.sessions)
              .set({ summaryMd: buildSummaryMd(toSessionOut(sessRows[0]), sets) })
              .where(eq(schema.sessions.id, sid));
          }
          seededSession = true;
        }
      }
      ctx.invalidateQueries();
      return { seededPlan, seededSession };
    },
  }),
  getPlanner: defineAction({
    description:
      "读取 ATI Planner 当前状态：成人处方目标快照、约束快照、当前生效的计划版本（周安排、动作处方、直接/间接组统计、时间预算、证据清单）、待确认的提案（如有）与最近的 Planner 事件（训练反馈对规划的反向输入），以及 v2.0 的器械快照 ATI-EQ-1.1（已确认器械与未确认项）、Exercise Library 状态统计（ACTIVE/CONDITIONAL/PROVISIONAL）与 E1–E6 证据分级说明。首次调用时把现有分化周登记为 v1 基线（只登记、不改动任何计划）。",
    request: z.object({}),
    response: z.object({
      goals: z.record(z.string(), z.string()),
      constraints: z.record(z.string(), z.string()),
      equipmentSnapshot: z.object({
        id: z.string(),
        version: z.string(),
        confirmedAt: z.string(),
        confirmationSource: z.string(),
        items: z.array(z.object({ name: z.string(), detail: z.string() })),
        unconfirmed: z.array(z.string()),
        gateRule: z.string(),
      }),
      librarySummary: z.object({
        total: z.number(),
        exercises: z.number(),
        cardio: z.number(),
        active: z.number(),
        conditional: z.number(),
        provisional: z.number(),
        note: z.string(),
        nonActive: z.array(
          z.object({ id: z.string(), name: z.string(), status: z.string(), reason: z.string() }),
        ),
      }),
      // 完整动作库条目（kb_v2.0.md 第五节 §5 全部字段，供页面逐条核对）
      library: z.array(
        z.object({
          id: z.string(),
          name: z.string(),
          variationId: z.string(),
          aliases: z.array(z.string()),
          patterns: z.array(z.string()),
          primary: z.array(z.string()),
          secondary: z.array(z.string()),
          stabilizers: z.array(z.string()),
          equipment: z.array(z.string()),
          equipmentSnapshotMatch: z.string(),
          techniqueCues: z.string(),
          commonErrors: z.array(z.string()),
          skill: z.string(),
          populationScope: z.string(),
          stop: z.string(),
          timeSetupCost: z.string(),
          fatigueCost: z.string(),
          progressionOptions: z.array(z.string()),
          replacements: z.array(z.string()),
          source: z.string(),
          appraisal: z.string(),
          sourceStatus: z.string(),
          kind: z.string(),
          lastReviewedAt: z.string(),
          version: z.string(),
        }),
      ),
      evidenceGrades: z.array(
        z.object({ grade: z.string(), label: z.string(), note: z.string() }),
      ),
      current: planVersionOut.nullable(),
      proposal: planVersionOut.nullable(),
      events: z.array(
        z.object({
          id: z.number(),
          kind: z.string(),
          note: z.string(),
          createdAt: z.string(),
          planVersionId: z.number().nullable(),
        }),
      ),
      fractionalNote: z.string(),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      await ensurePlannerBaseline(db);
      const rows = await db
        .select()
        .from(schema.planVersions)
        .orderBy(desc(schema.planVersions.version));
      const current = rows.find((r) => r.status === "current") ?? null;
      const proposal = rows.find((r) => r.status === "proposed") ?? null;
      const eventRows = await db
        .select()
        .from(schema.plannerEvents)
        .orderBy(desc(schema.plannerEvents.id))
        .limit(12);
      const currentOut = current ? toPlanVersionOut(current) : null;
      return {
        goals: currentOut?.goalSnapshot ?? { ...PLANNER_GOALS },
        // 器械口径以 v2.0 快照 ATI-EQ-1.1 为准：旧版本行里存的笼统表述
        // （「学校健身房：杠铃、哑铃…」）是当时的历史快照、不回改原行，
        // 展示层统一换成快照口径。
        constraints: {
          ...(currentOut?.constraintsSnapshot ?? PLANNER_CONSTRAINTS),
          equipment: EQUIPMENT_CONSTRAINT_TEXT,
          // 恢复口径同器械口径：旧版本快照里的「睡眠约 6 小时」是更正前的
          // 历史前提，展示层统一换成已更正口径，存量版本行不回改。
          recoveryState: RECOVERY_STATE_TEXT,
          // 休息日口径以当前生效周安排实算：旧快照写死的日期（11-15 休息、
          // 11-21 休息）与已生效的 v4 安排不符，统一按周安排里的 rest 日生成。
          fixedRest: currentOut
            ? (() => {
                const restDays = currentOut.weeklySchedule.filter((d) => d.kind === "rest");
                return restDays.length
                  ? `以当前生效版本 v${currentOut.version} 的周安排为准（${currentOut.weekStart ?? ""} 至 ${currentOut.weekEnd ?? ""}）：休息日为 ${restDays.map((d) => d.date).join("、")}，其余日期均为训练日；该周之外的日期不在本版安排内`
                  : `以当前生效版本 v${currentOut.version} 的周安排为准（${currentOut.weekStart ?? ""} 至 ${currentOut.weekEnd ?? ""}）：本周没有休息日，其余日期不在本版安排内`;
              })()
            : (PLANNER_CONSTRAINTS.fixedRest ?? "休息日以当前生效版本的周安排为准"),
        },
        equipmentSnapshot: {
          id: EQUIPMENT_SNAPSHOT.id,
          version: EQUIPMENT_SNAPSHOT.version,
          confirmedAt: EQUIPMENT_SNAPSHOT.confirmedAt,
          confirmationSource: EQUIPMENT_SNAPSHOT.confirmationSource,
          items: EQUIPMENT_SNAPSHOT.items,
          unconfirmed: EQUIPMENT_SNAPSHOT.unconfirmed,
          gateRule: EQUIPMENT_SNAPSHOT.gateRule,
        },
        librarySummary: {
          total: LIBRARY_COUNTS.total,
          exercises: LIBRARY_COUNTS.exercises,
          cardio: LIBRARY_COUNTS.cardio,
          active: LIBRARY_COUNTS.active,
          conditional: LIBRARY_COUNTS.conditional,
          provisional: LIBRARY_COUNTS.provisional,
          note: "计数口径：唯一动作/变式共 52 个（kb 原始 51 行中条目 21 与 25 是同一台坐姿反手下拉器械，已按 kb_v2.0.1 数据清理说明合并为 EX21，得 50 个；2026-11-15 核心动作更新再新增 EX52 高卷腿与 EX53 绳索卷腹）；其中力量动作/变式 51 个，跑步机有氧 1 条单列、不计入力量动作数。每条条目含 kb_v2.0.md §5 全部字段（variation_id、技术要点、常见错误、适用人群、疲劳成本、独立 source_status 等），展开下方条目可逐条核对。计划只能从 ACTIVE 条目选动作；CONDITIONAL（附件/空间未确认）与 PROVISIONAL（轨迹/身份未核验）只用于检索核验，绝不进入正式计划。动作库可持续扩充，条目数不是动作上限。",
          nonActive: EXERCISE_LIBRARY.filter((e) => e.status !== "ACTIVE").map((e) => ({
            id: e.id,
            name: e.name,
            status: e.status,
            reason: e.appraisal,
          })),
        },
        library: EXERCISE_LIBRARY.map((e) => ({
          id: e.id,
          name: e.name,
          variationId: e.variationId,
          aliases: e.aliases,
          patterns: e.patterns,
          primary: e.primary,
          secondary: e.secondary,
          stabilizers: e.stabilizers,
          equipment: e.equipment,
          equipmentSnapshotMatch: e.equipmentSnapshotMatch,
          techniqueCues: e.techniqueCues,
          commonErrors: e.commonErrors,
          skill: e.skill,
          populationScope: e.populationScope,
          stop: e.stop,
          timeSetupCost: e.timeSetupCost,
          fatigueCost: e.fatigueCost,
          progressionOptions: e.progressionOptions,
          replacements: e.replacements,
          source: e.source,
          appraisal: e.appraisal,
          sourceStatus: e.sourceStatus,
          kind: e.kind,
          lastReviewedAt: e.lastReviewedAt,
          version: e.version,
        })),
        evidenceGrades: EVIDENCE_GRADES,
        current: currentOut,
        proposal: proposal ? toPlanVersionOut(proposal) : null,
        events: eventRows.map((e) => ({
          id: e.id,
          kind: e.kind,
          note: e.note,
          createdAt: e.createdAt.toISOString(),
          planVersionId: e.planVersionId,
        })),
        fractionalNote:
          "直接组 = 1.0、明显间接组暂估 = 0.5、极轻参与 = 0：0.5 来自 Pelland 2026 的 fractional set 研究估算模型，不是生理常数；原始直接组数与折算总量分开列示。推类复合动作对前三角/肱三头只记间接贡献，不把整组重复计入每个参与肌群。",
      };
    },
  }),

  generatePlan: defineAction({
    description:
      "用 ATI Planner v2.0 按成人处方目标、当前实测状态、约束与本次检索的最新证据生成一周计划提案（新 PlanVersion，status=proposed）：动作只能来自 Exercise Library 的 ACTIVE 条目并通过器械快照 ATI-EQ-1.1 硬过滤，每个动作附七问选择记录与反锚定审计（生成前先做锚定预检并把同模式 ACTIVE 替代候选交给模型定案），全部写入 evidence_manifest；单个动作的选择记录被判 EVIDENCE_INSUFFICIENT 或缺项时逐个补救（同模式替代定案/定向重生成/按库条目补正），不让单个选择失败拖垮整份提案，补救过程随提案公开标注；补救后仍失败的单个选择强制降级——优先以同模式 ACTIVE 库条目替定并在补正记录里写明降级原因、替定条目与定案依据，无法替定时剔除该动作并标注剔除原因——任何单个选择失败都不会让整份提案被放弃；仅当剩余问题是结构/安全类校验（时长、容量、日期、库过滤）时才不保存提案、现行计划不受影响。",
    request: z.object({
      weekStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
      requestNote: z.string().max(2000).optional(),
      daysAvailable: z.number().int().min(1).max(7).nullable().optional(),
      minutesPerSession: z.number().int().min(30).max(180).nullable().optional(),
    }),
    response: z.object({
      ok: z.boolean(),
      message: z.string(),
      versionId: z.number().nullable(),
    }),
    async handler(
      ctx,
      args,
    ): Promise<{ ok: boolean; message: string; versionId: number | null }> {
      const db = ctx.db<typeof schema>();
      await ensurePlannerBaseline(db);
      const versionRows = await db
        .select()
        .from(schema.planVersions)
        .orderBy(desc(schema.planVersions.version));
      const current = versionRows.find((r) => r.status === "current") ?? null;
      const currentOut = current ? toPlanVersionOut(current) : null;
      const weekStart = args.weekStart ?? current?.weekStart ?? mondayOf(shanghaiToday());
      const weekDates = Array.from({ length: 7 }, (_, i) => addDaysStr(weekStart, i));
      const weekEnd = weekDates[weekDates.length - 1] ?? weekStart;
      const capMinutes = args.minutesPerSession ?? 95;
      const baselineTotalSets = currentOut?.totalWorkSets ?? 65;

      const goals: Record<string, string> = { ...(currentOut?.goalSnapshot ?? PLANNER_GOALS) };
      const constraints: Record<string, string> = {
        ...(currentOut?.constraintsSnapshot ?? PLANNER_CONSTRAINTS),
        // v2.0：器械口径以快照 ATI-EQ-1.1 为准，覆盖旧版本快照的笼统表述
        equipment: EQUIPMENT_CONSTRAINT_TEXT,
        // 恢复口径同样覆盖：旧快照的「睡眠约 6 小时」是用户更正前的前提，
        // 不得带进新一代提案（平均约 7.5 小时，单晚偏短不降强度）。
        recoveryState: RECOVERY_STATE_TEXT,
      };
      if (args.daysAvailable != null) {
        constraints.availableDays = `本周可训练 ${args.daysAvailable} 天（用户本次指定），其余为休息日`;
      }
      if (args.minutesPerSession != null) {
        constraints.sessionTime = `单次约 ${args.minutesPerSession} 分钟（用户本次指定，硬约束）：含热身、组间休息与切换余量；时间缩短时重排优先级，不机械每动作减一组`;
      }

      // ---- 构建统一上下文（与实时层同源：目标/约束/现行计划/历史/反馈事件） ----
      const planRows = await db.select().from(schema.plans).orderBy(asc(schema.plans.date));
      const currentByDate = new Map<string, { title: string; exercises: Exercise[] }>();
      for (const p of planRows) {
        currentByDate.set(p.date, { title: p.title, exercises: parseExercises(p.exercisesJson) });
      }
      const sessionRowsAll = await db.select({ date: schema.sessions.date }).from(schema.sessions);
      const sessionDates = new Set(sessionRowsAll.map((s) => s.date));
      const weekPlanText = weekDates
        .map((d) => {
          const p = currentByDate.get(d);
          if (!p) return `${d}：无计划${sessionDates.has(d) ? "（已有训练记录）" : ""}`;
          const exText = p.exercises
            .map(
              (e) =>
                `  - ${e.name}：${e.sets.map((s) => `${s.weightKg ?? "未设"}kg×${s.reps}（休${s.restSeconds}秒）`).join("、")}${e.note ? `；备注：${e.note}` : ""}`,
            )
            .join("\n");
          return `${d}「${p.title}」${sessionDates.has(d) ? "（已有训练记录，不得改动）" : ""}\n${exText}`;
        })
        .join("\n");
      const historyFacts = await historyFactsText(db);
      const completedSessions = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.status, "completed"))
        .orderBy(desc(schema.sessions.id))
        .limit(2);
      const nextSuggestionsText = completedSessions
        .filter((s) => s.nextSuggestion)
        .map((s) => `【${s.date} ${s.title} 的下次建议】${(s.nextSuggestion ?? "").slice(0, 1200)}`)
        .join("\n");
      const eventRows = await db
        .select()
        .from(schema.plannerEvents)
        .orderBy(desc(schema.plannerEvents.id))
        .limit(8);
      const eventsText = eventRows.length
        ? eventRows.map((e) => `- ${e.note}`).join("\n")
        : "（暂无 Planner 事件）";
      const evidence = PLANNER_EVIDENCE_IDS.map((id) =>
        EVIDENCE_CLAIMS.find((c) => c.id === id),
      ).filter((c): c is EvidenceClaim => c != null);
      const evidenceText = evidence
        .map((c) => `- ${c.id}｜${c.book}｜${c.location}｜命题：${c.fact}｜边界：${c.guardrail}`)
        .join("\n");

      const system =
        "你是 ATI（Adaptive Training Intelligence）统一训练智能体的规划视角（ATI Planner）。系统只保留一个决策循环：观察目标与状态 → 构建上下文 → 检索证据 → 综合判断 → 生成计划提案 → 用户确认后执行 → 反馈再更新。你不是固定模板生成器：不存在写死的分化模板、容量百分比或动作路径，分化、动作组合、容量与进阶都由你按目标、状态、约束和证据现判。处方配置为成人处方：本系统仅面向成年人，不存在青少年配置与年龄分支，ACSM 2026 等成人证据（适用人群 ≥18 岁）直接适用，固定体重与体形目标保留为优化方向（不承诺结果）。v2.0 三层词表必须分开：14 个决策动词是系统裁决类型、不是动作；动作只能从 Exercise Library 的 ACTIVE 条目中选，且必须通过器械快照 ATI-EQ-1.1 硬过滤——CONDITIONAL（附件/空间未确认）与 PROVISIONAL（轨迹/身份未核验）条目绝不进入计划；用户历史只是带权重证据，单次提及永远不能成为默认首选（尤其背部训练不得因用户最初提过引体向上就总以它起手）。你受确定性安全边界约束：有训练记录的日期不得改动、单次时长与容量爬坡不得越界、不得编造未记录的数据、持续疼痛必须提示专业评估——违反的提案会被服务端拒绝并要求重新生成。";

      const basePrompt = [
        `任务：为 ${weekStart} 至 ${weekEnd} 这一周生成一份训练计划提案（工作假设）。提案只是提案：用户看过差异后确认才生效，所以请大胆按最新证据现判，不必保留现行分化表。`,
        "",
        "== 用户本次说明 ==",
        args.requestNote?.trim() ? args.requestNote.trim() : "（无特别说明，按目标、实测状态与最新证据现判）",
        "",
        "== 目标快照（成人处方） ==",
        JSON.stringify(goals, null, 2),
        "",
        "== 约束快照 ==",
        JSON.stringify(constraints, null, 2),
        "",
        "== 目标周现行计划（差异比较基准；有训练记录的日期不要列入 days） ==",
        weekPlanText,
        "",
        "== 跨课历史事实（只陈述数据） ==",
        historyFacts,
        "",
        "== 最近训练的下次建议（实时层复盘产出，是输入之一，不是命令） ==",
        nextSuggestionsText || "（暂无）",
        "",
        "== Planner 事件（训练中反馈的反向输入） ==",
        eventsText,
        "",
        `== 器械快照 ${EQUIPMENT_SNAPSHOT.id}（硬性前置：计划只能用已确认器械；未确认项不得假设） ==`,
        EQUIPMENT_SNAPSHOT.items.map((i) => `- ${i.name}：${i.detail}`).join("\n"),
        "尚未确认（不得自动假设）：" + EQUIPMENT_SNAPSHOT.unconfirmed.join("；"),
        "",
        "== Exercise Library ACTIVE 条目（计划只能从这里选动作，名字必须与库名或别名一致） ==",
        EXERCISE_LIBRARY.filter((e) => e.status === "ACTIVE")
          .map(
            (e) =>
              `- ${e.id} ${e.name}${e.aliases.length ? `（别名：${e.aliases.join("、")}）` : ""}｜模式 ${e.patterns.join("/")}｜主 ${e.primary.join("、")}｜设备 ${e.equipment.join("、")}｜出处 ${e.source}`,
          )
          .join("\n"),
        "== 不可进入计划的条目（仅供检索核验，选了会被服务端拒绝） ==",
        EXERCISE_LIBRARY.filter((e) => e.status !== "ACTIVE")
          .map((e) => `- ${e.id} ${e.name}：${e.status}`)
          .join("\n"),
        "",
        "== 本次检索的证据（evidenceIds 只能从这里选；状态 SOURCE_LIMITED） ==",
        evidenceText,
        "另有最新研究背景（设计阶段登记，核验状态见证据清单）：ACSM 2026 立场声明（Currier et al.，137 篇综述、3 万余名健康成年人）——每周每肌群至少约 10 组总体有利增肌、训练至瞬时力竭不是必需、2–3 RIR 是实用的努力程度参考、主要肌群每周至少训练两次可作参照；这些是群体层面参考，不是个人必须达到的门槛。Pelland 2026 剂量 Meta 回归——容量与适应存在递减收益，直接组与间接组分开计，fractional set（间接 0.5）是研究估算模型、不是生理常数。Held 2026 并行训练 umbrella review——休闲训练者可同时改善心肺与力量，但对高水平运动员外推有限。",
        "",
        "== 规划要求 ==",
        "1. 分化由你现判：在全身/上下肢/推拉腿/肌群单日/混合之间按可用天数、单次时长、每肌群刺激频率、动作学习、肌群重叠、疲劳、跑步安排与依从性比较选择，在 splitRationale 里写清为什么这样分、为什么不用更简单的方案。不要套用现行分化表，不要因循健美传统。",
        "2. 动作按模式组织（水平推/垂直推/水平拉/垂直拉/膝主导/髋主导/单侧/核心/携重/有氧）：先排最重要、技术要求最高、最需要专注的动作；同一天避免多个高全身疲劳动作无必要叠加；每个动作的 note 写清主要目的与技术要点，effortTarget 写目标 RIR 区间，substitutions 给同模式可替代动作（器械不可用或不适时用）。",
        `3. 重量只锚定实测与现行计划里已验证的重量：用「实测锚点」和现行组表推进入手重量，不用推算 1RM 定处方；没有实测的动作给可执行的保守起点并在 uncertainties 里注明。卧推已知 80kg×3 未达目标、顶组安排不要超过已验证水平太多；深蹲 100kg×8 是实测做组表现。`,
        `4. 容量：全周工作组围绕当前可恢复水平（约 ${baselineTotalSets} 组）组织，靠后续反馈爬坡，不在一周内跳回停训前约 102 组峰值；「每周固定 +10%」不是规则。训练量与恢复要一起看：当前睡眠平均约 7.5 小时（用户已更正；11-14 单晚约 6 小时只是偶发偏短，不得按睡眠不足降强度或封顶），顶组前提按平均睡眠写进 note。`,
        `5. 时间：每个训练日的组表必须能在 ${capMinutes} 分钟内从容完成（服务端按热身 8 分钟 + 每组做功 + 组间休息 + 每动作 2 分钟切换估算校验）。休息按动作类型给：深蹲/硬拉 180–300 秒、卧推/划船/肩推/引体 120–180 秒、上斜/腿举 120–180 秒、孤立 60–90 秒、腹部 45–90 秒；时间紧时删低优先级内容并写进 lowPriorityDroppable，不要压缩主要复合动作的休息、不要机械地每个动作减一组。`,
        "6. 跑步是次要目标：如安排，放在不显著影响下肢训练质量的位置（与腿日错开，或腿日之后），以轻松可交谈强度为主；不得把 400 米/800 米目标时间直接转成高强度间歇处方。",
        "7. 休息日不写死日期：以约束快照、用户本次指定与当前生效版本周安排为准现判（现行周 2026-11-16 至 11-22 仅 11-22 整休、11-21 是训练日，不得再把 11-21 排成休息日）；days 覆盖目标周全部 7 天，休息日 kind=rest、exercises 为空、title 写明休息原因；已有训练记录的日期不要列入 days。",
        "8. 安全：飞鸟 12.5kg 拉伸撕痛史——胸部孤立拉伸类动作控制拉伸幅度与重量上限并写进 note；若安排里涉及反复不适的动作，safetyNotes 必须写明持续疼痛应寻求专业评估，不能只靠换动作掩盖风险；不安排 1RM 测试；深蹲/卧推顶组在 note 里写明用保护杆或有人保护。",
        "9. 缺失数据：睡眠与营养没有逐日记录——把不确定性写进 uncertainties，不要假设达标或未达标；如有一个最关键的澄清问题，放进 questionForUser，其余照常给出完整提案。",
        "10. 进阶假设（progressionHypotheses）写清：本版计划靠什么反馈进阶或回退（多次稳定+恢复好才小幅进阶；一次表现好只记录；多次下降先查负荷/技术/休息/睡眠/营养/压力）。恢复假设（recoveryAssumptions）写清本版对睡眠、酸痛与连续训练日的处理。",
        "11. 【v2.0 动作库硬约束】动作只能从上面 Exercise Library 的 ACTIVE 条目里选，名字与库名或其别名一致；不要使用未入库的动作名（包括双杠臂屈伸、绳索面拉、悬垂举腿、俯身腿弯举、器械腿弯举、站姿提踵、俯身哑铃肩伸、哑铃前平举、上斜哑铃弯举、杠铃臂屈伸等现行计划里的旧名——它们没有出处登记，本版起不再使用；核心用平板支撑/死虫，肱二头用牧师椅弯举/哑铃弯举/锤式弯举，肱三头用哑铃仰卧肱三头伸展，股四头补充用坐姿腿伸展）；CONDITIONAL/PROVISIONAL 条目（绳索类附件未确认、反手下拉与髋铰链器械轨迹未核验）一个都不能排。设备清单决定能不能做，科学证据决定值不值得做，目标与现实约束决定这次做什么。",
        "12. 【v2.0 反锚定 + 七问】选动作时就要按七问标准逐个比较：为什么选它、书/文献如何评价、同模式替代候选是什么、为什么没选替代、时间效率与疲劳代价、有无相反结论、用户历史实际起到的作用——这七问的书面记录会在紧接着的第二步按已确定的动作名单逐条收集并写入 evidence_manifest，所以本步必须先把比较做实。特别注意：背部训练不得默认以引体向上起手——用户最初只提过一次引体向上，这不是证据；垂直拉与水平拉的首项都要在候选（高位下拉、坐姿器械划船、杠铃俯身划船、单臂哑铃划船、正握/反握引体等）里按证据与约束比较后决定。连续多日同一肌群以同一动作起手时，第二步记录里必须给出 ROTATION_REVIEW 式的保留或轮换理由。",
        "13. 【v2.0 证据分级】评价动作优劣时按 E1–E6 分级陈述：E1 立场声明/系统综述/Meta（如 ACSM 2026、Haugen 2023 机器与自由重量比较——未发现肌肥大普遍差异）、E2 长期随机对照、E3 机制/肌电（只解释、不单独证明长期优势）、E4 九本教材（「教材列出」不等于「更有效」）、E5 学者视频、E6 一般博主。正反冲突时并列写进 opposing，不要只挑支持所选动作的一方；没有直接头对头比较时明说「缺乏直接比较」，不得伪造精确效率分数。",
        "14. 【热身组必须进组表】每个训练日的主项（排最前的大重量复合动作，如深蹲/硬拉/卧推）必须把热身递进出成正式的组：排在该动作 sets 的最前面、标 warmup=true、组间歇 restSeconds=120（如空杠/轻重量起步、逐级递增到工作重量前一档）；热身组不计入工作组数与容量。严禁只把热身递进写进 note 而组表里没有热身组——服务端会判违规；note 里也不要再写热身重量递进（组表已经有了）。",
        "15. 【配重必须能配出来】杠铃片有 2.5kg 档、杠重 20kg：杠铃动作的重量只能是 5 的倍数（25/30/…/65/70/…/100/105…），如目标 102.5 必须写 100、62.5 写 60、65 就写 65（优先向下取整到最近的 5 的倍数，服务端也会向下取整兜底）；哑铃动作每手重量按 2.5kg 一档（如 7.5/10/12.5/17.5）；固定器械/绳索等自有档位不按此限。",
        "所有文字用简体中文。summary 一句话概括本版与现行计划最大的不同；title 字段是每天的训练标题（如「胸 + 三头」），休息日写休息原因。",
      ].join("\n");

      // ---- 第一步：计划结构（分化/动作/组表），不含七问记录 ----
      let planRaw: z.infer<typeof plannerPlanOut> | null = null;
      let lastViolations: string[] = [];
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          planRaw = await ctx.inference.complete(
            attempt === 0
              ? basePrompt
              : `${basePrompt}\n\n== 上一版提案未通过确定性校验，必须修正 ==\n${lastViolations.map((v) => `- ${v}`).join("\n")}\n请重新给出完整的一周提案：保留合理的规划判断，只修正上面列出的问题。`,
            { system, schema: plannerPlanOut, timeout_secs: 240 },
          );
        } catch (e) {
          return {
            ok: false,
            message: `规划生成暂时不可用（模型调用失败：${e instanceof Error ? `${e.name}: ${e.message.slice(0, 200)}` : "未知错误"}），没有保存任何提案；现行计划与全部记录未受影响，可稍后重试。`,
            versionId: null,
          };
        }
        lastViolations = validatePlanProposal(
          { ...planRaw, selectionRationale: [] },
          weekDates,
          sessionDates,
          baselineTotalSets,
          capMinutes,
          false,
        );
        if (!lastViolations.length) break;
        planRaw = null;
      }
      if (!planRaw) {
        return {
          ok: false,
          message: `生成的提案两次未通过安全与数据校验（${lastViolations.join("；")}），已放弃保存；现行计划未受影响。`,
          versionId: null,
        };
      }

      // ---- 第二步：为已选动作逐条补七问选择记录（反锚定留痕） ----
      const chosenNames = [
        ...new Set(
          planRaw.days
            .filter((d) => d.kind === "training")
            .flatMap((d) => d.exercises.map((e) => e.name)),
        ),
      ];
      const rationalePrompt = [
        `任务：为一份已经定稿的训练计划提案，逐个动作补写「动作选择记录」（v2.0 七问）。计划结构已定，不要改动、不要新增或删除动作；只输出 selectionRationale 数组，名单里的每个动作恰好一条，name 与给定名字完全一致。`,
        "",
        "== 成人处方目标（摘要） ==",
        goals.primaryGoal ?? "",
        goals.strengthGoal ?? "",
        "",
        "== 本次入选动作及其库条目（出处与证据评价以此为准，不得另编） ==",
        chosenNames
          .map((n) => {
            const e = findLibraryExercise(n);
            return e
              ? `- ${n}｜库 ${e.id} ${e.name}｜模式 ${e.patterns.join("/")}｜主 ${e.primary.join("、")}｜设备 ${e.equipment.join("、")}｜出处 ${e.source}｜评价 ${e.appraisal}｜替换链 ${e.replacements.join("、") || "无"}`
              : `- ${n}｜未命中库条目`;
          })
          .join("\n"),
        "",
        "== 生成前锚定审计（服务端预检：写七问之前先过这一关，锚定式依据在这里就被拦截） ==",
        ...anchorPrecheckLines(planRaw.days),
        "",
        "== 每个动作必须回答的七问（对应字段） ==",
        "why：为什么这次选它（目标匹配 + 技术/器械/时间约束）；evidenceView：书/文献如何评价它（引用库条目出处与评价，按 E1–E6 分级陈述，教材列出不等于更有效）；alternative：至少一个同模式 ACTIVE 替代候选（从上面预检名单里选）；whyNotAlternative：为什么这次没选替代；timeFatigue：时间效率与疲劳代价（说明分子/分母，无直接比较数据时明说未证实）；opposing：有无相反结论或冲突观点，没有就写「未检索到直接相反结论」；historyRole：用户历史在这次排序中实际起到的作用——没有作用就明说「未起作用」；严禁把「用户提过一次」写成选择依据（会被判 EVIDENCE_INSUFFICIENT）。",
        "特别注意：正握引体向上——用户只在最初提过一次，背部动作的排序不得由这次提及决定；若计划里选了它，historyRole 必须写清这次提及未起作用、入选理由是证据与约束本身；若它作为某日首项，还要给出 ROTATION_REVIEW 式的保留理由。",
        "全部用简体中文，每条每个字段写实质内容（不要空话套话）。",
      ].join("\n");
      let rationale: SelectionRationaleT[] = [];
      let rationaleViolations: string[] = [];
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const batch = await ctx.inference.complete(
            attempt === 0
              ? rationalePrompt
              : `${rationalePrompt}\n\n== 上一版选择记录未通过反锚定校验，必须修正 ==\n${rationaleViolations.map((v) => `- ${v}`).join("\n")}\n请重新输出完整的 selectionRationale 数组。`,
            { system, schema: rationaleBatchOut, timeout_secs: 240 },
          );
          rationale = batch.selectionRationale;
        } catch (e) {
          return {
            ok: false,
            message: `计划结构已生成，但动作选择记录生成失败（模型调用失败：${e instanceof Error ? `${e.name}: ${e.message.slice(0, 200)}` : "未知错误"}），没有保存任何提案；现行计划未受影响，可稍后重试。`,
            versionId: null,
          };
        }
        rationaleViolations = validateSelectionRationale({
          days: planRaw.days,
          selectionRationale: rationale,
        });
        if (!rationaleViolations.length) break;
      }
      // ---- 第二步补救：单个选择失败不得让整个提案失败 ----
      // 两轮批量七问仍有违规时，按违规点名的动作逐个补救，而不是整份放弃：
      // (1) 被判 EVIDENCE_INSUFFICIENT 的动作先做同模式替代定案——按其库
      //     条目替换链/同模式检索换成 ACTIVE 替代动作（如正握引体向上 →
      //     高位下拉），组数与结构不变，只换动作本体与名称；
      // (2) 每个出问题动作单独定向重生成一次七问（带服务端算好的替代
      //     候选名单与违规原文）；
      // (3) 定向重生成仍不合格时，用库条目已登记数据拼服务端补正七问；
      // (4) 以上仍失败的单个选择进入降级（见下方「第二步降级」）：同模式
      //     ACTIVE 强制替定并标注，或剔除并标注原因——绝不放弃整份提案。
      // 全部补救动作逐条记入 repairNotes，随提案 rationale 公开标注。
      const repairNotes: string[] = [];
      if (rationaleViolations.length) {
        const failedNames = [
          ...new Set(
            rationaleViolations
              .map((v) => /「([^」]+)」/.exec(v)?.[1])
              .filter((n): n is string => !!n),
          ),
        ];
        const rationaleByName = new Map(rationale.map((r) => [r.name, r]));
        for (const failedName of failedNames) {
          const nameViolations = rationaleViolations.filter((v) => v.includes(`「${failedName}」`));
          const insufficient = nameViolations.some((v) => v.includes("EVIDENCE_INSUFFICIENT"));
          let effectiveName = failedName;
          // (1) EVIDENCE_INSUFFICIENT → 同模式替代定案（逐日处理）
          if (insufficient) {
            const failedEntry = findLibraryExercise(failedName);
            if (failedEntry) {
              const candidates = samePatternActiveAlternatives(failedEntry, 4);
              for (const day of planRaw.days) {
                if (day.kind !== "training") continue;
                const idx = day.exercises.findIndex((e) => e.name === failedName);
                if (idx < 0) continue;
                const usedNames = new Set(day.exercises.map((e) => e.name));
                const cand = candidates.find(
                  (c) => !usedNames.has(c.name) && !c.aliases.some((a) => usedNames.has(a)),
                );
                const target = day.exercises[idx];
                if (cand && target) {
                  day.exercises[idx] = {
                    ...target,
                    name: cand.name,
                    note: `${target.note ? `${target.note}；` : ""}（服务端反锚定补正：原选「${failedName}」的选择依据被判 EVIDENCE_INSUFFICIENT，已按同模式 ACTIVE 候选改为「${cand.name}」，组数与结构不变）`,
                  };
                  repairNotes.push(
                    `${day.date}「${failedName}」→「${cand.name}」：原选择依据被判 EVIDENCE_INSUFFICIENT（单次提及不能成为默认首选的依据），已重新检索同模式 ACTIVE 替代候选并以证据与约束定案替换，组数与结构不变。`,
                  );
                  effectiveName = cand.name;
                }
              }
            }
          }
          // 该动作（或替代后的动作）若已有合格七问，不再处理
          const dayOf = planRaw.days.find(
            (d) => d.kind === "training" && d.exercises.some((e) => e.name === effectiveName),
          );
          const existing = rationaleByName.get(effectiveName);
          if (
            dayOf &&
            !rationaleItemViolations(dayOf.date, effectiveName, existing).length
          ) {
            continue;
          }
          // (2) 定向重生成一次（只补这一个动作）
          let fixed: SelectionRationaleT | null = null;
          const entry = findLibraryExercise(effectiveName);
          if (entry) {
            const alts = samePatternActiveAlternatives(entry, 3);
            try {
              const batch = await ctx.inference.complete(
                [
                  `任务：只为一个动作补写「动作选择记录」（v2.0 七问），输出 selectionRationale 数组且只含这一条，name 必须与给定名字完全一致：「${effectiveName}」。`,
                  `库条目（出处与评价以此为准，不得另编）：${entry.id} ${entry.name}｜模式 ${entry.patterns.join("/")}｜主 ${entry.primary.join("、")}｜设备 ${entry.equipment.join("、")}｜出处 ${entry.source}｜评价 ${entry.appraisal}｜替换链 ${entry.replacements.join("、") || "无"}`,
                  `同模式 ACTIVE 替代候选（服务端检索）：${alts.map((a) => a.name).join("、") || "无"}。`,
                  `上一版该动作的记录未通过校验：${nameViolations.join("；")}`,
                  "七问字段：why 为什么这次选它（目标匹配 + 技术/器械/时间约束）；evidenceView 书/文献如何评价（引库条目出处与评价，E1–E6 分级，教材列出不等于更有效）；alternative 从上面候选名单里选至少一个；whyNotAlternative 为什么这次没选替代；timeFatigue 时间效率与疲劳代价（无直接比较数据时明说未证实）；opposing 相反结论，没有就写「未检索到直接相反结论」；historyRole 用户历史实际起到的作用——严禁把「用户提过/练过一次」写成选择依据，没有作用就明确写「未起作用」。",
                  "全部用简体中文，每个字段写实质内容。",
                ].join("\n"),
                { system, schema: rationaleBatchOut, timeout_secs: 240 },
              );
              const item = batch.selectionRationale.find((r) => r.name === effectiveName);
              if (item && dayOf && !rationaleItemViolations(dayOf.date, effectiveName, item).length) {
                fixed = item;
                repairNotes.push(
                  `「${effectiveName}」的选择记录经定向重生成后通过反锚定校验（同模式替代候选由服务端按库条目检索后定案）。`,
                );
              }
            } catch {
              // 定向重生成失败走 (3) 服务端补正，不让单个动作拖垮整份提案
            }
          }
          // (3) 服务端补正七问（全部取自库条目已登记数据）
          if (!fixed) {
            fixed = buildFallbackRationale(effectiveName);
            if (fixed) {
              repairNotes.push(
                `「${effectiveName}」的选择记录由服务端按其库条目（${entry?.id ?? "未入库"}）的出处、证据评价、技术要点与疲劳成本补正：排序只依据证据与约束，用户历史未起作用。`,
              );
            }
          }
          if (fixed) {
            rationaleByName.set(effectiveName, fixed);
            if (effectiveName !== failedName) rationaleByName.delete(failedName);
          }
        }
        rationale = [...rationaleByName.values()];
        rationaleViolations = validateSelectionRationale({
          days: planRaw.days,
          selectionRationale: rationale,
        });
        // ---- 第二步降级：补救仍失败的单个选择强制降级，绝不放弃整份提案 ----
        // 逐个补救（替代定案/定向重生成/服务端补正）之后仍有选择记录违规时，
        // 对每个仍违规的选择逐日降级处理：
        // (a) 优先同模式 ACTIVE 强制替定：换成同模式 ACTIVE 库条目（当日
        //     尚未排入者），替定条目的七问由服务端按其库条目补正（字段
        //     均为实质表述，不是只写替代动作名），并在 repairNotes 里写明
        //     原选择为何被降级、替定条目是哪一个、定案依据是什么；
        // (b) 实在无法替定（无同模式 ACTIVE 候选、当日候选已全部占用、
        //     或替定条目的补正记录仍不合格）时，把该动作从当日计划剔除，
        //     并在 repairNotes 里写明剔除原因；剔除后当日若无动作剩余，
        //     该日改为休息日并标注，避免「训练日没有动作」的结构违规。
        // 降级只处理选择记录类违规；每一轮至少替定或剔除一个动作，循环
        // 必然收敛——任何情况下都不因单个选择失败而放弃整份提案。
        for (let pass = 0; rationaleViolations.length && pass < 4; pass++) {
          const failingNames = [
            ...new Set(
              rationaleViolations
                .map((v) => /「([^」]+)」/.exec(v)?.[1])
                .filter((n): n is string => !!n),
            ),
          ];
          if (!failingNames.length) break;
          let progressed = false;
          for (const failedName of failingNames) {
            // 该动作此刻是否仍违规（同一轮里可能已被前面的替定顺带解决）
            const stillFailing = planRaw.days.some(
              (d) =>
                d.kind === "training" &&
                d.exercises.some((e) => e.name === failedName) &&
                rationaleItemViolations(
                  d.date,
                  failedName,
                  rationaleByName.get(failedName),
                ).length > 0,
            );
            if (!stillFailing) continue;
            const reasons = [
              ...new Set(
                rationaleViolations
                  .filter((v) => v.includes(`「${failedName}」`))
                  .map((v) => v.replace(/^\d{4}-\d{2}-\d{2}/, "")),
              ),
            ].join("；");
            const failedEntry = findLibraryExercise(failedName);
            const candidates = failedEntry
              ? samePatternActiveAlternatives(failedEntry, 6)
              : [];
            for (const day of planRaw.days) {
              if (day.kind !== "training") continue;
              let idx = day.exercises.findIndex((e) => e.name === failedName);
              while (idx >= 0) {
                const target = day.exercises[idx];
                if (!target) break;
                const usedNames = new Set(day.exercises.map((e) => e.name));
                // (a) 同模式 ACTIVE 强制替定
                let substituted: LibraryExercise | null = null;
                for (const cand of candidates) {
                  if (
                    usedNames.has(cand.name) ||
                    cand.aliases.some((a) => usedNames.has(a))
                  ) {
                    continue;
                  }
                  const existingCand = rationaleByName.get(cand.name);
                  if (
                    existingCand &&
                    !rationaleItemViolations(day.date, cand.name, existingCand).length
                  ) {
                    substituted = cand; // 已有合格七问，直接替定
                    break;
                  }
                  const candRationale = buildFallbackRationale(cand.name);
                  if (!candRationale) continue;
                  if (rationaleItemViolations(day.date, cand.name, candRationale).length) {
                    continue;
                  }
                  rationaleByName.set(cand.name, candRationale);
                  substituted = cand;
                  break;
                }
                if (substituted) {
                  day.exercises[idx] = {
                    ...target,
                    name: substituted.name,
                    note: `${target.note ? `${target.note}；` : ""}（服务端降级替定：原选「${failedName}」的选择记录经逐个补救仍未通过反锚定校验，已强制改为同模式 ACTIVE 条目「${substituted.name}」，组数与结构不变）`,
                  };
                  repairNotes.push(
                    `${day.date}「${failedName}」→「${substituted.name}」（降级替定）：原选择记录在批量重生成、定向重生成与服务端补正之后仍未通过反锚定校验——${reasons}。按降级规则强制替定为同模式（${substituted.patterns.join("/")}）ACTIVE 库条目 ${substituted.id}「${substituted.name}」；替定依据是该条目已登记的证据评价（出处：${substituted.source}；库内评价：${substituted.appraisal}），其七问选择记录已由服务端按该条目的出处、证据评价、时间与疲劳成本补正（同模式替代候选写明为「${substituted.name}」所属模式内的候选比较，不是只写一个动作名）；原动作的组数、次数目标与组间休息保持不变。`,
                  );
                } else {
                  // (b) 无法替定 → 剔除该动作并标注原因
                  day.exercises.splice(idx, 1);
                  repairNotes.push(
                    `${day.date}「${failedName}」（降级剔除）：原选择记录在批量重生成、定向重生成与服务端补正之后仍未通过反锚定校验——${reasons}；同模式 ACTIVE 候选（${candidates.map((c) => c.name).join("、") || "无可用候选"}）在当日已全部排入，或其补正选择记录仍不合格，无法替定，故将该动作从当日计划中剔除；当日其余动作与整周其他日期的安排不受影响，提案照常保存待确认。`,
                  );
                }
                progressed = true;
                idx = day.exercises.findIndex((e) => e.name === failedName);
              }
              // 剔除后当日无动作剩余 → 改为休息日，避免结构校验判违规
              if (day.kind === "training" && day.exercises.length === 0) {
                day.kind = "rest";
                day.title = `${day.title}（当日动作经降级剔除，改为休息）`;
                day.lowPriorityDroppable = [];
                repairNotes.push(
                  `${day.date} 因当日动作已全部经降级剔除、无动作剩余，该日由训练日改为休息日并在此标注；整周其余日期不受影响。`,
                );
              }
            }
            // 原动作已不在任何一天出现时，删掉它那份不合格的选择记录
            if (
              !planRaw.days.some((d) => d.exercises.some((e) => e.name === failedName))
            ) {
              rationaleByName.delete(failedName);
            }
          }
          if (!progressed) break;
          rationale = [...rationaleByName.values()];
          rationaleViolations = validateSelectionRationale({
            days: planRaw.days,
            selectionRationale: rationale,
          });
        }
        // 结构性校验（时长/容量/库过滤）在替代与降级后重新过一遍
        if (!rationaleViolations.length) {
          rationaleViolations = validatePlanProposal(
            { ...planRaw, selectionRationale: rationale },
            weekDates,
            sessionDates,
            baselineTotalSets,
            capMinutes,
            false,
          );
        }
      }
      if (rationaleViolations.length) {
        // 走到这里的只能是结构/安全类违规（时长、容量、日期与库过滤）：
        // 选择记录类违规已在降级环节被逐个替定或剔除，不会再让整份提案
        // 因单个选择失败而被放弃。
        return {
          ok: false,
          message: `生成的提案经逐个补救与降级后仍未通过结构与安全校验（${rationaleViolations.join("；")}），已放弃保存；现行计划未受影响。`,
          versionId: null,
        };
      }
      const raw: PlannerProposalRaw = { ...planRaw, selectionRationale: rationale };

      // 只保留目标周内的日期（校验已保证），组装版本数据
      const days: DayPlanT[] = raw.days
        .filter((d) => weekDates.includes(d.date))
        .map((d) => ({
          date: d.date,
          kind: d.kind,
          title: d.title,
          exercises: (d.exercises as Exercise[]).map((e) => ({
            name: e.name,
            note: e.note,
            category: e.category,
            // 配重取整兜底：杠铃/哑铃重量向下取整到能配出来的档位
            sets: e.sets.map((s) => ({ ...s, weightKg: loadableWeight(e.name, s.weightKg) })),
          })),
          effortTargets: Object.fromEntries(
            d.exercises.map((e) => [e.name, e.effortTarget]),
          ),
          substitutions: Object.fromEntries(
            d.exercises.map((e) => [e.name, e.substitutions]),
          ),
          droppable: d.lowPriorityDroppable,
        }));
      const { prescriptions, muscleVolume, totalWorkSets } = buildPrescriptionsAndVolume(days);
      const schedule: Array<z.infer<typeof scheduleDayOut>> = weekDates.map((date) => {
        const day = days.find((d) => d.date === date);
        const existingPlan = planRows.find((p) => p.date === date);
        if (!day) {
          // 提案未提及的日期：生效后保持原样（有训练记录的日期模型不得列入）
          const cur = currentByDate.get(date);
          return {
            date,
            planId: existingPlan?.id ?? null,
            title: cur?.title ?? "未安排",
            kind: "unchanged",
            totalSets: cur
              ? cur.exercises.reduce(
                  (a, e) => a + ((e.category ?? "strength") === "cardio" ? 0 : workSetCount(e)),
                  0,
                )
              : 0,
            estimatedMinutes: cur ? estimateDayBudget(cur.exercises).totalMin : 0,
          };
        }
        if (day.kind === "rest") {
          return {
            date,
            planId: existingPlan?.id ?? null,
            title: day.title,
            kind: "rest",
            totalSets: 0,
            estimatedMinutes: 0,
          };
        }
        const b = estimateDayBudget(day.exercises);
        return {
          date,
          planId: planRows.find((p) => p.date === date)?.id ?? null,
          title: day.title,
          kind: "training",
          totalSets: day.exercises.reduce(
            (a, e) => a + ((e.category ?? "strength") === "cardio" ? 0 : workSetCount(e)),
            0,
          ),
          estimatedMinutes: b.totalMin,
        };
      });
      const budgets: Array<z.infer<typeof timeBudgetOut>> = days
        .filter((d) => d.kind === "training")
        .map((d) => ({ date: d.date, ...estimateDayBudget(d.exercises), droppable: d.droppable ?? [] }));
      const diffLines = diffProposalDays(currentByDate, days);
      const diffSummary = [
        `周工作组 ${baselineTotalSets} → ${totalWorkSets} 组。`,
        ...diffLines,
      ].join("\n");
      const citedIds = [...new Set(raw.evidenceIds)].filter((id) =>
        PLANNER_EVIDENCE_IDS.includes(id),
      );
      // evidence_manifest = 账本/文献清单 + v2.0 动作选择记录（七问 + 反锚定）
      const manifest = [
        ...buildEvidenceManifest(citedIds.length ? citedIds : PLANNER_EVIDENCE_IDS.slice(0, 6)),
        ...buildSelectionManifest(days, raw.selectionRationale),
      ];
      // 生成前反锚定审计结果（ROTATION_REVIEW）随提案留痕
      const auditLines = anchoringAuditLines(days, currentByDate);
      const uncertainties = [...raw.uncertainties];
      if (raw.questionForUser) uncertainties.unshift(`待你确认：${raw.questionForUser}`);
      const safetyNotes = [...raw.safetyNotes];
      if (
        /撕痛|疼痛|不适/.test(JSON.stringify(constraints) + historyFacts) &&
        !safetyNotes.some((n) => n.includes("专业评估"))
      ) {
        safetyNotes.push(
          "服务端安全补充：历史记录里有动作不适/疼痛信息（如飞鸟拉伸撕痛）——同一动作反复不适或持续疼痛时，不要只靠换动作掩盖风险，应停止相关动作并寻求专业评估。",
        );
      }

      // 旧的待确认提案被新提案取代（保留在历史里，不删除）
      await db
        .update(schema.planVersions)
        .set({ status: "superseded" })
        .where(eq(schema.planVersions.status, "proposed"));
      const nextVersion = (versionRows[0]?.version ?? 0) + 1;
      const inserted = await db
        .insert(schema.planVersions)
        .values({
          version: nextVersion,
          status: "proposed",
          origin: "planner",
          title: `${weekStart} 起一周 · Planner 提案`,
          weekStart,
          weekEnd,
          goalSnapshot: JSON.stringify(goals),
          constraintsSnapshot: JSON.stringify(constraints),
          weeklySchedule: JSON.stringify(schedule),
          exercisePrescriptions: JSON.stringify(prescriptions),
          proposalDays: JSON.stringify(days),
          muscleVolume: JSON.stringify(muscleVolume),
          timeBudget: JSON.stringify(budgets),
          progressionHypotheses: JSON.stringify(raw.progressionHypotheses),
          recoveryAssumptions: JSON.stringify(raw.recoveryAssumptions),
          evidenceManifest: JSON.stringify(manifest),
          uncertainties: JSON.stringify(uncertainties),
          safetyNotes: JSON.stringify(safetyNotes),
          diffSummary,
          rationale: [
            raw.summary,
            raw.splitRationale,
            ...(repairNotes.length
              ? [`【服务端反锚定补正（v2.0）】以下选择在生成中被逐个补救，未让单个选择失败拖垮整份提案：\n${repairNotes.join("\n")}`]
              : []),
            ...(auditLines.length
              ? [`【生成前历史锚定审计（v2.0 §6）】\n${auditLines.join("\n")}`]
              : ["【生成前历史锚定审计（v2.0 §6）】未发现同一肌群重复起手或与现行计划同日同首动作的锚定延续。"]),
          ].join("\n"),
          confidence: raw.confidence,
        })
        .returning({ id: schema.planVersions.id });
      const versionId = inserted[0]?.id ?? null;
      await db.insert(schema.plannerEvents).values({
        kind: "plan_generated",
        planVersionId: versionId,
        note: `Planner 生成计划版本 v${nextVersion}（${weekStart} 起一周）提案：${raw.summary} 提案尚未生效，等你确认。`,
        payloadJson: JSON.stringify({ weekStart, totalWorkSets, confidence: raw.confidence }),
      });
      ctx.invalidateQueries();
      return {
        ok: true,
        message: `已生成 v${nextVersion} 提案：${raw.summary} 请在下方核对差异与证据清单，确认后才生效。`,
        versionId,
      };
    },
  }),

  confirmPlan: defineAction({
    description:
      "确认一份待确认的计划提案并使其生效：逐日写入 plans（训练日新建/更新、休息日删除原计划），当前版本转入历史；任一目标日期已有训练记录时整体拒绝、不做部分写入。",
    request: z.object({ versionId: z.number() }),
    response: z.object({ ok: z.literal(true), version: z.number() }),
    async handler(ctx, args): Promise<{ ok: true; version: number }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.planVersions)
        .where(eq(schema.planVersions.id, args.versionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这个计划版本。");
      if (row.status !== "proposed") throw new Error("这份提案已经处理过了，不能重复确认。");
      const days = parseJsonOr<DayPlanT[]>(row.proposalDays, []);
      if (!days.length) throw new Error("这份提案没有可生效的日计划内容。");
      // 生效前复查：目标日期只要有训练记录（进行中或已完成）就整体拒绝
      const conflictDates: string[] = [];
      for (const day of days) {
        const sess = await db
          .select({ id: schema.sessions.id })
          .from(schema.sessions)
          .where(eq(schema.sessions.date, day.date))
          .limit(1);
        if (sess.length) conflictDates.push(day.date);
      }
      if (conflictDates.length) {
        throw new Error(
          `${conflictDates.join("、")} 已有训练记录，提案不能覆盖这些日期；请重新生成提案。`,
        );
      }
      const now = new Date();
      for (const day of days) {
        const existing = await db
          .select()
          .from(schema.plans)
          .where(eq(schema.plans.date, day.date))
          .limit(1);
        if (day.kind === "rest") {
          if (existing[0]) {
            await db.delete(schema.plans).where(eq(schema.plans.id, existing[0].id));
          }
          continue;
        }
        const exercises: Exercise[] = day.exercises.map((e) => ({
          name: e.name,
          note: e.note,
          category: e.category ?? "strength",
          sets: e.sets,
        }));
        if (existing[0]) {
          await db
            .update(schema.plans)
            .set({ title: day.title, exercisesJson: JSON.stringify(exercises), updatedAt: now })
            .where(eq(schema.plans.id, existing[0].id));
        } else {
          await db.insert(schema.plans).values({
            date: day.date,
            title: day.title,
            exercisesJson: JSON.stringify(exercises),
            testDay: 0,
          });
        }
      }
      // 回填 schedule 的 planId 并切换版本状态
      const schedule = parseJsonOr<Array<z.infer<typeof scheduleDayOut>>>(row.weeklySchedule, []);
      for (const s of schedule) {
        const p = await db
          .select({ id: schema.plans.id })
          .from(schema.plans)
          .where(eq(schema.plans.date, s.date))
          .limit(1);
        s.planId = p[0]?.id ?? null;
        if (s.kind === "unchanged") s.kind = p[0] ? "training" : "rest";
      }
      await db
        .update(schema.planVersions)
        .set({ status: "superseded" })
        .where(eq(schema.planVersions.status, "current"));
      await db
        .update(schema.planVersions)
        .set({ status: "current", decidedAt: now, weeklySchedule: JSON.stringify(schedule) })
        .where(eq(schema.planVersions.id, row.id));
      await db.insert(schema.plannerEvents).values({
        kind: "plan_confirmed",
        planVersionId: row.id,
        note: `你确认了计划版本 v${row.version}，已写入每日计划生效。差异：${row.diffSummary.split("\n")[0] ?? ""}`,
        payloadJson: JSON.stringify({ version: row.version }),
      });
      ctx.invalidateQueries();
      return { ok: true, version: row.version };
    },
  }),

  rejectPlan: defineAction({
    description: "拒绝一份待确认的计划提案：提案转入历史（rejected），每日计划与当前版本完全不变。",
    request: z.object({ versionId: z.number() }),
    response: z.object({ ok: z.literal(true) }),
    async handler(ctx, args): Promise<{ ok: true }> {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.planVersions)
        .where(eq(schema.planVersions.id, args.versionId))
        .limit(1);
      const row = rows[0];
      if (!row) throw new Error("找不到这个计划版本。");
      if (row.status !== "proposed") throw new Error("这份提案已经处理过了。");
      await db
        .update(schema.planVersions)
        .set({ status: "rejected", decidedAt: new Date() })
        .where(eq(schema.planVersions.id, row.id));
      await db.insert(schema.plannerEvents).values({
        kind: "plan_rejected",
        planVersionId: row.id,
        note: `你拒绝了计划版本 v${row.version} 提案，每日计划保持不变。`,
        payloadJson: JSON.stringify({ version: row.version }),
      });
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  getPlanVersions: defineAction({
    description: "列出全部计划版本历史（基线、当前、提案、已取代、已拒绝）及各自的差异摘要，供版本历史查看；不改动任何数据。",
    request: z.object({}),
    response: z.object({
      versions: z.array(
        z.object({
          id: z.number(),
          version: z.number(),
          status: z.string(),
          origin: z.string(),
          title: z.string(),
          weekStart: z.string().nullable(),
          weekEnd: z.string().nullable(),
          totalWorkSets: z.number(),
          diffSummary: z.string(),
          rationale: z.string(),
          confidence: z.number().nullable(),
          createdAt: z.string(),
          decidedAt: z.string().nullable(),
        }),
      ),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      await ensurePlannerBaseline(db);
      const rows = await db
        .select()
        .from(schema.planVersions)
        .orderBy(desc(schema.planVersions.version));
      return {
        versions: rows.map((r) => {
          const out = toPlanVersionOut(r);
          return {
            id: out.id,
            version: out.version,
            status: out.status,
            origin: out.origin,
            title: out.title,
            weekStart: out.weekStart,
            weekEnd: out.weekEnd,
            totalWorkSets: out.totalWorkSets,
            diffSummary: out.diffSummary,
            rationale: out.rationale,
            confidence: out.confidence,
            createdAt: out.createdAt,
            decidedAt: out.decidedAt,
          };
        }),
      };
    },
  }),

  fixWarmupAndLoadableWeights: defineAction({
    description:
      "一次性修复（幂等，可重复调用）：把 2026-11-18 深蹲备注里的热身递进（60kg×5、80kg×5）转成组表里的热身组；把 2026-11-18 至 11-21 计划中配不出来的杠铃/哑铃重量按可配档位向下取整（杠铃 5 的倍数、哑铃 2.5 一档），同步修正备注与标题里的旧重量文字，并同步当前生效计划版本里存着的提案日计划与周安排标题。只改 plans 与当前 plan_versions，绝不触碰任何会话与逐组记录。",
    request: z.object({}),
    response: z.object({ ok: z.literal(true), changed: z.array(z.string()) }),
    async handler(ctx): Promise<{ ok: true; changed: string[] }> {
      const db = ctx.db<typeof schema>();
      const changed: string[] = [];
      const DATES = ["2026-11-18", "2026-11-19", "2026-11-20", "2026-11-21"];
      // 备注/标题里的旧重量文字同步（顺序重要：先长串后短串）
      const fixText = (t: string): string =>
        t
          .replaceAll("热身递进60kg×5、80kg×5各1组后，", "先按组表做热身组（60kg×5、80kg×5），再进")
          .replaceAll("102.5kg", "100kg")
          .replaceAll("62.5kg", "60kg");
      // 注：65kg 是可配重量（5 的倍数），不再改写为 60kg（2026-11-24 取整规则改版）
      const fixExercises = (exercises: Exercise[], date: string): Exercise[] => {
        let out = exercises.map((e) => ({ ...e, note: fixText(e.note) }));
        if (date === "2026-11-18") {
          out = out.map((e) => {
            if (!e.name.includes("深蹲") && !e.name.includes("后蹲")) return e;
            if (e.sets.some((s) => s.warmup)) return e;
            return {
              ...e,
              sets: [
                { weightKg: 60, reps: "5", restSeconds: 120, warmup: true },
                { weightKg: 80, reps: "5", restSeconds: 120, warmup: true },
                ...e.sets,
              ],
            };
          });
        }
        return normalizeExerciseWeights(out);
      };

      for (const date of DATES) {
        const rows = await db
          .select()
          .from(schema.plans)
          .where(eq(schema.plans.date, date))
          .limit(1);
        const plan = rows[0];
        if (!plan) continue;
        const before = plan.exercisesJson;
        const parsed = parseExercises(before);
        if (!parsed.length) continue; // 解析不出动作就绝不覆盖原计划
        const fixed = fixExercises(parsed, date);
        const title = fixText(plan.title);
        const after = JSON.stringify(fixed);
        if (after !== before || title !== plan.title) {
          await db
            .update(schema.plans)
            .set({ exercisesJson: after, title, updatedAt: new Date() })
            .where(eq(schema.plans.id, plan.id));
          changed.push(`${date} 计划已修正（热身组/可配重量）`);
        }
      }

      // 当前生效版本里存着的提案日计划与周安排标题同步修正（口径一致）
      const currentRows = await db
        .select()
        .from(schema.planVersions)
        .where(eq(schema.planVersions.status, "current"))
        .limit(1);
      const current = currentRows[0];
      if (current) {
        let dirty = false;
        let proposalDaysJson = current.proposalDays;
        if (proposalDaysJson) {
          const days = parseJsonOr<DayPlanT[]>(proposalDaysJson, []);
          const fixedDays = days.map((d) =>
            DATES.includes(d.date)
              ? { ...d, title: fixText(d.title), exercises: fixExercises(d.exercises, d.date) }
              : d,
          );
          const next = JSON.stringify(fixedDays);
          if (next !== proposalDaysJson) {
            proposalDaysJson = next;
            dirty = true;
          }
        }
        const schedule = parseJsonOr<Array<z.infer<typeof scheduleDayOut>>>(current.weeklySchedule, []);
        for (const s of schedule) {
          const t = fixText(s.title);
          if (t !== s.title) {
            s.title = t;
            dirty = true;
          }
        }
        if (dirty) {
          await db
            .update(schema.planVersions)
            .set({ proposalDays: proposalDaysJson, weeklySchedule: JSON.stringify(schedule) })
            .where(eq(schema.planVersions.id, current.id));
          changed.push(`计划版本 v${current.version} 的存档日计划与周安排标题已同步修正`);
        }
      }
      if (changed.length) ctx.invalidateQueries();
      return { ok: true, changed };
    },
  }),
} satisfies ActionsModule;
