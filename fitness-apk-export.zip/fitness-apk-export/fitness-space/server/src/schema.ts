// 每日健身计划的数据表：
// plans    —— 某一天的训练计划（动作与每组目标以 JSON 保存，便于整表编辑）
// sessions —— 一次实际训练（与计划同日关联），含摘要与 Drive 上传状态
// set_logs —— 逐组记录：目标、实际、休息、感受与 Muse 的实时调整
// plan_versions —— ATI Planner 的计划版本（工作假设）：目标/约束快照、周安排、
//   动作处方、直接/间接组统计、时间预算、证据清单与差异；current 只有一个，
//   planner 生成的新版本先以 proposed 落库，用户确认才生效，历史版本不覆盖。
// planner_events —— Planner 事件日志（只追加）：实时层 MODIFY_NEXT_SESSION /
//   停止信号等反馈事件与版本生成/确认/拒绝记录，供下一次规划读取。

import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const plans = sqliteTable("plans", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  // 本地日期 YYYY-MM-DD（Asia/Shanghai），一天一份计划
  date: text("date").notNull().unique(),
  title: text("title").notNull(),
  // 测试日开关：1=开，-1=关，0=未设置（按标题/动作含「摸底/测试」自动判断）
  testDay: integer("test_day").notNull().default(0),
  // [{ name, note, sets: [{ weightKg: number|null, reps: string, restSeconds: number, warmup?: boolean }] }]
  // warmup=true 的组是热身组：排在工作组前、可记录，但不计入工作组数。
  exercisesJson: text("exercises_json").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const planVersions = sqliteTable("plan_versions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  // 版本号（从 1 起递增）；status: current（当前生效）| proposed（待确认提案）
  // | superseded（被新版本取代）| rejected（用户拒绝的提案）
  version: integer("version").notNull(),
  status: text("status").notNull().default("proposed"),
  // origin: baseline（既有计划登记基线）| planner（模型生成的提案）
  origin: text("origin").notNull().default("planner"),
  title: text("title").notNull(),
  weekStart: text("week_start"),
  weekEnd: text("week_end"),
  // 以下均为 JSON 文本（设计 §13 PlanVersion 字段逐项落列）：
  // goalSnapshot / constraintsSnapshot —— 规划时的目标与约束快照
  // weeklySchedule —— [{ date, planId, title, kind, totalSets, estimatedMinutes }]
  // exercisePrescriptions —— ExercisePrescription[]（动作模式/主次肌群/组数信用…）
  // proposalDays —— 仅 proposed 版本有：确认时要写入 plans 的完整日计划
  // muscleVolume —— [{ muscle, directSets, indirectSets, fractionalEstimate }]
  // timeBudget —— [{ date, warmupMin, workMin, restMin, transitionMin, totalMin, droppable[] }]
  goalSnapshot: text("goal_snapshot").notNull(),
  constraintsSnapshot: text("constraints_snapshot").notNull(),
  weeklySchedule: text("weekly_schedule").notNull(),
  exercisePrescriptions: text("exercise_prescriptions").notNull(),
  proposalDays: text("proposal_days"),
  muscleVolume: text("muscle_volume").notNull(),
  timeBudget: text("time_budget").notNull(),
  progressionHypotheses: text("progression_hypotheses").notNull(), // JSON string[]
  recoveryAssumptions: text("recovery_assumptions").notNull(), // JSON string[]
  evidenceManifest: text("evidence_manifest").notNull(), // JSON 证据卡[]
  uncertainties: text("uncertainties").notNull(), // JSON string[]
  safetyNotes: text("safety_notes").notNull(), // JSON string[]
  diffSummary: text("diff_summary").notNull(), // 与上一版本/现行计划的差异（逐行）
  rationale: text("rationale").notNull().default(""),
  confidence: real("confidence"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
  decidedAt: integer("decided_at", { mode: "timestamp_ms" }),
});

export const plannerEvents = sqliteTable("planner_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  // kind: ati_modify_next_session | ati_stop_signal | plan_generated |
  //       plan_confirmed | plan_rejected
  kind: text("kind").notNull(),
  planVersionId: integer("plan_version_id"),
  sessionId: integer("session_id"),
  setLogId: integer("set_log_id"),
  note: text("note").notNull(),
  payloadJson: text("payload_json"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const sessions = sqliteTable("sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  planId: integer("plan_id"),
  date: text("date").notNull(),
  title: text("title").notNull(),
  status: text("status", { enum: ["in_progress", "completed"] })
    .notNull()
    .default("in_progress"),
  startedAt: integer("started_at", { mode: "timestamp_ms" }),
  endedAt: integer("ended_at", { mode: "timestamp_ms" }),
  summaryMd: text("summary_md"),
  review: text("review"),
  nextSuggestion: text("next_suggestion"),
  // 跨动作「停止」类提醒：[{ id, exerciseIdx, exerciseName, message, acknowledged }]
  alertJson: text("alert_json"),
  driveStatus: text("drive_status").notNull().default("none"), // none | pending | uploaded | failed
  driveFileName: text("drive_file_name"),
  driveLink: text("drive_link"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const setLogs = sqliteTable("set_logs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  sessionId: integer("session_id").notNull(),
  exerciseName: text("exercise_name").notNull(),
  exerciseIdx: integer("exercise_idx").notNull(),
  setIdx: integer("set_idx").notNull(),
  // 热身组标记（开始训练时从计划组表快照）：1=热身组。热身组可正常记录
  // 重量/次数/感受，但不计入工作组数（当天/每周总组数与肌群折算组数）。
  warmup: integer("warmup").notNull().default(0),
  targetWeightKg: real("target_weight_kg"),
  targetReps: text("target_reps").notNull(),
  targetRestSeconds: integer("target_rest_seconds").notNull().default(90),
  // 开始训练时快照的原始计划目标（调整后目标会改写上面三列，原始值留在这里对照）
  origWeightKg: real("orig_weight_kg"),
  origReps: text("orig_reps"),
  origRestSeconds: integer("orig_rest_seconds"),
  actualWeightKg: real("actual_weight_kg"),
  actualReps: text("actual_reps"),
  // 还剩几次余量（RIR），知识库统一标尺：3=3+（还能标准地做 3 个以上）、
  // 2、1、0（1 个也做不了）；旧数据里的 4 按 3+ 显示。只问「还能标准地做几个」，
  // 取代旧的 difficulty 模糊难度（旧列保留兼容历史数据，新反馈不再写入）
  rir: real("rir"),
  // 四项客观证据之三：动作是否变形 —— 未变形 | 变形 | 变形且无法纠正
  deform: text("deform"),
  // 四项客观证据之四的停止信号补充：同一部位持续酸痛超过 72 小时仍训练（1=是）
  sorenessOver72: integer("soreness_over72"),
  // 有氧组结构化记录：时长（分钟）、配速（分/公里，如 "6:30"）、距离（km）
  durationMin: real("duration_min"),
  pace: text("pace"),
  distanceKm: real("distance_km"),
  restSeconds: integer("rest_seconds"),
  done: integer("done").notNull().default(0),
  skipped: integer("skipped").notNull().default(0),
  // 跳过由谁决定：user=本人手动跳过；ai=Muse 建议经本人确认后跳过
  skippedBy: text("skipped_by"),
  // 旧版记录标记：1=用户在「今日」页横幅里选择了「保留原样并继续」，
  // 该组不进入 ATI 决策上下文的「今日已完成组」链（避免旧格式数据干扰趋势判断）
  legacy: integer("legacy").notNull().default(0),
  difficulty: text("difficulty"), // 轻松 | 适中 | 困难
  joint: text("joint"),
  pump: integer("pump"), // 1-5
  fatigue: integer("fatigue"), // 1-10
  note: text("note"),
  aiSuggestion: text("ai_suggestion"),
  // 裁决在途状态（切后台/息屏/退出后恢复用）：submitFeedback 在跑推理前
  // 先落 running + adjudication_started_at，裁决结果写回时置 done，异常
  // 中断置 failed。客户端据此区分「还在裁决」「裁决被中断可续跑」与
  // 「从未提交」，不再只靠那条长请求的 promise 是否返回判断状态。
  adjudicationStatus: text("adjudication_status"), // running | done | failed | null
  adjudicationStartedAt: integer("adjudication_started_at", { mode: "timestamp_ms" }),
  // 本条建议的裁决标识：ATI 改造后存「ATI · 主裁决动作中文名」（历史行
  // 保留当时的规则 A–G 编号原文）；ai_evidence 是本组反馈事实摘要，
  // ai_action 是主裁决动作中文名（历史值为维持/加重/降重/减组/停止）
  aiRule: text("ai_rule"),
  aiEvidence: text("ai_evidence"),
  aiAction: text("ai_action"),
  // 本条建议的依据：引用了哪条训练原则、依据性质（客观触发 | 主观感受参考）
  aiBasisPrinciple: text("ai_basis_principle"),
  aiBasisKind: text("ai_basis_kind"),
  aiAdjustments: text("ai_adjustments"), // JSON 数组（建议原文，仅展示）
  // 建议制：Muse 的调整先存为待确认建议（proposal_json），用户点「接受」才改写后续组；
  // proposal_status: pending | accepted | dismissed | undone | none
  proposalJson: text("proposal_json"),
  proposalStatus: text("proposal_status"),
  // 已接受并真正落地的改动说明（由服务端按实际 diff 逐项生成，与改动严格一致）
  appliedNote: text("applied_note"),
  // 接受时对受影响组的快照，撤销时据此恢复（含新增组 id 与提醒 id）
  undoJson: text("undo_json"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});
