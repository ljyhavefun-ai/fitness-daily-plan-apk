# Data Plan

## Context provenance
- `深蹲从 90kg 起测，若只能做 3 次就降到 80–85kg；热身组次数减少、测试组往前放`（父对话中助手按峻宇原计划抄录、峻宇未纠正的 2026-11-13 摸底卡；作为 2026-11-13 当日计划的种子内容，UI 内可改）
- `罗马尼亚硬拉 60kg×8 找动作，再测` + `跑步 20 分钟、能说话的速度` + `明天 11 月 13 日（周五）克拉玛依小雨……改到室内跑步机`（同上摸底卡与天气修正；种子计划里跑步写为室内跑步机 20 分钟）
- `2026-11-11 晚第一次恢复训练（胸+激活），卧推 50kg×8、70kg×8、80kg×1，上斜哑铃 25kg×10，自重引体 12 个，腿没练`（MEMORY.md 用户本人实测记录；作为一条已完成历史会话种子，让历史/统计页打开即有真实数据，全部可在 UI 删除/修改）
- `60kg、170cm；每周 3 次全身力量+2 次轻松有氧`（USER.md/MEMORY.md 用户档案；仅用于 AI 建议提示词上下文，不在页面上替用户断言展示）
- 用户本次请求原文：逐组记录、感受输入后 Muse 实时优化后续组数/重量/休息/动作替换、结束生成摘要并上传 Drive「健身日志」文件夹、文件名含日期、历史/趋势/下次建议/简单统计。

## Tested sources
### Google Drive（hatch_gws_cli）
**Used by**: uploadSummaryToDrive 动作经 ctx.agent.spawnTask 调用 CLI 完成上传（服务端动作不能直连连接器，改走用户自己的 agent + 已连接的 Drive CLI）
**Test command**: `/opt/hatch/bin/hatch_gws_cli drive status` 与 `drive files list --params '{q: name = 健身日志 and mimeType = folder}'`
**Sample output**: status 返回 `{"ok":true,"status":"connected"}`；名为「健身日志」的文件夹不存在（files: []），根目录有两份同名文件「健身日志.md」。
**Processing**: 上传时先查/建「健身日志」文件夹，再以 `健身日志-YYYY-MM-DD.md` 上传摘要 markdown；回调用 recordDriveUpload 保存文件名与链接，UI 展示状态。总结页「训练日志存档」区块按 driveStatus 明确展示四种状态：未上传（显示「上传到 Drive」按钮）、上传中（pending 时每 4 秒自动刷新状态、约 2.5 分钟后停，并有「立即刷新状态」按钮）、上传成功（绿色成功条 + 文件名 + Drive 打开链接）、上传失败（红色失败提示 + 「重试上传到 Drive」按钮）；finishSession 结束训练时在服务端自动调用同一上传流程，状态回写后总结页自动呈现结果。

### ctx.inference（组间感受 → 实时调整建议）
**Used by**: submitSetFeedback、finishSession（下次训练建议）
**Test command**: `bun /opt/muse/assets/spaces/ts-runtime/dist/probe-ctx.js < /tmp/probe-inference5.ts`（complete(prompt, {system, schema}) 形式）
**Sample output**: 输入「深蹲第1组 目标90kg×5 实际90kg×3 感受困难、膝盖紧」返回 suggestion「90kg对今天来说偏重了，后续降重到80kg做3组×3-4次，组间休息3-4分钟……」及 adjustments 数组（重量/次数/休息/动作注意），与用户 11-13 卡片「只能做3次就降到80–85kg」的口径一致。
**Processing**: schema 约束输出 {suggestion, adjustments[], nextSetWeightKg?, nextSetReps?, restSeconds?, replaceWith?}；服务端把数值调整机械地应用到当前动作剩余未完成组的计划目标并回写 plan，页面即时刷新；关节疼痛类感受在提示词中强制优先降载/替换。

## Long-term data behavior
- **Refresh policy**: 无定时刷新；数据为用户自录，打开即读 DB。Drive 上传为用户点按触发（外加结束训练时提供一键上传）。
- **Growth**: 每次训练新增 1 条 session + 若干 set_logs；计划按日期一条，可增删改。
- **Ordering**: 历史按日期倒序；趋势按周聚合最近 8 周训练量，动作进步取每动作历史最大重量序列。
- **Time semantics**: 日期为 Asia/Shanghai 本地日期（YYYY-MM-DD 字符串）；started_at/ended_at 存时间戳按本地渲染；总时长由起止时间差计算。

## Rejected approaches
- **Tried**: 服务端动作直接调用 Drive 连接器上传
  **Why rejected**: 动作运行时没有连接器通道；连接器只能经用户 agent 的 CLI 使用，故走 spawnTask + 回调 action 落库，按钮与状态仍在空间内。
- **Tried**: ctx.inference.complete 使用 messages 数组签名
  **Why rejected**: 探针实测该运行时签名为 complete(prompt, {system, schema})，messages 形式直接报错，按实测签名实现。

Imagery not needed: 健身记录工具无视觉主体，动作用文字与数字呈现，用户未要求图片。

## 交互补充（2026-11-13 编辑）
- **当前组重量默认**：训练面板的重量/次数输入改为渲染时派生——默认直接取该组计划目标（含 Muse 感受反馈后改写的最新目标，目标一变输入自动同步），用户手动改过且目标未再变时才用改后的值；旧实现用只依赖组 id 的 useEffect 同步，Muse 调整当前组目标后输入不跟随、需手动改，已修复。
- **震动反馈**：统一 buzz() 助手（navigator.vibrate，不支持的设备静默跳过）；触发点：开始训练、完成一组、跳过一组、休息到时（[200,100,200,100,200] 间歇模式）、点「休息结束」、Muse 建议到达、保存计划、结束训练、Drive 上传成功/失败。
- **系统通知**：今日页顶部「训练提醒」开关，偏好存 localStorage 键 `fitness-notif-enabled`；开启时申请浏览器 Notification 权限并发测试通知。四个触发时刻：休息结束（通知与页面横幅均写明下一组动作名、第几组、目标重量×次数）、Muse 建议到达（写明动作/组号与已应用的调整）、训练结束摘要生成、Drive 上传成功/失败（DriveButton 监听 driveStatus 由 pending 跃迁触发，初次打开旧记录不误报）。限制如实写在开关旁：通知由页面发出、无服务器推送通道，切后台时浏览器可能暂停页面计时导致提醒延迟，页面内横幅 + 震动兜底。

## 交互补充（2026-11-13 模拟体验优化）
- **调整改建议制**：submitFeedback 只存感受 + 待确认建议（proposal_json/proposal_status=pending），不再改写任何组；respondProposal(accept) 才落地改动，服务端逐组逐项比对生成 appliedNote（只写真正改的值、跳过写明第几组），接受前快照存 undo_json，undoProposal 可完整撤销（含删新增组、撤停止提醒）；忽略=proposal_status=dismissed 不改动。被跳过的组在列表里保持可点「撤销」恢复；skipped_by 区分 user（本人决定）/ai（Muse 建议经确认），总结与复盘提示词按此归因，不把 AI 跳组写成用户决定；生成总结前 verifyAppliedNotes 校验已接受调整都有 appliedNote。
- **测试日**：plans.test_day 三态（1 开 / -1 关 / 0 按标题与动作含「摸底|测试」自动判定）；getDay 返回有效值，计划页与编辑器都有开关。测试日时提示词约束 + 服务端二次剔除：降测试重量（低于剩余组最高目标）、减组、替换测试动作一律从建议中剔除并写 guardNotes 明示。
- **跨动作停止提醒**：AI 在 stopWarning 里点名后续同类动作，用户接受后落到 sessions.alert_json；对应动作卡标红、当前动作出现红色确认条，用户点「我确认身体没问题」acknowledgeAlert 后才算确认；撤销调整时提醒一并撤除。
- **一键按计划继续**：submitFeedback 带 quickContinue 只存感受直接返回，不调 AI、不弹建议。
- **有氧结构化字段**：set_logs 加 duration_min/pace/distance_km，logSet 可写；训练面板对无重量且次数为时长型（如「20分钟」）的组显示时长/距离/配速三输入，配速留空按时长÷距离自动算；总结表单独列配速列，实际列写时长与距离。
- **三列总结**：set_logs 在 startSession 时快照 orig_* 原始目标；总结（页面与 md）同时列原始计划/调整后目标/实际；平均休息只计 target_rest_seconds>0 的力量组；总时长统一 Math.round 到分钟并注明「四舍五入」。
- **目标重量未设**：显示「未设」；计划总览对未设组给行内快捷填入口（updatePlanSetWeight）；训练中进入未设组默认沿用同动作上一组实际重量（可改）并橙字提示。
- **休息计时兜底**：logSet 返回 serverNow，客户端以服务端时间戳为休息起点并保存时钟偏移；休息状态存 localStorage（fitness-rest-<sessionId>），切回前台/切页回来按真实经过时间补算，visibilitychange 时立即重算。
- **Drive 重复上传**：startDriveUpload 若该会话已有 driveFileName（即重复上传），新文件名为「健身日志-日期-HHmm.md」新建副本避免同名；DriveButton pending 超过 30 秒显示「仍在上传，可先离开，稍后在历史里查看结果」。
- **深蹲备注对齐（只改种子与既有计划的备注文字）**：备注改为「递进摸底：60kg×5 热身 → 80kg×3 → 90kg×3 测试 → 85kg×3 收尾……」与组表 60/80/90/85 一致；seedInitialData 对既有计划仅当备注含「从 90kg 起测」时替换备注，组表重量不动；2026-11-11 真实记录未动。
- **统计分母**：getStats 返回 feedbackSets，感受分布注明「基于 N 组有反馈的记录」；通知设置区显示当前 Notification 权限状态（已允许/已被拒绝/尚未询问）。

## 知识库规则 A–G 接入（2026-11-13 编辑）
- **规则来源（唯一口径）**：Obsidian 知识库 `~/workspace/obsidian/健身增肌知识库/给每日健身计划的建议规则.md`（构建时逐行读入核对）。服务端 RULES 常量按该文件逐条转述：A 停止信号、B 维持（默认）、C 加重（含 NSCA 2-for-2、下肢 2.5–5kg/上肢 1.25–2.5kg）、D 降重（两项证据、减 10%、只满足一项先延长休息 1 分钟）、E 减组（两项证据、测试日只在 A 停止）、F 减载周（同重量连续 3 课失败或两周停滞；容量减半、重量减 10–20%、RIR ≥ 4）、G 先排查恢复（睡眠 <7h、蛋白 120g/天、深蹲硬拉休息 2–4 分钟、连续训练无休息日）。getPrinciples 下发给「训练原则」页与服务端裁决共用。
- **服务端先行裁决**：submitFeedback 不再让模型决定改不改——evaluateRules 按四项客观证据 deterministic 裁决（命中规则、五选一动作 维持/加重/降重/减组/停止、重量/休息/减组数值），模型只润色一句教练说明且不得推翻；模型失败时纯模板建议照样成立。RIR 与完成次数矛盾以完成次数为准并写入证据。
- **四项客观证据**：set_logs 新增 deform（未变形/变形/变形且无法纠正）与 soreness_over72（持续酸痛 >72h，规则 A 第三触发）；完成次数取 logSet 实际记录并在表单顶部只读展示；关节沿用 正常/发紧/刺痛。缺一项证据时 D/E 不得下调（规则文件第 1 节），只延长休息并在 guardNotes 写明缺哪项。
- **三段式建议**：ai_suggestion 由服务端拼装「证据：…（命中规则 X）。建议：…。依据：规则 X——…（原则出处）」，另存 ai_rule/ai_evidence/ai_action 三列；待确认卡、已接受/已忽略/无需改动卡、历史详情、总结 md 全部展示规则编号与证据。旧的「无客观触发守卫 + 10% 封顶」逻辑被规则裁决取代：降重只在 D 两项证据齐备时发生且固定减 10%，减组只在 E 两项证据齐备时减 1 组，停止只在 A 发生且跳过当日剩余全部组并联动 stopWarning 标红后续同类动作。
- **RIR 标尺统一为知识库五档**：3+ / 2 / 1 / 0 / 0 且动作变形；存储 3 表示 3+，旧数据 4 显示与统计都并入 3+；submitFeedback 的 rir 入参上限改 3。统计分桶改 0/1/2/3+ 四桶。
- **跨课 F/G**：computeDeloadSignal 按已完成会话历史判定（同动作同重量连续 3 课有少 ≥2 次的组 → 减载原因；≥6 课且最近 14 天各动作最大重量未超此前水平且有失败课 → 两周停滞；数据不足不下结论），finishSession/regenerateAdvice 把规则 F 减载注记与规则 G 恢复排查清单（任一动作出现连续 2 组失败时）以服务端文本追加到下次建议，不交给模型凭感觉判断。规则 C 的加重只作用于下次训练：组内反馈给出 nextSessionWeightKg 建议值、不生成待确认改动，复盘提示词同步按 C 的幅度口径。
- **测试日**：裁决内处理——非 A 情况一律维持 + 休息延长，测试重量/组数不动，guardNotes 写明；A 触发才停止测试。

## 放宽调整与 RIR 标尺（2026-11-13 编辑）
- **默认按计划、客观触发才下调**：submitFeedback 先在服务端用真实完成数据算客观触发（实际次数比目标少 ≥2、关节含「刺痛」、备注提到变形/做不起来）；未触发时守卫剔除一切降重（低于剩余组最高目标）、减组、替换、stopWarning，只保留延长休息/维持原计划，并把剔除原因写进 guardNotes；触发但非关节刺痛时降重封顶剩余最高目标的 90%、减组最多 1 组、替换须同时有 stopWarning。关节刺痛与测试日保护不变。
- **RIR 取代难度三档**：set_logs 新增 rir 列（0=力竭…4=4 次及以上），表单主信号改为「还剩几次余量」并常驻标尺文案（RPE 10=0 次…RPE 7=3 次）；difficulty 列保留只读兼容历史数据，新反馈不再写入。关节/泵感/疲劳在界面与提示词中都标注「参考信号，不单独决定降重」。getStats 的分布改为 RIR 分桶（0/1/2/3/4+），feedbackSets 改为填了 RIR 的组数。
- **建议必须带依据**：feedbackOut/proposal 新增 basisPrinciple（引用 PRINCIPLES 七条之一，服务端归一化校验）与 basisKind（客观触发/主观感受参考，未触发时服务端强制后者）；adjustments 每项带 kind（再加「信息性」）；建议文案未含「依据」时服务端自动补注记。依据存 ai_basis_principle/ai_basis_kind 两列，待确认卡、已接受/已忽略/无需改动各状态、历史详情、总结 md（已确认调整行尾注 + 未采纳建议单列存档）都展示。
- **训练原则页**：服务端 PRINCIPLES 常量（渐进超负荷、RIR/RPE 与力竭、容量与频率、强度与次数区间、组间休息、热身与动作技术、恢复与减载）为唯一口径，getPrinciples 动作下发给新增的第四页签「训练原则」（含 RIR/RPE 标尺表）；submitFeedback、finishSession、regenerateAdvice 三处提示词都嵌入同一套原则摘要。内容为通用训练科学概念的自述总结，不含任何书籍原文（Z-Library 下载未做，见任务说明）。

## 按详细提示词重建升级（2026-11-13 编辑，用户外部提示词 + 9 本书核对结果）
- **数据保护核查（构建前实测）**：沙箱副本 getDay(2026-11-13) 确认计划 id 1 组表（深蹲 60×5/80×3/90×3/85×3、硬拉 60×8×2 + 第 3 组 null、跑步机 20 分钟、testDay=true）与备注原文无误；会话 id 4 进行中、已记 2 组深蹲（60kg×5、87.5kg×5，difficulty=适中、无 rir/deform/joint、proposalStatus=pending 但 proposal 为 null 的旧格式建议）；getStats 确认 2026-11-09 周 1 场/5 组/1290kg。本次未动任何存量行。
- **旧版记录兼容**：set_logs 新增 legacy 列（迁移 0006，默认 0，不回填改数据）；setLogOut 新增 legacyRecord/needsRir 派生字段（已完成 + 有 difficulty + 新版三证据全缺）；submitFeedback 的连续失败链排除 legacyRecord 组。今日页训练视图顶部黄色决策横幅（LegacyBanner）：补全 RIR（逐组五档胶囊，走 submitFeedback quickContinue 落库）、保留原样（markLegacySets 标记，不改数值）、删除会话（二次确认后 deleteSession）。
- **规则引擎补强**：规则 A 新增 RIR 0 且动作变形（技术力竭，标尺第五档）触发；反馈表单 RIR 胶囊补第五档「0 且变形」（联动 rir=0 + deform=变形）；规则 D 降重取整改为 2.5kg 倍数；aiSuggestion 改为【客观证据】【裁决建议】【规则依据】三段标签格式。既有 D 先行、E 为降重后升级路径的优先级（上一轮已定）保持不变。
- **书籍核对数字同步进 PRINCIPLES**：NSCA 第 5 版增肌 67–80%/8–12 次、多关节休息 2–3 分钟/单关节 60–90 秒；Schoenfeld 每节每肌群 40–70 次容量口径；容量 landmarks MEV/MAV/MRV；蛋白 1.6–2.2g/kg 与本人目标 120g/天、热量 2500–2700kcal。规则 A–G summary 文案未动。
- **计划类别**：exerciseSchema 新增可选 category（strength/cardio），savePlan 缺失时按名称/时长型次数自动识别落库；种子计划补显式 category；前端有氧面板优先按 category 判定。
- **前端极速交互**：当前组面板新增「⚡ 一键按计划继续（RIR 2 / 正常）」主通道（logSet + quickContinue，不调 AI）；次数 ±1 步进；空目标重量快捷胶囊（沿用上组/±2.5/±5）+「保存为计划默认值」复选框（完成时调 updatePlansetweight）；有氧喘息/说话程度三胶囊（随快速通道记入备注）；休息计时改 ±30 秒并加 Web Audio 提示音；跨动作提醒加「跳过本动作全部组」；跳过组按钮改名「恢复此组」；建议卡按钮文案对齐（接受并改写后续组/忽略（维持原计划）/重新生成裁决说明走 submitFeedback 重跑、已接受卡为「撤销此调整」）。
- **Wake Lock 与提醒文案**：训练提醒开启且训练进行中时 TrainingView 申请 navigator.wakeLock 屏幕常亮（切回前台重申请），激活时显示绿色小字；开关旁文案改为提示词口径（无服务器推送、建议前台常亮或用语音助手设系统闹钟）。
- **Drive 文件名**：同日重复上传后缀由 HHmm 改为 HHmmss（与本次提示词口径一致，基础名 健身日志-YYYY-MM-DD.md 不变）。
- **统计口径补全**：getStats 新增 totalVolumeKg、restSamples、totalStrengthSets；RIR 分布改为五档（3+/2/1/0/0 且变形，rir=0 且变形单列）并在前端注明分母与早期记录说明；动作进步点新增 est1RmKg（Epley 公式）双线展示；平均休息为 0 样本时显示「--（暂无休息计时样本）」。

## 每组流程卡死修复（2026-11-13 编辑，用户真机反馈）
- **故障定性（证据）**：用户截图（12:41，深蹲第 1 组）中橙色「完成这一组」与绿色「一键按计划继续」两个按钮同时呈半透明发白状，与正常渲染的饱和色对比即 `disabled:opacity-50`——点了一次后 logSet 请求一直未返回，按钮锁死：无「记录中」文案、无错误提示、无重试入口，服务端核查该会话 0/9 组未落库。页面与服务端动作本身无报错（证据包 console 为空、logSet 为纯 DB 更新）。
- **记录通道加固**：当前组面板、跳过、结束休息的 logSet 统一走 runLog 入口，记住本次 payload 与成功回调；按钮 pending 时显示「正在记录…」；pending 超 8 秒出现慢提示与「重新记录这一组」；失败出现红色错误条 + 「重新记录」原样重试（logSet 为同值更新，重发不记重）；顶部新增四步流程指示（①做这一组 ②点按钮记录 ③休息计时 ④开始下一组），当前步高亮。
- **流程拆分（什么时候开始/反馈/下一组）**：记录成功即进入独立「休息中」视图（已记录确认行 + 休息计时 + 下一组预告），休息期间不再提前把下一组面板当当前组推出；completeCurrent 不再自动打开反馈表单——反馈改为休息区的可选入口（或事后在组列表点「写感受」补），不填按计划继续；休息结束（计时到点或点「立即结束休息」）后才显示下一组面板。两个完成按钮的二选一口径写在按钮下方。

## savePlan testDay 丢失与删会话修复（2026-11-13 编辑，用户实测报告）
- **故障实测（沙箱复现基线）**：生产计划 id 1 的 test_day 存量值为 -1（显式关）——标题与动作名都含「摸底」，若存量为 0（未设置）getDay 会自动判定为测试日，故 getDay 显示 false 证明存量被写成了 -1；同一通 12:09 的 savePlan 还删掉了进行中的会话 id 4（用户已确认放弃恢复，不再处理）。
- **savePlan 加固**：落库值改为单一显式计算——显式传 testDay 就按传入值存（true→1 / false→-1），缺省时沿用原行存量值（新计划为 0=未设置），任何路径都不把「没传」写成关闭；写后回读校验落库值与目标值一致，不一致直接报错，杜绝「返回成功但开关被悄悄改掉」。savePlan 只写 plans 表本身，代码层面不引用 sessions/set_logs，不可能删除、清空或重置任何会话（进行中与已完成都不动）。
- **安全修复通道**：新增 setPlanTestDay 动作——按日期只单列更新 plans.test_day（写后回读校验），不改标题、组表、备注，不触碰会话与逐组记录。计划 id 1 的 testDay 恢复走这条通道（提交后对正式库执行一次 setPlanTestDay{date:"2026-11-13", testDay:true}），全程未调用 savePlan。
- **沙箱验证（副本数据，含会话 id 5 进行中 0/9 组、会话 id 1 已完成 1290kg）**：savePlan 传 testDay:false → getDay 为 false 且会话 5 的 9 组（id 30–38）原样；savePlan 不传 testDay → 仍为 false（-1 被沿用，未被重置为 0 后经标题自动判定翻转）；setPlanTestDay(true) → getDay plan.testDay=true、会话 5 仍 in_progress 且 doneSets=0、会话 1 的 1290kg 与总结原文无误；计划组表（深蹲 60/80/90/85、硬拉 60/60/null、弯举 2 组×12）与备注逐字未变。

## 交互逻辑重建（2026-11-13 编辑，按外部详细提示词第 11–26 节）
- **范围**：只改 client/src/App.tsx 的呈现与流程引导；未改 server 动作、规则 A–G、RIR 标尺、Drive 约定与视觉主题；未动任何存量数据（计划 id 1、会话 id 1/5）。
- **引导与承接**：训练页加进度条与「你现在在」承接文案；记录成功（橙色完成与绿色一键两条通道）都弹横幅写明已保存哪组 + 下一组目标；反馈处理结果按状态分文案（已应用调整/已撤销/已忽略/待确认/已记录按计划继续），训练中常驻「最近已应用的调整」条（取服务端 accepted + appliedNote）。
- **建议生命周期**：pendingExpired 纯展示判定——待确认建议要改的同动作后续组全部 done/skipped（或不存在）时显示「未处理，已失效」、禁用接受按钮、组表与总结同步标注；不写回服务端状态，历史 pending 不被自动改成 dismissed。建议卡内嵌「查看规则 X 依据」details，内容与训练原则页同源（getPrinciples），不跳页不丢计时。
- **跳过组拦截**：被跳过的组不进入自动流程（current 取第一个未完成且未跳过组，原有行为）；从组表恢复被跳过的组改为两步确认，AI 建议跳过的组按钮文案为「我知道，仍要做此组」。
- **未填感受**：hasFeedback 判定；训练组表与总结明细对已完成无反馈组明确显示「未填感受（正常状态）」，不伪造 RIR。
- **总结四层**：首屏结果（完成组数/时长/训练量/平均休息 + 存档状态行）→ 本次重要变化（已确认调整 / 规则 A 异常 / 未生效建议三分区）→ 复盘与下次建议（注明建议≠已建计划）→ 完整三列明细默认折叠（details）。
- **Drive 统一组件**：沿用同一 DriveButton（今日总结与历史详情共用同一组件与服务端状态）；已上传态新增「上传修正版」入口（服务端按既有约定生成时间后缀新文件、旧文件保留）；未上传/失败文案按状态机口径（失败明示记录未丢失）。
- **历史/趋势/原则**：历史详情加「正在查看某日记录」头与返回列表按钮、列表卡片显示四种存档状态；趋势错误态给重试按钮（不以 0 冒充）、周趋势可点选看单周场次/组数/训练量、RIR 分布注明未填不入分母、单点动作显示「暂无足够历史数据」；原则页改为 RIR 标尺（常用概念）→ 原则折叠 → 规则 A–G 折叠（触发与裁决/判断依据），与服务端常量同源。
- **测试日开关**：PlanOverview 改走 setPlanTestDay 专用动作（原先误走 savePlan），保存后显示「开 → 关」前后状态反馈，失败明示状态未变。
- **未做/待真机**：logSet 服务端幂等未新增（现为按 setId 的同值更新，重发不记重，沿用既有 8 秒慢提示 + 失败原样重试）；震动/提示音/Wake Lock/通知/切后台计时仍为待真机验证；TC-01–TC-18 未逐项在沙箱回放，仅做了构建与审计核查。

## 原书证据 Skills 接入（2026-11-13 编辑，muse-fitness-evidence-skills-v1）
- **来源包**：`~/workspace/muse-fitness-evidence-skills-v1/`（用户经另一 AI 制作、存 Google Drive「运动书籍 / Muse健身Skills知识包-v1.0」，本地副本已由父任务核对 SHA256 与 manifest 一致）；9 个 Skills + `references/claim-ledger.json` 44 条证据（E01–E44）。包内自述：仅结构验证、章节与关键片段定位核验，未逐字核验全部书页——页面与服务端统一标 SOURCE_LIMITED，不宣称 SOURCE_VERIFIED。
- **只读审计基线（构建前实测）**：22 个既有动作；计划 id 1（testDay=true、组表与备注原文）；会话 id 1（1290kg）与 id 5（9/9、Drive 文件 健身日志-2026-11-13-140546.md、uploaded）无误；getSessionDetail(2) 返回「找不到这次训练」，会话 2/3/4 不存在；getStats 与 16:04 基准一致（2 场/14 组/5170kg、平均休息 189 秒/9 样本、RIR 3/1/0/0/1、有效 RIR 5 组）。
- **服务端接入（只增不改）**：新增 EVIDENCE_CLAIMS 常量——由构建脚本从 claim-ledger.json 程序化生成逐字转录（fact=synthesis、guardrail、scope=muse_use、location、book 按 source-registry 补全名），避免人工改写命题；新增映射 RULE_EVIDENCE（A:E32/E34/E44、B:E06/E07/E15/E26、C:E04/E05/E25、D:E06/E26/E21、E:E26/E27/E17、F:E22/E30/E43、G:E36/E26/E06）、PRINCIPLE_EVIDENCE、METRIC_EVIDENCE（volume/avgRest/rirDist/est1rm，定义文案按 fitness-trend-analytics 口径、数字仍以 getStats 为准）、NEXT_SUGGESTION_EVIDENCE（E04/E05/E25/E26/E30/E43）、NUTRITION_NOTE（文案取 fitness-nutrition 典型输出、不设强制目标，证据 E35/E38/E39/E37/E42）、PLAN_REVIEW_EVIDENCE（E01/E08/E03/E09/E07）、SKILL_ROUTES 路由表；新增只读动作 getEvidence（第 23 个动作）统一下发。evaluateRules、RULES、PRINCIPLES、2-for-2 跨课判定、规则 F 门槛、orig/target/actual、建议制、Drive 约定、savePlan 全部未动。
- **Skills 路由落点**：guardian=全部证据展开的总守门口径（EvidencePanel 固定五段：事实→服务端规则→原书/章节位置→适用→不能推导 + SOURCE_LIMITED 注记）；session-flow + rir-feedback=今日训练既有流程与反馈表单（本轮未改其行为，仅建议卡依据层增厚）；hypertrophy-programming=计划总览「编排依据」；progressions + recovery=总结页下次建议的原书依据；nutrition=总结页「训练后提示（饮食与补水）」；trend-analytics=趋势页「指标定义与原书依据」；technique-safety=规则 A 建议卡证据（E32/E34/E44）与原则页规则卡。
- **客户端改动**：新增 EvidencePanel / RuleEvidencePanel / ruleLetterOf 组件；建议卡三态（pending/已接受/无需改动）新增 RuleEvidencePanel；顺带修复 RuleDetail 旧缺陷——它此前拿完整规则名（「规则 B（…）」）与单字母 id 比对永远查不到、恒显示兜底文案，现先取字母再查。SessionSummary 下次建议区块加依据面板、存档区前加营养提示区块；PrinciplesView 给 RIR 标尺、每条原则、每条规则挂证据并新增「原书证据与 Skills 路由」区块；StatsView 新增指标定义区块；PlanOverview 末尾加编排依据。当前组主屏未塞任何长文，全部按需展开（details）。
- **隔离验收（沙箱副本，生产数据未动）**：见本次交付报告；用沙箱内 2099-01-01 夹具计划/会话验证 T02/T04/T05/T06/T08/T11/T12 类断言，getEvidence 返回 44 条且映射 ID 全部能在账本中找到。

## 规则更正同步（2026-11-13 编辑，按知识库补库更正）
- **更正来源**：Obsidian 知识库补库更正——`给每日健身计划的建议规则.md` 规则 C/F 更正段、`书籍/Starting Strength.md` 失败处理（官网 FAQ《Starting Strength FAQ》“Stalling”节口径）、`书籍/NSCA Essentials.md` 2-for-2 规则（多源讲义/闪卡逐字一致口径）。本次只同步这两条，其他规则 A/B/D/E/G 与 PRINCIPLES 文案不动。
- **规则 F**：RULES F 的 summary 改为 Starting Strength 官网 FAQ 原口径——没完成规定组数次数 → 下次同重量再试一次 → 做成继续加重 → 再失败一次该动作减载 8–10% 再用小增幅爬回去 → 历经 2–3 次减载又爬回后再次停滞且睡眠营养没问题则线性进阶大概结束、转中级编程；旧文案「同一重量连续 3 次训练课都完不成」删除（第三方说法、疑似与 StrongLifts 混淆）。减载周安排不变（容量减半、重量减 10–20%、RIR ≥ 4、不冲不测），两周停滞触发保留。computeDeloadSignal 同步改判定：同动作同重量由连续 3 课失败改为 FAQ 失败两次（slice(-2)），减载原因文案同步写明 8–10% 重置与线性进阶结束条件；deloadNote 的减载周安排文字未改。
- **规则 C**：RULES C 的 2-for-2 措辞改为「连续两次训练课、最后一组超目标 2 次以上，下次加重，加重幅度 2.5–10%」；旧文案「连续两组都比目标多做 2 次」删除（题库误写）。evaluateRules 同步改判定：新增 prevSessionLastSet 入参（submitFeedback 查最近一次含该动作已完成组的已完成会话、取其最后一组），2-for-2 只在本组为本课最后一组且本课与上一课最后一组都超目标 ≥2 次时触发，建议重量按 5%（区间 2.5–10% 内）计算并按 0.5kg 取整；本课内连续两组超标不再触发。规则 C 另一路径（末组 RIR ≥ 2、下肢 2.5–5kg/上肢 1.25–2.5kg）未改。getPrinciples 直接下发 RULES 常量，故「训练原则」页与三处提示词（submitFeedback/finishSession/regenerateAdvice 均拼 RULES summary）自动同步，无客户端硬编码文案需改。

## 风格 N 换肤（2026-11-13 编辑，用户从十八版对比中选定 N）
- **N 规格来源**：对比页（slug mei-ri-jian-shen-ji-hua-feng-ge-shi-li-dui-bi）构建产物中的 `.t-retro` 原始 CSS 与文案——奶油底 #fdf3d8 + 藏蓝 #1d3557 + 红 #e63946，像老式美式健身房海报；Georgia 衬线；卡片 #fffdf0 + 2.5px 藏蓝边 + 18px 圆角 + 4px 红色硬阴影；主按钮红胶囊、一键继续钢蓝 #457b9d 胶囊；步进钮藏蓝圆钮、数值框白底 2px 藏蓝边胶囊；当前动作名斜体；页签选中红。
- **实现方式（只改 client，服务端与数据零改动）**：theme.css 全量换 token（浅色为 N 原版；深色为藏蓝夜版：深藏蓝底 #131f30 + 藏蓝面 #1d3557 + 奶油字 + 亮红 #ff5964 + 钢蓝边）；@theme 加 Georgia/宋体衬线栈与放大圆角阶梯（lg 14 / xl 18）；theme.css 末尾无层 `button{border-radius:999px}` 全局胶囊化（只改圆角不改布局）。App.tsx 定向替换：主卡片模式（26 处）加 2.5px 藏蓝边 + 红硬阴影、当前组面板同处理、休息计时藏蓝块加红硬阴影且其半透明层改用 var(--bg) 透明度（深色下同样可见）、步进 −/+ 改藏蓝钮奶油字、重量/次数/有氧数值框改胶囊粗边、一键继续改钢蓝 token --steel、其下二选一说明颜色名同步（橙→红、绿→蓝）、图表红 #e63946 / 估算 1RM 钢蓝 #457b9d / 网格线 surface2、页签栏 2.5px 藏蓝上边、当前动作名斜体。
- **页面逻辑**：按用户 16:30 详细提示词的交互逻辑保持不变——本轮仅换肤，未改任何流程、状态机、规则 A–G、证据层与动作；计划 id 1、会话 id 1/5 与 Drive 文件未动（本轮无服务端改动、无数据写入）。

## 重量输入框加宽（2026-11-13 编辑，用户反馈三/四位数字如 127.5 容纳不下）
- **当前组面板（主改动）**：重量/次数行由 flex 改为 grid 两列（重量列弹性占满、次数列固定 7rem，原 9rem）；重量与次数的 −/+ 步进钮改固定窄钮（重量 2.5rem、次数 2rem，原靠 px-3/px-2.5 撑宽），输入内边距收窄，把横向空间让给数字本身；重量输入字号按内容长度自适应（≤4 字符 3xl、5–6 字符 26px、≥7 字符 2xl），127.5 与 1000.5 这类三/四位数加小数都完整显示不截断。
- **计划总览补填重量**：行内补填框 w-24 → w-32、字号 text-sm → text-base。
- **计划编辑器**：每组重量框 w-20 → w-28 且字号升 text-base，整行改 flex-wrap，窄屏放不下时换行而不是挤压输入框；次数/休息框保持 w-20 并加 shrink-0 防压缩。
- **范围**：只改 client/src/App.tsx 三处输入的样式类名，输入逻辑、步进幅度（±2.5kg）、服务端与数据零改动。

## RIR 胶囊白话化与排布修复（2026-11-13 编辑，用户反馈看不懂且「0 变形」叠放）
- **问题**：反馈表单证据 2 的五个 RIR 选项（3+/2/1/0/0 且变形）挤在一行 flex，手机上每格约 60px，「0 且变形」与 10px 副标题被压得叠在一起；且只写数字、含义靠下方小字，用户看不懂。
- **改法（只改呈现，档位数值与联动逻辑不动）**：主表单改为两列网格、每格 min-h-16 左对齐，按钮主文案直接写白话——「还能做 3 个以上（偏轻）/ 还能做 2 个（目标区间）/ 还能做 1 个（接近极限）/ 还能做 0 个（一个也做不了，已力竭）」，第五档「0 个，且动作变形了」整行占满并写明「技术力竭，按规则 A 停」；标题改为「做完停下时，还能标准地再做几个？」并注明这就是余量 RIR；下方说明同步改白话。旧版补填横幅（LegacyBanner）的同款五档同步改两列网格 + 白话标签（pick 值 3/2/1/0/9 不变）。统计页 RIR 分布标签「2 次/1 次」统一为「2（还能做 2 个）/1（还能做 1 个）」，标签列加宽防挤压。
- **不变**：rir 存储口径（3=3+）、第五档联动 rir=0+deform=变形、规则 A–G 裁决、服务端 RIR_SCALE 与证据层均未动。

## 动作备注收起与一键继续胶囊去符号（2026-11-13 编辑，用户截图反馈）
- **动作备注默认收起（只改呈现，备注原文数据不动）**：当前组面板与计划总览里整段平铺的动作备注（如深蹲「递进摸底：60kg×5 热身 → …务必用深蹲架保护杆…」）改为原生 details 默认折叠，只露一行「动作要点（点开看，默认收起）」，点开才看全文；当前组主屏回到只看动作名、组号、重量与次数。训练页组列表本来就不渲染备注，无需改。
- **一键继续胶囊**：按钮文案去掉 ⚡ 符号，改为纯文字「一键按计划继续（RIR 2 / 正常）」；按钮加 whitespace-nowrap 且字号在窄屏降为 text-sm，保证整行单行不换行、不被挤断。按钮行为（logSet + quickContinue、RIR 2 / 正常口径）未变。

## 反馈栏上主屏与 RIR 说明删除（2026-11-13 编辑，用户截图反馈）
- **删 RIR 解释（只删解释，不删问题）**：FeedbackForm 证据 2 选项下方那段说明（「平时待在『还能做 2 个 / 1 个』最合适……完整标尺见底部『训练原则』页」）整段删除；证据 2 标题里的定义括注「（这个数就叫余量 RIR，选最接近的一项）」也删掉，标题只留提问本身「做完停下时，还能标准地再做几个？」；各档白话标签、档位数值、第五档联动与规则 A–G 裁决未动。用户原话：这句不需要再解释、已经知道了。
- **写给 AI 的反馈栏提到主屏（只改 client 呈现与入口，服务端零改动）**：原先反馈表单的备注只是表单底部一行小输入「补充说明（可选）」，且休息区入口是折叠的可选按钮。现改为——FeedbackForm 顶部（证据 1 之下、证据 2 之上）新增红边框区块「写给 AI 的反馈记录」：3 行 textarea + 一句说明（写完提交后 AI 结合证据按规则 A–G 裁决、实时调整还没练的组），仍写入同一 note 字段、走同一 submitFeedback（服务端本就用 note 做变形关键词客观触发与教练提示词输入）；底部旧「补充说明」输入删除，提交按钮文案改「提交反馈，让 Muse 调整后续组」。
- **休息时自动打开**：completeCurrent 记录成功进入休息后，力量组若尚无反馈、无既有建议，自动打开该组反馈表单（表单紧贴休息区下方渲染，即训练主屏）；休息区原折叠按钮改为重开入口（文案去掉「可选」），表单打开时显示「先不写反馈，收起（按计划继续）」；一键按计划继续路径仍显式关闭表单、不调 AI；有氧组不自动打开（其喘息程度仍走原快速通道）。记录成功横幅文案同步改为指向已打开的反馈栏。
- **开始前完整计划（核查确认，未改代码）**：PlanOverview 本就逐动作、逐组展示当日完整计划（每组重量×次数与休息秒数、动作要点折叠），其下才是「开始训练」按钮——满足「开始训练之前展示总的当日训练计划」，本轮不动。

## 删除「训练提醒」开关（2026-11-13 编辑，用户指令）
- **删除范围（只改 client/src/App.tsx）**：今日页的 NotificationSettings 组件（开关、权限状态、说明文案）整段删除；NOTIF_PREF_KEY（fitness-notif-enabled）、notifSupported/notifEnabled/setNotifEnabled、fireNotification 全部删除；五处系统通知触发全部摘除（Drive 上传成功/失败、Muse 建议到达、结束训练摘要生成、休息结束）。服务端动作、数据零改动；既有 localStorage 里的旧偏好键不再被读取，无害残留。
- **保留的页面内提醒**：休息结束横幅（仍写明下一组动作/组号/目标）、建议到达与记录成功的页面内横幅、buzz() 震动全部触发点、休息结束 Web Audio 提示音、Drive 状态条文案均原样保留。
- **Wake Lock 解绑**：屏幕常亮原先挂在通知开关下（开启提醒才申请）；开关删除后改为训练进行中自动申请（TrainingView 挂载即申请、切回前台重申请），「已激活屏幕常亮，防止计时器休眠」绿色状态字保留——常亮是防计时休眠的功能，与系统通知无关。

## Y 换肤实施（2026-11-13 晚，设计师交付包 01/02/06）
- **范围**：只改 client/src/theme.css（整份换为 Y token：墨绿黑 #0B1210 + 青柠 #B9F27D + 玻璃 L1–L4）与 client/src/App.tsx（四态单向流程、建议卡三态、总结四层、历史/趋势/原则重排、18 动效 WAAPI 单实例、骨架屏、SHEET/Toast 基础设施）。server/、drizzle/、space.json 零改动；23 个动作与全部真实数据（计划 id 1/2、会话 id 1/5、统计 2 场/14 组/5170kg/平均休息 189 秒）经 invoke 回读逐字核对未变。
- **06 增量落地**：删除「按计划完成」按钮，D2 主操作只剩实色青柠「完成」+ 草稿步进/点按输入（重量 (0,400] 1 位小数、次数 [1,99]，非法红描边不发请求；未设重量显示「—」可直接完成）；「填感受再记」降级为 48px 热区文字链，两路共享同一草稿，草稿只作 actual 提交、绝不写回计划。
- **E20 笔误显示修正**：证据文本里的「NSCA2026」在客户端渲染时替换为「NSCA 第 5 版 2027」（fixEvidenceText），服务端原文未动，待知识包作者更正源文件后可撤下此替换。
- **已知折中**：RestTimer 倒计时字号取 52px（规格 72px 在 150px 环内会溢出）；D3 键盘贴合上移、慢网 8 秒条、真机震动/提示音/Wake Lock/后台计时/Drive 失败分支未在本次构建环境实测，待真机验证。

## ATI 统一决策体系落地（2026-11-14 编辑，设计源：~/workspace/ATI_自适应训练智能系统_设计v1.0.md）
- **服务端**：`evaluateRules`（规则 A–G 硬编码裁决）整体删除，替换为统一训练决策协调器 `runAtiDecision`：观察状态 → 构建 §10.3 上下文 JSON（event/goal/planned/actual/recovery/history/constraints，睡眠与营养无数据源时恒为 null 并标「未记录」，不补默认值）→ 按话题从 44 条证据账本检索（ATI_TOPIC_EVIDENCE）→ 模型从 14 个可组合裁决动作（ATI_ACTIONS）返回 §10.4 结构化裁决 → 确定性安全校验 `validateDecision`（停止信号强制 STOP、重量 ≤ 参考重量×1.1 取 0.5kg、休息 30–600 秒、测试日保护、T16 钳制：达标+RIR 3+ 时休息不得超过原定值、低置信度 <0.5 剥夺加重/加组）→ 不合格要求模型重生成一次，仍不合格走保守兜底（停止信号→STOP_EXERCISE+RED；其余→按原定休息 CONTINUE）。准备度六维权重（表现 30/睡眠 20/疲劳 15/酸痛 10/营养 15/心理 10）由服务端按已提供维度归一化重算，模型给的 overall 不采信；恢复分层 GREEN/BLUE/AMBER/RED 只作展示，停止信号强制 RED。智能休息基础表 REST_TABLE（深蹲/硬拉 180–300、卧推/划船/肩推/引体 120–180、上斜/腿举 120–180、孤立 60–90、腹部 45–90），旧「达标固定 +60 秒」已删除。finishSession/regenerateAdvice 的复盘与下次建议改走 ATI_REVIEW 提示词 + 纯事实 historyFactsText，服务端不再拼接规则 F/G 结论。getPrinciples 改为返回 ati 块（loop/actions/restTable/recoveryLevels/readiness/safetyBoundaries），getEvidence 新增 atiTopics，ruleEvidence 仅为历史兼容保留。proposal 新增 atiActions/confidence/recoveryLevel/readinessOverall/evidenceIds（带默认值，旧建议 JSON 仍可解析）；set_logs.ai_rule 新记录写「ATI · 主裁决动作中文名」，历史行原文不动。无 schema 迁移（仅 schema.ts 注释更新）。
- **客户端**：反馈卡与依据弹层改用 AtiMetaLine（恢复色点+准备度+置信度+组合动作）与 AtiEvidencePanel（按裁决自带 evidenceIds 展开账本原文）；训练原则页重写为 ATI 体系页（决策循环八步、14 动作网格、智能休息表、恢复四层、准备度权重、安全边界、RIR 标尺、原则、skill 路由、按 ATI 话题筛选的证据库）。Y 风格与四态单向流未动；重量输入框整行+步进器下一行的版式未动（探针实测 127.5 完整显示）。
- **数据完整性（提交前 invoke 回读核对）**：计划 7 个（id 1–7：11-13 摸底/11-14 上肢/11-16 胸/11-17 背/11-18 腿/11-19 肩/11-20 手臂+核心）重量次数组数原样；会话 id 1/5/6 与 27 条逐组记录未动，getStats 与改造前基线逐项一致（3 场/27 组/7670kg/平均休息 200 秒/RIR 分布一致）；44 条证据原文未动（E09/E26 中提及 A–G 的 guardrail 是账本原文，按约束保留）。
- **沙箱模拟验证（2099-01-01 夹具，仅沙箱库，不出货）**：①T16 场景（卧推 70×8 达标、RIR 3+、未变形、关节正常）→ 裁决 CONTINUE+MAINTAIN_LOAD、休息 120 秒 = 原定值未加 60 秒，引用 E04/E05/E07/E15/E25，GREEN、准备度 81.5、置信度 80%；②停止场景（第 2 组关节刺痛）→ STOP_EXERCISE+GATHER_INFORMATION+MODIFY_NEXT_SESSION、RED 强制、setsDelta −1、引用 E32，respondProposal 接受后第 3 组被跳过（appliedNote「已应用：跳过第 3 组」）。

## ATI Planner 规划层落地（2026-11-14 编辑，设计源：~/workspace/ATI_目标导向训练规划系统_完整设计文档v1.0.md + 运行提示词与决策契约 + 共享知识库规范；成人处方为用户 2026-11-14 19:45 决定，19:48/19:49 追加「用最先进理论、不必墨守成规」「11-16~11-20 五天也要重排、不必保留旧分化表」）
- **统一循环**：Planner 与实时 ATI 共用上下文（目标/约束快照、现行计划、跨课历史事实、最近复盘建议、Planner 事件）、共用 44 条账本与确定性安全边界；不另造规则引擎，不写死分化/容量/动作路径，旧规则 A–G 与「每周固定 +10%」不进 Planner。分化、动作组合、容量由模型按 ACSM 2026 / Pelland 2026 等最新证据与实测状态现判（服务端只做校验：目标周内日期、有会话日期禁改、单次时长估算 ≤ 上限+10 分钟、周工作组 ≤ 当前可恢复水平 1.25 倍、重量 0–400kg；校验不过要求重生成一次，再不过不保存）。
- **数据模型（迁移 0007，只增不改）**：新增 plan_versions（设计 §13 PlanVersion 全字段：goal/constraints 快照、weekly_schedule、exercise_prescriptions、proposal_days（仅提案有，确认时据此写 plans）、muscle_volume、time_budget、progression/recovery 假设、evidence_manifest、uncertainties、safety_notes、diff_summary、status current/proposed/superseded/rejected、origin baseline/planner）与 planner_events（只追加：ati_modify_next_session / ati_stop_signal / plan_generated / plan_confirmed / plan_rejected）。submitFeedback 在裁决含 MODIFY_NEXT_SESSION 或停止信号时各追加一条事件（只记事件、不改任何计划），下一次 generatePlan 把最近事件作为输入。
- **动作建模（设计 §5）**：EXERCISE_CLASS_RULES 按名称归类动作模式（水平推/垂直推/水平拉/垂直拉/膝主导/髋主导/单侧/核心/携重/有氧等）与主/次肌群；直接组 1.0、明显间接 0.5、极轻 0，原始直接组与折算总量分开存与展示，0.5 标注为 Pelland 2026 fractional set 研究估算模型、非生理常数；推类对前三角/肱三头只记 0.5 间接，不重复整组计入（v1 实测：胸直接 12、肱三头直接 6+间接 12→折算 12、前三角直接 6+间接 9→折算 10.5）。
- **v1 基线**：getPlanner/getPlanVersions 首次调用时把 2026-11-16~11-22 已排分化周登记为 v1（status=current、origin=baseline、65 个工作组、计划 id 3/5/7/4/6 对应 11-16/17/18/19/20），只登记不改 plans；目标快照=成人处方（70kg/强壮威武主目标、卧推 120/深蹲 130 做组参考、跑步次要、不承诺结果），约束快照=55–95 分钟硬约束、每天可练、容量从 65 组可恢复水平起步、11-15 考试与 11-21 休息、实测锚点与恢复状态（睡眠约 6h、飞鸟撕痛史）。旧分化表按用户最新指示只保留在版本历史，等待被新提案取代。
- **新动作（第 24–28 个）**：getPlanner（目标/约束/当前版本/待确认提案/最近事件/fractional 说明）、generatePlan（统一上下文→账本检索 PLANNER_EVIDENCE_IDS 12 条→模型结构化提案→确定性校验→落 proposed + 服务端逐项 diff + evidence_manifest；模型失败或两次校验不过返回 ok:false 不保存）、confirmPlan（生效前复查目标日期无任何会话才逐日写 plans：训练日更新保留 testDay/新建 testDay=0、休息日删计划；旧 current 转 superseded）、rejectPlan、getPlanVersions。
- **证据清单（设计 §12/知识库规范）**：每次提案附 manifest：实际引用账本条目（SOURCE_LIMITED、章节定位）+ ACSM 2026（部分全文、本次未回读标未核验，DOI 10.1249/MSS.0000000000003897 出自设计文档）+ Pelland 2026（摘要级、Springer 全文未获取标未核验，DOI 10.1007/s40279-025-02344-w 出自设计文档）+ Held 2026（摘要级）+ 九本书（整章级未核验，不声称精读）；模型 evidenceIds 只允许账本内编号，账外剔除。
- **界面（设计 §15，按钮越少越好）**：新增第五页签「训练规划」：唯一生成入口（底部抽屉：一句自然语言说明 + 可选目标周/天数/时长）、待确认提案卡（差异清单 + 为什么这样安排 + 确认/拒绝两步确认）、当前计划视图（周安排/直接-间接-折算组数表/动作处方/证据展开）、目标与约束快照、反馈影响事件流、版本历史；未新增任何加组/减组/换动作类按钮。Y 风格与四态流未动，导航指示条改 w-1/5。
- **沙箱验收（副本库，生产未动）**：基线 getStats 前后一致（3 场/27 组/7670kg/平均休息 200 秒）；v1 登记 65 组无误；generatePlan(11-16 周) 一次通过校验生成 v2 提案（上下肢×2+手臂核心轻松跑、64 组、主要肌群频率 2 次/周、附 13 条 manifest 与待确认问题）；confirmPlan 后 11-16 写入新计划（id 3 不变）、11-18 休息日计划删除；generatePlan(11-23 周，3 天/55 分钟) 自动重分化为 3 天全身 36 组、单次估算 ≤65 分钟，rejectPlan 后当前版本仍为 v2；T16 回归（2099 夹具）仍通过（CONTINUE、休息 120 秒未加时）；关节刺痛夹具 → STOP_EXERCISE+RED 且 planner_events 落 ati_stop_signal 一条。
- **出货提案**：post_submit_action 对正式库调用一次 generatePlan{weekStart:"2026-11-16", requestNote: 按成人处方与最新证据重排本周}，使 v2 提案随交付备好待用户过目确认（提案不生效、不改任何 plan；生成失败时用户可在「训练规划」页手动点生成）。

## ATI Planner v2.0 落地（2026-11-14 编辑，设计源：~/workspace/ati_v2_docs/ 三篇 v2.0 文档 + v2.0.1 修订；成人定位为用户 2026-11-14 21:50 定版）
- **三层分离（服务端常量，无新迁移）**：决策动词仍是 ATI_ACTIONS 14 个（裁决类型）；新增 EXERCISE_LIBRARY 51 条（kb_v2.0.md 第六节逐条转录：9 大类、含跑步机有氧条目；字段含模式/主次肌群/设备依赖/技能/出处/证据评价/停止条件/替换链），状态 ACTIVE 35 / CONDITIONAL 13 / PROVISIONAL 3；新增 EQUIPMENT_SNAPSHOT ATI-EQ-1.1（20 项已确认器械 + 7 类未确认细节与门槛规则，髋铰链固定器械只按用户描述登记、商品名未知不命名）；新增 EVIDENCE_GRADES E1–E6（E5/E6 当前登记为无，未核验不编造视频）。getPlanner 下发快照、库状态统计与分级说明；规划页新增「器械快照 · 动作库」折叠区，训练原则页新增 v2.0 三层区；未新增操作按钮。
- **硬过滤与反锚定（确定性校验）**：validateLibrarySelection——提案动作必须命中库条目且为 ACTIVE，未入库（无出处登记，如双杠臂屈伸/绳索面拉/悬垂举腿等旧名）与 CONDITIONAL/PROVISIONAL 一律判违规、两试不过不保存；validateSelectionRationale——每个被选动作必须有七问记录（为什么选/书与文献评价/替代候选/为什么没选替代/时间与疲劳/相反结论/历史作用），唯一依据是「提过一次」判 EVIDENCE_INSUFFICIENT；anchoringAuditLines 生成前做锚定审计，ROTATION_REVIEW 行写入提案 rationale。七问记录由 buildSelectionManifest 与库条目出处/评价合并进 evidence_manifest（sourceType「动作选择记录（v2.0 七问 + 反锚定）」）；manifest 另补 Haugen 2023（E1，标未核验）与视频证据条目（未登记，如实说明）。
- **生成分两步**：单次调用同时产出整周组表 + 全部七问会触发平台推理超时（沙箱实测 "Web artifact inference timed out"），generatePlan 改为同一次生成内两步推理——先 plannerPlanOut 出结构（校验不含七问），再 rationaleBatchOut 按已定动作名单逐条补七问（带库条目原文评价），合并后全量校验才落库。提案 schema 次要字段加默认值，偶漏字段由语义校验驱动重试而非整次失败。
- **成人定位（21:50 定版）**：系统仅面向成年人——删除全部青少年条件表述（PLANNER_GOALS.prescriptionProfile、Planner 系统提示、v2.0 注释），无青少年配置/默认处方/年龄分支；目标快照明记 70kg、卧推做组 120kg、深蹲做组 130kg、强壮威武为优化目标、跑步次要、ACSM 2026 适用人群 ≥18 岁。44 条账本原文（E11 等）按硬约束未动。旧版本行里存的笼统器械表述不回改，getPlanner 展示层与 generatePlan 新版本统一覆盖为 ATI-EQ-1.1 口径（EQUIPMENT_CONSTRAINT_TEXT）。
- **沙箱验收（副本库，生产未动）**：改前基线 getStats 3 场/27 组/7670kg/平均休息 200 秒、RIR [5,1,0,5,1]、版本 id1 current/id2 superseded/id3 proposed 与改前一致；T16 回归（2099 夹具，卧推 70×8、RIR 3+、未变形）→ CONTINUE+MAINTAIN_LOAD、休息 120 秒未加时；generatePlan(11-16 周，v2.0 规则) 生成 v3 提案（id 4，64 组）：26 个处方动作全部命中 ACTIVE（22 条七问记录进 manifest、共 38 条），11-16 保留胸日、背日以高位下拉/坐姿器械划船起手（引体只在周五第二位）、11-21 休息不变、锚定审计留痕；提案未生效，11-16 计划（id 3）逐字未变；旧提案 id 3 按既有语义转 superseded 保留在历史（未删除、未生效）。
- **出货提案**：post_submit_action 对正式库调用一次 generatePlan{weekStart:"2026-11-16", requestNote: 按 ATI v2.0 规则重排 11-16 至 11-20、保留 11-16 胸日}，使 v3 提案随交付备好待确认（不生效、不改任何 plan）。

## v2.0 落地补修（2026-11-14 编辑，用户实机核对发现两处未完成）
- **问题一 · §5 字段补齐与去重（数据源：~/workspace/ati_v2_docs/kb_v2.0.md 第五节 §5 字段清单 + 第六节条目原文 + 末尾 v2.0.1 数据清理说明）**：EXERCISE_LIBRARY 拆为原始转录（LibraryExerciseBase）+ LIBRARY_SECTION5 补齐表，逐条补齐 variation_id、stabilizers、equipment_snapshot_match、technique_cues（kb「技术」原文）、common_errors（由技术要点/停止条件直接引申，不引入文档外断言）、population_scope（成人定位 + 条目适用原文）、time_setup_cost、fatigue_cost（局部/全身/确定性）、progression_options（按快照哑铃 2.5kg/杠铃 5kg 档位口径），并新增独立 source_status 字段（与计划可用性 status 同值登记）、kind、last_reviewed_at=2026-11-14、version=2.0.1；缺补齐数据在模块加载时直接抛错，不允许半成品入库。按 v2.0.1 清理说明合并原条目 21 与 25（同一台坐姿反手下拉器械）为单一 EX21（别名保留：反手坐姿划船/坐姿反手下拉/反手坐姿背部下拉，PROVISIONAL 不变）。计数口径（LIBRARY_COUNTS，全站唯一）：唯一动作/变式 50 = 力量 49 + 跑步机有氧 1（EX51，kind=cardio 单列）；状态 ACTIVE 38 / CONDITIONAL 10 / PROVISIONAL 2（修正上一轮自报 35/13/3 与总数 51 的错误）。getPlanner 新增 library 全字段下发，规划页动作库区逐条可展开核对 §5 字段；getPrinciples 与规划页计数文案同步为新口径。CONDITIONAL/PROVISIONAL 仍不得进入正式计划；未核验字段（EX21/EX39 的轨迹、疲劳、进阶）如实写「未核验」，未虚构页码/DOI/视频/引语。
- **问题二 · generatePlan 补救路径（修复实机两次 EVIDENCE_INSUFFICIENT 整份失败）**：三段补救——(1) 生成前锚定审计提前拦截：计划结构定稿后、写七问之前，anchorPrecheckLines 按库条目算出每个入选动作的同模式 ACTIVE 替代候选（samePatternActiveAlternatives：替换链优先 + 模式检索），对当日首项与库内评价已点名「不是默认首选」的条目（正握引体向上）发明确警告并注入第二步提示词，锚定式依据在写七问时就被拦下；(2) 两轮批量七问仍有违规时按违规点名逐个补救：被判 EVIDENCE_INSUFFICIENT 的动作先做同模式替代定案（按替换链换成 ACTIVE 替代，如引体→高位下拉，组数与结构不变、note 标注补正），再对每个出问题动作单独定向重生成一次七问（带服务端候选名单与违规原文）；(3) 定向重生成仍不合格时用 buildFallbackRationale 按库条目已登记数据（出处/评价/技术要点/§5 时间与疲劳成本/替换链）拼服务端补正七问，historyRole 明确「未起作用」。单个选择失败不再拖垮整份提案；全部补救逐条记入版本 rationale 的段公开标注；补救后仍不过校验才放弃保存。validateSelectionRationale 抽出 rationaleItemViolations 单条校验供三处共用（锚定正则语义不变）。实测教训：替代候选名可短至 2 字（「死虫」），补正七问的 alternative 字段须写成「名称（编号，同模式 ACTIVE 条目）」的实质表述，否则会被自身的 ≥4 字实质内容校验拦下。
- **沙箱验收（副本库，生产未动）**：改前基线 getStats 3 场/27 组/7670kg/平均休息 200 秒、版本 id1 current/id2 superseded/id3 proposed 与改前一致；getPlanner 核对库总数 50（49+1）、ACTIVE 38/CONDITIONAL 10/PROVISIONAL 2、EX25 已并入 EX21、50 条 §5 字段无一缺失；generatePlan(11-16 周，75 分钟上限) 完整生成 v3 提案（沙箱 id 4，64 组，proposed）：背日以坐姿器械划船（11-16）与高位下拉（11-19）起手、引体未入选且 rationale 写明七问比较过程，补救路径真实触发一次（平板支撑定向重生成并留痕），11-21 休息不变；11-16 现行计划（plan id 3）逐字未变，getStats 与 44 条证据生成前后不变；ATI 实时决策循环、Y 风格、成人定位与目标快照均未动。
- **出货提案**：post_submit_action 对正式库调用一次 generatePlan{weekStart:"2026-11-16", minutesPerSession:75, requestNote: 按 ATI v2.0 规则重排 11-16 至 11-20、背首项按证据定案不默认引体}，使 v2.0 规则新提案随交付备好待确认（不生效、不改任何 plan；按既有语义旧提案 id 3 转 superseded 保留在历史、未删除未生效）。

## v2.0 补救残留修复 · 单个选择降级（2026-11-14 编辑）
- **问题**：v24 后沙箱第一次 generatePlan 中，11-17 与 11-22 两条「平板支撑」选择记录经逐个补救仍未通过校验，整份提案仍被放弃保存（versionId 为 null），第二次调用才成功——「单个选择失败不拖垮整份提案」只做到一半。
- **修复（generatePlan 第二步降级层，补救 (1)–(3) 之后、结构校验之前）**：补救后仍违规的每个选择逐日降级——(a) 优先同模式 ACTIVE 强制替定：换成 samePatternActiveAlternatives 的同模式 ACTIVE 条目（当日未排入者优先），替定条目的七问须先通过 rationaleItemViolations（已有合格记录则沿用，否则用 buildFallbackRationale 按库条目补正，alternative 写成含名称/编号/模式的实质表述），并在 repairNotes 写明原选择为何被降级（违规原文）、替定条目（编号+名称）、定案依据（出处+库内评价）；(b) 无法替定（无同模式 ACTIVE 候选、当日候选已全部占用、或替定补正仍不合格）时剔除该动作并在 repairNotes 写明剔除原因；剔除后当日无动作剩余则该日改为休息日并标注。降级循环逐轮重验 validateSelectionRationale，每轮至少替定/剔除一个出现位置、必然收敛；最终放弃分支只剩结构/安全类违规（时长/容量/日期/库过滤）可达，选择记录类违规不再能让整份提案被放弃。
- **沙箱验收（副本库，生产未动、未在生产调用 generatePlan）**：基线 getStats 3 场/27 组/7670kg/平均休息 200 秒、44 条证据（E01–E44）、版本历史（id 5 为 current，系用户已确认版本，未动其状态）与 11-16 现行每日计划生成前后逐项一致；构造场景（两日排平板支撑 + 一日内同排正握引体/高位下拉/反握引体三个垂直拉）调用 generatePlan：提案一次保存成功（沙箱 id 6，proposed，versionId 非 null），平板支撑选择记录在补救层被服务端按 EX49 库条目补正并留痕——本次未走到降级层（补救 (3) 已救回），降级层为补救全失败时的最后兜底，按构造保证收敛。

## 核心动作更新（2026-11-15 编辑，只改动作库）
- **背景**：用户 2026-11-15 00:05 确认核心最终定法——平板支撑出局（不再计腹肌组数，EX49 条目本身不改动）；主项 = 绳索卷腹（上腹、可加载）+ 高卷腿（下腹、离心为主），每周 2 次、每次各 3 组、共 12 组；悬垂举腿降级为条件变式、不进正式计划（本次不入库）。本次只动 EXERCISE_LIBRARY 代码常量，不动任何计划/会话/逐组记录/版本历史/统计/44 条证据账本/成人处方/Y 风格，未调用 generatePlan、未生成提案；11-15 与 11-22 计划里平板支撑换高卷腿由主代理随后用 savePlan 单独处理。
- **编号决定**：任务书指定高卷腿为 EX51，但 EX51 已被跑步机有氧条目占用（且 kind 判定与 §5 补齐均按 EX51=有氧登记），为不改动任何已有条目，高卷腿顺延为 **EX52**、绳索卷腹为 **EX53**；新条目 lastReviewedAt=2026-11-15、version=2.0.2，既有条目保持 2026-11-14 / 2.0.1。
- **EX52 高卷腿（ACTIVE）**：§5 全部字段齐备。证据只写已核验项：E3 Escamilla et al. 2006（Physical Therapy）反向卷腹模式（支持动作模式，高卷腿为其躺姿固定版）；E5 东哥（账号「烧毁一切就是美」，东京健美公开赛冠军）视频《练腹肌，我只推荐这个动作！》https://www.bilibili.com/video/BV17noEYhEUU/（2025-04-14，已实际观看，字幕原话「练腹肌高卷腿最有效」）；解剖依据（腹直肌不跨髋、只在脊柱屈曲/骨盆后倾时工作）。条目内写明与龙旗的区别（屁股先着地护腰）与同悬垂举腿的关系；东哥「悬垂举腿最差」标注为其个人观点、不作证据。器械（可调角度训练椅调平 + 杠铃杆）均在 ATI-EQ-1.1 已确认项内。EVIDENCE_GRADES 的 E5 注记同步改为已登记此 1 条。
- **EX53 绳索卷腹（CONDITIONAL，核查后新增）**：核查结论——原库无绳索卷腹条目（核心仅 EX49 平板支撑、EX50 死虫）。状态判定按任务书标准：龙门架/绳索站已确认，但绳索把手附件仍在 ATI-EQ-1.1 未确认项内 → CONDITIONAL，条目内写明「待用户确认绳索把手附件后转 ACTIVE」。证据：Nippard 加权卷腹为首选上腹动作按 2026-11-14 23:20 核查结论登记转述，具体视频标题/URL/时间戳本次未复核、如实标未核验，不单独作评级依据；NSCA 5e Ch17 模式依据（E4）。
- **总数**：现库 52 个唯一动作/变式（力量 51 + 跑步机有氧 1）；ACTIVE 39、CONDITIONAL 11、PROVISIONAL 2。LIBRARY_COUNTS 为动态计算，getPlanner / getAtiSystem 两处下发自动一致；getPlanner 的 librarySummary.note 文案已同步为 52/51 口径。

## source_status 独立字段修正（2026-11-15 编辑，只改 EX52/EX53 两字段）
- **问题**：上一轮入库时 sourceStatus 直接取自条目 status，EX52 高卷腿的 source_status 显示为 ACTIVE，「已核验（verified）」只写在 appraisal 文案里。按 kb_v2.0.md §5，source_status 是独立于状态的字段。
- **修正**：新增 SourceStatus 类型（LibraryStatus | "verified"）；EXERCISE_LIBRARY 构建处 EX52 单独登记 sourceStatus="verified"（证据 Escamilla 2006、东哥视频、解剖依据均已核验；其 status 仍为 ACTIVE 不变，variation_id 保持 core/gao-juan-tui-lying-fixed）。EX53 绳索卷腹：代码库与 kb 中均无为 CONDITIONAL 条目另设的「未完全核验」source_status 约定值（kb §5 只定义 ACTIVE/CONDITIONAL/PROVISIONAL/INACTIVE 四档），故按任务书兜底口径保持现有值 CONDITIONAL，不得写 verified；其来源未完全核验的事实已在其 source 文案中如实标注（Nippard 结论未复核、绳索把手附件未确认）。
- **解耦（保证统计与计划逻辑零变化）**：原先按 sourceStatus 统计/筛选的三处改按 status——LIBRARY_COUNTS（ACTIVE 39/CONDITIONAL 11/PROVISIONAL 2 不变）、samePatternActiveAlternatives（同模式 ACTIVE 替代候选，EX52 仍可被选为替代）、getPlanner 的 nonActive 清单（仍为 13 条、EX52 不误入）。validateLibrarySelection 与 generatePlan 提示词本就按 status 过滤，未动。未动任何其他条目、计划、会话、逐组记录、版本历史与 44 条证据账本，未生成提案。

## 「空间没更新」修复（2026-11-15 编辑）
- **诊断**：数据层无误——v4（id 6）已是 current、确认事件在、11-16~11-21 每日计划已按推/拉/腿写入、11-22 计划已删、统计 3 场/27 组未动。问题在可见性与旧口径两处：(1) 今日页默认落在今天（11-15），而 v4 按设计从 11-16 起、11-15 计划故意未动，页面上没有任何「新一周已生效」的提示，看起来与确认前一模一样；(2) 休息日在 getDay 只返回 plan=null，今日页一律渲染「还没有训练计划 / 新建计划」，与「11-22 整休」说法直接冲突；(3) 规划页约束快照仍是更正前旧口径——recoveryState 写「睡眠约 6 小时」、fixedRest 写「11-15 休息、11-21 休息」，与已生效安排和用户 2026-11-14 的睡眠更正（平均 7.5 小时）都不符，generatePlan 还会把旧 recoveryState 带进新提案。
- **修复（无迁移，只改读写口径与今日页）**：getDay 新增 plannerDay（该日在当前生效版本周安排中的 kind/title/version）与 currentWeek（当前生效版本整周安排）；今日页新增「当前生效计划」周安排条（整周逐日可点选，选中日不在该周时明示「这一天不在这周安排里、计划未被改动」），休息日改为「休息日 · 整休」卡（保留临时新建入口），周安排为训练日但每日计划缺失时明示数据不一致。恢复口径新增 RECOVERY_STATE_TEXT 常量（平均 7.5 小时口径），PLANNER_CONSTRAINTS、getPlanner 展示层（同器械口径覆盖法，存量版本行不回改）、generatePlan 约束构建与提示词统一覆盖；getPlanner 的 fixedRest 改为按当前生效版本周安排实算 rest 日期生成。

## 首页不滚动恢复（2026-11-15 编辑，设计师 spec 01 §C.1 D1）
- **范围**：只改 client/src/App.tsx 的 PlanOverview 呈现；服务端、数据零改动（提交前 getDay(2026-11-15) 回读：计划 id 9 五个动作的组表/重量/备注逐字未变）。
- **紧凑行**：每动作一条 60px 行——第一行动作名 + 组数，第二行 13px 次要正文（新 helper exerciseSummary）：每组「重量 × 次数」以 · 行内分隔，未设重量写「重量未设」，时长型次数（「20分钟」等含单位字）只写次数本身，目标组间休息全组一致时行尾写一次、不一致逐组带上。
- **计划区定高**：动作列表容器 height:453px + overflow-y-auto + overscroll-behavior:contain，超出只在区内滚；「开始今日训练」CTA 与上次归档行在容器之外、底部导航不动，首屏不整页滚动。「编排依据」证据面板移入计划区末尾（仍在区内滚动范围），保证首屏固定元素不被挤出。
- **要点默认收起**：行默认收起，点行展开动作要点全文与逐组明细（含未设重量的行内补填入口，updatePlanSetWeight 行为不变）；训练中 TrainingView 的 D2 首屏无滚动约束未动。

## 主界面滑动无反应修复（2026-11-16 编辑，用户真机反馈）
- **故障定性**：今日页计划区是定高 453px 的内层滚动区且带 `overscroll-behavior: contain`，占主屏大半；矮屏上页面本身需滚动时，从列表起滑、列表到边界后手势被 contain 吞掉不链回页面，表现为上下滑动没反应（内容长短/屏高不同导致间歇触发）。证据包渲染与控制台无报错，属手势链问题而非渲染故障。
- **修复（只改 client）**：计划区 overscrollBehavior 改回默认 auto 并显式 `touch-action: pan-y`，滚动到边界链回页面；453px 定高与区内滚动的设计不变。Toast 提示条（fixed、z-40、无可点元素）加 `pointer-events: none`，消除其显示的 2.6 秒内盖住区域吞起滑手势的间歇拦截。服务端与数据零改动。

## 先反馈再记录修复与依据隐藏（2026-11-17 编辑，用户真机反馈 + 两条核心思想）
- **故障定性（证据）**：当前组面板的「填感受再记」文字链误接到 completeCurrent（与「完成」同一处理函数），点一下就 logSet 落库、进休息，之后才自动打开反馈表单——顺序与按钮文案相反，用户想先填反馈永远填不上。沙箱复现与修复均用 2099-01-01 夹具（卧推 60×8×3）验证，生产数据未动。
- **修复（只改 client，服务端与数据零改动）**：completeCurrent 的草稿校验与入参构建抽为 buildCurrentPayload，两条路共用；新增 startFeedbackFirst——只校验草稿、打开当前组反馈表单（preRecord 模式：顶部明示「这一组还没记录」、完成次数显示草稿实际值），绝不调用 logSet；FeedbackForm 新增 recordFirst 钩子，提交时先落库（mutateAsync，含横幅与开始休息，与「完成」同一套收尾）成功后才 submitFeedback，落库失败整单失败且错误文案明示「这一组还没记上，反馈也没有提交」。面板在该模式下把完成/跳过换成一句提示 + 「不填了，直接记录这一组」文字链（仍走 completeCurrent），不新增主按钮。沙箱实测：点「填感受再记」后三组仍 done=false/actual 为空；表单选 RIR 2/未变形/正常提交后第 1 组 done、60×8、rir=2 落库并生成 ATI 建议；普通「完成」路径回归正常（第 2 组点完成即记录）。
- **依据隐藏（只改 client 呈现，服务端记录与模型上下文不动）**：新增 shortSuggestion——界面只显示建议的【ATI 裁决】段（旧格式取「建议：」段、无分段长文本只取第一句），反馈事实/评估/理由/E 编号证据原文仍存服务端供模型与复盘。删除全部用户可见的证据面：FeedbackForm 的 BasisLine/AtiMetaLine/AtiEvidencePanel/AdjustmentsList 与「看依据」Sheet（待确认卡改为结论 + 具体改动清单 + 安全校验注记 + 下一步观察一行）、当前组 D2 卡的「看依据」链、计划总览的编排依据、总结页下次建议/营养提示的原书依据、趋势页指标的原书依据（「指标定义与原书依据」改名「指标定义」）、原则页的全部证据展开 + 证据分级 + 原书证据与 Skills 路由一节 + 44 条证据库、规划页提案的 evidence manifest 与快照证据分级、动作库条目的出处/证据评价两行。getEvidence 服务端动作保留（模型与数据层不变），客户端仅 SessionSummary 营养提示文案与 StatsView 指标定义仍取用其非证据字段。

## 热身组进组表 + 配重取整（2026-11-18 编辑，用户当场指出两处）
- **问题**：11-18 腿日深蹲组表直接是 102.5kg×5×3，热身递进 60×5、80×5 只写在备注里，照表练等于冷启动；且 102.5/62.5/65 都配不出来——杠铃片 5kg 一档、杠 20kg，杠铃总重只能是 20+10k，用户今晚只能按 100 蹲、60 拉。
- **数据模型（迁移 0008，只增不改）**：set_logs 新增 warmup 列（开始训练时从计划组表快照）；计划组表 set 对象新增 warmup 布尔（exerciseSchema 与 plannerDayOut 同步，旧 JSON 默认 false 解析）。热身组排在工作组前、组间歇 120 秒、走现有记录与「填感受再记」流程（沙箱实测 ATI 裁决能正确识别热身组上下文）。
- **计数口径（全站统一排除热身组）**：workSetCount/warmupSetCount 为唯一口径——buildPrescriptionsAndVolume（肌群直接/间接/折算组）、validatePlanProposal 周容量校验、generatePlan 周安排 totalSets、diffProposalDays、ensurePlannerBaseline、getStats（完成组数/训练量/进步曲线/RIR 分布）、listSessions（doneSets/totalSets/volumeKg）、buildSummaryMd（完成组数与训练量，热身组单列一行说明、明细表组别列标「热身」）、historyFactsText 失败判定。客户端 PlanOverview/SessionSummary/DayDoneCard 同步只计工作组、热身另计展示。验证：修复后 11-18 仍 14 组、本周仍 83 组、getStats 与改前基线逐项一致（5 场/53 组/15523kg）。
- **配重取整（loadableWeight，生成与保存共用）**：杠铃（名称含「杠铃」）向下取整到 20+10k（≤20 取 20）；哑铃向下取整到 2.5 一档；其他器械不取整。落点：savePlan、updatePlanSetWeight、generatePlan 组装 DayPlanT 时逐组兜底；Planner 提示词新增第 14/15 条（热身组必须进组表 + 配重必须能配出来），validatePlanProposal 新增「热身只写在备注里」违规（备注含「热身」+ kg 数字但组表无 warmup 组 → 判违规重生成）。
- **v5 存量修正（新动作 fixWarmupAndLoadableWeights，幂等，post_submit 对正式库执行一次）**：11-18 深蹲备注热身递进转成组表热身组（60×5、80×5、120 秒）并改备注措辞；11-18/19/20/21 四天计划重量按可配档位取整（深蹲 102.5→100、RDL 62.5→60（11-18 与 11-21）、卧推 65→60），备注与标题文字同步（11-19 标题改「卧推60kg重试」）；当前生效版本 v5 的 proposalDays 与 weeklySchedule 标题同步修正。11-19/20/21 备注经逐条核对无明确热身重量（11-21 腿举是「按可完成10次试起」的递进式起步、11-19 卧推与 11-20 各动作均无热身重量），不转热身组。绝不触碰 sessions/set_logs：进行中的 session 9 已生成的 14 行组（102.5/62.5 旧目标）原样未动，用户重新开场后新会话才带热身组。
- **沙箱验收（副本库，生产未动）**：fix 动作在沙箱跑通且报告 5 项变更；getDay(11-18) 深蹲组表 = 热身 60×5/80×5（120s）+ 工作组 100×5×3，session 9 的 14 行逐字未变；2099-01-01 夹具：savePlan 存热身组且重量被取整（热身 63→60、工作组 102.5→100、哑铃 13→12.5），startSession 生成带 warmup 标记的组行，热身组 logSet + quickContinue 反馈 + 完整 ATI 反馈均跑通，listSessions 该场 totalSets=3/doneSets=0（热身不计）；夹具已删除。
- **平台 v29 升级（同轮完成）**：客户端表单输入按 FIELDS（actionFields 宏）从动作请求 schema 取限制——submitFeedback.note/joint/fatigue（fatigue 删除手写 min/max）、logSet.durationMin/distanceKm/pace、updatePlanSetWeight.weightKg、savePlan.title/exercises.name/exercises.sets.reps/exercises.sets.restSeconds、generatePlan.requestNote；无限制字段（实际重量/次数草稿、动作备注、组重量）保持原样。upload/submit/quick/respond/finishMut/start 六个已由 isError 就地提示失败的 mutation 补 onError 标记，避免 v29 底部通知与就地文案重复；logSet 的 runLog 逐次重试机制（per-call onError + 原样重试，2026-11-13 卡死修复的核心设计）保持不变。

## 裁决被切后台/息屏掐断修复（2026-11-19 编辑，用户真机反馈）
- **故障定性（证据）**：用户截图（18:37）中提交按钮停在「Muse 正在综合裁决这一组…」——submitFeedback 是一条长请求（反馈落库 → 最多 2×90 秒推理 → 结果最后才写回），中途没有任何落库状态；切后台/息屏/退出空间时 WebView 被冻结或回收，客户端 mutation 的 promise 永不落定（按钮永久禁用、整表锁死），服务端请求若同时被掐断则裁决结果永不落库、只剩反馈字段；刷新后无任何状态能区分「还在裁决」与「裁决已丢」，只能盲目重填重提；且回前台除休息计时与 Wake Lock 外没有任何自愈刷新，只能手动刷新。
- **裁决状态落库（迁移 0009，只增不改）**：set_logs 新增 adjudication_status（running | done | failed | null）与 adjudication_started_at。submitFeedback 在反馈落库后、跑推理前先写 running + 开始时间，裁决写回时置 done，异常置 failed；quickContinue 清空标记。setLogOut 新增 adjudicationStatus/adjudicationStartedAt（毫秒时间戳）下发。
- **裁决主体抽共用函数**：submitFeedback 后半段（上下文组装 → runAtiDecision → 建议组装 → 写回 + Planner 事件）整体抽为 adjudicateSavedFeedback(ctx, db, setId)，只读行上已保存的反馈（fb），submitFeedback 与 resumeAdjudication 共用同一条裁决路径，无第二套逻辑。
- **新动作 resumeAdjudication（第 30 个）**：已有裁决结果且不在进行中 → 原样返回存量结果不重跑；running 且开始不足 60 秒 → 返回 stillRunning=true 不抢跑（等客户端轮询）；其余（failed / running 已超时 / 本次修复前的旧中断状态：状态为空+反馈已存+无裁决）→ 刷新在途标记后用行上反馈续跑同一裁决主体；无反馈无裁决时明确报错。
- **客户端恢复**：FeedbackForm 按服务端状态渲染——被中断时显示黄色恢复块（文案按 failed/running/旧状态区分）+「重新裁决这一组」按钮（走 resumeAdjudication，stillRunning 时提示等自动出现）；本地请求 pending 超 20 秒显示安抚说明（反馈已保存、切后台/锁屏没关系、回来自动出现或可续跑）；服务端已有结果但本地请求还挂着时自动 reset 解开按钮。组列表对被中断组加「裁决被中断」徽标、入口按钮改「继续裁决」（共用 adjudicationInterrupted 判定）。TrainingView 在任一组裁决 running 时每 8 秒轮询刷新；App 根加回前台自愈（visibilitychange 可见 / pageshow bfcache / focus → invalidateQueries），不再依赖手动刷新。
- **沙箱验收（副本库，生产未动）**：以用户进行中会话（id 10）实测——重构后 submitFeedback 对卧推第 3 组（id 94）全路径跑通（CONTINUE + MODIFY_NEXT_SESSION、证据 E04/E05/E25/E07）；resumeAdjudication 对已有结果组（id 92/94）原样返回存量裁决 stillRunning=false；对无反馈组（id 95）明确报错；给 id 95 用 quickContinue 存反馈造成「反馈已存、裁决缺失」后，resumeAdjudication 接管续跑出真实裁决（EXTEND_REST + MAINTAIN_LOAD + GATHER_INFORMATION、proposal pending）；getStats 基线未动（5 场已完成、2026-11-09 周 3 场/27 组/7670kg、11-16 周 2 场/26 组/7853kg 与证据包一致）。真机切后台/息屏的实际恢复观感仍待用户下次训练时验证。

## 配重取整改 2.5kg 档（2026-11-24 编辑，峻宇 11-23 纠正、11-24 定版）
- **规则更正**：旧规则按杠铃片 5kg 一档取整（可配重量 20+10k），把 65 压成 60，是错的。峻宇 11-23 纠正：杠铃片有 2.5kg 档、杠 20kg，可配重量为 5 的倍数（25、30…65、70、75…）；62.5、102.5 仍配不出来。11-24 定版改取整。
- **改动（只改 server/src/actions.ts 的取整规则，不动任何已有计划/会话/逐组记录）**：`loadableWeight` 杠铃分支由 `20 + floor((w-20)/10)*10` 改为向下取到最近的 5 的倍数 `floor(w/5)*5`（≤20 仍为 20）；哑铃 2.5kg 一档不变；固定器械/绳索不取整不变。savePlan、generatePlan、updatePlanSetWeight、fixWarmupAndLoadableWeights 全部经此函数，口径自动统一；generatePlan 提示词第 15 条同步改写（65 就写 65）；fixWarmupAndLoadableWeights 的备注文字映射删除「65kg→60kg」（65 现为可配重量），102.5→100、62.5→60 保留。
- **核对**：函数级验证 65→65、62.5→60、102.5→100、25→25、70→70、22→20、67→65；哑铃 17.5→17.5、16→15；坐姿划船 62.5 不取整。器械快照里「杠铃 5kg 一档加重」等历史登记文字（ATI-EQ-1.1 快照原文与动作库 progressionOptions）未动——那是快照记录，不是取整逻辑。

## better-ui 视觉打磨（2026-11-25 编辑，技能源 ~/workspace/custom-skills/better-ui/）
- **范围**：只改 client/src/theme.css 与 client/src/App.tsx 的视觉细节；功能、数据、结构、风格 Y token（墨绿黑 + 青柠 + 毛玻璃）、5 个 tab、ATI 逻辑全部未动。按压缩放/错峰入场属 better-motion，本轮未做。
- **嵌套圆角（外层 = 内层 + 内边距 + 边框宽）**：RIR 选项组外层 rounded-xl(20px) 与选项同圆角、内边距 4px → 外层改 rounded-[24px]（20+4）。反馈卡内的待确认/已接受建议卡与当前组面板内的 D2 建议条原用内联圆角 16，与休息区同款建议条（12）不一致、且与外层卡同为 16 → 统一改 12（与 glass-inner/glass-btn 的内层圆角口径一致）；已接受卡顺带删掉被内联样式覆盖的失效 rounded-2xl 类。玻璃层级阶梯本身（卡 16 / 内层 12 / 面板 20 / 结果 28）是设计师交付的成套 token、全站一致，按技能口径属有意约定，未动。
- **阴影与边框**：.cta-lime 只有发光阴影、无边框 → 补 border: 1px solid transparent，forced-colors 模式去掉阴影后仍有轮廓，平时不可见且不改变尺寸。其余带阴影的玻璃层与 Sheet 本就带真实边框，未动。
- **图片描边**：全站无内容图片（无 <img>、无背景图，图表为 Recharts SVG 数据墨水、休息环为进度指示），规则无落点，未加。
- **hover 与点按高亮**：全站无任何 :hover / hover: 样式（已 grep 核实），不存在触摸端 hover 卡住问题；自绘按压态（.pressable 全站 + 底部 tab 的 animPress）补 -webkit-tap-highlight-color: transparent，避免系统灰闪与按压动画叠加。
- **图标**：全站无图标库与描边图标 SVG，图标均为文字字形（✓ ✕ ‹ ›），天然继承 currentColor 与相邻文字字重；唯一 SVG 是休息计时环（进度指示、描边用状态 token），无写死颜色的图标填充可改，未动。图表系列色（#B9F27D 等）是数据色不是图标，未动。
- **滚动 containment**：底部抽屉 Sheet 的滚动面板补 overscrollBehavior: contain。今日计划区 453px 定高列表按 2026-11-23 设计注释明示保持 auto（滚到边界需链回页面），不在弹窗/抽屉/菜单之列，未动。
- **圆角修正（2026-11-25 晚，用户指出上一条改错方向）**：反馈卡待确认建议卡、已应用卡、当前组面板 D2 建议条三处均为 p-3（内边距 12px），内含「接受」按钮圆角 12px，上一轮把外层统一到 12 恰成父子同圆角；按公式外层 = 内层 + 内边距，三处外层内联圆角 12 → 24。顺带全站复核：RIR 选项组已是 24（20+4）合规；休息区 44px 槽位建议条只有横向 px-3、纵向贴边，属技能口径的非对称内边距（独立表面），未动；其余带圆角容器内只有文字或圆点徽章，无同圆角嵌套。
