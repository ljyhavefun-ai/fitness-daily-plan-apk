ALTER TABLE `set_logs` ADD COLUMN `warmup` integer DEFAULT 0 NOT NULL;
