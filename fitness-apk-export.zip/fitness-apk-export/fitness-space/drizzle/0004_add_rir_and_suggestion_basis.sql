ALTER TABLE `set_logs` ADD COLUMN `rir` real;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `ai_basis_principle` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `ai_basis_kind` text;
