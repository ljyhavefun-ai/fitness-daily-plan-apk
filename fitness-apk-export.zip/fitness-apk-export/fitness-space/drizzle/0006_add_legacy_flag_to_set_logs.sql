ALTER TABLE `set_logs` ADD COLUMN `legacy` integer DEFAULT 0 NOT NULL;
