ALTER TABLE `set_logs` ADD COLUMN `deform` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `soreness_over72` integer;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `ai_rule` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `ai_evidence` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `ai_action` text;
