ALTER TABLE `set_logs` ADD COLUMN `adjudication_status` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `adjudication_started_at` integer;
