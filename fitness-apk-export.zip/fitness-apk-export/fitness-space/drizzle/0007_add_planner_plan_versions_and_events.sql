CREATE TABLE `plan_versions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`version` integer NOT NULL,
	`status` text DEFAULT 'proposed' NOT NULL,
	`origin` text DEFAULT 'planner' NOT NULL,
	`title` text NOT NULL,
	`week_start` text,
	`week_end` text,
	`goal_snapshot` text NOT NULL,
	`constraints_snapshot` text NOT NULL,
	`weekly_schedule` text NOT NULL,
	`exercise_prescriptions` text NOT NULL,
	`proposal_days` text,
	`muscle_volume` text NOT NULL,
	`time_budget` text NOT NULL,
	`progression_hypotheses` text NOT NULL,
	`recovery_assumptions` text NOT NULL,
	`evidence_manifest` text NOT NULL,
	`uncertainties` text NOT NULL,
	`safety_notes` text NOT NULL,
	`diff_summary` text NOT NULL,
	`rationale` text DEFAULT '' NOT NULL,
	`confidence` real,
	`created_at` integer NOT NULL,
	`decided_at` integer
);
--> statement-breakpoint
CREATE TABLE `planner_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kind` text NOT NULL,
	`plan_version_id` integer,
	`session_id` integer,
	`set_log_id` integer,
	`note` text NOT NULL,
	`payload_json` text,
	`created_at` integer NOT NULL
);
