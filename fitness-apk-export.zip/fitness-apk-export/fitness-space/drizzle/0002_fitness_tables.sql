DROP TABLE IF EXISTS entries;
--> statement-breakpoint
CREATE TABLE plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  exercises_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER,
  date TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'in_progress',
  started_at INTEGER,
  ended_at INTEGER,
  summary_md TEXT,
  review TEXT,
  next_suggestion TEXT,
  drive_status TEXT NOT NULL DEFAULT 'none',
  drive_file_name TEXT,
  drive_link TEXT,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE set_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL,
  exercise_name TEXT NOT NULL,
  exercise_idx INTEGER NOT NULL,
  set_idx INTEGER NOT NULL,
  target_weight_kg REAL,
  target_reps TEXT NOT NULL,
  target_rest_seconds INTEGER NOT NULL DEFAULT 90,
  actual_weight_kg REAL,
  actual_reps TEXT,
  rest_seconds INTEGER,
  done INTEGER NOT NULL DEFAULT 0,
  skipped INTEGER NOT NULL DEFAULT 0,
  difficulty TEXT,
  joint TEXT,
  pump INTEGER,
  fatigue INTEGER,
  note TEXT,
  ai_suggestion TEXT,
  ai_adjustments TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
