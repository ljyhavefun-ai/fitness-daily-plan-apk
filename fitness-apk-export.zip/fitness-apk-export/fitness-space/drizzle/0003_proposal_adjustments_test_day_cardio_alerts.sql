ALTER TABLE `plans` ADD COLUMN `test_day` integer DEFAULT 0 NOT NULL;
--> statement-breakpoint
ALTER TABLE `sessions` ADD COLUMN `alert_json` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `orig_weight_kg` real;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `orig_reps` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `orig_rest_seconds` integer;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `duration_min` real;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `pace` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `distance_km` real;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `skipped_by` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `proposal_json` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `proposal_status` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `applied_note` text;
--> statement-breakpoint
ALTER TABLE `set_logs` ADD COLUMN `undo_json` text;
