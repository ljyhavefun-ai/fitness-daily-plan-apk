# 参考书目（Bibliography）

本仓库只列书目。**9 本书的全文不在仓库里**（版权原因），`data/evidence.json` 与 `data/principles.json` 只含证据摘要、章节与页码定位，不含任何一本书的全文内容。

**不要从网上找盗版全文放进仓库。** 需要查原文时请用正版纸书、电子书或图书馆渠道；APK 内引用只写书名、版次、章节与页码。

## 书目

1. Haff, G. G., & Triplett, N. T. (Eds.). *NSCA's Essentials of Strength Training and Conditioning*. 5th edition. Human Kinetics, 2025.
   - 证据账本中的主要来源（E01–E09 等），第 18 章为计划编排核心依据。
2. Rippetoe, M. *Starting Strength: Basic Barbell Training*. 3rd edition. The Aasgaard Company, 2011.
3. Zatsiorsky, V. M., & Kraemer, W. J. *Science and Practice of Strength Training*. 3rd edition. Human Kinetics, 2020.
4. Schoenfeld, B. *Science and Development of Muscle Hypertrophy*. 1st edition. Human Kinetics, 2016.
5. Helms, E., Valdez, A., & Morgan, A. *The Muscle and Strength Pyramid: Training*. v2.
6. Helms, E., Valdez, A., & Morgan, A. *The Muscle and Strength Pyramid: Nutrition*. v2.
7. Jeukendrup, A., & Gleeson, M. *Sport Nutrition*. 2nd edition. Human Kinetics, 2010.
8. Israetel, M., Hoffmann, J., & Davis, M. *Scientific Principles of Strength Training*. Renaissance Periodization.
9. Israetel, M., & Hoffmann, J. *Scientific Principles of Powerlifting*. Renaissance Periodization.

## 说明

- 上述书名、作者与版次与空间内证据账本（`data/evidence.json`，44 条 E01–E44）登记的一致；个别条目在账本中只记简称（如 RP），此处按全称列出。
- 另有两类非书证据不属于本书目：ACSM 2026 立场声明、Haugen 2023 机器与自由重量 Meta 分析（E1 级综述，见 `data/principles.json` 的 `evidenceGrades`），以及东哥 Bilibili 视频《练腹肌，我只推荐这个动作！》（BV17noEYhEUU，2025-04-14，E5 级，已实际观看核验）。
