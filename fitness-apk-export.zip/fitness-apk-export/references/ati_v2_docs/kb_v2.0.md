[NORMAL_TEXT] ATI 共享知识库规范与 Exercise Library — v2.0.1
[NORMAL_TEXT] 状态：修订稿 | 关联目录：ATI 目标导向规划系统
[NORMAL_TEXT] 一、知识库原则
[NORMAL_TEXT] ATI Planner 与 ATI 实时决策引擎共享同一个版本化知识库。知识库至少分为：
[NORMAL_TEXT] 1. 原始来源库：九本书全文、论文全文、官方立场声明、专家视频。
[NORMAL_TEXT] 2. 结构化证据库：证据卡、研究人群、结果、局限、证据等级。
[NORMAL_TEXT] 3. Exercise Library：动作定义、变式、肌群映射、设备依赖、技术要点、适用边界、证据评价、替换链。
[NORMAL_TEXT] 4. Equipment Snapshot：用户已确认的器械可行域。
[NORMAL_TEXT] 5. Decision/Plan Manifest：每次规划或训练决策使用的证据版本与设备快照版本。
[NORMAL_TEXT] 个人排除清单已作废。用户没有绝对不用的器械。设备是否存在由快照确认；动作科学质量由证据评价；本次是否适用由目标、时间、技术、疼痛/恢复、安全与场地约束共同决定。
[NORMAL_TEXT] 二、证据等级与评价框架
[NORMAL_TEXT] E1：高质量立场声明、系统综述、Meta分析。
[NORMAL_TEXT] E2：长期随机对照训练研究及直接干预研究。
[NORMAL_TEXT] E3：机制、生物力学、肌电和急性研究；只能辅助解释机制，不能单独证明长期肌肥大优势。
[NORMAL_TEXT] E4：九本指定书籍。每条记录书名、版本、章节、页码/行范围；必要时回溯书中引用的原始研究。
[NORMAL_TEXT] E5：可核验学者/专业人士公开视频或讲座。记录频道/作者、资历、视频标题、URL、时间戳、观点原文/准确转述、其引用研究、利益冲突与可信度。E5是补充解释，不与E1/E2等权。
[NORMAL_TEXT] E6：普通博主、论坛、个人案例。仅作低可信度实践线索，不可独立决定动作优劣。
[NORMAL_TEXT] 证据评价不得混淆：
[NORMAL_TEXT] - “教材列出/教授该动作”证明它是常用且有技术描述的训练选项，不证明它比其他动作更有效。
[NORMAL_TEXT] - 肌电或急性泵感不等于长期肌肥大结果。
[NORMAL_TEXT] - 设备类别（自由重量/固定器械）不构成普遍优劣。ACSM 2026与Haugen 2023的证据综合没有支持机器或自由重量在肌肥大方面存在普遍优越性；力量表现存在测试模式专项性。
[NORMAL_TEXT] - “时间效率”必须说明分子/分母。可考察目标刺激/占用时间、力量任务表现/时间、刺激/疲劳成本、器械切换/等待成本。缺少直接比较时，不给精确效率分数。
[NORMAL_TEXT] - 多关节动作可作为有限时间下的优先候选，但不能替代所有孤立动作；孤立动作在目标肌群补足、局部刺激或疲劳管理方面可能有作用。
[NORMAL_TEXT] - 动作变化应有计划地服务于肌肉区域、动作模式、训练目标或关节舒适性；避免无理由随机频繁更换。
[NORMAL_TEXT] 三、Evidence Appraisal 字段（每个动作必填）
[NORMAL_TEXT] - outcome_scope：肌肥大/特定力量/运动表现/健康功能；
[NORMAL_TEXT] - direct_evidence：是否有该动作与替代动作的直接长期比较；
[NORMAL_TEXT] - evidence_grade：E1–E6及其具体来源；
[NORMAL_TEXT] - supported_benefits：研究支持的作用；
[NORMAL_TEXT] - limitations：研究未证明什么；
[NORMAL_TEXT] - time_efficiency：时间成本与证据依据；
[NORMAL_TEXT] - fatigue_cost：局部/全身疲劳代价及其确定性；
[NORMAL_TEXT] - skill_cost：技术学习和安全要求；
[NORMAL_TEXT] - progression：负荷/次数/动作质量可否渐进；
[NORMAL_TEXT] - confidence：高/中/低，并说明原因；
[NORMAL_TEXT] - opposing_views：正反观点并列；
[NORMAL_TEXT] - verdict：针对明确目标的结论，不允许无目标的“万能排名”。
[NORMAL_TEXT] 四、正式器械约束快照 ATI-EQ-1.1
[NORMAL_TEXT] 用户已确认：
[NORMAL_TEXT] 1. 龙门架/绳索站；
[NORMAL_TEXT] 2. 高位下拉；
[NORMAL_TEXT] 3. 牧师椅；
[NORMAL_TEXT] 4. 卧推架；
[NORMAL_TEXT] 5. 史密斯机；
[NORMAL_TEXT] 6. 深蹲架；
[NORMAL_TEXT] 7. 坐姿划船；
[NORMAL_TEXT] 8. 坐姿反手下拉；
[NORMAL_TEXT] 9. 固定推肩器械；
[NORMAL_TEXT] 10. 固定推胸器械（平板、上斜）；
[NORMAL_TEXT] 11. 蝴蝶机；
[NORMAL_TEXT] 12. 倒蹬腿举；
[NORMAL_TEXT] 13. 坐姿腿伸展；
[NORMAL_TEXT] 14. 髋外展/内收器械；
[NORMAL_TEXT] 15. 用户描述的髋主导/硬拉类固定器械：臀部后方有靠垫，使用者向前髋铰链，双手拉动可装杠铃片的把手完成类似硬拉动作。商品名、品牌和型号未知，不得猜测名称；
[NORMAL_TEXT] 16. 哑铃每2.5 kg一档，最大/最小重量未知；
[NORMAL_TEXT] 17. 杠铃每5 kg一档，空杆重量、最大负重未知；
[NORMAL_TEXT] 18. 可调角度训练椅；
[NORMAL_TEXT] 19. 引体单杠；
[NORMAL_TEXT] 20. 跑步机。
[NORMAL_TEXT] 未知细节：绳索站数量、滑轮独立调节方式、附件类型与配重范围；机器具体品牌/型号；安全杠、保护者配置；哑铃/杠铃最大最小重量；跑步机速度坡度范围；场地拥挤度和携重行走空间。依赖这些未知信息的动作标记 CONDITIONAL，不得进入正式计划，除非后续确认。
[NORMAL_TEXT] 五、动作库结构
[NORMAL_TEXT] 每个动作必须具有：
[NORMAL_TEXT] exercise_id、canonical_name、variation_id、aliases、movement_patterns、primary_muscles、secondary_muscles、stabilizers、equipment_requirements、equipment_snapshot_match、technique_cues、common_errors、skill_level、population_scope、contraindications_stop_conditions、time_setup_cost、fatigue_cost、progression_options、replacement_chain、evidence_sources、evidence_appraisal、source_status、last_reviewed_at、version。
[NORMAL_TEXT] source_status：
[NORMAL_TEXT] - ACTIVE：出处已核验、设备依赖已确认、技术信息足够；
[NORMAL_TEXT] - CONDITIONAL：需要确认附件、设备配置、空间或型号；
[NORMAL_TEXT] - PROVISIONAL：设备/动作身份尚未准确识别；
[NORMAL_TEXT] - INACTIVE：来源不足或安全信息不完整，不可被计划调用。
[NORMAL_TEXT] 六、初始 Exercise Library（按当前设备快照筛选）
[NORMAL_TEXT] 说明：以下为初始候选库，不等于每个动作都应进入同一周计划。所有“效率/优劣”评级均是目标相关的证据判断，不是助手主观喜好。除非另有直接头对头研究，条目所引教材主要支持动作定义和技术指导，不足以证明其比替代动作更优。
[NORMAL_TEXT] A. 水平推 / 胸部
[NORMAL_TEXT] 01. 杠铃平板卧推
[NORMAL_TEXT] 模式：水平推；主肌：胸大肌；次肌：前三角、肱三头；设备：杠铃、卧推架/凳。
[NORMAL_TEXT] 技术：建立稳定支撑，腕肘与杠铃路径协调，控制下降和推起；必须满足安全保护条件。
[NORMAL_TEXT] 适用/停止：需要掌握杠铃技术；无保护条件、肩腕疼痛或无法控制动作时不执行。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.430；Starting Strength 3e Ch5。
[NORMAL_TEXT] 证据评价：E4有明确技术章节；E1设备类型比较不支持自由重量对肌肥大普遍更优。若目标是杠铃卧推专项力量，专项性支持其训练价值；时间效率属于多关节候选。不能称其对所有胸部目标绝对最佳。
[NORMAL_TEXT] 替换链：固定平板胸推 → 哑铃平板卧推 → 俯卧撑（后者设备/支撑条件另核）。
[NORMAL_TEXT] 02. 哑铃平板卧推
[NORMAL_TEXT] 模式：水平推；主肌：胸大肌；次肌：前三角、肱三头；设备：哑铃、可调椅。
[NORMAL_TEXT] 技术：双侧独立控制，腕肘对齐，下降幅度以肩部舒适和控制为界。
[NORMAL_TEXT] 适用/停止：适合可独立控制两侧哑铃者；若控制失稳或肩部不适，降低复杂度并评估。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.430（哑铃变式）；Helms Training 2e 水平推/动作选择。
[NORMAL_TEXT] 证据评价：E4支持其为卧推变式；E1/E2未证明其普遍优于杠铃或机器。可提供独立侧控制和不同活动范围，但具体优势需结合个体和目标判断。
[NORMAL_TEXT] 替换链：固定平板胸推 → 杠铃平板卧推。
[NORMAL_TEXT] 03. 史密斯平板卧推
[NORMAL_TEXT] 模式：水平推；主肌：胸大肌；次肌：前三角、肱三头；设备：史密斯机、平凳。
[NORMAL_TEXT] 技术：先调整座椅/凳位，使固定轨迹符合肩肘舒适路径；熟悉安全钩。
[NORMAL_TEXT] 适用/停止：固定轨迹不适配或设备安全钩不熟悉时不执行。
[NORMAL_TEXT] 出处：Helms Training 2e Exercise Selection/机器与自由重量选择；ACSM 2026设备类型比较。
[NORMAL_TEXT] 证据评价：E1不支持机器类在肌肥大上天然低效；但固定轨迹个体适配差异较大。该具体史密斯卧推与自由卧推的直接长期比较证据不足。
[NORMAL_TEXT] 替换链：固定平板胸推 → 哑铃平板卧推。
[NORMAL_TEXT] 04. 固定平板胸推
[NORMAL_TEXT] 模式：水平推；主肌：胸大肌；次肌：前三角、肱三头；设备：已确认固定平板胸推器械。
[NORMAL_TEXT] 技术：座椅高度使把手起始位与胸部匹配，肩胛和躯干稳定，控制回程。
[NORMAL_TEXT] 适用/停止：设备轨迹适配且无痛者；轨迹引发疼痛则调整或替换。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.434（Vertical Chest Press Machine）；Haugen 2023机器/自由重量Meta分析。
[NORMAL_TEXT] 证据评价：E1设备类型比较未发现肌肥大普遍差异；固定轨迹可能降低稳定要求、便于快速设置。没有证据证明它对所有人比自由重量更高效。
[NORMAL_TEXT] 替换链：哑铃平板卧推 → 杠铃平板卧推。
[NORMAL_TEXT] 05. 上斜哑铃卧推
[NORMAL_TEXT] 模式：上斜水平推；主肌：胸大肌锁骨部；次肌：前三角、肱三头；设备：哑铃、可调椅。
[NORMAL_TEXT] 技术：椅背角度适中，肩胛稳定，避免过度耸肩和强行深拉伸。
[NORMAL_TEXT] 适用/停止：肩前侧不适时调整角度或停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.432；Schoenfeld《Science and Development of Muscle Hypertrophy》Ch3 exercise selection/ROM。
[NORMAL_TEXT] 证据评价：E4支持动作技术和目标肌群思路；特定上斜角度的长期最优角度证据有限。适合补充不同推举方向，不可宣称必然优于平板推胸。
[NORMAL_TEXT] 替换链：固定上斜胸推 → 杠铃上斜卧推。
[NORMAL_TEXT] 06. 固定上斜胸推
[NORMAL_TEXT] 模式：上斜水平推；主肌：胸大肌锁骨部；次肌：前三角、肱三头；设备：已确认固定上斜胸推器械。
[NORMAL_TEXT] 技术：座椅/起始把手位置适配；控制底部活动范围。
[NORMAL_TEXT] 适用/停止：器械轨迹舒适者；若轨迹不适配则换哑铃变式。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.434胸推机器技术；ACSM 2026设备类型综述。
[NORMAL_TEXT] 证据评价：E1机器与自由重量肌肥大未显示一致差异；该特定上斜机器相对哑铃上斜的直接比较证据不足。
[NORMAL_TEXT] 替换链：上斜哑铃卧推 → 杠铃上斜卧推。
[NORMAL_TEXT] 07. 杠铃上斜卧推
[NORMAL_TEXT] 模式：上斜水平推；主肌：胸大肌锁骨部；次肌：前三角、肱三头；设备：杠铃、卧推架、上斜椅。
[NORMAL_TEXT] 技术：设置安全保护；握距与触胸点稳定。
[NORMAL_TEXT] 适用/停止：须有保护条件和熟练技术；否则优先固定上斜胸推。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.432（barbell variation）；Starting Strength 3e Ch5技术原则。
[NORMAL_TEXT] 证据评价：E4技术来源；专项力量价值高于泛化机器替代，肌肥大方面无普遍优越证据。
[NORMAL_TEXT] 替换链：固定上斜胸推 → 上斜哑铃卧推。
[NORMAL_TEXT] 08. 蝴蝶机夹胸（Pec Deck）
[NORMAL_TEXT] 模式：水平内收/胸部孤立；主肌：胸大肌；次肌：前三角；设备：已确认蝴蝶机。
[NORMAL_TEXT] 技术：座椅与轴心位置匹配，肘/前臂支撑舒适，控制离心，不强迫肩部过度后伸。
[NORMAL_TEXT] 适用/停止：肩前侧不适或设备轴心不匹配时缩小范围/停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.435。
[NORMAL_TEXT] 证据评价：E4明确列出动作；作为单关节胸部补充可提供局部刺激，但单位时间覆盖肌群较少，通常不取代主要推举。没有证据证明它普遍优于绳索夹胸。
[NORMAL_TEXT] 替换链：绳索夹胸（附件确认后） → 哑铃飞鸟（活动范围舒适时）。
[NORMAL_TEXT] 09. 绳索夹胸
[NORMAL_TEXT] 模式：水平内收/胸部孤立；主肌：胸大肌；次肌：前三角；设备：龙门架及合适把手（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：肩胛稳定、肘角固定、控制回程；避免以过度拉伸追求幅度。
[NORMAL_TEXT] 适用/停止：需确认两侧滑轮和把手；肩部不适时不做。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 Variable Resistance Training；Helms Training 2e水平推/孤立动作选择。
[NORMAL_TEXT] 证据评价：E4动作模式依据；直接比较长期增肌证据有限。双侧滑轮布置可能增加设置/占位成本，效率取决于场地。
[NORMAL_TEXT] 替换链：蝴蝶机夹胸 → 哑铃飞鸟。
[NORMAL_TEXT] B. 垂直推 / 肩部
[NORMAL_TEXT] 10. 固定器械肩推
[NORMAL_TEXT] 模式：垂直推；主肌：三角肌前束/中束；次肌：肱三头；设备：已确认固定推肩器械。
[NORMAL_TEXT] 技术：座椅和把手起始高度匹配；躯干稳定；不强迫肩关节进入疼痛范围。
[NORMAL_TEXT] 适用/停止：轨迹舒适且设备适配者；疼痛时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.457；ACSM 2026。
[NORMAL_TEXT] 证据评价：E4明确动作技术；E1机器与自由重量没有肌肥大普遍差异。稳定轨迹可能减少平衡/设置要求，但不代表刺激必然更高。
[NORMAL_TEXT] 替换链：坐姿哑铃肩推 → 站姿杠铃推举。
[NORMAL_TEXT] 11. 坐姿哑铃肩推
[NORMAL_TEXT] 模式：垂直推；主肌：三角肌前束/中束；次肌：肱三头；设备：哑铃、可调椅。
[NORMAL_TEXT] 技术：肋骨不过度外翻，前臂保持可控，肩部活动范围舒适。
[NORMAL_TEXT] 适用/停止：能安全拿放哑铃者；肩部活动受限时不强迫幅度。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.458（dumbbell variation）。
[NORMAL_TEXT] 证据评价：E4支持变式；机器/自由重量肌肥大无普遍差异。哑铃拿放和稳定成本可能高于固定器械，需计入时间效率。
[NORMAL_TEXT] 替换链：固定器械肩推 → 站姿杠铃推举。
[NORMAL_TEXT] 12. 站姿杠铃推举
[NORMAL_TEXT] 模式：垂直推；主肌：三角肌前束/中束；次肌：肱三头、躯干稳定肌；设备：杠铃、深蹲架。
[NORMAL_TEXT] 技术：建立躯干张力，杠铃沿可控路径通过头部，避免腰椎过伸。
[NORMAL_TEXT] 适用/停止：需具备动作教学和安全放置条件；腰肩不适或无法控制时不安排。
[NORMAL_TEXT] 出处：Starting Strength 3e Ch6 The Press；NSCA 5e Ch16 p.458。
[NORMAL_TEXT] 证据评价：E4有完整技术教学；对推举专项力量有特异性价值。若目标是节省时间且减少技术成本，固定肩推可能更方便；没有普遍肌肥大优势证据。
[NORMAL_TEXT] 替换链：固定器械肩推 → 坐姿哑铃肩推。
[NORMAL_TEXT] 13. 哑铃侧平举
[NORMAL_TEXT] 模式：肩外展孤立；主肌：三角肌中束；次肌：冈上肌、上斜方肌；设备：哑铃。
[NORMAL_TEXT] 技术：负荷轻到能控制；肘腕自然；避免躯干摆动和耸肩代偿。
[NORMAL_TEXT] 适用/停止：肩部疼痛时停止或由专业人员评估动作范围。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.460。
[NORMAL_TEXT] 证据评价：E4支持动作类别；作为中束定向补充有合理性，但没有充分证据证明其比所有绳索/器械侧平举更优。局部刺激目标明确，时间效率低于多关节动作但可能补足目标肌群。
[NORMAL_TEXT] 替换链：绳索侧平举（附件确认后） → 其他可用侧平举变式。
[NORMAL_TEXT] 14. 绳索侧平举
[NORMAL_TEXT] 模式：肩外展孤立；主肌：三角肌中束；次肌：冈上肌、上斜方肌；设备：龙门架、单把手（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：滑轮高度和站位适配；控制躯干，不用摆动完成。
[NORMAL_TEXT] 适用/停止：先确认单把手；肩部疼痛时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 Variable Resistance；NSCA 5e Ch16 p.460侧平举动作模式。
[NORMAL_TEXT] 证据评价：E4模式支持；不同阻力曲线的长期优势尚不能仅凭急性肌电推断。与哑铃相比是否更高效需按实际配重曲线和设置时间评价。
[NORMAL_TEXT] 替换链：哑铃侧平举 → 固定器械肩推（目标不同，替换时需重新核算刺激）。
[NORMAL_TEXT] C. 水平拉 / 背部
[NORMAL_TEXT] 15. 杠铃俯身划船
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌、菱形肌、中斜方肌；次肌：后三角、肱二头、躯干稳定肌；设备：杠铃。
[NORMAL_TEXT] 技术：髋铰链保持躯干位置，脊柱受控，拉动时不借腰弹起。
[NORMAL_TEXT] 适用/停止：需要髋铰链和躯干等长控制；腰背疲劳或技术不稳时选胸托/器械划船。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.420；Schoenfeld《肌肥大》背部训练章节讨论水平面划船。
[NORMAL_TEXT] 证据评价：E4动作技术来源；多关节、单位动作覆盖多肌群，可能有时间效率优势；但躯干等长负荷较高，局部目标刺激/疲劳比因人而异。无证据证明它应永远作为背日首项。
[NORMAL_TEXT] 替换链：坐姿划船 → 胸托哑铃划船 → 低位绳索划船（附件确认后）。
[NORMAL_TEXT] 16. Pendlay划船
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌、中背；次肌：肱二头、躯干稳定肌；设备：杠铃、可安全放置的地面空间。
[NORMAL_TEXT] 技术：每次从静止位置启动；躯干角度一致；不靠腰部反弹。
[NORMAL_TEXT] 适用/停止：技术要求较高；无法稳定控制起始位时不选。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.421。
[NORMAL_TEXT] 证据评价：E4有动作技术说明；更偏向严格起始和力量输出练习，不能假设比常规俯身划船更增肌或更省时。直接长期对照证据不足。
[NORMAL_TEXT] 替换链：杠铃俯身划船 → 坐姿划船。
[NORMAL_TEXT] 17. 单臂哑铃划船
[NORMAL_TEXT] 模式：水平拉/单侧；主肌：背阔肌、中背；次肌：后三角、肱二头、躯干抗旋转肌；设备：哑铃、训练椅。
[NORMAL_TEXT] 技术：支撑稳定，躯干不旋转借力，控制肩胛移动。
[NORMAL_TEXT] 适用/停止：可用支撑降低平衡要求；腰背不适时改胸托或坐姿器械。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.422；Helms Training 2e horizontal pull选择。
[NORMAL_TEXT] 证据评价：E4明确列出；单侧训练可处理两侧差异，但一侧一侧完成会增加总用时。没有证据证明其总体优于双侧划船。
[NORMAL_TEXT] 替换链：坐姿划船 → 胸托哑铃划船。
[NORMAL_TEXT] 18. 胸托哑铃划船
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌、中背；次肌：后三角、肱二头；设备：哑铃、可调训练椅。
[NORMAL_TEXT] 技术：胸部支撑稳定；颈部中立；控制肩胛前伸/后缩。
[NORMAL_TEXT] 适用/停止：适合希望降低躯干等长负荷者；凳子角度和支撑稳定性需确认。
[NORMAL_TEXT] 出处：Helms Training 2e horizontal pull/bench-supported row讨论；NSCA 5e Ch16划船技术原则。
[NORMAL_TEXT] 证据评价：E4支持作为划船变式；减少躯干稳定需求是生物力学特点，但缺少其比坐姿划船更增肌的直接证据。时间成本需计入凳子设置。
[NORMAL_TEXT] 替换链：坐姿划船 → 单臂哑铃划船。
[NORMAL_TEXT] 19. 坐姿器械划船
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌、菱形肌、中斜方肌；次肌：后三角、肱二头；设备：已确认坐姿划船器械。
[NORMAL_TEXT] 技术：躯干保持稳定，肘按目标方向移动，回程受控，不大幅后仰。
[NORMAL_TEXT] 适用/停止：机器轨迹和握把舒适；不适配时调整握法/范围或替换。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.424。
[NORMAL_TEXT] 证据评价：E4明确动作；机器训练在肌肥大方面并未显示普遍劣势。设置较快、躯干稳定要求较低，可能具备较好的时间/疲劳效率；是否优于绳索或哑铃划船没有直接结论。
[NORMAL_TEXT] 替换链：单臂哑铃划船 → 杠铃俯身划船。
[NORMAL_TEXT] 20. 低位绳索坐姿划船
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌、中背；次肌：后三角、肱二头；设备：龙门架低位滑轮、坐姿固定方式和把手（附件/座位未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：躯干稳定，回程不被配重拉走，肘路径符合目标。
[NORMAL_TEXT] 适用/停止：需确认低位滑轮、附件和坐姿空间。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.425（Low-Pulley Seated Row）；Helms Training 2e horizontal pull。
[NORMAL_TEXT] 证据评价：E4明确列出类似动作；绳索阻力形式可行，但设置和占位成本可能高于固定坐姿划船。无直接证据证明更优。
[NORMAL_TEXT] 替换链：固定坐姿划船 → 单臂哑铃划船。
[NORMAL_TEXT] 21. 反手坐姿划船（用户确认的固定器械）
[NORMAL_TEXT] 模式：水平拉；主肌：背阔肌/中背（具体偏向取决于设备轨迹）；次肌：肱二头、后三角；设备：已确认坐姿反手下拉器械（设备名称按用户原话保留，具体轨迹待实物核验）。
[NORMAL_TEXT] 技术：先观察器械把手轨迹和关节活动方向；不得根据“反手下拉”名称擅自认定为垂直拉或水平拉。
[NORMAL_TEXT] 适用/停止：需现场确认其真实运动轨迹后决定动作模式与肌群映射。
[NORMAL_TEXT] 出处：NSCA 5e Ch16水平/垂直拉动作技术目录；Helms Training 2e vertical/horizontal pull分类。具体机器型号未知。
[NORMAL_TEXT] 证据评价：PROVISIONAL。设备存在已确认，但动作模式、目标肌群和技术指导尚未完全核验，不得在确认运动轨迹前用于计划或与其他动作做优劣排名。
[NORMAL_TEXT] 替换链：轨迹确认后再建立同模式替换链。
[NORMAL_TEXT] D. 垂直拉 / 背阔肌
[NORMAL_TEXT] 22. 正握引体向上
[NORMAL_TEXT] 模式：垂直拉；主肌：背阔肌、大圆肌；次肌：肱二头、肱肌及肩胛控制肌；设备：已确认引体单杠。
[NORMAL_TEXT] 技术：身体不摆荡，肩胛和肘部运动受控；不以颈部前探完成动作。
[NORMAL_TEXT] 适用/停止：需具备控制自重的能力；肩肘疼痛或无法控制时停止并评估。
[NORMAL_TEXT] 出处：Starting Strength 3e Ch7 Chin-ups and Pull-ups；NSCA 5e Ch17自重训练。
[NORMAL_TEXT] 证据评价：E4明确教授引体类；多关节垂直拉，可作为背部与上肢拉力候选。其相对高位下拉的肌肥大优势未被证明；自重负荷和技术门槛可能使其对部分训练者不易精细调节。
[NORMAL_TEXT] 替换链：高位下拉 → 反手下拉（具体模式确认） → 辅助变式（辅助引体机未确认，不可用）。
[NORMAL_TEXT] 23. 反握引体向上（Chin-up）
[NORMAL_TEXT] 模式：垂直拉；主肌：背阔肌；次肌：肱二头、肱肌；设备：已确认引体单杠。
[NORMAL_TEXT] 技术：反握自然宽度，控制身体摆动和离心阶段。
[NORMAL_TEXT] 适用/停止：肘腕肩不适时停止；无法稳定完成时选择可调负荷下拉。
[NORMAL_TEXT] 出处：Starting Strength 3e Ch7；NSCA 5e Ch17 bodyweight exercise。
[NORMAL_TEXT] 证据评价：E4有技术依据；反握会改变肘屈肌参与，但不能仅凭握法宣称更有效增肌。与正握的长期肌肥大比较证据有限。
[NORMAL_TEXT] 替换链：高位下拉 → 正握引体向上。
[NORMAL_TEXT] 24. 高位下拉（常规握法）
[NORMAL_TEXT] 模式：垂直拉；主肌：背阔肌、大圆肌；次肌：肱二头、肱肌、肩胛控制肌；设备：已确认高位下拉。
[NORMAL_TEXT] 技术：躯干稳定，向上胸方向拉动，避免颈后拉和过度后仰。
[NORMAL_TEXT] 适用/停止：按机器轨迹和握把适配；肩部不适时调整范围或停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.423；Helms Training 2e vertical pull。
[NORMAL_TEXT] 证据评价：E4明确列出；负荷易调、设置相对快，可能比自重引体更易匹配不同能力。没有证据证明它普遍比引体更有效或更无效。
[NORMAL_TEXT] 替换链：正握引体 → 坐姿反手下拉（待轨迹确认）。
[NORMAL_TEXT] 25. 坐姿反手下拉器械动作
[NORMAL_TEXT] 模式：待现场核验；用户将其描述为练背器械；设备：已确认该器械存在。
[NORMAL_TEXT] 技术：必须核验是垂直下拉还是水平划船、握把方向、起始姿势和活动轨迹。
[NORMAL_TEXT] 适用/停止：未核验前为PROVISIONAL，不进入计划。
[NORMAL_TEXT] 出处：需设备照片/说明书和对应NSCA/Helms动作章节；不得臆造器械型号或引用页码。
[NORMAL_TEXT] 证据评价：当前无足够信息评价其效率和肌群偏向。
[NORMAL_TEXT] 替换链：核验模式后生成。
[NORMAL_TEXT] 26. 单臂绳索高位下拉
[NORMAL_TEXT] 模式：垂直拉/单侧；主肌：背阔肌；次肌：肱二头、躯干抗侧屈肌；设备：龙门架高位滑轮和单把手（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：骨盆和胸廓稳定，肘向髋方向移动，控制回程。
[NORMAL_TEXT] 适用/停止：确认单把手和高位滑轮后方可用。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 Variable Resistance；Helms Training 2e vertical pull。
[NORMAL_TEXT] 证据评价：E4支持绳索阻力和垂直拉模式；单侧版本可能增加局部控制需求，但单侧完成会增加时间。缺乏其优于双侧下拉的长期证据。
[NORMAL_TEXT] 替换链：高位下拉 → 正握引体。
[NORMAL_TEXT] 27. 绳索直臂下压
[NORMAL_TEXT] 模式：肩伸展/垂直拉辅助；主肌：背阔肌；次肌：大圆肌、肱三头长头参与；设备：龙门架高位滑轮及直杆/绳把（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：肘角基本固定，髋躯干稳定，不用腰部摆动。
[NORMAL_TEXT] 适用/停止：需确认附件；肩部活动受限或疼痛时不强行拉伸。
[NORMAL_TEXT] 出处：Helms Training 2e pull-over/lat pushdown讨论；NSCA 5e Ch17 variable resistance。
[NORMAL_TEXT] 证据评价：E4模式依据；作为单关节/辅助动作可补充肩伸展刺激，但单位时间覆盖肌群有限，不能替代主要垂直拉。没有证据证明其必需。
[NORMAL_TEXT] 替换链：高位下拉 → 绳索 pullover（附件确认后）。
[NORMAL_TEXT] E. 膝主导 / 股四头肌与臀部
[NORMAL_TEXT] 28. 杠铃后蹲
[NORMAL_TEXT] 模式：膝主导/复合下肢；主肌：股四头肌、臀大肌；次肌：内收肌、躯干稳定肌；设备：杠铃、深蹲架。
[NORMAL_TEXT] 技术：建立安全架高度和保护条件，脚掌稳定，膝髋协调，深度以动作质量为准。
[NORMAL_TEXT] 适用/停止：需教练/合格监督下掌握架位和技术；疼痛、失控或安全设施不足时不执行。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.439；Starting Strength 3e Ch2 The Squat。
[NORMAL_TEXT] 证据评价：E4有完整技术指导；多关节动作单位时间覆盖肌群较多。若目标是杠铃深蹲专项表现，专项性价值明显；不代表它对每个人的肌肥大都优于腿举。
[NORMAL_TEXT] 替换链：史密斯深蹲 → 腿举 → 高脚杯深蹲。
[NORMAL_TEXT] 29. 杠铃前蹲
[NORMAL_TEXT] 模式：膝主导；主肌：股四头肌、臀大肌；次肌：上背和躯干稳定肌；设备：杠铃、深蹲架。
[NORMAL_TEXT] 技术：前架位置稳定，肘部抬起，躯干保持受控。
[NORMAL_TEXT] 适用/停止：前架活动度或技术不足时不强行使用。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.441。
[NORMAL_TEXT] 证据评价：E4有技术依据；可作为不同躯干角度与负荷分布的蹲类变式，但直接证明其普遍优于后蹲的长期证据不足。
[NORMAL_TEXT] 替换链：杠铃后蹲 → 史密斯深蹲 → 腿举。
[NORMAL_TEXT] 30. 史密斯深蹲
[NORMAL_TEXT] 模式：膝主导；主肌：股四头肌、臀大肌；次肌：内收肌、躯干稳定肌；设备：史密斯机。
[NORMAL_TEXT] 技术：站位需适配固定轨迹；使用安全钩；不为迁就轨迹而扭曲关节位置。
[NORMAL_TEXT] 适用/停止：固定轨迹舒适且安全钩熟悉；轨迹不适配则替换。
[NORMAL_TEXT] 出处：Helms Training 2e Exercise Selection/机器与自由重量讨论；NSCA 5e Ch16 squat technique。
[NORMAL_TEXT] 证据评价：E1机器与自由重量肌肥大没有普遍差异；固定轨迹可降低平衡需求，但具体史密斯深蹲对比其他蹲类的优势未证实。
[NORMAL_TEXT] 替换链：杠铃后蹲 → 腿举 → 高脚杯深蹲。
[NORMAL_TEXT] 31. 倒蹬腿举
[NORMAL_TEXT] 模式：膝主导；主肌：股四头肌、臀大肌；次肌：内收肌；设备：已确认倒蹬腿举器械。
[NORMAL_TEXT] 技术：腰背贴靠垫，下降深度不引起骨盆明显卷曲，膝盖方向稳定。
[NORMAL_TEXT] 适用/停止：设备轨迹适配且无痛；髋膝不适或腰盆失控时缩小范围/停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.438 Hip Sled (Machine)；Helms Training 2e squat/leg press alternatives。
[NORMAL_TEXT] 证据评价：E4明确列出髋 sled/腿举；E1设备类别证据不支持机器天然低效。稳定性要求低、设置快，可能适合在有限时间内增加下肢训练量；但不能替代杠铃深蹲专项技术。
[NORMAL_TEXT] 替换链：史密斯深蹲 → 杠铃后蹲（目标专项时） → 高脚杯深蹲。
[NORMAL_TEXT] 32. 哑铃高脚杯深蹲
[NORMAL_TEXT] 模式：膝主导；主肌：股四头肌、臀大肌；次肌：核心和上背稳定肌；设备：哑铃。
[NORMAL_TEXT] 技术：负重靠近躯干，脚掌稳定，蹲起过程膝髋协调。
[NORMAL_TEXT] 适用/停止：可作为较易教学的蹲模式；哑铃重量或握持成为限制时换器械。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 squat principles；NSCA PTQ 2023基础动作教学。
[NORMAL_TEXT] 证据评价：E4支持基础蹲模式；对新手的技术学习成本可能较低，但可用负重上限受哑铃区限制。没有证据证明其比腿举/史密斯更有效。
[NORMAL_TEXT] 替换链：腿举 → 史密斯深蹲 → 杠铃后蹲（需监督）。
[NORMAL_TEXT] 33. 哑铃反向弓步
[NORMAL_TEXT] 模式：单侧/膝主导；主肌：股四头肌、臀大肌；次肌：内收肌、核心稳定肌；设备：哑铃、可用地面空间（空间尚未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：后撤步受控，前脚稳定，骨盆不明显摇摆。
[NORMAL_TEXT] 适用/停止：平衡不足先徒手并扶支撑；空间不足或膝髋疼痛时不排。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.447 reverse step lunge；Ch17 unilateral training。
[NORMAL_TEXT] 证据评价：E4动作依据；单侧训练可提供左右侧独立刺激，但单位训练时间较高，且平衡/空间成本需纳入效率判断。无证据证明它普遍优于双侧蹲。
[NORMAL_TEXT] 替换链：史密斯深蹲 → 腿举 → 分腿蹲（空间确认后）。
[NORMAL_TEXT] 34. 哑铃分腿蹲
[NORMAL_TEXT] 模式：单侧/膝主导；主肌：股四头肌、臀大肌；次肌：内收肌、核心稳定肌；设备：哑铃、地面空间（CONDITIONAL）。
[NORMAL_TEXT] 技术：双脚前后固定，垂直下降，前脚稳定。
[NORMAL_TEXT] 适用/停止：平衡不足先扶支撑；空间或平衡条件不满足时不排。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 unilateral training；NSCA PTQ 2023 fundamental movement progressions。
[NORMAL_TEXT] 证据评价：E4支持单侧模式；可处理单侧能力差异，但每侧分别完成带来时间成本。无直接证据证明比腿举更高效。
[NORMAL_TEXT] 替换链：腿举 → 史密斯深蹲。
[NORMAL_TEXT] 35. 坐姿腿伸展
[NORMAL_TEXT] 模式：膝伸展孤立；主肌：股四头肌；设备：已确认坐姿腿伸展器械。
[NORMAL_TEXT] 技术：膝关节轴与机器旋转轴对齐，控制活动范围和离心，不甩动配重。
[NORMAL_TEXT] 适用/停止：轴心无法适配或膝部不适时不使用。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.455。
[NORMAL_TEXT] 证据评价：E4明确列出；孤立训练能直接针对股四头肌，但单位时间刺激的肌群覆盖低于复合动作。适合作为补充，不是所有下肢训练的必需动作。机器本身不因“孤立”而低效，需看目标。
[NORMAL_TEXT] 替换链：腿举 → 史密斯深蹲。
[NORMAL_TEXT] F. 髋主导 / 后链
[NORMAL_TEXT] 36. 杠铃传统硬拉
[NORMAL_TEXT] 模式：髋主导/髋膝复合；主肌：臀大肌、腘绳肌、竖脊肌；次肌：股四头肌、背阔肌、握力肌群；设备：杠铃和安全地面空间。
[NORMAL_TEXT] 技术：杠铃贴近身体，脊柱位置稳定，起拉前建立躯干张力。
[NORMAL_TEXT] 适用/停止：技术要求较高，需合格指导；腰背不适或动作控制不足时停止并评估。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.452；Starting Strength 3e Ch4 Deadlift。
[NORMAL_TEXT] 证据评价：E4有完整技术依据；多关节、覆盖肌群多，但全身疲劳和技术成本也可能较高。若目标为硬拉专项力量，其特异性高；不自动成为所有后链训练的最高效率选项。
[NORMAL_TEXT] 替换链：杠铃RDL → 用户描述的髋铰链固定器械（待识别） → 臀桥（凳/地面配置确认后）。
[NORMAL_TEXT] 37. 杠铃罗马尼亚硬拉
[NORMAL_TEXT] 模式：髋主导/髋铰链；主肌：腘绳肌、臀大肌；次肌：竖脊肌、背阔肌稳定；设备：杠铃。
[NORMAL_TEXT] 技术：髋向后移动，膝微屈且角度相对稳定，杠铃沿腿部下行，脊柱受控。
[NORMAL_TEXT] 适用/停止：先掌握髋铰链；腰背不适或动作失控时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.454；Helms Training 2e hip hinge variants。
[NORMAL_TEXT] 证据评价：E4明确列出；可用相对简单的器械设置训练髋铰链与后链，但躯干等长负荷不可忽视。没有证据证明其普遍优于固定髋铰链器械。
[NORMAL_TEXT] 替换链：哑铃RDL → 用户描述的髋铰链固定器械（待识别）。
[NORMAL_TEXT] 38. 哑铃罗马尼亚硬拉
[NORMAL_TEXT] 模式：髋主导/髋铰链；主肌：腘绳肌、臀大肌；次肌：竖脊肌、背阔肌稳定；设备：哑铃。
[NORMAL_TEXT] 技术：哑铃贴近腿部，髋向后折叠，控制下降深度。
[NORMAL_TEXT] 适用/停止：适合负荷较轻或希望独立控制两侧者；握力先疲劳时需重新评估。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.454 RDL变式；Helms Training 2e hip hinge。
[NORMAL_TEXT] 证据评价：E4动作模式支持；较容易细调负荷，但拿放和握力限制可能影响时间效率。未证明比杠铃RDL更增肌。
[NORMAL_TEXT] 替换链：杠铃RDL → 用户描述的髋铰链固定器械（待识别）。
[NORMAL_TEXT] 39. 用户描述的可装片髋铰链固定器械
[NORMAL_TEXT] 模式：暂定髋主导/髋铰链；主肌/次肌：暂不最终锁定，需依据实际阻力臂、髋/躯干支点和运动轨迹核验；设备：用户确认的机器，臀后靠垫、前倾髋铰链、双手拉动可装片把手。
[NORMAL_TEXT] 技术：先核验设备说明、起始位、支点、阻力方向、安全限位和动作轨迹；不自行猜测品牌或常见商品名。
[NORMAL_TEXT] 适用/停止：设备身份和技术未核验前为PROVISIONAL，不得排入训练计划。
[NORMAL_TEXT] 出处：用户现场描述（仅证明设备外观/操作特征）；髋铰链生物力学需待设备核验后匹配NSCA/Helms相关章节。
[NORMAL_TEXT] 证据评价：当前无法给出效率或优劣评级；不允许根据“看起来像硬拉”推断其与传统硬拉等效。
[NORMAL_TEXT] 替换链：核验后再建立；暂不进入可执行替换链。
[NORMAL_TEXT] 40. 龙门架 Pull-through
[NORMAL_TEXT] 模式：髋主导/髋铰链；主肌：臀大肌、腘绳肌；次肌：躯干稳定肌；设备：龙门架低位滑轮、绳把（附件和滑轮位置未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：髋向后移动，站起时髋伸展，避免用手臂拉动。
[NORMAL_TEXT] 适用/停止：附件、低位滑轮和活动空间确认后才可用。
[NORMAL_TEXT] 出处：Helms Training 2e hip hinge/cable exercise selection；NSCA 5e Ch17 variable resistance。
[NORMAL_TEXT] 证据评价：E4动作模式依据；设置/占位成本可能高于杠铃RDL或固定器械。缺少直接证据证明其长期肌肥大优越。
[NORMAL_TEXT] 替换链：哑铃RDL → 杠铃RDL。
[NORMAL_TEXT] G. 髋外展/内收与手臂孤立
[NORMAL_TEXT] 41. 髋外展器械
[NORMAL_TEXT] 模式：髋外展孤立；主肌：臀中肌/臀小肌及髋外展肌群；设备：已确认髋外展/内收器械的外展配置。
[NORMAL_TEXT] 技术：座椅和活动范围适配，控制回程，不借躯干摆动。
[NORMAL_TEXT] 适用/停止：髋部疼痛或设备轴心不适配时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16运动模式/髋部肌群训练原则；NSCA 5e Ch18 exercise selection。具体器械未在动作目录单列，标记E4模式依据。
[NORMAL_TEXT] 证据评价：可作为髋外展肌群的局部补充；不应取代主要下肢复合训练。缺少与深蹲/腿举直接比较长期效果的证据。
[NORMAL_TEXT] 替换链：侧卧髋外展（地面空间/垫子确认后）。
[NORMAL_TEXT] 42. 髋内收器械
[NORMAL_TEXT] 模式：髋内收孤立；主肌：髋内收肌群；设备：已确认髋外展/内收器械的内收配置。
[NORMAL_TEXT] 技术：轴心位置适配，控制内收和回程，不使用弹震。
[NORMAL_TEXT] 适用/停止：腹股沟或髋部疼痛时停止并评估。
[NORMAL_TEXT] 出处：NSCA 5e Ch16/18髋部训练与动作选择原则；具体机器型号未核验。
[NORMAL_TEXT] 证据评价：作为内收肌局部训练有明确目标，但是否对当前目标有额外收益需要评估；缺少直接比较证明其普遍必要。
[NORMAL_TEXT] 替换链：其他髋部复合动作（目标肌群不同，替换前需重新核算）。
[NORMAL_TEXT] 43. 牧师椅哑铃/杠铃弯举
[NORMAL_TEXT] 模式：肘屈孤立；主肌：肱二头肌；次肌：肱肌、肱桡肌；设备：牧师椅、哑铃或杠铃（实际握杆/哑铃配置需确认）。
[NORMAL_TEXT] 技术：上臂支撑稳定，避免肩部前后摆动，控制离心。
[NORMAL_TEXT] 适用/停止：肘部不适或支撑角度不适配时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.426 barbell biceps curl；Helms Training 2e biceps isolation。
[NORMAL_TEXT] 证据评价：E4支持弯举类；支撑可限制身体借力，但没有证据证明牧师椅比所有站姿弯举更有效。局部刺激明确，时间效率低于复合拉动作。
[NORMAL_TEXT] 替换链：哑铃弯举 → 绳索弯举（附件确认后）。
[NORMAL_TEXT] 44. 哑铃锤式弯举
[NORMAL_TEXT] 模式：肘屈孤立；主肌：肱肌、肱桡肌，肱二头肌参与；设备：哑铃。
[NORMAL_TEXT] 技术：中立握，肘部稳定，避免身体摆动。
[NORMAL_TEXT] 适用/停止：肘腕疼痛时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.427 Hammer Curl。
[NORMAL_TEXT] 证据评价：E4明确列出；握法改变前臂/肘屈肌参与，但不证明其全面优于旋后弯举。适合作为肱肌/前臂屈肌补充。
[NORMAL_TEXT] 替换链：牧师椅弯举 → 常规哑铃弯举。
[NORMAL_TEXT] 45. 哑铃弯举
[NORMAL_TEXT] 模式：肘屈孤立；主肌：肱二头肌；次肌：肱肌、肱桡肌；设备：哑铃。
[NORMAL_TEXT] 技术：肘部位置稳定，避免躯干摆动，旋后动作可控。
[NORMAL_TEXT] 适用/停止：肘腕不适时调整握法或停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.426 biceps curl；Helms Training 2e isolation exercise selection。
[NORMAL_TEXT] 证据评价：E4动作依据；单关节补充，局部目标清楚但单位时间覆盖低。没有直接证据证明它优于牧师椅弯举。
[NORMAL_TEXT] 替换链：牧师椅弯举 → 锤式弯举。
[NORMAL_TEXT] 46. 龙门架弯举
[NORMAL_TEXT] 模式：肘屈孤立；主肌：肱二头肌；次肌：肱肌；设备：龙门架、低位滑轮和把手（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：上臂位置稳定，滑轮路径不拉扯肩肘，控制离心。
[NORMAL_TEXT] 适用/停止：确认附件和滑轮位置后才可用。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 variable resistance；Helms Training 2e biceps isolation。
[NORMAL_TEXT] 证据评价：E4阻力模式依据；可能提供不同阻力曲线，但缺少其优于哑铃/牧师椅的长期比较。设置时间须计入效率。
[NORMAL_TEXT] 替换链：牧师椅弯举 → 哑铃弯举。
[NORMAL_TEXT] 47. 龙门架肱三头下压
[NORMAL_TEXT] 模式：肘伸孤立；主肌：肱三头肌；设备：龙门架高位滑轮及直杆/绳把（附件未确认，CONDITIONAL）。
[NORMAL_TEXT] 技术：上臂相对稳定，肘关节完成伸展，避免肩部代偿。
[NORMAL_TEXT] 适用/停止：确认附件；肘部疼痛时停止。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.462 triceps pushdown machine；NSCA 5e Ch17 variable resistance。
[NORMAL_TEXT] 证据评价：E4有下压动作依据；局部刺激明确，适合作为推举后的补充；无证据证明绳索版本优于固定机器。
[NORMAL_TEXT] 替换链：哑铃肱三头伸展 → 其他已确认的肘伸动作。
[NORMAL_TEXT] 48. 哑铃仰卧肱三头伸展
[NORMAL_TEXT] 模式：肘伸孤立；主肌：肱三头肌（长头在肩屈位参与）；设备：哑铃、可调椅。
[NORMAL_TEXT] 技术：上臂位置稳定，肘部活动范围舒适，不强行追求极深拉伸。
[NORMAL_TEXT] 适用/停止：肘肩不适时停止或换动作。
[NORMAL_TEXT] 出处：NSCA 5e Ch16 p.461 lying barbell triceps extension（哑铃变式需标记为变式推导）；Helms Training 2e triceps isolation。
[NORMAL_TEXT] 证据评价：E4支持肱三头伸展动作类别；具体哑铃版本的直接比较证据不足。可作为局部补充，需考虑肘关节舒适度。
[NORMAL_TEXT] 替换链：绳索下压（附件确认后） → 固定器械/哑铃变式。
[NORMAL_TEXT] H. 核心与有氧
[NORMAL_TEXT] 49. 平板支撑
[NORMAL_TEXT] 模式：核心抗伸展；主肌：腹壁稳定肌群；设备：自重/地面空间。
[NORMAL_TEXT] 技术：头、躯干、骨盆保持整体，正常呼吸，不塌腰。
[NORMAL_TEXT] 适用/停止：肩腕不适时改前臂或高位支撑。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 core stability。
[NORMAL_TEXT] 证据评价：E4支持核心稳定训练；适合基础控制练习，但静态支撑不是腹肌肌肥大的唯一或普遍最佳方案。
[NORMAL_TEXT] 替换链：死虫 → 鸟狗（需按目标选择，不视为完全等效）。
[NORMAL_TEXT] 50. 死虫
[NORMAL_TEXT] 模式：核心抗伸展；主肌：躯干深层稳定肌；设备：自重/地面。
[NORMAL_TEXT] 技术：骨盆保持稳定，对侧手脚缓慢伸展，正常呼吸。
[NORMAL_TEXT] 适用/停止：腰盆控制不足时缩小范围。
[NORMAL_TEXT] 出处：NSCA 5e Ch17 core stability principles；具体动作需按该章教学原文复核。
[NORMAL_TEXT] 证据评价：E4模式依据；技术学习成本较低，适合控制训练；没有证据证明其比负重核心动作更有效增肌。
[NORMAL_TEXT] 替换链：平板支撑 → 鸟狗。
[NORMAL_TEXT] 51. 跑步机轻松跑/快走
[NORMAL_TEXT] 模式：有氧/跑步；主系统：心肺耐力、下肢反复周期性运动；设备：已确认跑步机。
[NORMAL_TEXT] 技术：速度从可对话强度开始，先确认设备急停和安全使用方法。
[NORMAL_TEXT] 适用/停止：仅作为经适龄安全评估后的轻松有氧选项；出现疼痛、眩晕或异常不适时停止。
[NORMAL_TEXT] 出处：Jeukendrup《运动营养》运动训练与能量代谢章节；并行训练证据需另行检索；本条不声称跑步机优于户外跑。
[NORMAL_TEXT] 证据评价：设备存在已确认；跑步机只是可控场地工具，不自动等于最有效跑步训练。跑步速度、坡度、设备上限未知。
[NORMAL_TEXT] 七、动作条目状态与当前可执行性
[NORMAL_TEXT] ACTIVE候选：明确匹配已确认设备且不依赖未确认附件/空间的动作。
[NORMAL_TEXT] CONDITIONAL：需要确认附件、空间、设备轨迹、安全保护或配重范围。
[NORMAL_TEXT] PROVISIONAL：设备身份或动作模式尚未识别，例如“坐姿反手下拉”机器的实际运动轨迹、用户描述的髋铰链固定器械。
[NORMAL_TEXT] 不得把CONDITIONAL/PROVISIONAL条目放入正式训练计划。库中保留这些条目是为了检索和核验，不代表当前可执行。
[NORMAL_TEXT] 八、YouTube/公开视频证据记录模板
[NORMAL_TEXT] video_evidence_id：
[NORMAL_TEXT] channel_or_author：
[NORMAL_TEXT] credential_verification：
[NORMAL_TEXT] video_title：
[NORMAL_TEXT] URL：
[NORMAL_TEXT] timestamp：
[NORMAL_TEXT] verbatim_claim_or_accurate_paraphrase：
[NORMAL_TEXT] claim_scope（动作技术/肌群刺激/时间效率/伤病风险/训练计划）：
[NORMAL_TEXT] studies_cited_by_creator：
[NORMAL_TEXT] conflict_of_interest：
[NORMAL_TEXT] evidence_grade（E5学者/专业人士；E6普通博主/个人经验）：
[NORMAL_TEXT] corroborating_or_conflicting_E1_E4_sources：
[NORMAL_TEXT] confidence_and_limitations：
[NORMAL_TEXT] 视频不是动作库入库的必需条件；不得为了凑齐来源而编造频道或视频。知名度不等于可信度，学术资历也不等于其每个观点都正确。观点必须回到其引用的原始研究核验。
[NORMAL_TEXT] 九、初始动作库统计
[NORMAL_TEXT] 当前版本列出51个动作/训练变式条目，其中：
[NORMAL_TEXT] - 明确设备依赖、可进入候选池的动作：需在具体训练计划生成前再过安全/技术和配件核验；
[NORMAL_TEXT] - CONDITIONAL：涉及未知绳索附件、空间或具体配置的条目；
[NORMAL_TEXT] - PROVISIONAL：用户描述的两台设备需进一步确认动作轨迹/型号；
[NORMAL_TEXT] - 跑步机轻松跑作为有氧条目单独管理。
[NORMAL_TEXT] 该数量是知识库候选条目数，不是系统只能使用的动作上限。后续检索九本书与新文献后可持续扩充，不得以51作为封闭动作菜单。
[NORMAL_TEXT] 十、主要来源与适用范围
[NORMAL_TEXT] 1. NSCA, Essentials of Strength Training and Conditioning, 5th ed., Ch16：
[NORMAL_TEXT]    - 背部：Bent-Over Row p.420；Pendlay Row p.421；One-Arm Dumbbell Row p.422；Lat Pulldown p.423；Seated Row p.424；Low-Pulley Seated Row p.425。
[NORMAL_TEXT]    - 肱二：Barbell Biceps Curl p.426；Hammer Curl p.427。
[NORMAL_TEXT]    - 胸：Flat Barbell Bench Press/Dumbbell Variation p.430；Incline Dumbbell/Barbell Variation p.432；Dumbbell Fly p.433；Vertical Chest Press Machine p.434；Pec Deck p.435。
[NORMAL_TEXT]    - 下肢：Hip Sled p.438；Back Squat p.439；Front Squat p.441；Zercher Squat p.443；Lunges pp.445–447；Step-Up p.449；Good Morning p.451；Deadlift p.452；Stiff-Leg Deadlift p.453；RDL p.454；Leg Extension p.455；Seated Leg Curl p.456。
[NORMAL_TEXT]    - 肩：Machine Shoulder Press p.457；Seated Barbell/Dumbbell Shoulder Press p.458；Lateral Shoulder Raise p.460。
[NORMAL_TEXT]    - 肱三：Lying Triceps Extension p.461；Triceps Pushdown p.462。
[NORMAL_TEXT]    注：目录页码证明动作被该书列入技术章节，不代表比较优越性。
[NORMAL_TEXT] 2. Starting Strength, 3rd ed., Ch2 Squat; Ch4 Deadlift; Ch5 Bench Press; Ch6 Press; Ch7 Chin-ups/Pull-ups and assistance exercises。
[NORMAL_TEXT] 3. Zatsiorsky, Science and Practice of Strength Training, 3rd ed., Ch6 Exercises Used for Strength Training。
[NORMAL_TEXT] 4. Schoenfeld, Science and Development of Muscle Hypertrophy, Ch3 exercise selection/planes of movement/ROM/variation；背部章节关于水平划船与背部不同平面训练的讨论。
[NORMAL_TEXT] 5. Helms et al., The Muscle and Strength Training Pyramid: Training, 2nd ed., exercise selection、水平/垂直推拉、髋铰链、动作替换和训练量重叠章节。
[NORMAL_TEXT] 6. Currier BS et al. 2026 ACSM Position Stand. DOI: 10.1249/MSS.0000000000003897. https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/ 。137篇系统综述、30,000+名健康成年人；纳入人群≥18岁，不能直接外推青少年处方。
[NORMAL_TEXT] 7. Haugen T et al. 2023. DOI: 10.1186/s13102-023-00713-4. https://pmc.ncbi.nlm.nih.gov/articles/PMC10426227/ 。机器与自由重量训练系统综述/Meta分析，未发现肌肥大有显著差异，力量测试有专项性；成年人证据。
[NORMAL_TEXT] 8. Iversen VM et al. 2021. DOI: 10.1007/s40279-021-01490-1. https://link.springer.com/content/pdf/10.1007/s40279-021-01490-1.pdf 。时间效率叙述性综述，支持多关节动作作为时间受限的优先候选；不是每种动作直接比较的试验。
[NORMAL_TEXT] 9. Kassiano W et al. 2022. DOI: 10.1519/JSC.0000000000004258. 系统综述纳入8项研究、241名年轻男性；适度系统变化可能有利，过度随机变化可能不利。样本范围有限。
[NORMAL_TEXT] 十一、每次决策前的全量重学机制
[NORMAL_TEXT] 每次规划、重排、动作替换或训练反馈决策前，重新从九本书原始全文检索相关章节并回读完整上下文、表格、图注和脚注；再检索最新立场声明、系统综述、Meta分析和必要的原始研究。按需检索相关章节并扩大到相关章节群，不要求无差别逐字重读所有书页。未读到的部分必须标“未核验”。每个动作决策都输出 evidence_manifest，记录文件版本、章节/页码/行范围、DOI/URL、全文状态、研究人群、结论、限制和冲突来源。
[NORMAL_TEXT] 十二、重要适用边界
[NORMAL_TEXT] 本知识库包含成人研究和成人训练教材。成人研究（包括ACSM 2026）不能直接转化为青少年个体化负荷、增肌或体重变化处方。系统应根据实际年龄、安全和合格监督条件调整输出；在不满足条件时只提供一般性运动教育与安全说明，不生成成人高负荷训练计划
[NORMAL_TEXT] 【v2.0.1 数据清理说明】
[NORMAL_TEXT] 动作库条目21与25描述的是用户确认的同一台“坐姿反手下拉（练背器械）”，不得作为两个独立动作计数。数据导入时应合并为同一个 canonical exercise_id，保留“坐姿反手下拉/反手坐姿背部下拉”作为待核验别名；实际动作模式仍须在现场确认轨迹后标注。因此本版原始条目行数为51，去重后的唯一动作/变式条目为50。该设备保持 PROVISIONAL，未核验运动轨迹前不得用于计划或证据排序。
[NORMAL_TEXT] 。