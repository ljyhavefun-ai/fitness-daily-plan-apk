[NORMAL_TEXT] ATI 目标导向训练规划系统 — 完整设计文档 v2.0
[NORMAL_TEXT] 版本：2.0 | 日期：2026-11-14 | 关联：ATI 自适应训练智能系统
[NORMAL_TEXT] 0. 版本纠错与问题定义
[NORMAL_TEXT] v1.0 的14项 CONTINUE、INCREASE_LOAD、MAINTAIN_LOAD、DECREASE_LOAD、EXTEND_REST、SHORTEN_REST、REDUCE_SETS、ADD_SET、SUBSTITUTE_EXERCISE、STOP_EXERCISE、STOP_SESSION、DELOAD、MODIFY_NEXT_SESSION、GATHER_INFORMATION，是 Decision Actions（决策动词），不是 Exercise（训练动作）。它们描述系统能做何种裁决，不构成训练动作清单。
[NORMAL_TEXT] v1.0 的真实缺陷是：决策动词词表与动作知识库没有分层；真实 Exercise Library 过窄；缺少按动作模式×目标肌群×器械的候选动作空间；用户历史被过度锚定；器械确认没有成为计划生成前置条件。用户曾经提过引体向上，不构成背部训练默认动作的证据。连续训练中背部总以引体向上起手，是历史锚定导致的错误。
[NORMAL_TEXT] v2.0 把以下对象分离：
[NORMAL_TEXT] A. Decision Vocabulary：系统可以采取的裁决类型。
[NORMAL_TEXT] B. Exercise Library：经过来源登记的动作条目与变式。
[NORMAL_TEXT] C. Equipment Snapshot：用户当前场地已确认的器械能力。
[NORMAL_TEXT] D. Selection Evidence：本次选择某动作而非同模式其他动作的理由。
[NORMAL_TEXT] E. Plan Version：待用户确认的计划版本。
[NORMAL_TEXT] 1. 设计目标与边界
[NORMAL_TEXT] 规划层负责目标解析、动作候选检索、器械约束过滤、动作组合、训练日分配、容量与周期安排、恢复约束和计划版本管理。ATI 实时层负责单组反馈后的即时调整。两者共享用户画像、Exercise Library、证据索引、反馈事件和同一个决策循环。
[NORMAL_TEXT] 保留两条架构原则：
[NORMAL_TEXT] 1) 只保留一个循环：目标/反馈 → 建上下文 → 检索原文 → 生成或调整 → 执行 → 反馈 → 更新。
[NORMAL_TEXT] 2) 软件按钮尽量少；复杂性放在模型理解、知识检索和证据推理，不把复杂性转嫁给用户。
[NORMAL_TEXT] 安全与年龄边界：目标字段可以记录用户自述的长期愿望，但年龄未知或属于青少年时，不能启用成人增肌/体重变化处方，也不能生成成人高负荷或极限训练方案。青少年配置应优先动作技能、全面体能、健康和合格监督。成人研究（包括 ACSM 2026）仅适用于其研究对象，不可直接外推至青少年。当前文档不根据用户愿望自动生成任何训练计划。
[NORMAL_TEXT] 2. 三层词表必须独立
[NORMAL_TEXT] 2.1 Decision Vocabulary（决策动词）
[NORMAL_TEXT] v1.0 的14项原样保留为动作裁决词表：
[NORMAL_TEXT] CONTINUE、INCREASE_LOAD、MAINTAIN_LOAD、DECREASE_LOAD、EXTEND_REST、SHORTEN_REST、REDUCE_SETS、ADD_SET、SUBSTITUTE_EXERCISE、STOP_EXERCISE、STOP_SESSION、DELOAD、MODIFY_NEXT_SESSION、GATHER_INFORMATION。
[NORMAL_TEXT] 可在未来增加决策动词，但只能表示系统裁决，不得混入具体动作名称。每个决策事件要有触发原因、影响范围、置信度、安全校验和是否需用户确认。
[NORMAL_TEXT] 2.2 Exercise Library（动作库）
[NORMAL_TEXT] 动作条目是具体动作/变式，例如杠铃俯身划船、胸托哑铃划船、坐姿器械划船、低位绳索划船、正握引体、辅助引体、高位下拉、绳索直臂下压。它们不能成为决策动词。
[NORMAL_TEXT] 动作条目可被一个或多个动作模式标签引用；同一动作的别名、握法和设备差异要用 variation_id 表示，不可制造重复动作计数。
[NORMAL_TEXT] 2.3 Equipment Capability（器械能力）
[NORMAL_TEXT] 器械不是动作，也不是用户偏好。每项设备必须有确认状态、可用范围、位置/附件、负重/配重信息和最后确认时间。器械未知不得默认为可用。
[NORMAL_TEXT] 3. 核心架构：候选召回—约束过滤—证据排序—用户确认
[NORMAL_TEXT] 模型不得从历史动作直接生成计划。它必须按如下流程工作：
[NORMAL_TEXT] Step 1：确认目标、训练史、时间、健康/技术约束。
[NORMAL_TEXT] Step 2：确认当前器械快照；没有快照则只问器械，不生成训练计划。
[NORMAL_TEXT] Step 3：按动作模式、目标肌群、器械能力从 Exercise Library 召回多个候选。
[NORMAL_TEXT] Step 4：先做硬过滤：设备是否确认、动作是否有来源、技术能力是否匹配、是否存在疼痛/安全限制。
[NORMAL_TEXT] Step 5：为每个剩余候选检索原书/论文证据。
[NORMAL_TEXT] Step 6：比较候选动作，而非只给首个命中项；说明选择理由与未选理由。
[NORMAL_TEXT] Step 7：检查近期动作历史的锚定风险和同肌群重复起手。
[NORMAL_TEXT] Step 8：形成计划草案、证据清单和差异视图。
[NORMAL_TEXT] Step 9：用户确认后计划才生效；器械或约束变化时重新校验。
[NORMAL_TEXT] Step 10：训练反馈进入同一个循环，更新下一次计划。
[NORMAL_TEXT] 候选排序可以考虑：目标适配、技术掌握、可用器械、动作稳定性、疲劳成本、时间成本、个人偏好、疼痛/不适反馈、近期重复度和证据适用性。排序权重由上下文推理，不把某一动作永久固定为第一名。安全和设备确认是硬门槛，不参与权重抵消。
[NORMAL_TEXT] 4. 动作模式×肌群×器械的组织方式
[NORMAL_TEXT] 一级动作模式：
[NORMAL_TEXT] - 水平推
[NORMAL_TEXT] - 垂直推
[NORMAL_TEXT] - 水平拉
[NORMAL_TEXT] - 垂直拉
[NORMAL_TEXT] - 膝主导
[NORMAL_TEXT] - 髋主导/髋铰链
[NORMAL_TEXT] - 单侧下肢与单侧上肢
[NORMAL_TEXT] - 核心稳定（抗伸展、抗旋转、抗侧屈、屈曲/伸展）
[NORMAL_TEXT] - 携重/步态稳定
[NORMAL_TEXT] 每个动作可以有多个标签。例如单臂哑铃划船同时属于水平拉、单侧、背部。标签不意味着重复计算训练组数。
[NORMAL_TEXT] 器械维度：
[NORMAL_TEXT] - 杠铃与杠铃附件
[NORMAL_TEXT] - 哑铃/壶铃
[NORMAL_TEXT] - 绳索/龙门架（高位、低位、双站/单站、附件）
[NORMAL_TEXT] - 固定器械（需逐台确认）
[NORMAL_TEXT] - 自重/引体杆
[NORMAL_TEXT] - 弹力带/悬吊
[NORMAL_TEXT] - 有氧器械
[NORMAL_TEXT] 每种设备可用性必须来自用户确认的 Equipment Snapshot。
[NORMAL_TEXT] 5. Exercise Library 数据字段
[NORMAL_TEXT] 每个动作至少具备：
[NORMAL_TEXT] exercise_id、canonical_name、aliases、variation_id、movement_patterns、primary_muscles、secondary_muscles、stabilizers、equipment_requirements、technique_cues、common_errors、skill_level、population_scope、contraindication_or_stop_conditions、fatigue_cost_profile、setup_time、space_requirement、evidence_sources、source_status、replacement_chain、last_reviewed_at、version。
[NORMAL_TEXT] 动作没有可核验出处，不得进入 active 状态；可以进入待核验队列，但不能被计划调用。来源必须指向书名、版本、章节/页码或论文 DOI；不确定页码就只写章节并标明页码未核验，不得虚构。
[NORMAL_TEXT] 6. 反锚定机制（强制）
[NORMAL_TEXT] 6.1 用户历史只是带权重证据。单次提及、单次训练记录、某天做过某动作，永远不能自动成为默认首选动作，也不能固化成模板。
[NORMAL_TEXT] 6.2 每次动作选择必须在 evidence_manifest 中记录：
[NORMAL_TEXT] - 选中的动作与 variation_id；
[NORMAL_TEXT] - 证据来源及其适用范围；
[NORMAL_TEXT] - 目标匹配原因；
[NORMAL_TEXT] - 技术/器械/时间约束；
[NORMAL_TEXT] - 为什么选择它而不是至少一个同模式替代候选；
[NORMAL_TEXT] - 用户历史在本次排序中实际起到的作用。
[NORMAL_TEXT] 6.3 如果唯一依据是“用户提过一次”，必须标记 EVIDENCE_INSUFFICIENT，并重新检索替代动作；不得开出计划。
[NORMAL_TEXT] 6.4 单次训练记录仅用于记录暴露和反馈，不得推断为偏好或技术熟练。
[NORMAL_TEXT] 6.5 连续多日同一肌群总以同一动作起手时，系统必须触发 ROTATION_REVIEW：主动检查是否有更适合的候选，说明继续使用或轮换的理由。轮换不是为了变化而变化；若动作最适配，可保留，但必须给出证据与约束理由。
[NORMAL_TEXT] 6.6 计划生成前执行历史锚定审计：检查动作出现频率、首动作频率、是否因为历史提及而获得不合理排序加权。
[NORMAL_TEXT] 7. 器械确认门槛（硬性前置条件）
[NORMAL_TEXT] 在有效 Equipment Snapshot 建立前，系统不得生成训练计划。第一次交互的首要输出必须是器械确认请求，不得先给计划、动作清单或默认训练日。
[NORMAL_TEXT] 确认项目：
[NORMAL_TEXT] A. 杠铃区：是否有标准杠铃、杠铃片、深蹲架/安全杠、卧推架/保护架、可调卧推凳、上斜凳、地面硬拉空间。
[NORMAL_TEXT] B. 哑铃区：最小/最大重量、重量递增档位、是否有可调凳。
[NORMAL_TEXT] C. 绳索区：龙门架/绳索站数量、是否双侧/单侧可调、高低滑轮、配重范围、常见附件（直杆、短杆、绳把、单把手）。
[NORMAL_TEXT] D. 固定器械：逐项确认腿举、哈克深蹲、史密斯机、胸推、肩推、蝴蝶机、坐姿划船、高位下拉、腿弯举、腿屈伸、提踵、臀推/臀外展、背伸展、辅助引体等。
[NORMAL_TEXT] E. 自重区：引体杆、双杠、俯卧撑支撑、悬吊/TRX、弹力带。
[NORMAL_TEXT] F. 有氧区：跑步机、椭圆机、动感单车、划船机、楼梯机、室内跑道。
[NORMAL_TEXT] G. 场地状态：高峰/低峰、拥挤程度、器械等待情况、可否占用两站龙门架、训练空间是否足够。
[NORMAL_TEXT] H. 其他：器械品牌/型号、是否有限制使用区域、用户是否熟悉设备操作。
[NORMAL_TEXT] 采集方式允许自然语言、逐项勾选或现场拍照后人工核验；不能把模糊照片识别结果当作已确认。对关键设备要明确回答“有/没有/不确定”。不确定=不可用。
[NORMAL_TEXT] 快照结构：
[NORMAL_TEXT] equipment_snapshot_id、version、confirmed_at、gym_location_label（可选）、equipment_items[]、capacity/range、attachments、availability_notes、crowding_profile、user_confirmation_source、confidence、expires_or_recheck_condition。
[NORMAL_TEXT] 设备变化、临时维修、器械被占用或换健身房时，触发重新校验。不能悄悄保留用不了的动作。
[NORMAL_TEXT] 8. 训练规划与动作组合
[NORMAL_TEXT] 计划只能从 Active Exercise Library 中选动作，且必须通过当前 Equipment Snapshot 硬过滤。
[NORMAL_TEXT] - 每个训练动作对应目标肌群、次要参与肌群和稳定肌群。
[NORMAL_TEXT] - 直接组、间接组分别记录；fractional set 仅作为估算模型，不能当成精确生理事实。
[NORMAL_TEXT] - 检查水平推/垂直推、水平拉/垂直拉、膝主导/髋主导的平衡与重叠。
[NORMAL_TEXT] - 同模式可用多种设备变式；优先选择与目标、技能、设备、恢复和时间最匹配的动作，不因用户曾提过某动作就优先。
[NORMAL_TEXT] - 动作选择要考虑训练顺序、局部疲劳、全身疲劳、关节反馈、器械等待和切换成本。
[NORMAL_TEXT] - 动作替换链只提供同模式候选，不代表机械等价；替换后重新计算肌群刺激、技术需求和疲劳成本。
[NORMAL_TEXT] 9. 训练分化与周期安排
[NORMAL_TEXT] 分化由可用天数、单次时间、动作技能、恢复、训练目标和器械可用性共同决定。全身、上下肢、推拉腿、混合分化只是候选结构，不是固定菜单。模型需比较至少两个合理结构，选择后说明为什么。
[NORMAL_TEXT] 容量从当前可承受水平起步，观察训练完成度、动作质量、睡眠、疼痛、精力与表现趋势；不使用固定“每周加10%”规则。成人研究中的组数建议不能直接套用于青少年。
[NORMAL_TEXT] 10. 计划生效与版本化
[NORMAL_TEXT] PlanVersion 状态：DRAFT → REVIEWED → USER_APPROVED → ACTIVE → SUPERSEDED。
[NORMAL_TEXT] 用户确认前，草案不得改变正式训练日历。
[NORMAL_TEXT] 每次更新展示：新增动作、删除动作、替换动作、训练日变化、容量变化、原因、证据与风险。
[NORMAL_TEXT] 器械快照变化时 PlanValidation 必须重新运行。无效动作从当前可执行计划中移除并要求重新规划，不静默替换。
[NORMAL_TEXT] 保留历史版本和差异日志。
[NORMAL_TEXT] 11. 统一循环与运行机制
[NORMAL_TEXT] 唯一循环：
[NORMAL_TEXT] 目标/反馈 → 构建上下文 → 检索原文与动作证据 → 候选召回 → 器械/安全硬过滤 → 比较与选择 → 生成计划草案/即时决策 → 用户确认（规划变更）→ 执行 → 反馈 → 更新。
[NORMAL_TEXT] 规划层与实时层是同一个智能体在不同时间尺度上的决策视角，不建立第二套互不相通的流程。软件仅负责：快照与版本、硬约束校验、证据来源完整性、事件日志、用户确认和执行状态；模型负责语义理解、检索、动作选择和解释。
[NORMAL_TEXT] 12. 全量重学与 evidence_manifest
[NORMAL_TEXT] 每次规划、每次调整、每次替换动作前，都必须重新检索九本书全文和最新相关文献的相关原文范围，并回读完整连续段落、表格、图注、脚注与适用限制。不是只依赖一次性摘要或旧的证据卡。
[NORMAL_TEXT] 工程上不要求每次逐字重读九本书全部约86,000行；而是按本次问题检索全文相关章节并扩大上下文，若问题跨章节则跨章节回读。没有读到的部分必须标未核验。
[NORMAL_TEXT] 每个动作选择都要在 evidence_manifest 中记录 source_id、edition、chapter、page_or_line_range、DOI/URL、full_text_status、population、claim_supported、limitations、retrieval_timestamp、source_hash。
[NORMAL_TEXT] 不能虚构页码、DOI、引用内容。若原文不支持某项技术细节，标记待核验，不得把教练常识冒充书中原话。
[NORMAL_TEXT] 13. 当前版本资料审读状态
[NORMAL_TEXT] 本次已从 Drive 成功取得九本书的完整 Markdown 正文响应，并对 NSCA 5e Ch16/17、Starting Strength 3e Ch5–7、Helms Training 2e 的动作分类、动作重叠和替换相关段落进行了重新定位与回读。NSCA 5e Ch16 的动作目录明确列出多项背部动作：Bent-Over Row、Pendlay Row、One-Arm Dumbbell Row、Lat Pulldown、Seated Row、Low-Pulley Seated Row；其页面标注分别为 pp.420–425。Helms Training 2e 对水平拉和垂直拉提供多种选择，并明确指出可按个人能力、偏好与设备可用性选择；其列出 cable、single-arm dumbbell、chest-supported、seal/bench 和 machine row，以及 pull-up/chin-up、lat pulldown、band-assisted pull-up 等选项。
[NORMAL_TEXT] 但本次并未逐字精读九本书全部全文，也未逐一核验所有动作的原始插图/视频。故动作库中来源明确的条目可进入“有来源候选”；对变式的细节和特殊禁忌，仍须按本次决策重新检索并验证。不能宣称九本书已全部精读。
[NORMAL_TEXT] 14. 下一阶段交付与器械输入
[NORMAL_TEXT] v2.0 文档先建立通用候选动作库，不假设用户所在健身房拥有任何器械。用户稍后提供的器械清单将形成 Equipment Snapshot v1；此后才允许筛选可用动作并制定计划。器械未确认时，唯一合法输出是器械确认请求或对系统设计的说明，不是训练计划。
[NORMAL_TEXT] 15. 主要依据
[NORMAL_TEXT] - NSCA. Essentials of Strength Training and Conditioning, 5th ed., Ch16 “Exercise Technique for Free Weight and Machine Training”, Ch17 “Exercise Technique for Alternative Modes and Nontraditional Implement Training”, Ch18 “Program Design for Resistance Training”。Ch16 动作目录：背部 pp.420–425；胸部 pp.430–435；下肢 pp.438–456；肩部 pp.457–460；三头 pp.461–462。
[NORMAL_TEXT] - Rippetoe M. Starting Strength: Basic Barbell Training, 3rd ed., Ch2 Squat, Ch4 Deadlift, Ch5 Bench Press, Ch6 Press, Ch7 Assistance Exercises / Chin-ups and Pull-ups。
[NORMAL_TEXT] - Zatsiorsky VM, Kraemer WJ, Fry AC. Science and Practice of Strength Training, 3rd ed., Ch6 Exercises Used for Strength Training。
[NORMAL_TEXT] - Schoenfeld BJ. Science and Development of Muscle Hypertrophy, Ch3 Role of Resistance Training Variables in Hypertrophy（Volume, Frequency, Load, Exercise Selection, Exercise Order, ROM, Effort）。
[NORMAL_TEXT] - Helms ER et al. The Muscle and Strength Training Pyramid: Training, 2nd ed., exercise selection, movement patterns, overlap, accessory exercise choice and substitutions.
[NORMAL_TEXT] - Renaissance Periodization. Scientific Principles of Strength Training, exercise variation, assistance work, fatigue management and stimulus-recovery-adaptation.
[NORMAL_TEXT] - Currier BS et al. 2026 ACSM Position Stand, DOI: 10.1249/MSS.0000000000003897. 137 systematic reviews, >30,000 adults; adults ≥18 only. https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/
[NORMAL_TEXT] - Pelland JC et al. 2026, The Resistance Training Dose Response, DOI: 10.1007/s40279-025-02344-w. 67 studies, 2,058 participants; direct/indirect set modeling and diminishing returns. https://pubmed.ncbi.nlm.nih.gov/41343037/
[NORMAL_TEXT] - NSCA PTQ 2023, Progressive Strategies for Teaching Fundamental Resistance Training Movement Patterns. https://www.nsca.com/contentassets/3d09f06f0b4c4f6fbd8cc382ed1f3d4a/ptq-10.2.1-progressive-strategies-for-teaching-fundamental-resistance-training-movement-patterns.pdf
[NORMAL_TEXT] 结论
[NORMAL_TEXT] v2.0 不再让“用户曾提过什么”决定“系统以后只会开什么动作”。系统先确认场地，再从有出处的动作库召回多个同模式候选，做硬约束过滤和证据比较，解释为什么选A而不是B，最后形成待确认计划
[NORMAL_TEXT] 【v2.0.1 设计修订：取消个人器械黑名单，证据驱动动作评价】
[NORMAL_TEXT] 一、明确作废的设计
[NORMAL_TEXT] - 作废“用户个人不用/不认可器械排除清单”及其更新机制。
[NORMAL_TEXT] - 用户已明确表示没有绝对不用的器械。不得再要求用户列出永久不用设备，也不得自行推断用户讨厌、拒绝或不会使用某设备。
[NORMAL_TEXT] - 用户对某动作的即时感受、疼痛、技术熟悉程度、训练时间和实际可达性仍是个体约束；但这些信息不等于该动作在科学上的优劣评价。
[NORMAL_TEXT] 二、评价权归属
[NORMAL_TEXT] 动作/器械的科学优劣由可追溯证据决定，不由助手主观偏好决定，也不由用户未验证的主观印象决定。用户目标、时间预算、设备可用性、技能水平和反馈决定“本次是否适合”，但不改写“文献如何评价”。
[NORMAL_TEXT] 动作库每个条目必须包含 Evidence Appraisal，至少记录：
[NORMAL_TEXT] - 目标结果：肌肥大、特定力量、运动表现、健康/功能；
[NORMAL_TEXT] - 文献支持的作用与局限；
[NORMAL_TEXT] - 是否有直接头对头比较；如无，明确“缺乏直接比较”；
[NORMAL_TEXT] - 刺激/时间效率、疲劳成本、技术学习成本和设置成本；
[NORMAL_TEXT] - 证据等级、适用人群、研究局限和冲突观点；
[NORMAL_TEXT] - 综合评级及理由。评级必须针对明确目标，不得给动作一个脱离目标的万能“好/坏”分数。
[NORMAL_TEXT] 三、证据层级
[NORMAL_TEXT] E1：立场声明、系统综述、Meta分析。
[NORMAL_TEXT] E2：长期随机对照训练研究或直接干预研究。
[NORMAL_TEXT] E3：机制、生物力学、肌电或急性研究；用于解释，不单独证明长期增肌优势。
[NORMAL_TEXT] E4：九本指定教材的完整章节与其参考文献；记录版本、章节、页码/行范围。教材观点应追溯其研究依据，并与更新研究并列核对。
[NORMAL_TEXT] E5：可核验学术/专业人士的公开视频或讲座。记录作者/频道、资历、标题、URL、时间戳、观点原文或准确转述、引用研究、利益冲突及可信度。它是补充解释，不与E1/E2等权。
[NORMAL_TEXT] E6：一般健身博主、论坛或个人案例，只能作为低可信度经验线索，不得独立决定动作评级。
[NORMAL_TEXT] 正反观点冲突时并列呈现，说明来源等级、研究设计、样本与适用边界；不得只挑支持某个动作的一方。视频内容未找到或未核验时，标记“未核验”，不得编造视频、频道或引语。
[NORMAL_TEXT] 四、效率不是主观印象
[NORMAL_TEXT] “效率”必须定义为目标收益与代价的关系，可分别估计：
[NORMAL_TEXT] - 目标肌群刺激/占用时间；
[NORMAL_TEXT] - 目标任务力量表现/训练时间；
[NORMAL_TEXT] - 训练刺激/全身与局部疲劳成本；
[NORMAL_TEXT] - 刺激/器械设置、等待和切换成本。
[NORMAL_TEXT] 没有直接比较证据时不得生成貌似精确的效率分数。ACSM 2026 与机器/自由重量系统综述未支持机器或自由重量存在普遍的肌肥大优越性；时间效率叙述性综述支持把多关节动作作为优先候选，但不意味着孤立动作无价值或每个复合动作都对所有肌群最好。
[NORMAL_TEXT] 五、器械约束与选择
[NORMAL_TEXT] 当前器械快照只定义可行域；证据定义动作评价；目标与约束决定本次选择。不存在用户个人永久排除清单。器械“已确认存在”不等于自动优先，也不等于证据评级高。用户若尚不熟悉某设备，系统可评估学习成本和安全条件，必要时先提供专业监督下的熟悉指导或选用更易掌握的动作，但不得将其永久拉黑。
[NORMAL_TEXT] 六、正式器械快照 ATI-EQ-1.1（用户已确认）
[NORMAL_TEXT] - 龙门架/绳索站；
[NORMAL_TEXT] - 高位下拉；
[NORMAL_TEXT] - 牧师椅；
[NORMAL_TEXT] - 卧推架；
[NORMAL_TEXT] - 史密斯机；
[NORMAL_TEXT] - 深蹲架；
[NORMAL_TEXT] - 坐姿划船；
[NORMAL_TEXT] - 坐姿反手下拉；
[NORMAL_TEXT] - 固定推肩器械；
[NORMAL_TEXT] - 固定推胸器械（平板、上斜）；
[NORMAL_TEXT] - 蝴蝶机；
[NORMAL_TEXT] - 倒蹬腿举；
[NORMAL_TEXT] - 坐姿腿伸展；
[NORMAL_TEXT] - 髋外展/内收器械；
[NORMAL_TEXT] - 髋主导/硬拉类固定器械：用户描述为臀部后方有靠垫、向前髋铰链、双手拉动可装杠铃片把手完成类似硬拉的动作。商品名、品牌、型号均未知，不得擅自命名；
[NORMAL_TEXT] - 哑铃（2.5 kg一档，最小/最大重量未知）；
[NORMAL_TEXT] - 杠铃（5 kg一档，空杆重量与最大负重未知）；
[NORMAL_TEXT] - 可调角度训练椅；
[NORMAL_TEXT] - 引体单杠；
[NORMAL_TEXT] - 跑步机。
[NORMAL_TEXT] 尚未确认的细节：绳索站数量、滑轮独立性、附件种类、配重范围；各机器具体型号；深蹲/卧推架安全杠和保护条件；哑铃与杠铃最大最小重量；跑步机数量、速度/坡度范围；场地拥挤度与携重走空间。不能自动假设这些细节。
[NORMAL_TEXT] 。