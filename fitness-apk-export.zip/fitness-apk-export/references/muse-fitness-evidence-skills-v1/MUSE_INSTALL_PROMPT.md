# 给 Muse 执行 AI 的接入指令（复制即可）

你正在改造既有全栈空间 `mei-ri-jian-shen-ji-hua`。我已提供一个 `muse-fitness-evidence-skills-v1` 目录，它包含九个可组合 Skills 和44条可核验原书证据。

**必须真正接入工作流，而不是仅把这些Markdown当宣传文案。**

## 第一步：只读审计
检查空间现有实际组件与22项服务端动作签名、训练常量 `TRAINING_PRINCIPLES_AND_RULES`、`evaluateRules`；校验计划 id1，会话 id1/id5，只读确认会话2/3/4仍不存在；读取Drive存档状态。不得启动播种、清库、覆盖或删除动作。不要碰其他空间。先列出哪些组件显示了AI建议及哪些动作允许改动目标。

## 第二步：配置Skills路由
- 所有涉及科学依据的回答先经过 `fitness-evidence-guardian`。
- 今日训练UI经过 `fitness-session-flow` + `fitness-rir-feedback`。
- 计划评估调用 `fitness-hypertrophy-programming`。
- 训练末尾复盘/下次建议的原书解释调用 `fitness-progressions` 与 `fitness-recovery`，但服务端原有 `evaluateRules` 先裁决。
- 饮食/补水文本调用 `fitness-nutrition`，不把历史用户设定变成普遍强制目标。
- 趋势页调用 `fitness-trend-analytics`，统计以 `getstats` 为准。
- 技术/刺痛相关文本调用 `fitness-technique-safety`，规则A永不被LLM推翻。

## 第三步：科学解释位置
在“训练原则”“建议卡查看依据”“下次训练建议”“趋势指标定义”提供**按需展开**的证据，不要在当前组主屏塞长文。每个内容单元显示：事实→服务端规则或科学原理→原书/章节位置→适用条件→不能推导什么。证据ID需要映射到 `references/claim-ledger.json`。

## 第四步：严格服务端边界
本包绝不替换现有A–G、RIR五档、2-for-2跨课判定、规则F至少6场门槛、orig/target/actual分层、accepted才改后续组、Drive路径与命名。`saveplan`不碰会话。建议卡证据部分可以丰富，但不自动改写其裁决状态；LLM只能润色或补充解释。

## 第五步：独立验证
建立完全隔离的测试夹具，运行 `tests/acceptance.md` 中的案例，特别是：100kg×8属于深蹲非末组；pending不能静默接受；RIR缺失不能自动补2；2-for-2必须跨连续两课；规则A跳过的组不能直达；8秒超时只能安全核验后重试。跑通后只报告真实通过项目，留存未通过项。

## 第六步：交付
输出修改文件/组件、实际调用Skills的路由点、所用证据ID列表、测试结果、没有改变的真实数据核对结果、无法验证的真机能力。不要宣称原始PDF所有页逐字复查完成；未核对的数字不用于自动训练调整。
