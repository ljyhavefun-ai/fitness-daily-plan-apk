# 每日健身计划｜原书驱动的 Muse Skills v1.0

本包是面向 Muse 空间 `mei-ri-jian-shen-ji-hua` 的**可移植 Skill 源码与验收规范**，不包含用户原书的正文复制件，也没有修改现有 Muse 生产数据库或用户 Google Drive 中的书籍。

## 包内内容

|Skill|主要职责|
|---|---|
|`fitness-evidence-guardian`|九书证据引用、适用性校验、来源冲突与裁决边界|
|`fitness-session-flow`|训练记录、休息、建议卡、失败恢复与单屏引导|
|`fitness-hypertrophy-programming`|增肌频率、负荷、组数、组间休息和动作顺序|
|`fitness-rir-feedback`|RIR、实际结果与主观反馈拆分、缺失值处理|
|`fitness-progressions`|2-for-2跨训练课、下次进阶与减载边界|
|`fitness-recovery`|疲劳、恢复、警示与长期趋势|
|`fitness-nutrition`|均衡营养、补水、训练前后营养与书籍年代限制|
|`fitness-trend-analytics`|统计分母、训练量与估算1RM语义|
|`fitness-technique-safety`|动作质量与场地安全提示|

核心文档：
- `references/source-registry.md`：9 个 Drive 文件、版本和原文件链接。
- `references/evidence-ledger.md`：44 条逐条定位的证据命题和边界。
- `references/claim-ledger.json`：供 Muse 执行 AI 读取的结构化命题。
- `references/conflict-matrix.md`：教材之间与现有 A–G 规则之间的差异处理。
- `MUSE_INSTALL_PROMPT.md`：粘贴给 Muse 执行 AI 的接入提示词。
- `tests/acceptance.md`：逐项可观察验收脚本。
- `schemas/evidence-response.schema.json`：建议与科学依据的结构契约。

## 全书研读状态说明

已从 Google Drive `运动书籍` 文件夹下载并提取 9 个文件的可读文本（PDF、EPUB）。对与本空间密切相关的章节做了关键词定位、上下文复核及代表性表格截图检查。**这不等于已经逐字人工核验数千页正文中的每一张表和全部参考文献。**账本只允许使用已具备明确位置的命题；其余必须后续核对后才能进入自动说明或规则解释。

本包不提供原著全文、课本大段复刻或受版权保护的表格/图片；只提供原创的应用设计、条件与短篇科学解释。只有原始 Drive 文件仍对 Muse 的执行环境可读时，执行 AI 才能再次打开原书复核。

## 生产接入顺序
1. 先只读检查 Muse 22 个动作和真实会话 id1、id5、计划 id1。
2. 将本包9个目录作为独立可组合 Skills 引入 Muse；若 Muse 不支持原生 Skill 目录，则把 `SKILL.md` 作为知识规则模块加载，并通过 `MUSE_INSTALL_PROMPT.md` 指定路由。
3. 执行 AI 必须核对证据、调用服务端 `evaluateRules`；资料层不得重写 A–G。
4. 测试只用隔离夹具，不运行 `seedinitialdata`，不恢复会话 2–4。
5. 通过 `tests/acceptance.md` 后，再考虑将技能解释组件挂在相应页面。

## 不可做
- 不改他人空间、不删除/覆盖真实数据或原始 Drive 书籍。
- 不登录任何盗版网站、不额外下载原书。
- 不把书中成人健美、力量举或赛事营养例子直接作为个人强制训练或饮食处方。
- 不声称这些 Skills 已经**部署**到 Muse：本交付是可导入包，需由 Muse 端实际安装和验证。
