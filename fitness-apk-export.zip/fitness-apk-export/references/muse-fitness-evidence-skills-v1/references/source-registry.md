# 来源登记簿（仅供连接原始 Google Drive 文件的执行 AI 核验）

以下是原书文件，**不是本套 Skills 的再分发素材**。所有 Skill 只提供原创摘要、判断流程与定位，不复制书籍正文/表格/插图。

|标识|书籍（原文件版本）|格式|原始 Drive 链接|审查定位|
|---|---|---|---|---|
|N5|Essentials of Strength Training and Conditioning, 5th ed.|PDF|[原文件](https://drive.google.com/file/d/1hhAeTeWT8mkCfpCpJ_Fm0x6ifZuwu1Cg/view)|Chapter 18, 7, 23, 24|
|HTr|The Muscle and Strength Pyramid: Training, 2nd ed. (2019)|PDF|[原文件](https://drive.google.com/file/d/1qiXrf0jQj9b0n30Pq9IJnqfWLCPyTnqS/view)|Volume, Intensity, Frequency; Rest; Programs|
|HNu|The Muscle and Strength Pyramid: Nutrition, 2nd ed. (2018)|PDF|[原文件](https://drive.google.com/file/d/1LuN1BdoS5sNVRL4m_mneBXnC-ptP76ln/view)|Energy Balance; Macros; Hydration; Timing|
|Sch|Science and Development of Muscle Hypertrophy (2016)|EPUB|[原文件](https://drive.google.com/file/d/1kaPnMe56Ewi-cLzz5NtG5jmiNsPEYTgz/view)|Chapters 3, 4, 6, 7|
|Zat|Science and Practice of Strength Training, 3rd ed. (2021)|PDF|[原文件](https://drive.google.com/file/d/1n7xE6IklAFyic5SaDm47XRI9_8I7ggQO/view)|Chapters 4, 8–11|
|RP|Scientific Principles of Strength Training (Renaissance Periodization)|PDF|[原文件](https://drive.google.com/file/d/1gCFzHrTrMPgJC70s8H6V29spco0A9XAP/view)|Specificity, Overload, Fatigue, SRA, Individual Difference|
|RPdup|Scientific Principles of Strength Training (second Drive file; apparent duplicate)|PDF|[原文件](https://drive.google.com/file/d/1TMBh8r7Igj_-ayqoeYdGoJpDzHoR0kfj/view)|Parallel edition; check against RP|
|SS|Starting Strength: Basic Barbell Training, 3rd ed. (2011)|EPUB|[原文件](https://drive.google.com/file/d/1szzIxP6QqhBS58jDR4NwuudedzjNGgFc/view)|Chapter 2, Chapter 8|
|SN|Sport Nutrition: An Introduction to Energy Production and Performance, 2nd ed. (2010)|PDF|[原文件](https://drive.google.com/file/d/1bSkNV7rxmRHeq_g6422RR8PaH8KFuPYw/view)|Protein/Amino Acids; Water Requirements|

## 已核对的版本与限制
- NSCA：PDF 标注 Fifth Edition，PDF 实际 1876 页；来源文献与正文定位采用**PDF 物理页码**，不等同书内印刷页码。
- Helms 训练版：第二版，PDF 版权页标注 2019。营养版：第二版，PDF 标注版权 2018。
- Schoenfeld：EPUB 版权页标注 2016；引用用 EPUB 章节/内部 HTML 段落序号，**不伪造印刷页码**。
- Starting Strength：EPUB 第三版，版权 2011；EPUB 内部文件非自然阅读顺序，引用按章名，不虚构页码。
- Zatsiorsky：第三版，版权/出版信息 2021。
- RP：两个 Drive PDF 标题略不同但封面与目录高度相同；暂时作为同书重复来源处理，不能作为两项独立研究相互验证。
- Sport Nutrition：第二版版权 2010；部分章节围绕耐力、高温比赛人群，不能直接成为日常训练的刚性水/能量处方。

## 研读方法与诚实边界
原始文件已完成批量文本提取与目录索引，重点主题对应章节逐段抽样、交叉比对并核验数值。由于总计数千页、部分表格为图形或布局复杂，**不得宣称已人工逐字验证所有页、每张图或每个实验原表**。本次 Skill 只把已明确定位且检查过上下文的命题列为可用证据；其余列待核验。
PDF 页码见 `claim-ledger.json`；EPUB 使用章节和小节位置，建议执行 AI 再次打开对应书内位置复核。