---
name: fitness-session-flow
description: 移动端训练会话一步一屏流程、请求恢复、休息计时与建议反馈的可靠交互。
---

# Muse 训练进行中引导

## 适用页面
今日页四类状态：未开始、训练中、休息中、已完成。首屏始终显示“现在在哪／刚完成什么／下一步”。

## 状态协议
`PLAN_PREVIEW → SESSION_STARTING → SET_READY → SET_SUBMITTING → REST_ACTIVE → REST_READY → SET_READY → SESSION_COMPLETING → SUMMARY_READY`。并行子状态：`FEEDBACK_OPTIONAL`、`PROPOSAL_PENDING`、`SAFETY_BLOCKED`、`REQUEST_UNCERTAIN`。休息到时自动亮起下一组，但**不能自动认为已经开始/完成下一组**。

## 服务端动作绑定（不得更改原有语义）
|操作|动作|成功反馈|下一阶段|
|---|---|---|---|
|展开今日|`getday`|计划+当前会话版本|按服务端状态恢复|
|开始|`startsession`|创建会话、保存 orig 快照|第一组准备|
|按目标完成|`logset`|实际值、已保存、下一组预告|休息|
|有差异/反馈|`logset` 后按契约调用 `submitfeedback`|先记录再反馈，禁止重复写组|休息/建议|
|快速继续|`submitfeedback(quickContinue=true)`|反馈已保存，后续目标未变|正常推进|
|接受建议|`respondproposal(accept=true)`|列出实际 diff 并显示撤销|返回训练|
|忽略建议|`respondproposal(accept=false)`|不改目标|返回训练|
|撤销|`undoproposal`|恢复前后具体字段|返回训练|
|跨动作警示确认|`acknowledgealert`|已知晓，不代表风险消失|按当前阻断规则|
|结束|`finishsession`|完整总结|已完成|
|上传|`uploadtodrive` + `recorddriveupload`|状态同步、真实文件名|总结存档|

## 记录流程的三条不同语义
1. `按目标完成`：仅当实际输入与目标**完全一致**，并且用户明确确认无异常；如果既有快捷逻辑默认 RIR=2，按钮文案/说明必须预先告知。不能推定真实 RIR 一定等于2。参考 `E12,E13`。
2. `记录其他情况`：重量、次数不一致或动作/关节异常，按实际填写；允许独立提交客观值及选择反馈。
3. `仅记录，跳过感受`：主观字段保持 `null`，摘要显示“未填感受”，不能把 null 自动转 0 或 2。

## 最小屏幕信息
准备组：组别、动作、目标重量/次数、步进器、当前训练进度、下一步。
休息中：刚完成数据、服务端时间戳校准的倒计时、下组预告、可选反馈。页面切后台后通过实时时刻恢复，不保证后台提醒准时。
已完成：结算摘要、调整/未处理建议分离、日志存档入口。

## 异步防重复
所有写入 `idle → pending → success / failed / uncertain`。8秒尚未返回，显示“正在确认是否保存”并查服务端；不能盲重试。`logset/startsession/finishsession/uploadtodrive/respondproposal` 必须通过现有唯一组ID/会话ID及服务端幂等保护或读后核验保证不重复。成功才推进。

## 建议生命周期
服务端 `pending/accepted/dismissed/undone` 四值不修改。前端可衍生 `expired_in_ui`：作用组全部完成、原数据更正或新裁决冲突后显示“未处理且已失效”；**不静默调用 dismiss，也不再提供直接接受**。`appliedNote` 仅在真 diff 且accepted有效时显示。

## 操作安全
规则 A 是最高优先级警示。服务端已确认跳过的组从当前流移除，不能用“下一组”绕开；反馈填错必须走更正→核验→撤销→恢复。不得对正在进行的会话运行删除或重建。[E05,E32]

## 验收脚本
深蹲 60×5→120秒休息→65秒提前结束；80×5接受休息240→300秒；100×8 快速继续不得生成建议；80×8 未填感受必须显示；RDL第三组目标重量空，快捷设置；弯举第2组异常停止；最后一组进入总结。对每一步断言主屏文案与后端是否发生字段变化。
