---
name: fitness-evidence-guardian
description: 训练科学证据治理、书籍定位与矛盾裁决，禁止将书中示例误写成用户强制处方。
---

# Muse 健身证据守门员

## 触发
所有涉及训练计划、体能趋势、反馈裁决说明、营养、恢复、估算 1RM、动作安全的生成内容，必须先运行本 Skill；非训练业务（存档上传、页签切换）不必每次查原书。

## 前提材料
- `../../references/source-registry.md`：9 个原文件，8 类主要著作（RP 文件高度相似，不重复计数）。
- `../../references/evidence-ledger.md` 与 `claim-ledger.json`：44 条经定位的原创命题、使用边界、适用位置。
- Muse 已存在的 `TRAINING_PRINCIPLES_AND_RULES` 和 `evaluateRules`：**生产裁决唯一事实来源**。

## 强制执行顺序
1. 识别问题类型 `training_plan / session_feedback / recovery / nutrition / statistics / technique`。
2. 提取数据事实：计划快照 `orig*`、已确认目标 `target*`、完成值 `actual*`、RIR 原始值、反馈来源、是否缺失、相邻训练课历史。
3. 先问：来源证据是否适用于该目标、人群、经验、动作和时间尺度？例如 RP 力量举方法不能自动变成所有人的增肌方法；2010 年运动营养章节不是2026年最新推荐。
4. 仅从账本选证据 ID，并打开原文对应章节核对**完整上下文、限定条件、表格注释与页码类型**。只核对标题或关键词不合格。
5. 分开输出四类信息：`observed_fact`（真实日志）、`source_supported`（原书解释）、`application_policy`（Muse 既定 A–G）、`uncertainty`（数据缺失/来源不适用）。
6. 涉及训练目标改写时，**先调现有服务端 evaluateRules / respondproposal**。资料引擎只能生成旁注，绝不以自己的结论代替裁决。
7. 如果上下文不足，执行 `evidence_status=insufficient`，精确说明缺少哪个字段或页码；不能“自信猜测”。

## 证据置信标记
- `SOURCE_VERIFIED`：原文相关章节、数据表注释及适用对象已经查看，定位可复核。
- `SOURCE_LIMITED`：仅能确认一部分上下文或适用条件受限，允许解释但不能升格成自动决策。
- `SOURCE_UNVERIFIED`：仅标题、二手转述、无效页码或未读原文；不得声称原书支持。
- `SYSTEM_POLICY`：用户约束或 Muse 固定规则，**不得冒充“原书已经证明”**。

## 矛盾处理，不允许抹平
- `E03` 传统增肌范围（NSCA）与 `E10/E19` 可在更宽负荷区间增肌不是互斥：一个是典型模板，另一个是负荷适用范围的补充；显示“典型模板，不是硬性阈值”。
- `E07` NSCA 的多关节/单关节休息指南与 `E15/E20` Helms/Schoenfeld 的维持后续表现讨论，适用层级不同；不能声称“唯有90秒才能长肌肉”。
- `E04` 2-for-2 是跨**连续两次训练课末组**，`E05` 又指出技术缺口，因此“满足次数”≠“立即自动加重”。
- `E35` 增肌阶段与 `E40` 减脂阶段蛋白范围不同；只展示相关阶段的内容，且非对所有年龄的强制目标。
- RP 特异性 `E24` 明确是偏力量举；用户项目若是一般健身，不套整套力量举周期。

## 输出对象契约
```json
{
  "decision_context":"仅供解释/建议/统计，不改变服务端裁决",
  "observed_fact":[],
  "evidence":[{"id":"E04","scope":"跨训练课末组","source_status":"SOURCE_VERIFIED"}],
  "policy":{"rule_id":"服务端返回值或null","authority":"server"},
  "applicability":{"result":"applicable|limited|not_applicable","reason":"明确原因"},
  "limitations":[],
  "user_facing_copy":"简短、清楚、无绝对化宣传"
}
```

## 禁止
不得搬运原书长篇内容、整表或插图；不得把练后评分当医学诊断；不得推荐危险极限测试；不得擅自写入体重或热量约束；不得因为书中高阶运动员样例而鼓励增加训练频次。Source IDs 是*证据定位*，不是新服务端动作。

## 验收
- 原文/系统规则分列并标注。[E03,E04,E05,E07,E19,E20,E24,E35,E40]
- 一个非末组超额记录，不得输出“2-for-2已满足”。
- 找不到原文页码则输出`SOURCE_UNVERIFIED`，禁止捏造页码。
