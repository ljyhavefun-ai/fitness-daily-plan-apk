# ATI 共享知识库 — 全文检索与证据登记规范 v1.0

> 本文件为 ChatGPT 于 2026-11-14 制作的配套文档原文整理。原始 Google Doc：https://docs.google.com/document/d/1GB-T5u3Vc11TR7Ig-OdqOfQfB7JFVpHLqL1WbxpjA8U/edit?usp=drivesdk（Drive 文件夹「ATI 目标导向规划系统」）。

## 一、知识库目标

ATI Planner 与 ATI 实时决策引擎共享唯一知识库。知识库不只是摘要集合，而是能够定位原始全文、章节、页码、表格、图注、脚注和引用研究的证据系统。

## 二、九本原始书籍清单

1. NSCA-Essentials-5th-ed.md
2. Starting-Strength-3rd-ed.md
3. Zatsiorsky-3rd-ed.md
4. Schoenfeld-Hypertrophy-1st-ed.md
5. RP-Strength-Training.md
6. RP-Strength-Powerlifting.md
7. Helms-Training-2nd-ed.md
8. Helms-Nutrition-v2.md
9. Jeukendrup-Sport-Nutrition-2nd-ed.md
原始文件存放于 Google Drive「运动书籍」文件夹。原文件保持只读，不覆盖、不重命名。

## 三、每次决策前的全文检索与回读

"全量重学"在工程上应定义为：每次决策都从原始全文重新检索并回读本次问题所需的完整证据范围，而不是只依赖过去生成的摘要。不能将每次逐字重读全部九本书作为硬要求；这会制造大量无关上下文，增加成本且降低检索质量。

执行步骤：
1. 解析决策问题及其变量。
2. 检索九本书的章节索引和全文。
3. 定位相关章节，回读完整连续段落、上下文、表格和图注。
4. 需要跨章节推理时，扩大回读范围。
5. 对关键结论追溯原书引用的研究。
6. 联网检索最新立场声明、系统综述、Meta分析和原始研究。
7. 尽可能阅读论文全文；若只能访问摘要，标记摘要级证据。
8. 对原始图表无法读取的内容，标记未核验并回到原始 PDF/EPUB。
9. 生成本次 evidence_manifest，关联到训练计划版本或实时决策事件。
10. 下次决策必须重新执行检索，不允许只复用旧摘要。

## 四、证据卡字段

- evidence_id
- source_type（教材/立场声明/系统综述/Meta分析/随机对照研究/观察研究）
- title
- authors
- year
- DOI_or_URL
- edition
- chapter
- page_or_line_range
- original_excerpt_or_table_id
- full_text_status（全文已读/部分全文/摘要/无法访问）
- population
- intervention_or_question
- outcome
- conclusion
- limitations
- applicability_to_user
- conflicting_evidence
- retrieval_timestamp
- source_version_hash

## 五、证据等级与解释

证据等级不是简单排序按钮。模型应结合研究设计、偏倚风险、样本规模、研究人群、干预时长、结果一致性和用户适用性判断。
- 立场声明/系统综述/Meta分析：提供总体证据图景，但需要查看纳入研究和局限。
- 随机对照研究：用于补充特定人群或变量的直接证据。
- 教材：提供机制、技术、训练理论和实践框架；注意版本日期。
- 教练经验：可作为实践假设，不得伪装成高等级科学证据。

## 六、版本管理

每个原始文件保存：
- source_id
- title
- edition
- drive_file_id
- modified_time
- content_hash
- chapter_index_version
- ingestion_time
- parsing_quality
- figure_table_coverage
原文发生变化时创建新版本，不覆盖旧证据。每次决策的证据清单固定到当时的来源版本，保证可追溯。

## 七、研究证据登记示例

1. Currier BS et al. 2026. ACSM Position Stand: Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults. DOI: 10.1249/MSS.0000000000003897. https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/
- 状态：全文页面已读取主要方法、纳入标准、结果与讨论关键段落；全文其余部分需按具体问题再次检索。
- 适用边界：研究纳入健康成年人≥18岁，不能直接作为青少年训练处方。
2. Pelland JC et al. 2026. The Resistance Training Dose Response: Meta-Regressions Exploring the Effects of Weekly Volume and Frequency on Muscle Hypertrophy and Strength Gains. DOI: 10.1007/s40279-025-02344-w. https://pubmed.ncbi.nlm.nih.gov/41343037/
- 状态：PubMed 完整页面摘要、方法、结果和参考文献入口已读取；Springer 论文全文未完整获取。
- 核心主题：直接/间接组数、fractional set、训练容量与频率的剂量反应及递减收益。
3. AAP. Resistance Training for Children and Adolescents. Pediatrics. 2020;145(6):e20201011. Reaffirmed 2024. https://publications.aap.org/pediatrics/article/145/6/e20201011/76942/Resistance-Training-for-Children-and-Adolescents
- 状态：官方摘要/页面信息可访问，全文页面受到验证限制，需后续补读。
4. Held et al. 2026. Maximizing Adaptations in Concurrent Training: An Umbrella Review of Meta-analyses. https://pubmed.ncbi.nlm.nih.gov/41762427/
- 状态：检索结果摘要已读取，需按具体并行训练问题回读全文。

## 八、禁止事项

- 不得把摘要说成全文。
- 不得把检索片段说成完整章节。
- 不得忽略适用人群。
- 不得将研究中的 fractional set 系数视为生理常数。
- 不得只保留结论而丢失限制条件。
- 不得让模型输出虚构页码、原文或 DOI。
- 不得把一次检索形成的摘要当作永久知识替代原文。
- 不得用成人研究直接覆盖青少年训练安全指南。

## 九、推荐实现

采用"全文文件仓 + 章节索引 + 段落级检索 + 证据卡 + 每次决策 evidence_manifest + 版本锁定"的结构。
全文文件是唯一原始事实来源；证据卡是导航和解释层，不是原文替代品。
每次 ATI 决策都附 evidence_manifest_id，能反查具体文件版本、章节、段落范围和论文全文状态。
